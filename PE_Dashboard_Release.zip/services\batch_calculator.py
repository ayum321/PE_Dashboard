"""
Ctrl-M batch analytics — extracted from app_v2.py and decoupled from
Streamlit. Pure pandas/numpy, no globals, no `st.cache_data`.

Public API:
    load_ctrlm_bytes(raw: bytes, filename: str) -> pandas.DataFrame
    compute_metrics(df: pandas.DataFrame)        -> dict
    build_top_jobs_df(df: pandas.DataFrame)      -> pandas.DataFrame
    build_batch_payload(df: pandas.DataFrame)    -> dict   (JSON-ready)

The original thresholds, groupings and classification rules are
preserved verbatim from `app_v2.py`:
    - DAILY_LIMIT_HRS   = 6.0
    - MONTHLY_LIMIT_HRS = 8.0
    - Buffer bands: BREACH < 0, CRITICAL < 10, CAUTION < 30, HEALTHY < 50, EXCELLENT
    - At-risk band: buffer_pct in [0, 15]
    - F6 z-score anomaly threshold: |z| > 2.0
"""
from __future__ import annotations

import difflib
import io
import logging
import os
import re
from typing import Any, Dict

import numpy as np
import pandas as pd

from services import pe_config

logger = logging.getLogger("pe_dashboard.batch_calculator")


# ── Constants (mirror app_v2.py) ────────────────────────────────
DAILY_LIMIT_HRS: float = 6.0
MONTHLY_LIMIT_HRS: float = 8.0


# ─────────────────────────────────────────────────────────────────
# RULE 3 — normalise_ctrlm_csv (call immediately after pd.read_csv)
# ─────────────────────────────────────────────────────────────────
def normalise_ctrlm_csv(df: pd.DataFrame) -> pd.DataFrame:
    """
    Rule 3 — Call immediately after pd.read_csv() / pd.read_excel().

    Normalises the Status column so downstream code sees only "OK" or "FAILED".
    Handles all Ctrl-M completion status variants:
        ENDED OK, Ended Ok, ended ok, ENDED_OK, COMPLETED, SUCCESS, DONE → OK
        ABENDED, FAILED, TERMINATED, <blank>           → FAILED

    Never mutates the original DataFrame — always returns a copy.
    """
    if df is None or df.empty or "Status" not in df.columns:
        return df

    try:
        from services.pe_utils import SUCCESS_STATUSES, _normalise_status_str

        def _norm(raw: str) -> str:
            cleaned = _normalise_status_str(str(raw))
            return "OK" if cleaned in SUCCESS_STATUSES else "FAILED"

        df = df.copy()
        df["Status"] = df["Status"].fillna("").astype(str).apply(_norm)
    except Exception:
        # Non-fatal: keep Status as-is if pe_utils unavailable
        pass
    return df


# ─────────────────────────────────────────────────────────────────
# Ctrl-M file loader (extracted verbatim from app_v2.py:1644)
# ─────────────────────────────────────────────────────────────────
def _parse_duration_str(s: str) -> float:
    """Parse human-readable duration to seconds.

    Handles: '2hr 21min', '1h 30m', '01:30:00', '5400', '90' (assumes secs).
    """
    sv = str(s).strip()
    # "2hr 21min" / "2h 21m" / "2 hours 21 minutes"
    m = re.match(r"(\d+)\s*h[r]?[s]?\s*(\d+)\s*m", sv, re.I)
    if m:
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60
    m = re.match(r"(\d+)\s*h[r]?[s]?$", sv, re.I)
    if m:
        return int(m.group(1)) * 3600
    m = re.match(r"(\d+)\s*m[in]?[s]?$", sv, re.I)
    if m:
        return int(m.group(1)) * 60
    # "01:30:00" HH:MM:SS
    m = re.match(r"(\d+):(\d+):(\d+)$", sv)
    if m:
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
    # "01:30" — treat as HH:MM
    m = re.match(r"(\d+):(\d+)$", sv)
    if m:
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60
    try:
        return float(sv)
    except Exception:
        return 0.0


def _parse_dt(s: "pd.Series | str") -> "pd.Series | pd.Timestamp":
    """Parse datetime from a Series or scalar covering all customer export formats.

    Formats seen across 35+ customer files:
      2025-11-28 06:50:00   — ISO (most common)
      26-06-2025 23:45      — DD-MM-YYYY (BJS, EU)
      3/2/2025 13:21        — M/D/YYYY US
      06-NOV-24 11.00.05.100271000 PM GMT — Oracle DB timestamp (BATCH_RUN_TIME)
    """
    _ORACLE_PAT = re.compile(
        r"(\d{2}-[A-Z]{3}-\d{2})\s+(\d{2})\.(\d{2})\.(\d{2})\.\d+\s+(AM|PM)\s+\w+",
        re.IGNORECASE)
    _FMTS = [
        "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
        "%d-%m-%Y %H:%M",    "%d-%m-%Y %H:%M:%S",
        "%m/%d/%Y %H:%M",    "%m/%d/%Y %H:%M:%S", "%m/%d/%Y",
        "%d/%m/%Y %H:%M",    "%d/%m/%Y %H:%M:%S",
        "%d-%b-%y %I:%M:%S %p",   # Oracle after dot→colon normalisation
    ]

    if isinstance(s, pd.Series):
        # Vectorised Oracle normalisation: "06-NOV-24 11.00.05.100271000 PM GMT" → "06-NOV-24 11:00:05 PM"
        s = s.astype(str).str.replace(
            r"(\d{2}-[A-Z]{3}-\d{2})\s+(\d{2})\.(\d{2})\.(\d{2})\.\d+\s+(AM|PM)\s+\w+",
            lambda m: f"{m.group(1)} {m.group(2)}:{m.group(3)}:{m.group(4)} {m.group(5)}",
            regex=True, flags=re.IGNORECASE,
        )
        for fmt in _FMTS:
            try:
                parsed = pd.to_datetime(s, format=fmt, errors="coerce")
                if parsed.notna().sum() > len(s) * 0.4:
                    return parsed
            except Exception:
                pass
        return pd.to_datetime(s, errors="coerce")
    else:
        sv = str(s).strip()
        m = _ORACLE_PAT.match(sv)
        if m:
            sv = f"{m.group(1)} {m.group(2)}:{m.group(3)}:{m.group(4)} {m.group(5)}"
        for fmt in _FMTS:
            try:
                return pd.to_datetime(sv, format=fmt)
            except Exception:
                pass
        return pd.to_datetime(sv, errors="coerce")


def _find_data_row(df_raw: pd.DataFrame) -> int:
    """Detect the actual header row in files with title/merged-cell preamble.

    Scans the first 15 rows for the row with the most non-null, non-'Unnamed'
    cells — that is the real column-header row.  Returns 0 if the file already
    starts clean.
    """
    best_row, best_score = 0, -1
    for i, row in df_raw.head(15).iterrows():
        vals = [str(v).strip() for v in row if str(v).strip() and not str(v).startswith("Unnamed")]
        # Prefer rows that contain Ctrl-M header keywords
        score = len(vals) + sum(2 for v in vals
                                if any(k in v.lower() for k in
                                       ("job", "start", "end", "status", "run", "time", "sec", "process")))
        if score > best_score:
            best_score, best_row = score, i
    return int(best_row)


def load_ctrlm_bytes(raw: bytes, filename: str = "") -> pd.DataFrame:
    """Load Ctrl-M batch execution data from CSV or XLSX bytes.

    Handles all column-naming conventions discovered across 35+ customer files:
      • Standard Ctrl-M export:  Job_Name, Start_Time, End_Time, Completion Status, Run Time (Sec.)
      • BATCH_RUN_TIME style:    PROCESS, START_DATE, END_DATE, STATUS/STATUS_MESSAGE
      • Daily summary style:     date, job_count, total_run_time_sec  (synthesizes Job_Name)
      • Merged-header XLSX:      detects real header row automatically
      • Legacy .xls (OLE/CFB):   xlrd engine
      • Corrupted/binary CSV:    raises ValueError with clear message
    """
    ext = os.path.splitext(filename)[1].lower() if filename else ""
    buf = io.BytesIO(raw)

    # ── Detect if raw bytes are binary/corrupted (not UTF-8 or Latin-1 text) ──
    if ext not in (".xlsx", ".xls") and len(raw) >= 4 and raw[:4] in (
            b'\xd0\xcf\x11\xe0', b'PK\x03\x04'):
        # OLE/ZIP magic bytes in a file named .csv → it's actually an Excel file
        ext = ".xlsx" if raw[:4] == b'PK\x03\x04' else ".xls"

    if ext in (".xlsx", ".xls"):
        engine = "xlrd" if (ext == ".xls" or raw[:4] == b'\xd0\xcf\x11\xe0') else "openpyxl"
        try:
            # First pass: read to detect if there's a merged-title preamble
            df_probe = pd.read_excel(buf, sheet_name=0, engine=engine, header=0, nrows=20)
            hdr_row = _find_data_row(df_probe)
            buf.seek(0)
            # df_probe was read with header=0 (physical row 0 became the column header).
            # _find_data_row returns the 0-based row INDEX within df_probe that looks like
            # the real header.  Since df_probe row 0 = physical file row 1, the actual
            # Excel header row we need is hdr_row + 1.
            # Guard: only do this when the probe columns are mostly Unnamed (bad title row).
            _unnamed = sum(1 for c in df_probe.columns if str(c).startswith("Unnamed"))
            if _unnamed > len(df_probe.columns) * 0.4:
                # Title / garbage in physical row 0 → real headers are buried
                actual_hdr = hdr_row + 1  # physical Excel row (0-indexed)
                df = pd.read_excel(buf, sheet_name=0, engine=engine,
                                   header=actual_hdr, dtype=str)
                logger.debug("load_ctrlm_bytes: buried header at Excel row %d in %s",
                             actual_hdr, filename)
            else:
                buf.seek(0)
                df = pd.read_excel(buf, sheet_name=0, engine=engine, dtype=str)
        except Exception as e:
            raise ValueError(f"Cannot parse Ctrl-M file: {e}") from e
    else:
        # Try UTF-8 first, fall back to Latin-1, then try as Excel
        for enc in ("utf-8", "latin-1", "cp1252"):
            try:
                buf.seek(0)
                df = pd.read_csv(buf, encoding=enc, on_bad_lines="skip", dtype=str)
                # Reject if result looks corrupt (e.g. CCH_MPWB — binary XLS named .csv)
                if len(df.columns) == 1 and df.columns[0].startswith("\xd0"):
                    raise ValueError("Binary content detected in CSV")
                break
            except UnicodeDecodeError:
                continue
            except Exception:
                break
        else:
            buf.seek(0)
            try:
                df = pd.read_excel(buf, sheet_name=0, engine="openpyxl", dtype=str)
            except Exception as e:
                raise ValueError(f"Cannot parse Ctrl-M file: {e}") from e

    # ── Numeric coercion (dtype=str used above for safe read; convert now) ──
    for col in df.columns:
        try:
            numeric = pd.to_numeric(df[col], errors="coerce")
            # Only coerce if > 50% of non-null values are numeric
            if numeric.notna().sum() > df[col].notna().sum() * 0.5:
                df[col] = numeric
        except Exception:
            pass

    df.columns = pd.Index([str(c).strip() for c in df.columns])
    col_map: Dict[str, str] = {}
    for c in df.columns:
        cl = c.lower().replace(" ", "_").replace("-", "_").replace(".", "_")
        # Skip unnamed / index columns
        if cl.startswith("unnamed"):
            continue
        if "folder" in cl:
            col_map[c] = "Folder"
        elif ("sub" in cl and "app" in cl) or cl in ("sub_application", "sub_app", "stream", "component"):
            col_map[c] = "Sub_Application"
        elif "application" in cl and "sub" not in cl and "sub_application" not in col_map.values():
            col_map[c] = "Application"
        elif "job" in cl and "name" in cl:
            col_map[c] = "Job_Name"
        elif cl in ("job", "jobname", "job_id", "jobid", "taskname", "task_name",
                    "task", "process_name", "processname", "ordername", "order_name",
                    "step_name", "stepname", "script_name", "scriptname", "name",
                    "process",  # BATCH_RUN_TIME pattern: PROCESS column
                    ):
            col_map[c] = "Job_Name"
        elif "start" in cl and ("time" in cl or "date" in cl or cl in ("start", "start_date")):
            col_map[c] = "Start_Time"
        elif "end" in cl and ("time" in cl or "date" in cl or cl in ("end", "end_date")):
            col_map[c] = "End_Time"
        elif "status" in cl and "message" not in cl:   # STATUS_MESSAGE is not a status flag
            col_map[c] = "Status"
        elif "completion" in cl and "status" in cl:
            col_map[c] = "Status"
        # Human-readable runtime strings: "2hr 21min", "1:30:00" — check BEFORE numeric runtime
        # Only map columns that clearly represent total batch runtime in H:M format
        elif cl in ("total_batch_runtime", "batch_runtime",
                    "runtime_hhmm", "total_time_hhmm"):
            col_map[c] = "_duration_str"
        # Runtime columns in seconds — ordered most-specific first to avoid clobbering
        elif cl in ("run_time_(sec_)", "run_time_(sec.)", "run_sec", "runtime_sec",
                    "total_runtime_sec", "total_run_time_sec", "total_runime_sec",
                    "total_runtimesec", "total_run_time_seconds",
                    "total_run_time_limited"):
            col_map[c] = "Run_Sec"
        elif "run" in cl and "sec" in cl and "avg" not in cl:
            col_map[c] = "Run_Sec"
        elif "total" in cl and "runtime" in cl:
            col_map[c] = "Run_Sec"
        elif "duration" in cl or "elapsed" in cl:
            col_map[c] = "Run_Sec"
        # Daily-summary files: synthesise Job_Name from date, derive Run_Sec from totals
        elif cl in ("date", "run_date", "week", "week_start", "week_ending"):
            col_map[c] = "Start_Time"   # date/week column doubles as Start_Time
        elif cl == "job_count":
            col_map[c] = "_job_count"   # preserve for synthetic row expansion

    df.rename(columns=col_map, inplace=True)

    # ── Daily-summary files: synthesise per-row job representation ────────
    # Files like Daily_Activity_Summary.csv have one row per day with a total
    # runtime but no Job_Name column.  We synthesise a "DAILY_BATCH" job so
    # the rest of the pipeline sees consistent data.
    if "Job_Name" not in df.columns and "Run_Sec" in df.columns:
        if "_job_count" in df.columns:
            # day-level summary — represent as a single synthetic job per day
            df["Job_Name"] = df["Start_Time"].astype(str).apply(
                lambda d: f"DAILY_BATCH_{str(d)[:10]}")
            df["Sub_Application"] = "DAILY_SUMMARY"
        elif "Start_Time" in df.columns:
            df["Job_Name"] = "BATCH"
            df["Sub_Application"] = "UNKNOWN"

    # RULE 3 — normalise Status after column mapping (Status may have been
    # renamed from "Completion Status", "State", "completion", etc.)
    df = normalise_ctrlm_csv(df)

    # ── CRITICAL: drop duplicate column names (keep first) ────────────────
    if df.columns.duplicated().any():
        dupes = df.columns[df.columns.duplicated(keep=False)].unique().tolist()
        logger.warning("Duplicate columns detected and deduplicated (kept first): %s", dupes)
        df = df.loc[:, ~df.columns.duplicated(keep="first")]

    # ── CRITICAL: sanitize all string columns before ANY .str accessor ─────
    # Fixes: 'float' object has no attribute 'lower'  (NaN cells in mixed cols)
    for _scol in ("Status", "Job_Name", "Folder", "Sub_Application", "Application"):
        if _scol in df.columns:
            col = df[_scol]
            # Extra guard: if duplicate columns still sneak through, take first
            if hasattr(col, "columns"):  # it's a DataFrame, not a Series
                col = col.iloc[:, 0]
                df[_scol] = col
            df[_scol] = df[_scol].fillna("").astype(str).str.strip()
    # Drop fully-empty rows that produce garbage after coercion
    _jcol = df["Job_Name"] if "Job_Name" in df.columns else df.iloc[:, 0]
    if hasattr(_jcol, "columns"):
        _jcol = _jcol.iloc[:, 0]
    df = df[_jcol.astype(str).str.len() > 0]

    # ── Fuzzy fallback ───────────────────────────────────────────
    _FUZZY_TARGETS = {
        "Job_Name":        ["jobname", "job_name", "jobid", "taskname", "task", "process", "name"],
        "Start_Time":      ["starttime", "start_time", "startdate", "start_date", "begin", "started"],
        "End_Time":        ["endtime", "end_time", "enddate", "end_date", "finish", "finished", "completed"],
        "Run_Sec":         ["runsec", "run_sec", "duration", "elapsed", "runtime", "exectime", "seconds"],
        "Sub_Application": ["subapp", "sub_app", "subapplication", "stream", "module", "component"],
    }
    unmapped_cols = [c for c in df.columns if c not in
                     ("Folder", "Sub_Application", "Application", "Job_Name",
                      "Start_Time", "End_Time", "Status", "Run_Sec",
                      "_duration_str", "_job_count")]
    for target, candidates in _FUZZY_TARGETS.items():
        if target in df.columns:
            continue
        for uc in list(unmapped_cols):
            normalised = uc.lower().replace(" ", "").replace("_", "").replace("-", "")
            matches = difflib.get_close_matches(normalised, candidates, n=1, cutoff=0.75)
            if matches:
                df.rename(columns={uc: target}, inplace=True)
                unmapped_cols.remove(uc)
                break

    # ── Reject clearly non-Ctrl-M files ─────────────────────────────────
    # These are summary/resource/metadata files that have no job run records.
    _col_set = {str(c).lower().strip() for c in df.columns}
    _NON_CTRLM = [
        {"metric", "value"},                               # pe_summary.csv style
        {"server", "category"},                            # resource/SLA-breach report
        {"index_name", "table_name"},                      # DBA metadata
    ]
    for _sig in _NON_CTRLM:
        if _sig.issubset(_col_set) and len(_col_set) <= len(_sig) + 4:
            raise ValueError(
                f"File does not contain Ctrl-M job execution records "
                f"(columns: {list(df.columns)[:6]}). Upload a file with one row per job run."
            )

    # ── Final fallbacks ──────────────────────────────────────────
    if "Job_Name" not in df.columns:
        # dtype == object OR StringDtype (pandas 3.x)
        str_cols = [c for c in df.columns
                    if str(df[c].dtype) in ("object", "string") and c not in
                    ("Folder", "Sub_Application", "Application", "Status",
                     "Start_Time", "End_Time", "Run_Sec", "_job_count", "_duration_str")]
        if str_cols:
            df.rename(columns={str_cols[0]: "Job_Name"}, inplace=True)
        else:
            df["Job_Name"] = "UNKNOWN"

    if "Sub_Application" not in df.columns:
        df["Sub_Application"] = "UNKNOWN"
    if "Status" not in df.columns:
        logger.debug("load_ctrlm_bytes: Status column absent — defaulting all rows to 'ENDED OK'")
        df["Status"] = "ENDED OK"

    if "Run_Sec" not in df.columns:
        # Prefer human-readable duration column if present
        if "_duration_str" in df.columns:
            parsed_secs = df["_duration_str"].apply(
                lambda x: _parse_duration_str(str(x)) if pd.notna(x) else 0.0)
            if parsed_secs.max() > 0:
                df["Run_Sec"] = parsed_secs
        if "Run_Sec" not in df.columns:
            nums = df.select_dtypes(include="number").columns.tolist()
            if nums:
                df.rename(columns={nums[-1]: "Run_Sec"}, inplace=True)
            else:
                df["Run_Sec"] = 0

    df["Run_Sec"] = pd.to_numeric(df["Run_Sec"], errors="coerce").fillna(0)

    # If Run_Sec is still all zeros and there's a human-readable duration column, parse it
    if "_duration_str" in df.columns and df["Run_Sec"].eq(0).all():
        parsed_secs = df["_duration_str"].apply(
            lambda x: _parse_duration_str(str(x)) if pd.notna(x) else 0.0)
        if parsed_secs.max() > 0:
            df["Run_Sec"] = parsed_secs

    # Also scan remaining unmapped columns for duration string patterns when Run_Sec still 0
    if df["Run_Sec"].eq(0).all():
        _DUR_KW = ("runtime", "run_time", "total_time", "batch_time")
        _skip = {"Job_Name", "Sub_Application", "Application", "Folder",
                 "Status", "Start_Time", "End_Time", "Run_Sec", "_duration_str"}
        for _col in df.columns:
            if _col in _skip:
                continue
            _cl = str(_col).lower().replace(" ", "_")
            if any(k in _cl for k in _DUR_KW):
                _parsed = df[_col].apply(
                    lambda x: _parse_duration_str(str(x)) if pd.notna(x) else 0.0)
                if _parsed.max() > 0:
                    df["Run_Sec"] = _parsed
                    break

    if "Start_Time" not in df.columns:
        _dt_exclude = {"Job_Name", "Folder", "Sub_Application", "Application",
                       "Status", "Run_Sec", "_job_count"}
        for c in df.columns:
            if c in _dt_exclude:
                continue
            try:
                parsed = pd.to_datetime(df[c], errors="coerce")
                # Require > 50% of rows to parse AND at least one non-epoch date
                if parsed.notna().sum() > len(df) * 0.5 and (
                        parsed.dropna() > pd.Timestamp("2000-01-01")).any():
                    df.rename(columns={c: "Start_Time"}, inplace=True)
                    break
            except Exception:
                pass
        if "Start_Time" not in df.columns:
            df["Start_Time"] = pd.Timestamp.now()

    if "End_Time" in df.columns:
        df["Start_Time"] = _parse_dt(df["Start_Time"])
        df["End_Time"]   = _parse_dt(df["End_Time"])
        # Only derive runtime from End−Start for successful runs.
        # ENDED NOT OK with Run_Sec=0 are pre-execution failures — their
        # wall-clock span is NOT a valid runtime and creates phantom peaks.
        mask = (df["Run_Sec"] == 0) & (df["Status"] == "OK")
        diff = (df.loc[mask, "End_Time"] - df.loc[mask, "Start_Time"]).dt.total_seconds()
        df.loc[mask, "Run_Sec"] = diff.clip(lower=0)
    else:
        df["Start_Time"] = _parse_dt(df["Start_Time"])

    df.dropna(subset=["Start_Time"], inplace=True)
    df["run_time_hrs"] = df["Run_Sec"] / 3600.0
    df["run_date"]     = df["Start_Time"].dt.date
    df["month"]        = df["Start_Time"].dt.to_period("M").astype(str)
    df["Hour_Bucket"]  = df["Start_Time"].dt.hour   # 0-23 for heatmap
    return df


# ─────────────────────────────────────────────────────────────────
# F3 — SLA Buffer (extracted from app_v2.py:2035)
# ─────────────────────────────────────────────────────────────────
def calculate_sla_buffer(sla_window_hrs: float, max_runtime_hrs: float) -> Dict[str, Any]:
    """F3 — SLA Buffer: remaining headroom between peak runtime and SLA window."""
    if sla_window_hrs <= 0 or max_runtime_hrs <= 0:
        return {"buffer_hrs": 0.0, "buffer_pct": 0.0,
                "growth_multiplier": 0.0, "growth_capacity_pct": 0.0, "status": "INVALID"}
    buffer_hrs        = sla_window_hrs - max_runtime_hrs
    buffer_pct        = (buffer_hrs / sla_window_hrs) * 100
    growth_multiplier = sla_window_hrs / max_runtime_hrs
    growth_capacity   = (buffer_hrs / max_runtime_hrs) * 100 if max_runtime_hrs > 0 else 0.0
    if   buffer_pct > 50: status = "EXCELLENT"
    elif buffer_pct > 30: status = "HEALTHY"
    elif buffer_pct > 10: status = "CAUTION"
    else:                 status = "CRITICAL"
    return {"buffer_hrs": round(buffer_hrs, 2),
            "buffer_pct": round(buffer_pct, 1),
            "growth_multiplier": round(growth_multiplier, 2),
            "growth_capacity_pct": round(growth_capacity, 1),
            "status": status}


# ─────────────────────────────────────────────────────────────────
# F6 — Anomaly detection (extracted from app_v2.py:2104)
# ─────────────────────────────────────────────────────────────────
def detect_job_anomalies(df: pd.DataFrame) -> list:
    """F6 — z-score anomaly detection on job peak runtimes."""
    anomalies: list = []
    if df is None or df.empty:
        return anomalies

    _jc = next((c for c in df.columns if "job_name" in c.lower() or c.lower() == "job"), None)
    _hc = next((c for c in df.columns if "run_time_hrs" in c.lower() or "peak_hrs" in c.lower()), None)
    if _jc is None or _hc is None:
        return anomalies

    top = (df.groupby(_jc)[_hc]
             .agg(peak_hrs="max", avg_hrs="mean").reset_index()
             .rename(columns={_jc: "Job_Name"}))

    if len(top) >= 3:
        mu  = top["peak_hrs"].mean()
        std = top["peak_hrs"].std()
        if std > 0.001:
            top["z_score"] = ((top["peak_hrs"] - mu) / std).round(2)
            stat = top[top["z_score"] > 2.0]
            for _, row in stat.iterrows():
                anomalies.append({
                    "job_name":     row["Job_Name"],
                    "peak_hrs":     round(float(row["peak_hrs"]), 3),
                    "avg_hrs":      round(float(row["avg_hrs"]), 3),
                    "z_score":      float(row["z_score"]),
                    "variance_pct": None,
                    "status":       "STATISTICAL_OUTLIER",
                    "severity":     3,
                })
    return sorted(anomalies, key=lambda x: x["severity"], reverse=True)


# ─────────────────────────────────────────────────────────────────
# build_top_jobs_df — name per Phase 3 brief
# ─────────────────────────────────────────────────────────────────
def build_top_jobs_df(df: pd.DataFrame,
                      sla_index: Dict[str, Any] | None = None) -> pd.DataFrame:
    """Group by composite key [Sub_Application, Job_Name] → peak/avg/total hours + SLA buffer.

    RULE 6: Always use ['Sub_Application', 'Job_Name'] composite key to prevent
    collision between DAILY and WEEKLY jobs sharing the same base name.

    SLA resolution priority (per job, not one global ceiling):
      1. Per-job lookup from uploaded SLA matrix (via build_sla_index / resolve_sla)
      2. Schedule-type detected from Sub_Application name
      3. System pe_config default (fallback only)
    """
    # RULE 6 — composite key: Sub_Application + Job_Name
    group_cols = (["Sub_Application", "Job_Name"]
                  if "Sub_Application" in df.columns
                  else ["Job_Name"])

    # Peak/avg from OK runs only — FAILED runs with 0-sec or inflated
    # wall-clock times must not skew SLA peak metrics.
    has_status = "Status" in df.columns
    ok_df = df[df["Status"] == "OK"] if has_status else df
    if ok_df.empty:
        ok_df = df  # fallback: all rows if every run failed

    top_jobs = (ok_df.groupby(group_cols)["run_time_hrs"]
                  .agg(["max", "mean", "sum"]).reset_index()
                  .rename(columns={"max": "peak_hrs", "mean": "avg_hrs", "sum": "total_hrs"})
                  .sort_values("peak_hrs", ascending=False))

    # Include jobs that only have FAILED runs (missing from ok_df groupby)
    if has_status:
        all_keys = df.groupby(group_cols).size().reset_index(name="_n")[group_cols]
        top_jobs = all_keys.merge(top_jobs, on=group_cols, how="left")
        top_jobs["peak_hrs"]  = top_jobs["peak_hrs"].fillna(0.0)
        top_jobs["avg_hrs"]   = top_jobs["avg_hrs"].fillna(0.0)
        top_jobs["total_hrs"] = top_jobs["total_hrs"].fillna(0.0)
        top_jobs = top_jobs.sort_values("peak_hrs", ascending=False)

        # Failure count per job
        fail_df = df[df["Status"] == "FAILED"]
        if not fail_df.empty:
            fail_counts = fail_df.groupby(group_cols).size().reset_index(name="fail_count")
            top_jobs = top_jobs.merge(fail_counts, on=group_cols, how="left")
            top_jobs["fail_count"] = top_jobs["fail_count"].fillna(0).astype(int)
        else:
            top_jobs["fail_count"] = 0
    else:
        top_jobs["fail_count"] = 0

    # ── Per-job SLA resolution ───────────────────────────────────
    # Build SLA index if caller didn't supply one
    if sla_index is None:
        sla_index = build_sla_index(df)

    job_sla_map = sla_index.get("job_sla", {})
    global_ceil = sla_index.get("global_ceiling", _detect_sla_ceiling(df))

    def _get_job_sla(row) -> float:
        """Look up per-job SLA. Falls back gracefully through index → global."""
        sub_app  = str(row.get("Sub_Application", "")) if "Sub_Application" in row.index else ""
        job_name = str(row.get("Job_Name", ""))
        key      = f"{sub_app}|{job_name}" if sub_app else job_name
        entry = job_sla_map.get(key)
        if entry and entry.get("sla_hrs", 0) > 0:
            return float(entry["sla_hrs"])
        # Alt key (job only)
        entry2 = job_sla_map.get(job_name)
        if entry2 and entry2.get("sla_hrs", 0) > 0:
            return float(entry2["sla_hrs"])
        return global_ceil

    top_jobs["sla_hrs"]      = top_jobs.apply(_get_job_sla, axis=1)
    top_jobs["sla_source"]   = top_jobs.apply(
        lambda r: (job_sla_map.get(
            f"{r.get('Sub_Application','') if 'Sub_Application' in r.index else ''}|{r.get('Job_Name','')}",
            job_sla_map.get(str(r.get("Job_Name", "")), {})
        ) or {}).get("source", "default"),
        axis=1,
    )

    # F3 — per-job SLA Buffer (buffer = sla_hrs - peak_hrs)
    top_jobs["buffer_pct"]   = ((top_jobs["sla_hrs"] - top_jobs["peak_hrs"]) / top_jobs["sla_hrs"] * 100).round(1)
    top_jobs["sla_used_pct"] = (top_jobs["peak_hrs"] / top_jobs["sla_hrs"] * 100).round(1)
    top_jobs["buffer_status"] = top_jobs["buffer_pct"].apply(
        lambda b: "BREACH"    if b < 0
        else ("CRITICAL"      if b < 10
        else ("CAUTION"       if b < 30
        else ("HEALTHY"       if b < 50 else "EXCELLENT"))))

    # Round floats for JSON cleanliness
    for col in ("peak_hrs", "avg_hrs", "total_hrs", "sla_hrs"):
        top_jobs[col] = top_jobs[col].round(3)
    return top_jobs


def _detect_sla_ceiling(df: pd.DataFrame) -> float:
    """Return the appropriate SLA ceiling for this batch dataset.

    Reads the sub-application names to detect whether the batch runs DAILY,
    WEEKLY, or MONTHLY (e.g. "PROD_WEEKLY_WF1_REQPL" → WEEKLY), then returns
    the matching pe_config ceiling.  Falls back to SLA_DAILY_HRS when the
    schedule type cannot be determined.

    NOTE: This is the *global* fallback used when no SLA matrix has been
    uploaded.  When contracts are available, build_sla_index() + per-job
    resolution is used instead (see build_top_jobs_df).
    """
    try:
        from services.sla_engine import classify_schedule as _cs
    except Exception:
        return pe_config.SLA_DAILY_HRS

    schedule_votes: Dict[str, int] = {"DAILY": 0, "WEEKLY": 0, "MONTHLY": 0}
    for col in ("Sub_Application", "Folder", "Application"):
        if col not in df.columns:
            continue
        for name in df[col].dropna().unique():
            stype = _cs(str(name))
            if stype in schedule_votes:
                schedule_votes[stype] += 1

    dominant, votes = max(schedule_votes.items(), key=lambda kv: kv[1])
    if votes == 0:
        return pe_config.SLA_DAILY_HRS

    ceiling_map: Dict[str, float] = {
        "DAILY":   pe_config.SLA_DAILY_HRS,
        "WEEKLY":  pe_config.SLA_WEEKLY_HRS,
        "MONTHLY": pe_config.SLA_MONTHLY_HRS,
    }
    return ceiling_map.get(dominant, pe_config.SLA_DAILY_HRS)


def build_sla_index(df: pd.DataFrame) -> Dict[str, Any]:
    """Build a per-job SLA index by joining the batch DataFrame against the
    uploaded SLA contracts (via resolve_sla's adaptive name matching).

    Returns a dict with two keys:
      "job_sla"   : {job_key → sla_hrs}   (job_key = "SubApp|JobName")
      "global_ceiling" : float             (dominant schedule ceiling, fallback)
      "contracts" : list[SlaContract]      (raw contracts for audit trail)
      "ceilings"  : dict                   (schedule-type → hrs from customer file)
      "source"    : "sla_matrix" | "default"

    When no SLA file has been uploaded, job_sla is empty and global_ceiling is
    the schedule-aware default.
    """
    from services import config_store as _cs
    from services.sla_engine import resolve_sla, classify_schedule, SlaContract

    global_ceiling = _detect_sla_ceiling(df)
    result: Dict[str, Any] = {
        "job_sla": {},
        "global_ceiling": global_ceiling,
        "contracts": [],
        "ceilings": {},
        "source": "default",
    }

    # Load SLA intelligence from config_store (set when SLA file uploaded)
    intel = None
    try:
        intel = _cs.get("_sla_intelligence")
    except Exception:
        pass

    if not intel or not isinstance(intel, dict):
        return result

    raw_contracts = intel.get("contracts", [])
    raw_ceilings  = intel.get("ceilings", {})

    if not raw_contracts:
        return result

    # Reconstruct SlaContract objects from the stored dicts
    contracts: list = []
    for c in raw_contracts:
        if not isinstance(c, dict):
            continue
        try:
            # Minimal reconstruction — only fields resolve_sla needs
            contracts.append(SlaContract(
                batch_name=c.get("batch_name", ""),
                schedule_type=c.get("schedule_type", "UNKNOWN"),
                schedule_raw=c.get("schedule_raw", ""),
                sla_model=c.get("sla_model", "WINDOW"),
                sla_window_hrs=c.get("sla_window_hrs"),
                sla_duration_hrs=c.get("sla_duration_hrs"),
                buffer_minutes=c.get("buffer_minutes"),
                source_row=c.get("source_row", 0),
                completeness=c.get("completeness", "complete"),
            ))
        except Exception:
            continue

    result["contracts"] = contracts
    result["ceilings"]  = {k: float(v) for k, v in raw_ceilings.items() if v}
    result["source"]    = "sla_matrix"

    # Resolve SLA for every unique (Sub_Application, Job_Name) pair
    group_cols = (["Sub_Application", "Job_Name"]
                  if "Sub_Application" in df.columns else ["Job_Name"])
    name_col   = "Sub_Application" if "Sub_Application" in df.columns else "Job_Name"

    for _, row in df[group_cols].drop_duplicates().iterrows():
        job_name = str(row.get("Job_Name", ""))
        sub_app  = str(row.get("Sub_Application", "")) if "Sub_Application" in row else ""
        # Use Sub_Application as primary name hint (closer to SLA file naming)
        primary  = sub_app or job_name
        sched_hint = primary

        resolved = resolve_sla(primary, sched_hint, contracts, result["ceilings"])
        # Fallback: try Job_Name if Sub_App didn't match
        if resolved.source == "assumed" and job_name and job_name != primary:
            alt = resolve_sla(job_name, job_name, contracts, result["ceilings"])
            if alt.source != "assumed":
                resolved = alt

        key = f"{sub_app}|{job_name}" if sub_app else job_name
        result["job_sla"][key] = {
            "sla_hrs":     resolved.sla_hrs,
            "source":      resolved.source,
            "confidence":  resolved.confidence,
            "detail":      resolved.source_detail,
            "schedule_type": resolved.schedule_type,
        }

    return result


# ─────────────────────────────────────────────────────────────────
# compute_metrics — extracted from app_v2.py:2314
# ─────────────────────────────────────────────────────────────────
def compute_metrics(df: pd.DataFrame) -> Dict[str, Any]:
    """Aggregate Ctrl-M runs into KPIs, time-series and top-jobs slices.

    RULE 6: Job-level counts (t_jobs, j_breach) are derived from build_top_jobs_df
    which uses the composite [Sub_Application, Job_Name] key.  Time-series
    (daily/window) keep Job_Name-only grouping for chart compatibility.

    SLA MATH RULE: Every SLA ceiling is resolved per-job from the uploaded
    SLA matrix (via build_sla_index → resolve_sla).  No hardcoded customer-
    specific values.  Falls back to schedule-type ceiling, then pe_config
    default.  Source is tagged on every resolved value.
    """
    # ── Build SLA index once (per-job ceiling from uploaded contracts) ───────
    sla_index     = build_sla_index(df)
    job_sla_map   = sla_index.get("job_sla", {})
    global_ceil   = sla_index.get("global_ceiling", _detect_sla_ceiling(df))
    sla_src_type  = sla_index.get("source", "default")

    # ── Per-job SLA breach counting ──────────────────────────────────────────
    # Breach = Sub_Application window (wall-clock: last End_Time − first Start_Time
    # per Sub_App per run_date) > per-job SLA ceiling resolved from SLA matrix.
    #
    # Falls back to summed run_time_hrs per Job_Name per run_date when
    # End_Time is not available (wall-clock can't be computed).
    has_end_time = "End_Time" in df.columns and df["End_Time"].notna().sum() > 0

    if has_end_time and "Sub_Application" in df.columns:
        # Primary: wall-clock window per Sub_Application per run_date
        window_agg = (
            df.groupby(["Sub_Application", "run_date"], as_index=False)
              .agg(
                  first_start=("Start_Time", "min"),
                  last_end=("End_Time", "max"),
                  job_name=("Job_Name", "first"),  # representative job name
              )
        )
        window_agg["elapsed_hrs"] = (
            (window_agg["last_end"] - window_agg["first_start"])
            .dt.total_seconds() / 3600.0
        ).clip(lower=0).fillna(0.0)

        def _sub_sla(row) -> float:
            sub_app  = str(row["Sub_Application"])
            job_name = str(row["job_name"])
            key = f"{sub_app}|{job_name}"
            entry = job_sla_map.get(key) or job_sla_map.get(job_name)
            if entry and entry.get("sla_hrs", 0) > 0:
                return float(entry["sla_hrs"])
            return global_ceil

        window_agg["sla_hrs"] = window_agg.apply(_sub_sla, axis=1)
        window_agg["breach"]  = window_agg["elapsed_hrs"] > window_agg["sla_hrs"]

        # Merge back to daily (Job_Name level) for compatibility with heatmap
        daily = (df.groupby(["Job_Name", "run_date"], as_index=False)
                   .agg(total_hrs=("run_time_hrs", "sum"), runs=("run_time_hrs", "count")))
        # Carry the per-Sub_App breach flags into the daily Job_Name frame
        sub_breach = (window_agg.groupby("run_date")["breach"].any().reset_index()
                                .rename(columns={"breach": "_day_breach"}))
        daily = daily.merge(sub_breach, on="run_date", how="left")
        daily["breach"] = daily["_day_breach"].fillna(False)
        daily.drop(columns=["_day_breach"], inplace=True)

        # Per-job breach column for heatmap (per-job wall-clock vs per-job SLA)
        job_breach_map = {}
        for _, r in window_agg.iterrows():
            key = (str(r["Sub_Application"]), str(r["run_date"]))
            job_breach_map[key] = bool(r["breach"])

    else:
        # Fallback: per-Job_Name per-day sum vs per-job SLA
        daily = (df.groupby(["Job_Name", "run_date"], as_index=False)
                   .agg(total_hrs=("run_time_hrs", "sum"), runs=("run_time_hrs", "count")))

        def _job_sla_for_row(row) -> float:
            job_name = str(row["Job_Name"])
            entry = job_sla_map.get(job_name)
            if entry and entry.get("sla_hrs", 0) > 0:
                return float(entry["sla_hrs"])
            return global_ceil

        daily["sla_hrs"] = daily.apply(_job_sla_for_row, axis=1)
        daily["breach"]  = daily["total_hrs"] > daily["sla_hrs"]
        job_breach_map   = {}

    monthly_lim = pe_config.SLA_MONTHLY_HRS
    monthly = (df.groupby(["Job_Name", "month"], as_index=False)
                 .agg(total_hrs=("run_time_hrs", "sum")))
    monthly["breach"] = monthly["total_hrs"] > monthly_lim

    total_d = len(daily)
    # F4 — Job SLA Compliance (per-job-day level)
    job_sla_comp = 0.0 if total_d == 0 else (1 - daily["breach"].sum() / total_d) * 100

    # ── Daily batch window time-series ───────────────────────────
    window = (df.groupby("run_date", as_index=False)
                .agg(total_hrs=("run_time_hrs", "sum"),
                     job_count=("Job_Name", "nunique"))
                .sort_values("run_date"))

    elapsed_available = False
    window_breach_days = 0

    if has_end_time:
        try:
            elap = (df.groupby("run_date")
                      .agg(first_start=("Start_Time", "min"),
                           last_end=("End_Time", "max"))
                      .dropna())
            if not elap.empty:
                elap["elapsed_hrs"] = (
                    (elap["last_end"] - elap["first_start"]).dt.total_seconds() / 3600.0
                ).clip(lower=0)
                window = window.merge(
                    elap[["elapsed_hrs"]],
                    left_on="run_date", right_index=True, how="left",
                )
                window["elapsed_hrs"] = window["elapsed_hrs"].fillna(0.0).round(3)
                elapsed_available = True
        except Exception:
            pass
    if not elapsed_available:
        window["elapsed_hrs"] = 0.0

    # ── Batch Window Compliance (wall-clock daily window vs global ceiling) ──
    n_window_days = len(window)
    if n_window_days > 0:
        if elapsed_available:
            window_breach_days = int((window["elapsed_hrs"] > global_ceil).sum())
        else:
            window_breach_days = int((window["total_hrs"] > global_ceil).sum())
        batch_window_comp = round((1 - window_breach_days / n_window_days) * 100, 1)
    else:
        batch_window_comp = 0.0

    # Sub-application rollup
    sub = (df.groupby("Sub_Application", as_index=False)
             .agg(total_hrs=("run_time_hrs", "sum"),
                  jobs=("Job_Name", "nunique")))

    # ── Worst-job peak (single highest peak_hrs across all jobs) ──
    top_jobs = build_top_jobs_df(df, sla_index=sla_index)
    t_jobs   = int(len(top_jobs))
    j_breach = int((top_jobs["buffer_status"] == "BREACH").sum())

    worst_job_name = ""
    worst_job_peak = 0.0
    if not top_jobs.empty:
        worst_idx = top_jobs["peak_hrs"].idxmax()
        worst_row = top_jobs.loc[worst_idx]
        worst_job_peak = float(worst_row["peak_hrs"])
        worst_job_name = str(worst_row.get("Job_Name", "?"))

    # F5 — At-risk: buffer_pct in [0, 15]
    j_at_risk = int((top_jobs["buffer_pct"].between(0, 15, inclusive="both")).sum())
    j_ok      = max(0, t_jobs - j_breach - j_at_risk)

    # F6 — Anomaly detection
    anomalies = detect_job_anomalies(df)

    # F3 — Fleet-level SLA buffer (worst job)
    peak_max = worst_job_peak
    fleet_sla_buffer = calculate_sla_buffer(global_ceil, peak_max) if peak_max > 0 else None

    # ── Data coverage / confidence ───────────────────────────────
    unique_dates = sorted(df["run_date"].unique())
    date_span = (max(unique_dates) - min(unique_dates)).days + 1 if len(unique_dates) >= 2 else 1
    has_start   = "Start_Time" in df.columns and df["Start_Time"].notna().sum() > 0
    has_status  = "Status" in df.columns
    has_sub_app = "Sub_Application" in df.columns and (df["Sub_Application"] != "UNKNOWN").any()
    ok_count    = int((df["Status"] == "OK").sum()) if has_status else 0
    fail_count  = int((df["Status"] == "FAILED").sum()) if has_status else 0

    # Confidence score (0-100): penalise missing columns, short date range, etc.
    conf = 100.0
    if not has_end_time:
        conf -= 15   # can't compute elapsed window
    if not has_status:
        conf -= 10   # can't distinguish OK vs FAILED
    if not has_sub_app:
        conf -= 5    # no sub-application grouping
    if date_span < 7:
        conf -= 20   # less than 7 days of data
    elif date_span < 14:
        conf -= 10
    elif date_span < 30:
        conf -= 5
    if len(df) < 50:
        conf -= 10
    conf = max(0.0, round(conf, 1))

    return {
        "daily":            daily,
        "monthly":          monthly,
        "window":           window,
        "compliance":       float(round(job_sla_comp, 1)),
        "job_sla_compliance":      float(round(job_sla_comp, 1)),
        "batch_window_compliance": float(round(batch_window_comp, 1)),
        "window_breach_days":      window_breach_days,
        "window_total_days":       n_window_days,
        "total_jobs":       t_jobs,
        "jobs_ok":          int(j_ok),
        "jobs_breach":      int(j_breach),
        "jobs_at_risk":     int(j_at_risk),
        "total_runs":       int(len(df)),
        "total_hrs":        float(round(df["run_time_hrs"].sum(), 2)),
        "sub_stats":        sub,
        "top_jobs":         top_jobs,
        "anomalies":        anomalies,
        "fleet_sla_buffer": fleet_sla_buffer,
        # ── Intelligence fields ──────────────────────────────────
        "worst_job_name":   worst_job_name,
        "worst_job_peak":   round(worst_job_peak, 3),
        "elapsed_available": elapsed_available,
        "date_span_days":   date_span,
        "date_range":       [str(unique_dates[0]), str(unique_dates[-1])] if unique_dates else [],
        "ok_runs":          ok_count,
        "fail_runs":        fail_count,
        "sla_source":       sla_src_type,
        "sla_daily_hrs":    global_ceil,
        "sla_ceiling":      global_ceil,   # canonical name for downstream callers
        "confidence":       conf,
        # ── SLA index for downstream (e.g. _build_sla_source_payload) ───────
        "_sla_index":       sla_index,
    }


# ─────────────────────────────────────────────────────────────────
# Heatmap builders
# ─────────────────────────────────────────────────────────────────

def _build_sla_heatmap(daily_df: pd.DataFrame, ceiling: float | None = None) -> Dict[str, Any]:
    """Job × Date SLA compliance matrix — mirrors app_v2::heatmap_fig.

    Returns:
        { jobs: [...], dates: [...], cells: [{job, date, hrs, breach}, ...] }
    """
    if daily_df is None or daily_df.empty:
        return {"jobs": [], "dates": [], "cells": []}

    lim = ceiling if ceiling and ceiling > 0 else pe_config.SLA_DAILY_HRS
    dates = sorted(daily_df["run_date"].unique())[-21:]   # last 21 days
    all_jobs = sorted(daily_df["Job_Name"].unique())
    if len(all_jobs) > 40:
        all_jobs = (
            daily_df.groupby("Job_Name")["total_hrs"].sum()
            .nlargest(40).index.tolist()
        )

    cells = []
    for job in all_jobs:
        for d in dates:
            sub = daily_df[(daily_df["Job_Name"] == job) & (daily_df["run_date"] == d)]
            if sub.empty:
                cells.append({"job": job, "date": str(d), "hrs": None, "breach": False})
            else:
                h = float(sub.iloc[0]["total_hrs"])
                cells.append({"job": job, "date": str(d), "hrs": round(h, 2),
                               "breach": h > lim})

    return {
        "jobs":  all_jobs,
        "dates": [str(d) for d in dates],
        "cells": cells,
        "limit": lim,
    }


def _build_hour_heatmap(df: pd.DataFrame) -> Dict[str, Any]:
    """Hour-of-day × Sub-Application execution density heatmap.

    X axis: Hour 0-23 | Y axis: top sub-apps | value: job count

    Returns:
        { sub_apps: [...], hours: [0..23], cells: [{sub_app, hour, count, total_hrs}, ...] }
    """
    if df is None or df.empty or "Hour_Bucket" not in df.columns:
        return {"sub_apps": [], "hours": list(range(24)), "cells": []}

    group_col = "Sub_Application" if "Sub_Application" in df.columns else (
                "Folder" if "Folder" in df.columns else None)
    if group_col is None:
        return {"sub_apps": [], "hours": list(range(24)), "cells": []}

    # Top 10 sub-apps by job count
    top_apps = (df.groupby(group_col)["Job_Name"].count()
                  .nlargest(10).index.tolist())
    df_f = df[df[group_col].isin(top_apps)].copy()

    pivot = (df_f.groupby([group_col, "Hour_Bucket"])
               .agg(count=("Job_Name", "count"),
                    total_hrs=("run_time_hrs", "sum"))
               .reset_index()
               .rename(columns={group_col: "sub_app", "Hour_Bucket": "hour"}))

    pivot["total_hrs"] = pivot["total_hrs"].round(2)
    cells = pivot.to_dict(orient="records")

    return {
        "sub_apps": top_apps,
        "hours":    list(range(24)),
        "cells":    cells,
    }


# ─────────────────────────────────────────────────────────────────
# Hourly counts — temporal data for executive JRTOS
# ─────────────────────────────────────────────────────────────────
def _build_hourly_counts(df: pd.DataFrame) -> Dict[str, Dict[int, int]]:
    """Aggregate job count and fail count per hour bucket (0-23) for temporal."""
    if df is None or df.empty or "Hour_Bucket" not in df.columns:
        return {"hourly_jobs": {}, "hourly_fails": {}}

    hourly_jobs = df.groupby("Hour_Bucket").size().to_dict()

    if "Status" in df.columns:
        fail_df = df[df["Status"] == "FAILED"]
        hourly_fails = fail_df.groupby("Hour_Bucket").size().to_dict() if not fail_df.empty else {}
    else:
        hourly_fails = {}

    # Ensure all hours 0-23 present
    for h in range(24):
        hourly_jobs.setdefault(h, 0)
        hourly_fails.setdefault(h, 0)

    return {"hourly_jobs": hourly_jobs, "hourly_fails": hourly_fails}


# ─────────────────────────────────────────────────────────────────
# build_batch_payload — JSON-ready envelope for the frontend
# ─────────────────────────────────────────────────────────────────
def _build_worst_job(m: dict, top_jobs_df: "pd.DataFrame") -> dict:
    """Return worst-job section using per-job SLA from top_jobs_df.

    Falls back to global sla_ceiling when top_jobs_df is empty or sla_hrs
    column is absent (ensures backward compatibility).
    """
    job_name  = m.get("worst_job_name", "")
    peak_hrs  = m.get("worst_job_peak", 0.0)
    # Try to pull per-job SLA from the top_jobs dataframe
    per_job_sla = m.get("sla_ceiling")   # default: global ceiling
    if not top_jobs_df.empty and "sla_hrs" in top_jobs_df.columns and job_name:
        match = top_jobs_df[top_jobs_df["Job_Name"] == job_name]
        if not match.empty:
            val = float(match.iloc[0]["sla_hrs"])
            if val > 0:
                per_job_sla = val

    buffer_pct = (
        round(((per_job_sla - peak_hrs) / per_job_sla * 100), 1)
        if per_job_sla and per_job_sla > 0 else 0.0
    )
    return {
        "job_name":   job_name,
        "peak_hrs":   peak_hrs,
        "sla_hrs":    per_job_sla,
        "buffer_pct": buffer_pct,
        "note": "Worst-job peak = single highest OK-run duration across all jobs.",
    }


def build_batch_payload(df: pd.DataFrame) -> Dict[str, Any]:
    """Run compute_metrics and flatten all DataFrames → JSON-ready dicts.

    The Phase 3 contract requires:
        - KPIs  (compliance %, total runs, SLA buffers)
        - Top 10 breaching jobs
        - Time-series data for the charts
    """
    if df is None or df.empty:
        return {
            "kpis": {
                "compliance_pct": 0.0,
                "total_runs":     0,
                "total_jobs":     0,
                "total_hrs":      0.0,
                "jobs_breach":    0,
                "jobs_at_risk":   0,
                "jobs_ok":        0,
                "daily_limit_hrs":   pe_config.SLA_DAILY_HRS,
                "monthly_limit_hrs": pe_config.SLA_MONTHLY_HRS,
                "fleet_sla_buffer":  None,
            },
            "top_jobs":      [],
            "top_breaches":  [],
            "window":        [],
            "sub_stats":     [],
            "anomalies":     [],
            "hourly_counts": {"hourly_jobs": {}, "hourly_fails": {}},
            "sla_heatmap":   {"jobs": [], "dates": [], "cells": [], "limit": pe_config.SLA_DAILY_HRS},
            "hour_heatmap":  {"sub_apps": [], "hours": list(range(24)), "cells": []},
        }

    m = compute_metrics(df)
    top_jobs_df: pd.DataFrame = m["top_jobs"]
    window_df:   pd.DataFrame = m["window"]
    sub_df:      pd.DataFrame = m["sub_stats"]

    # Top 10 breaching jobs (buffer < 0); fall back to worst 10 by peak if none breaching
    breaches_df = top_jobs_df[top_jobs_df["buffer_pct"] < 0].head(10)
    if breaches_df.empty:
        breaches_df = top_jobs_df.head(10)

    # Top 15 jobs by peak (used by the horizontal bar chart)
    top15_df = top_jobs_df.head(15).copy()

    # Identify top contributing job for each day (for chart annotation)
    daily_df = m["daily"]
    top_job_per_day = {}
    if daily_df is not None and not daily_df.empty:
        try:
            idx = daily_df.groupby("run_date")["total_hrs"].idxmax()
            for d, i in idx.items():
                row = daily_df.loc[i]
                top_job_per_day[str(d)] = str(row.get("Job_Name", "?"))
        except Exception:
            pass

    # Serialize the daily time-series window
    window_records = []
    elapsed_avail_local = bool(m.get("elapsed_available"))
    for _, r in window_df.iterrows():
        date_str = str(r["run_date"])
        elapsed_hrs = round(float(r.get("elapsed_hrs", 0)), 3)
        total_hrs   = round(float(r["total_hrs"]), 3)
        # Wall-clock breach when elapsed available; fall back to summed total only
        # when End_Time is missing (sum becomes an upper-bound proxy).
        if elapsed_avail_local:
            is_breach = elapsed_hrs > m["sla_ceiling"]
        else:
            is_breach = total_hrs   > m["sla_ceiling"]
        window_records.append({
            "run_date":     date_str,
            "total_hrs":    total_hrs,
            "elapsed_hrs":  elapsed_hrs,
            "job_count":    int(r["job_count"]),
            "breach":       bool(is_breach),
            "top_job":      top_job_per_day.get(date_str, ""),
        })

    # RULE 6 — include Sub_Application so findings engine can use composite key
    # sla_hrs / sla_source must be included so the frontend can show per-job ceiling
    _job_cols = [c for c in ["Sub_Application", "Job_Name", "peak_hrs", "avg_hrs",
                              "total_hrs", "sla_hrs", "sla_source",
                              "buffer_pct", "sla_used_pct", "buffer_status",
                              "fail_count"]
                 if c in top_jobs_df.columns]

    return {
        "kpis": {
            "compliance_pct":     m["compliance"],
            "job_sla_compliance":     m["job_sla_compliance"],
            "batch_window_compliance": m["batch_window_compliance"],
            "window_breach_days":      m["window_breach_days"],
            "window_total_days":       m["window_total_days"],
            "total_runs":         m["total_runs"],
            "total_jobs":         m["total_jobs"],
            "total_hrs":          m["total_hrs"],
            "jobs_breach":        m["jobs_breach"],
            "jobs_at_risk":       m["jobs_at_risk"],
            "jobs_ok":            m["jobs_ok"],
            # Execution-status counters (ENDED OK vs ENDED NOT OK)
            "ok_runs":            int(m.get("ok_runs", 0)),
            "failed_runs":        int(m.get("fail_runs", 0)),
            "fail_rate_pct":      round(
                (m.get("fail_runs", 0) / m["total_runs"] * 100.0)
                if m.get("total_runs") else 0.0, 2,
            ),
            "daily_limit_hrs":    m["sla_ceiling"],
            "monthly_limit_hrs":  pe_config.SLA_MONTHLY_HRS,
            "fleet_sla_buffer":   m["fleet_sla_buffer"],
        },
        # ── Separated analysis layers ────────────────────────────
        "elapsed_window": {
            "available":    m["elapsed_available"],
            "worst_day":    _worst_elapsed(window_records),
            "avg_elapsed_hrs": round(
                sum(w["elapsed_hrs"] for w in window_records) / max(len(window_records), 1), 3
            ) if m["elapsed_available"] else None,
            "note": (
                "Elapsed window = wall-clock from first Start_Time to last End_Time per day."
                if m["elapsed_available"]
                else "End_Time column missing — elapsed window cannot be computed. "
                     "Showing summed runtime only."
            ),
        },
        "summed_runtime": {
            "total_hrs":    m["total_hrs"],
            "worst_day_hrs": round(max((w["total_hrs"] for w in window_records), default=0.0), 3),
            "avg_day_hrs":  round(
                sum(w["total_hrs"] for w in window_records) / max(len(window_records), 1), 3
            ),
            "note": "Summed runtime = sum of all individual job Run_Sec values per day.",
        },
        "worst_job": _build_worst_job(m, top_jobs_df),
        # ── SLA source metadata ──────────────────────────────────
        "sla_source": _build_sla_source_payload(m),
        # ── Data coverage & confidence ───────────────────────────
        "data_coverage": {
            "date_span_days":   m["date_span_days"],
            "date_range":       m["date_range"],
            "total_runs":       m["total_runs"],
            "ok_runs":          m["ok_runs"],
            "fail_runs":        m["fail_runs"],
            "has_end_time":     m["elapsed_available"],
            "has_status":       m["ok_runs"] + m["fail_runs"] > 0,
            "has_sub_app":      any(s.get("Sub_Application", "UNKNOWN") != "UNKNOWN"
                                   for s in sub_df.to_dict(orient="records")),
            "confidence":       m["confidence"],
            "confidence_label": (
                "HIGH" if m["confidence"] >= 80 else
                "MEDIUM" if m["confidence"] >= 60 else
                "LOW" if m["confidence"] >= 40 else "INSUFFICIENT"
            ),
            "warnings":         _build_data_warnings(m),
        },
        "top_jobs":     top15_df[_job_cols].to_dict(orient="records"),
        "top_breaches": breaches_df[_job_cols].to_dict(orient="records"),
        "window":       window_records,
        "sub_stats":    sub_df.round({"total_hrs": 2}).to_dict(orient="records"),
        "anomalies":    m["anomalies"],
        "hourly_counts": _build_hourly_counts(df),
        "sla_heatmap":  _build_sla_heatmap(m["daily"], ceiling=m.get("sla_ceiling")),
        "hour_heatmap": _build_hour_heatmap(df),
        "daily_jobs":   _build_daily_jobs(df),
    }


def _build_daily_jobs(df: pd.DataFrame) -> Dict[str, list]:
    """Build per-day list of {job, start_hr, end_hr} for the concurrency
    timeline (Gantt) chart. start_hr / end_hr are decimal hours-of-day
    (e.g. 21.5 = 9:30 PM). End_Time is required — when missing, we fall
    back to start_hr + Run_Sec/3600.

    Returns: { "YYYY-MM-DD": [ {job, start_hr, end_hr}, ... ] }
    """
    if df is None or df.empty or "Start_Time" not in df.columns:
        return {}
    work = df.copy()
    work["Start_Time"] = pd.to_datetime(work["Start_Time"], errors="coerce")
    work = work.dropna(subset=["Start_Time"])
    if work.empty:
        return {}
    has_end = "End_Time" in work.columns
    if has_end:
        work["End_Time"] = pd.to_datetime(work["End_Time"], errors="coerce")

    out: Dict[str, list] = {}
    for _, r in work.iterrows():
        start = r["Start_Time"]
        if pd.isna(start):
            continue
        start_hr = start.hour + start.minute / 60.0 + start.second / 3600.0
        end = r.get("End_Time") if has_end else None
        if pd.isna(end) or end is None:
            run_sec = float(r.get("Run_Sec") or 0)
            end_hr = start_hr + run_sec / 3600.0
        else:
            # If job spans midnight, project end to start_hr + duration so the
            # Gantt bar stays on a single timeline.
            duration = (end - start).total_seconds() / 3600.0
            end_hr = start_hr + max(duration, 0)
        date_key = str(start.date())
        out.setdefault(date_key, []).append({
            "job":      str(r.get("Job_Name") or "?"),
            "start_hr": round(start_hr, 2),
            "end_hr":   round(end_hr, 2),
        })
    # Cap each day at 60 jobs (the chart only displays top 15 anyway, server
    # already sorts; this keeps payload size bounded).
    for k in list(out.keys()):
        if len(out[k]) > 60:
            out[k] = sorted(out[k], key=lambda j: j["end_hr"], reverse=True)[:60]
    return out


def _worst_elapsed(window_records: list) -> dict | None:
    """Find the day with the highest elapsed window."""
    elapsed_days = [w for w in window_records if w.get("elapsed_hrs", 0) > 0]
    if not elapsed_days:
        return None
    worst = max(elapsed_days, key=lambda w: w["elapsed_hrs"])
    return {"run_date": worst["run_date"], "elapsed_hrs": worst["elapsed_hrs"]}


def _build_data_warnings(m: dict) -> list:
    """Generate human-readable warnings about data quality issues."""
    warnings = []
    if not m["elapsed_available"]:
        warnings.append({
            "code": "NO_END_TIME",
            "text": "End_Time column missing — cannot compute real elapsed batch window. "
                    "Only summed job runtime is available.",
            "severity": "warning",
        })
    if m["date_span_days"] < 7:
        warnings.append({
            "code": "SHORT_HISTORY",
            "text": f"Only {m['date_span_days']} day(s) of batch data. "
                    "30+ days recommended for PE audit evidence.",
            "severity": "warning",
        })
    elif m["date_span_days"] < 30:
        warnings.append({
            "code": "PARTIAL_HISTORY",
            "text": f"{m['date_span_days']} days of data loaded. "
                    "30-day history recommended for full PE audit coverage.",
            "severity": "info",
        })
    if m["confidence"] < 60:
        warnings.append({
            "code": "LOW_CONFIDENCE",
            "text": f"Data confidence is {m['confidence']:.0f}% — "
                    "some metrics may not be fully reliable. Check source file completeness.",
            "severity": "warning",
        })
    if m["sla_source"] == "default":
        warnings.append({
            "code": "DEFAULT_SLA",
            "text": f"Using default SLA of {pe_config.SLA_DAILY_HRS:.1f}h. "
                    "Upload customer SLA matrix for accurate compliance measurement.",
            "severity": "info",
        })
    return warnings


def _build_sla_source_payload(m: dict) -> dict:
    """Build the SLA source metadata payload.

    Reads SLA intelligence from config_store AND the live sla_index produced
    by compute_metrics → build_sla_index → resolve_sla.  Emits match-quality
    statistics (how many jobs matched by exact / env-prefix / token-overlap /
    schedule fallback / assumed default) so the UI can show audit quality.
    """
    sla_index = m.get("_sla_index") or {}
    sla_type  = sla_index.get("source") or m.get("sla_source", "default")
    job_sla   = sla_index.get("job_sla", {})

    # Try to read rich SLA intelligence from config_store
    try:
        from services import config_store as _cs
        intel = _cs.get("_sla_intelligence")
    except Exception:
        intel = None

    base: dict = {
        "type":        sla_type,
        "daily_hrs":   m.get("sla_daily_hrs") or pe_config.SLA_DAILY_HRS,
        "weekly_hrs":  pe_config.SLA_WEEKLY_HRS,
        "monthly_hrs": pe_config.SLA_MONTHLY_HRS,
        "custom_hrs":  pe_config.SLA_CUSTOM_HRS,
    }

    # ── Match quality statistics ──────────────────────────────────────────────
    if job_sla:
        src_counts: dict = {}
        for entry in job_sla.values():
            s = entry.get("source", "default")
            src_counts[s] = src_counts.get(s, 0) + 1

        base["match_stats"] = {
            "total_jobs":      len(job_sla),
            "sla_matrix":      src_counts.get("sla_matrix", 0),
            "customer_fallback": src_counts.get("customer_fallback", 0),
            "assumed":         src_counts.get("assumed", 0),
            "default":         src_counts.get("default", 0),
        }
        # Per-job SLA resolution detail for audit trail (capped at 50 for payload size)
        base["job_sla_resolved"] = [
            {
                "job":        k,
                "sla_hrs":    v.get("sla_hrs"),
                "source":     v.get("source"),
                "confidence": v.get("confidence"),
                "detail":     v.get("detail"),
            }
            for k, v in list(job_sla.items())[:50]
        ]
    else:
        base["match_stats"] = {
            "total_jobs": 0, "sla_matrix": 0,
            "customer_fallback": 0, "assumed": 0, "default": 0,
        }
        base["job_sla_resolved"] = []

    if intel and isinstance(intel, dict):
        base["schema_type"]        = intel.get("schema_type", "unknown")
        base["detected_model"]     = intel.get("detected_model", "")
        base["valid_rows"]         = intel.get("valid_rows", 0)
        base["partial_rows"]       = intel.get("partial_rows", 0)
        base["total_rows"]         = intel.get("total_rows", 0)
        base["contracts"]          = intel.get("contracts", [])[:20]
        base["warnings"]           = intel.get("warnings", [])
        base["sections_detected"]  = intel.get("sections_detected", [])
        base["filename"]           = intel.get("filename", "")
        base["blocked"]            = intel.get("valid_rows", 0) == 0

        matched_jobs = base["match_stats"]["sla_matrix"]
        total_jobs   = base["match_stats"]["total_jobs"]
        assumed_jobs = base["match_stats"]["assumed"] + base["match_stats"]["default"]
        base["note"] = (
            f"SLA from '{intel.get('filename', '?')}' — "
            f"{intel.get('detected_model', 'unknown model')} · "
            f"{intel.get('valid_rows', 0)} contract rules · "
            f"{matched_jobs}/{total_jobs} jobs matched by name"
            + (f" ({assumed_jobs} using assumed defaults)" if assumed_jobs else "")
        )
    else:
        base["schema_type"]    = "none"
        base["detected_model"] = "Default system values"
        base["contracts"]      = []
        base["warnings"] = [{
            "code":     "NO_SLA_FILE",
            "text":     "No SLA matrix uploaded — compliance uses assumed defaults.",
            "severity": "critical" if sla_type == "default" else "info",
        }] if sla_type == "default" else []
        base["blocked"] = (sla_type == "default")
        base["note"] = (
            "Using default SLA windows from system configuration. "
            "Upload a customer SLA matrix to override."
            if sla_type == "default"
            else "Using customer-approved SLA windows from uploaded matrix."
        )

    return base
