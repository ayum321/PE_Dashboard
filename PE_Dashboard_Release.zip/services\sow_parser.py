"""
SOW (Statement of Work) volume targets parser.
Extracts PE volume metrics from PDF/DOCX using Gemini AI + regex fallback.
"""
from __future__ import annotations
import io
import json
import re
from typing import Any, Dict

_METRIC_LABELS = {
    "daily_dfu":         "Daily DFU (Demand Fulfillment Units)",
    "daily_sku":         "Daily SKU Count",
    "daily_orders":      "Daily Orders / Transactions",
    "batch_jobs":        "Daily Batch Jobs",
    "peak_users":        "Peak Concurrent Users",
    "data_volume_gb":    "Daily Data Volume (GB)",
    "cpu_baseline_pct":  "CPU Utilisation Baseline (%)",
    "mem_baseline_pct":  "Memory Utilisation Baseline (%)",
    "disk_baseline_pct": "Disk Utilisation Baseline (%)",
}

def parse_sow_volumes(raw_bytes: bytes, filename: str, api_key: str = "") -> Dict[str, Any]:
    """Extract volume targets from a SOW document. Returns {key: float} dict."""
    text = _extract_text(raw_bytes, filename)
    if api_key and text:
        try:
            return _gemini_extract(text[:6000], api_key)
        except Exception:
            pass
    return _regex_extract(text)


def _extract_text(raw_bytes: bytes, filename: str) -> str:
    ext = (filename or "").lower().rsplit(".", 1)[-1]
    try:
        if ext == "pdf":
            import fitz
            doc = fitz.open(stream=raw_bytes, filetype="pdf")
            return "\n".join(page.get_text() for page in doc)
        elif ext in ("docx", "doc"):
            from docx import Document
            doc = Document(io.BytesIO(raw_bytes))
            return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        else:
            return raw_bytes.decode("utf-8", errors="replace")
    except Exception:
        return raw_bytes.decode("utf-8", errors="replace")[:10000]


def _regex_extract(text: str) -> Dict[str, Any]:
    t = text.lower()
    patterns = {
        "daily_dfu":         r"(?:daily\s+)?dfu[\s:=]+(\d[\d,\.]*)",
        "daily_sku":         r"(?:daily\s+)?sku[\s:=]+(\d[\d,\.]*)",
        "daily_orders":      r"(?:daily\s+)?orders?[\s:=]+(\d[\d,\.]*)",
        "batch_jobs":        r"batch\s+jobs?[\s:=]+(\d[\d,\.]*)",
        "peak_users":        r"(?:peak|concurrent)\s+users?[\s:=]+(\d[\d,\.]*)",
        "data_volume_gb":    r"data\s+volume[\s:=]+(\d[\d,\.]*)\s*gb",
        "cpu_baseline_pct":  r"cpu[\s:=]+(\d[\d,\.]*)\s*%",
        "mem_baseline_pct":  r"mem(?:ory)?[\s:=]+(\d[\d,\.]*)\s*%",
        "disk_baseline_pct": r"disk[\s:=]+(\d[\d,\.]*)\s*%",
    }
    result: Dict[str, Any] = {}
    for key, pattern in patterns.items():
        m = re.search(pattern, t, re.IGNORECASE)
        if m:
            try:
                result[key] = float(m.group(1).replace(",", ""))
            except Exception:
                pass
    return result


def _gemini_extract(text: str, api_key: str) -> Dict[str, Any]:
    prompt = f"""You are a performance engineering consultant. Extract volume targets from this Statement of Work (SOW) document.

Return ONLY valid JSON with these exact keys (use null for missing values):
{{
  "daily_dfu": <number or null>,
  "daily_sku": <number or null>,
  "daily_orders": <number or null>,
  "batch_jobs": <number or null>,
  "peak_users": <number or null>,
  "data_volume_gb": <number or null>,
  "cpu_baseline_pct": <number or null>,
  "mem_baseline_pct": <number or null>,
  "disk_baseline_pct": <number or null>
}}

SOW TEXT:
{text}

JSON only, no explanation:"""

    # Try new SDK first
    try:
        from google import genai as _genai
        client = _genai.Client(api_key=api_key)
        response = client.models.generate_content(model="gemini-2.0-flash", contents=prompt)
        raw = response.text.strip()
    except ImportError:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-2.0-flash-001")
        raw = model.generate_content(prompt).text.strip()

    # Parse JSON from response
    m = re.search(r'\{[\s\S]*?\}', raw)
    if m:
        data = json.loads(m.group())
    else:
        data = json.loads(raw)

    # Remove null values
    return {k: float(v) for k, v in data.items() if v is not None}
