"""
Socket-polling browser auto-launcher for the PE Dashboard.

Waits until the FastAPI server is accepting TCP connections on the
configured host:port, then opens the dashboard URL in the default
browser (Chrome on Windows). Designed to be spawned in parallel with
`uvicorn` from start.bat.

Usage:
    python _open_browser.py [host] [port]
        host  default 127.0.0.1
        port  default 8765
"""
from __future__ import annotations

import socket
import sys
import time
import webbrowser

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8765
POLL_INTERVAL_SEC = 0.25
TIMEOUT_SEC = 30.0


def wait_for_port(host: str, port: int, timeout: float = TIMEOUT_SEC) -> bool:
    """Block until <host>:<port> accepts a TCP connection or timeout elapses."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=1.0):
                return True
        except (OSError, ConnectionRefusedError):
            time.sleep(POLL_INTERVAL_SEC)
    return False


def main() -> int:
    host = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_HOST
    port = int(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_PORT
    url = f"http://{host}:{port}/"

    print(f"[browser] waiting for server on {host}:{port} ...")
    if not wait_for_port(host, port):
        print(f"[browser] timeout — server did not start within {TIMEOUT_SEC}s")
        return 1

    print(f"[browser] server is up — opening {url}")
    try:
        webbrowser.open(url, new=2)
    except Exception as exc:
        print(f"[browser] failed to open browser: {exc}")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
