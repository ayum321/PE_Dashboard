"""
pe_config.py — Single source of truth for all PE Dashboard thresholds and settings.

Adapts the user's pe_config.py blueprint for the FastAPI (non-Streamlit) stack.
Reads from:
  1. .pe_config.json  (persistent config via config_store)
  2. Environment variables (GEMINI_API_KEY / GOOGLE_API_KEY)
  3. Hardcoded defaults (last resort)

Usage:
    from services import pe_config
    if cpu_value > pe_config.CPU_CRIT: ...
    pe_config.reload()  # re-read from disk after settings change
"""
from __future__ import annotations

from typing import Any

# ── Internal import (lazy to avoid circular) ─────────────────────────────────
def _cfg(key: str, default: Any = None) -> Any:
    """Read a value from config_store with fallback."""
    try:
        from services import config_store
        return config_store.get(key, default)
    except Exception:
        return default


# ── Vision provider ───────────────────────────────────────────────────────────
VISION_PROVIDER: str = "gemini"   # "gemini" | "azure" | "local"


# ── CPU thresholds (%) ────────────────────────────────────────────────────────
@property
def _cpu_warn(self) -> float:
    return float(_cfg("cpu_warning",  75.0))


# Use module-level constants (re-read live via reload() below)
CPU_WARN:  float = 75.0   # Warning band
CPU_CRIT:  float = 90.0   # Critical — rule engine fires

# ── Memory thresholds (%) ─────────────────────────────────────────────────────
MEM_WARN:  float = 70.0
MEM_CRIT:  float = 80.0

# ── Disk thresholds (%) ───────────────────────────────────────────────────────
DISK_WARN: float = 70.0
DISK_CRIT: float = 85.0

# ── Batch quality thresholds ──────────────────────────────────────────────────
BATCH_FAIL_RATE:  float = 5.0    # % failure rate above which rule R4 fires
ZERO_DUR_FLAG:    bool  = True   # Flag zero-duration jobs in findings

# ── SLA windows (hours) ──────────────────────────────────────────────
# Generic configurable defaults — NEVER hardcode 5 / 3.5 / 8 anywhere else.
# Override via Settings → config_store keys: daily_sla_hrs, weekly_sla_hrs,
# biweekly_sla_hrs, monthly_sla_hrs, custom_sla_hrs.
SLA_DEFAULTS: dict[str, float] = {
    "daily":    6.0,
    "weekly":   17.0,
    "biweekly": 17.0,
    "monthly":  17.0,
    "custom":   6.0,
}
SLA_DAILY_HRS:    float = SLA_DEFAULTS["daily"]
SLA_WEEKLY_HRS:   float = SLA_DEFAULTS["weekly"]
SLA_BIWEEKLY_HRS: float = SLA_DEFAULTS["biweekly"]
SLA_MONTHLY_HRS:  float = SLA_DEFAULTS["monthly"]
SLA_CUSTOM_HRS:   float = SLA_DEFAULTS["custom"]
SLA_BUFFER_WARN:  float = 15.0   # % buffer below which job is AT_RISK

# ── Benchmark ─────────────────────────────────────────────────────────────────
BENCH_THRESHOLD_PCT: float = 10.0   # % degradation → RED

# ── SOW baseline targets ──────────────────────────────────────────────────────
SOW_DFU:           float = 499_999.0
SOW_SKU:           float = 80_000.0
SOW_ORDERS:        float = 200_000.0
SOW_BATCH_JOBS:    float = 450.0


def reload() -> None:
    """
    Re-read all threshold values from config_store (disk).
    Call this after a Settings save to make the new values live immediately.
    """
    global CPU_WARN, CPU_CRIT, MEM_WARN, MEM_CRIT, DISK_WARN, DISK_CRIT
    global BATCH_FAIL_RATE, ZERO_DUR_FLAG
    global SLA_DAILY_HRS, SLA_WEEKLY_HRS, SLA_BIWEEKLY_HRS, SLA_MONTHLY_HRS, SLA_CUSTOM_HRS, SLA_BUFFER_WARN
    global BENCH_THRESHOLD_PCT
    global SOW_DFU, SOW_SKU, SOW_ORDERS, SOW_BATCH_JOBS

    CPU_WARN          = float(_cfg("cpu_warning",       75.0))
    CPU_CRIT          = float(_cfg("cpu_critical",      90.0))
    MEM_WARN          = float(_cfg("mem_warning",       70.0))
    MEM_CRIT          = float(_cfg("mem_critical",      80.0))
    DISK_WARN         = float(_cfg("disk_warning",      70.0))
    DISK_CRIT         = float(_cfg("disk_critical",     85.0))
    BATCH_FAIL_RATE   = float(_cfg("batch_fail_rate",   5.0))
    ZERO_DUR_FLAG     = bool (_cfg("zero_dur_flag",     True))
    SLA_DAILY_HRS     = float(_cfg("daily_sla_hrs",     SLA_DEFAULTS["daily"]))
    SLA_WEEKLY_HRS    = float(_cfg("weekly_sla_hrs",    SLA_DEFAULTS["weekly"]))
    SLA_BIWEEKLY_HRS  = float(_cfg("biweekly_sla_hrs",  SLA_DEFAULTS["biweekly"]))
    SLA_MONTHLY_HRS   = float(_cfg("monthly_sla_hrs",   SLA_DEFAULTS["monthly"]))
    SLA_CUSTOM_HRS    = float(_cfg("custom_sla_hrs",    SLA_DEFAULTS["custom"]))
    SLA_BUFFER_WARN   = float(_cfg("sla_buffer_warn",   15.0))
    BENCH_THRESHOLD_PCT = float(_cfg("benchmark_threshold", 10.0))
    SOW_DFU           = float(_cfg("sow_dfu",           499_999.0))
    SOW_SKU           = float(_cfg("sow_sku",           80_000.0))
    SOW_ORDERS        = float(_cfg("sow_orders",        200_000.0))
    SOW_BATCH_JOBS    = float(_cfg("sow_batch_jobs",    450.0))


def status_label(val: float | None, warn: float, crit: float) -> str:
    """Return 'CRITICAL' | 'WARNING' | 'OK' | 'UNKNOWN'."""
    if val is None:
        return "UNKNOWN"
    if val >= crit:
        return "CRITICAL"
    if val >= warn:
        return "WARNING"
    return "OK"


def format_pct(val: float | None, warn: float, crit: float) -> str:
    """Format a percentage with emoji status prefix."""
    icons = {"CRITICAL": "🔴", "WARNING": "🟡", "OK": "🟢", "UNKNOWN": "–"}
    st = status_label(val, warn, crit)
    if val is None:
        return "–"
    return f"{icons[st]} {val:.1f}%"


# ── Initialise from disk on module import ─────────────────────────────────────
try:
    reload()
except Exception:
    pass  # safe — defaults already set above
