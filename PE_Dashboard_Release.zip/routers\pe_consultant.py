"""
Senior PE Consultant — cross-pillar interconnection engine.

POST /api/pe-consultant
    Takes the outputs of the three operational pillars:
      - SLA Matrix     (/api/sla-matrix     or /api/sla-matrix/json)
      - PE Findings    (/api/generate-findings)
      - Red Flags & RCA (/api/red-flags)
    plus the supporting batch + resource context, and returns:

      1. cross_links — deterministic linkage between pillars
         (same job / sub-app / host appearing in 2+ pillars)
      2. evidence_chain — per-job audit trail across pillars
      3. consultant — LLM-driven Senior PE Consultant verdict
         (Grade, Score, Decision, top risks, predictions, next actions)
      4. accuracy   — self-check signal: confidence + missing inputs

The endpoint is read-only over the three pillar payloads. It does not
re-run the underlying calculators — the upstream results are the
single source of truth.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional

from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict

from services.pe_utils import coerce_float as _f, coerce_int as _i

router = APIRouter()


# ── Request / Response models ───────────────────────────────────

class PeConsultantRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    # Pillar outputs
    sla_matrix: Optional[Dict[str, Any]] = None   # /api/sla-matrix response
    findings:   Optional[Dict[str, Any]] = None   # /api/generate-findings response
    red_flags:  Optional[Dict[str, Any]] = None   # /api/red-flags response

    # Supporting context (so consultant can reason about scale + infra)
    batch_kpis:    Optional[Dict[str, Any]]       = None
    top_jobs:      Optional[List[Dict[str, Any]]] = None
    top_breaches:  Optional[List[Dict[str, Any]]] = None
    resource_kpis: Optional[Dict[str, Any]]       = None
    servers:       Optional[List[Dict[str, Any]]] = None
    customer_name: Optional[str]                  = None


class CrossLink(BaseModel):
    """A single piece of evidence that appears in two or more pillars."""
    entity:        str               # job name / host / sub-app
    entity_kind:   str               # "job" | "host" | "sub_application"
    pillars:       List[str]         # subset of: ["sla","findings","redflags"]
    sla_evidence:       Optional[Dict[str, Any]] = None  # {peak_hrs, sla_limit_hrs, status, breach_margin}
    findings_evidence:  Optional[List[Dict[str, Any]]] = None  # [{level, text, source}]
    redflags_evidence:  Optional[List[Dict[str, Any]]] = None  # [{id, risk, category, question}]
    severity:      str               # CRITICAL | HIGH | MEDIUM | LOW
    confidence:    int               # 0..100


class EvidenceChain(BaseModel):
    job_name:      str
    sub_application: Optional[str] = None
    chain:         List[Dict[str, Any]]   # ordered narrative steps
    verdict:       str                    # e.g. "Confirmed runtime breach + at-risk infra"


class ConsultantVerdict(BaseModel):
    grade:        str = "—"
    score:        float = 0.0
    decision:     str = "INSUFFICIENT_DATA"   # GO | HOLD | REMEDIATE | INSUFFICIENT_DATA
    headline:     str = ""
    top_risks:    List[str] = []
    predictions:  List[str] = []
    next_actions: List[str] = []
    narrative:    str = ""
    model:        str = ""
    # Agentic upgrade — list of tool calls the LLM made to gather evidence,
    # so the UI can show *why* the verdict reads the way it does.
    agent_trace:  List[Dict[str, Any]] = []
    tool_count:   int = 0


class AccuracySignal(BaseModel):
    pillars_loaded:  Dict[str, bool]
    coverage_pct:    int
    confidence:      int
    missing_inputs:  List[str]
    notes:           List[str]


class PeConsultantResponse(BaseModel):
    cross_links:    List[CrossLink]
    evidence_chain: List[EvidenceChain]
    consultant:     ConsultantVerdict
    accuracy:       AccuracySignal


# ── Helpers ─────────────────────────────────────────────────────

def _norm(name: Any) -> str:
    return str(name or "").strip().upper()


def _index_findings_by_job(findings: List[Dict[str, Any]],
                           job_names: set[str]) -> Dict[str, List[Dict[str, Any]]]:
    """Match findings whose text/sub mentions any job in `job_names`."""
    idx: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for f in findings:
        blob = (f.get("text", "") + " " + f.get("sub", "")).upper()
        for jn in job_names:
            if jn and jn in blob:
                idx[jn].append({
                    "level":  f.get("level"),
                    "text":   f.get("text"),
                    "source": f.get("source"),
                })
    return idx


def _index_redflags_by_job(flags: List[Dict[str, Any]],
                           job_names: set[str]) -> Dict[str, List[Dict[str, Any]]]:
    idx: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for fl in flags:
        blob = (fl.get("context", "") + " " + fl.get("data_point", "")).upper()
        for jn in job_names:
            if jn and jn in blob:
                idx[jn].append({
                    "id":       fl.get("id"),
                    "risk":     fl.get("risk"),
                    "category": fl.get("category"),
                    "question": fl.get("question"),
                })
    return idx


def _index_findings_by_host(findings: List[Dict[str, Any]],
                            hosts: set[str]) -> Dict[str, List[Dict[str, Any]]]:
    idx: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for f in findings:
        blob = (f.get("text", "") + " " + f.get("sub", "")).upper()
        for h in hosts:
            if h and h in blob:
                idx[h].append({
                    "level":  f.get("level"),
                    "text":   f.get("text"),
                    "source": f.get("source"),
                })
    return idx


def _index_redflags_by_host(flags: List[Dict[str, Any]],
                            hosts: set[str]) -> Dict[str, List[Dict[str, Any]]]:
    idx: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for fl in flags:
        blob = (fl.get("context", "") + " " + fl.get("data_point", "")).upper()
        for h in hosts:
            if h and h in blob:
                idx[h].append({
                    "id":       fl.get("id"),
                    "risk":     fl.get("risk"),
                    "category": fl.get("category"),
                    "question": fl.get("question"),
                })
    return idx


def _severity_from_status(status: str, fl_max: str, fd_max: str) -> str:
    order = {"CRITICAL": 4, "HIGH": 3, "BREACH": 4, "AT_RISK": 3,
             "MEDIUM": 2, "WARNING": 2, "LOW": 1, "INFO": 1, "OK": 0}
    sev = max(order.get(status.upper(), 0),
              order.get(fl_max.upper(), 0),
              order.get(fd_max.upper(), 0))
    if sev >= 4: return "CRITICAL"
    if sev == 3: return "HIGH"
    if sev == 2: return "MEDIUM"
    return "LOW"


def _build_cross_links(req: PeConsultantRequest) -> tuple[list[CrossLink], list[EvidenceChain]]:
    sla = req.sla_matrix or {}
    findings_resp = req.findings or {}
    rf_resp = req.red_flags or {}

    sla_breaches = sla.get("breaches") or []
    sla_jobs     = sla.get("job_summary") or []
    findings_list = findings_resp.get("findings") or []
    rf_list = rf_resp.get("flags") or []

    # Collect candidate jobs from SLA matrix (breach + at-risk)
    job_breach_map: Dict[str, Dict[str, Any]] = {}
    for b in sla_breaches:
        nm = _norm(b.get("job_name"))
        if not nm:
            continue
        prev = job_breach_map.get(nm)
        if not prev or _f(b.get("run_hrs")) > _f(prev.get("run_hrs")):
            job_breach_map[nm] = b

    # Also pull worst peak per job from job_summary if not in breaches
    for js in sla_jobs:
        nm = _norm(js.get("job_name"))
        if not nm or nm in job_breach_map:
            continue
        if _i(js.get("breach_runs")) > 0 or _i(js.get("atrisk_runs")) > 0:
            job_breach_map[nm] = {
                "job_name":          js.get("job_name"),
                "sub_application":   "",
                "run_hrs":           js.get("peak_hrs"),
                "sla_limit_hrs":     sla.get("sla_limit_hrs"),
                "breach_margin_hrs": _f(js.get("peak_hrs")) - _f(sla.get("sla_limit_hrs")),
                "status":            "BREACH" if _i(js.get("breach_runs")) > 0 else "AT_RISK",
            }

    job_keys = set(job_breach_map.keys())
    fidx_jobs = _index_findings_by_job(findings_list, job_keys)
    ridx_jobs = _index_redflags_by_job(rf_list, job_keys)

    cross: list[CrossLink] = []
    chains: list[EvidenceChain] = []

    for jn, b in job_breach_map.items():
        fevd = fidx_jobs.get(jn) or []
        revd = ridx_jobs.get(jn) or []
        pillars = ["sla"]
        if fevd: pillars.append("findings")
        if revd: pillars.append("redflags")

        # Only include cross-links that actually appear in ≥2 pillars
        if len(pillars) < 2:
            continue

        fl_max = max((x.get("risk", "LOW") for x in revd), default="LOW")
        fd_max = max((x.get("level", "info").upper() for x in fevd), default="INFO")
        # Map finding level → risk-ish word
        if fd_max == "CRITICAL": fd_max = "CRITICAL"
        elif fd_max == "WARNING": fd_max = "MEDIUM"
        else: fd_max = "LOW"

        sev = _severity_from_status(b.get("status", ""), fl_max, fd_max)

        cross.append(CrossLink(
            entity=b.get("job_name") or jn,
            entity_kind="job",
            pillars=pillars,
            sla_evidence={
                "peak_hrs":          _f(b.get("run_hrs")),
                "sla_limit_hrs":     _f(b.get("sla_limit_hrs")),
                "status":            b.get("status"),
                "breach_margin_hrs": _f(b.get("breach_margin_hrs")),
                "sub_application":   b.get("sub_application", ""),
            },
            findings_evidence=fevd or None,
            redflags_evidence=revd or None,
            severity=sev,
            confidence=90 if len(pillars) == 3 else 75,
        ))

        # Evidence chain narrative
        chain_steps = [
            {"pillar": "SLA Matrix",
             "fact":  f"{b.get('status')} — peak {_f(b.get('run_hrs')):.2f}h vs "
                      f"{_f(b.get('sla_limit_hrs')):.1f}h SLA "
                      f"(margin {_f(b.get('breach_margin_hrs')):+.2f}h)"},
        ]
        for fe in fevd[:2]:
            chain_steps.append({"pillar": f"Finding · {fe.get('level','').upper()}",
                                "fact": fe.get("text", "")})
        for re in revd[:2]:
            chain_steps.append({"pillar": f"Red Flag {re.get('id','')} · {re.get('risk','')}",
                                "fact": re.get("question", "")})

        verdict_word = "Confirmed cross-pillar risk" if len(pillars) == 3 else "Two-pillar evidence"
        chains.append(EvidenceChain(
            job_name=b.get("job_name") or jn,
            sub_application=b.get("sub_application") or None,
            chain=chain_steps,
            verdict=f"{verdict_word} — severity {sev}",
        ))

    # ── Host-level cross-links ───────────────────────────────────
    hosts = {_norm(s.get("host")) for s in (req.servers or []) if s.get("host")}
    hot_hosts = {
        _norm(s.get("host")) for s in (req.servers or [])
        if _f(s.get("cpu_used")) >= 80 or _f(s.get("mem_used")) >= 85
    }
    if hot_hosts:
        fidx_h = _index_findings_by_host(findings_list, hot_hosts)
        ridx_h = _index_redflags_by_host(rf_list, hot_hosts)
        for h in hot_hosts:
            fevd = fidx_h.get(h) or []
            revd = ridx_h.get(h) or []
            if not fevd and not revd:
                continue
            pillars = []
            if fevd: pillars.append("findings")
            if revd: pillars.append("redflags")
            if len(pillars) < 2:
                continue
            srv = next((s for s in (req.servers or []) if _norm(s.get("host")) == h), {})
            cross.append(CrossLink(
                entity=srv.get("host") or h,
                entity_kind="host",
                pillars=pillars,
                sla_evidence={
                    "cpu_used": _f(srv.get("cpu_used")),
                    "mem_used": _f(srv.get("mem_used")),
                    "role":     srv.get("type") or "",
                },
                findings_evidence=fevd or None,
                redflags_evidence=revd or None,
                severity=_severity_from_status(
                    "CRITICAL" if _f(srv.get("cpu_used")) >= 90 or _f(srv.get("mem_used")) >= 90 else "HIGH",
                    max((x.get("risk", "LOW") for x in revd), default="LOW"),
                    "CRITICAL" if any(x.get("level") == "critical" for x in fevd) else "MEDIUM",
                ),
                confidence=80,
            ))

    # Sort: severity then number of pillars
    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    cross.sort(key=lambda c: (sev_rank.get(c.severity, 9), -len(c.pillars)))
    return cross, chains


def _accuracy(req: PeConsultantRequest, cross: list[CrossLink]) -> AccuracySignal:
    pillars_loaded = {
        "sla":       bool((req.sla_matrix or {}).get("total_runs")),
        "findings":  bool((req.findings or {}).get("findings")),
        "redflags":  bool((req.red_flags or {}).get("flags")),
    }
    loaded_count = sum(1 for v in pillars_loaded.values() if v)
    coverage = int(loaded_count / 3 * 100)

    missing: list[str] = []
    if not pillars_loaded["sla"]:      missing.append("SLA Matrix not computed — run from SLA tab")
    if not pillars_loaded["findings"]: missing.append("PE Findings not generated")
    if not pillars_loaded["redflags"]: missing.append("Red Flags not generated")

    notes: list[str] = []
    if cross:
        notes.append(f"{len(cross)} cross-pillar link(s) — same evidence appears in ≥2 layers")
    else:
        if loaded_count == 3:
            notes.append("All three pillars loaded but no overlapping entities — consistent green signal")

    # Confidence: 100 only when all three pillars loaded AND batch confidence is high
    bk = req.batch_kpis or {}
    batch_conf = _i((bk.get("data_coverage") or {}).get("confidence"), 100)
    confidence = int(coverage * 0.6 + batch_conf * 0.4)

    return AccuracySignal(
        pillars_loaded=pillars_loaded,
        coverage_pct=coverage,
        confidence=confidence,
        missing_inputs=missing,
        notes=notes,
    )


def _build_digest(req: PeConsultantRequest, cross: list[CrossLink]) -> Dict[str, Any]:
    sla = req.sla_matrix or {}
    findings_resp = req.findings or {}
    rf_resp = req.red_flags or {}

    return {
        "customer": req.customer_name or "Unknown",
        "sla": {
            "mode":          sla.get("sla_mode"),
            "limit_hrs":     sla.get("sla_limit_hrs"),
            "compliance_pct":sla.get("compliance_pct"),
            "breach":        sla.get("breaching_runs"),
            "at_risk":       sla.get("at_risk_runs"),
            "ok":            sla.get("ok_runs"),
            "worst_job":     sla.get("worst_job"),
            "worst_hrs":     sla.get("worst_hrs"),
            "worst_margin":  sla.get("worst_margin_hrs"),
            "top_breaches":  (sla.get("breaches") or [])[:5],
        },
        "findings_summary": findings_resp.get("summary") or {},
        "top_findings": [
            {"level": f.get("level"), "text": f.get("text"),
             "source": f.get("source"), "recommendation": f.get("recommendation")}
            for f in (findings_resp.get("findings") or [])[:8]
            if f.get("level") in ("critical", "warning")
        ],
        "red_flags_by_risk": rf_resp.get("by_risk") or {},
        "top_red_flags": [
            {"id": fl.get("id"), "risk": fl.get("risk"),
             "category": fl.get("category"), "question": fl.get("question"),
             "context": fl.get("context")}
            for fl in (rf_resp.get("flags") or [])[:8]
            if fl.get("risk") in ("CRITICAL", "HIGH")
        ],
        "cross_links": [c.model_dump() for c in cross[:8]],
        "batch_kpis": {
            "compliance_pct": (req.batch_kpis or {}).get("compliance_pct"),
            "total_runs":     (req.batch_kpis or {}).get("total_runs"),
            "total_jobs":     (req.batch_kpis or {}).get("total_jobs"),
            "jobs_breach":    (req.batch_kpis or {}).get("jobs_breach"),
            "jobs_at_risk":   (req.batch_kpis or {}).get("jobs_at_risk"),
            "failed_runs":    (req.batch_kpis or {}).get("failed_runs"),
            "fail_rate_pct":  (req.batch_kpis or {}).get("fail_rate_pct"),
        },
        "fleet": {
            "grade":       (req.resource_kpis or {}).get("fleet_grade"),
            "score":       (req.resource_kpis or {}).get("fleet_score"),
            "n_critical":  (req.resource_kpis or {}).get("n_critical"),
            "n_warning":   (req.resource_kpis or {}).get("n_warning"),
            "total":       (req.resource_kpis or {}).get("total_servers"),
        },
    }


def _consultant_llm(digest: Dict[str, Any], accuracy: AccuracySignal) -> ConsultantVerdict:
    """Run Senior PE Consultant LLM. Falls back to deterministic verdict if AI unavailable."""
    try:
        from services.ai_engine import chat as _chat, is_ready
        ready = is_ready()
        ai_available = bool(ready.get("nvidia_key") or ready.get("gemini_key"))
    except Exception:
        ai_available = False

    # ── Deterministic baseline verdict (always computed) ──
    # Score: weighted compliance + finding criticals + red flag criticals
    sla_comp = _f(digest.get("sla", {}).get("compliance_pct"), 100.0)
    fc = _i((digest.get("findings_summary") or {}).get("critical"))
    fw = _i((digest.get("findings_summary") or {}).get("warning"))
    rfc = _i((digest.get("red_flags_by_risk") or {}).get("CRITICAL"))
    rfh = _i((digest.get("red_flags_by_risk") or {}).get("HIGH"))

    # Score 0..100
    score = sla_comp
    score -= fc * 6.0
    score -= fw * 1.5
    score -= rfc * 4.0
    score -= rfh * 1.5
    score = max(0.0, min(100.0, score))
    if   score >= 95: grade = "A"
    elif score >= 85: grade = "B"
    elif score >= 70: grade = "C"
    elif score >= 55: grade = "D"
    else:             grade = "F"

    if   score >= 90 and fc == 0 and rfc == 0: decision = "GO"
    elif score >= 75:                          decision = "HOLD"
    elif accuracy.coverage_pct < 67:           decision = "INSUFFICIENT_DATA"
    else:                                      decision = "REMEDIATE"

    # Top deterministic risks
    risks: list[str] = []
    for c in digest.get("cross_links", [])[:3]:
        risks.append(
            f"{c['entity']} ({c['entity_kind']}) — {c['severity']} across "
            f"{', '.join(c['pillars'])}"
        )
    if not risks:
        if rfc:
            risks.append(f"{rfc} CRITICAL red flag(s) without overlap with SLA breaches")
        if fc:
            risks.append(f"{fc} CRITICAL finding(s) require remediation")
        if not risks:
            risks.append("No CRITICAL cross-pillar risks detected")

    headline = (
        f"Grade {grade} · Score {score:.1f} · {decision} — "
        f"{len(digest.get('cross_links', []))} cross-pillar link(s), "
        f"{fc} critical finding(s), {rfc} critical red flag(s)"
    )

    next_actions_default = [
        "Resolve CRITICAL findings before any production-impacting change",
        "Address CRITICAL red flags with named owners and ETAs",
        "Re-run SLA Matrix after remediation to confirm compliance",
    ]
    predictions_default = [
        "If current trend persists, SLA breaches will recur within next batch cycle",
        "Cross-pillar links indicate compounding risk under peak load",
    ]

    if not ai_available:
        return ConsultantVerdict(
            grade=grade, score=round(score, 1), decision=decision,
            headline=headline,
            top_risks=risks,
            predictions=predictions_default,
            next_actions=next_actions_default,
            narrative=("AI provider not configured — deterministic Senior PE Consultant "
                       "scoring used. Configure NVIDIA NIM or Gemini key in Settings to "
                       "enable narrative analysis."),
            model="deterministic",
        )

    # ── LLM-driven Senior PE Consultant verdict ──
    system = (
        "You are a Senior Performance Engineering Consultant with 20+ years of "
        "experience auditing batch + infrastructure for Tier-1 enterprise customers. "
        "You write for a CTO and a PE lead. You quote exact numbers from the digest "
        "(no fabrication). You explicitly link findings, red flags, and SLA breaches "
        "by job/host name when possible. You state predictions with confidence levels. "
        "You separate measured facts from inference. You do not use filler language."
    )
    prompt = (
        "Three operational pillars (SLA Matrix, PE Findings, Red Flags) have been "
        "computed independently from real customer data. A deterministic cross-pillar "
        "linker has already identified entities that appear in 2+ pillars. "
        "Produce a Senior PE Consultant verdict in this exact structure:\n\n"
        "VERDICT: <one line, include grade and decision>\n"
        "TOP RISKS:\n"
        "  1. <risk> — evidence: <pillar references>\n"
        "  2. ...\n"
        "  3. ...\n"
        "PREDICTIONS (next 1-2 batch cycles, with confidence %):\n"
        "  - <prediction> [confidence X%]\n"
        "NEXT 48H ACTIONS (named owner role + concrete metric):\n"
        "  1. <action>\n"
        "  2. ...\n"
        "  3. ...\n"
        "ACCURACY NOTE: <1 line on data confidence and any missing inputs>\n\n"
        f"DIGEST:\n{digest}\n\n"
        f"ACCURACY SIGNAL: coverage={accuracy.coverage_pct}%, "
        f"confidence={accuracy.confidence}%, missing={accuracy.missing_inputs}"
    )

    try:
        # Agentic path — let the LLM call tools to fetch evidence directly
        # from session_cache (job history, host metrics, hottest hours, etc.)
        # so the verdict is grounded in row-level data instead of just the
        # pre-computed digest. Falls back to single-shot inside run_agent.
        from services.ai_agent import run_agent
        agent_trace: list = []
        tool_count = 0
        text, model, trace = run_agent(
            task=prompt,
            system=system + (
                "\n\nIMPORTANT: Before writing the verdict, call list_loaded_data, "
                "then drill into at least ONE concrete piece of evidence using "
                "get_breach_runs or get_resource_linked_runs or get_critical_servers, "
                "and quote those exact numbers in TOP RISKS."
            ),
            max_tokens=900, temperature=0.25,
        )
        agent_trace = trace
        tool_count  = sum(1 for t in trace if t.get("kind") == "tool_call")
    except Exception as exc:
        return ConsultantVerdict(
            grade=grade, score=round(score, 1), decision=decision,
            headline=headline, top_risks=risks,
            predictions=predictions_default, next_actions=next_actions_default,
            narrative=f"LLM unavailable ({exc}); deterministic scoring used.",
            model="deterministic",
        )

    # Parse the structured response into list fields (best effort)
    parsed_risks: list[str] = []
    parsed_preds: list[str] = []
    parsed_acts:  list[str] = []
    section = None
    for ln in (text or "").splitlines():
        s = ln.strip()
        if not s:
            continue
        u = s.upper()
        if u.startswith("TOP RISKS"):     section = "risks"; continue
        if u.startswith("PREDICTIONS"):   section = "preds"; continue
        if u.startswith("NEXT 48H") or u.startswith("NEXT ACTIONS"): section = "acts"; continue
        if u.startswith("ACCURACY NOTE") or u.startswith("VERDICT"): section = None; continue
        if section is None:
            continue
        # Strip bullet/number prefix
        clean = s.lstrip("0123456789.) -•").strip()
        if not clean:
            continue
        if section == "risks" and len(parsed_risks) < 5: parsed_risks.append(clean)
        elif section == "preds" and len(parsed_preds) < 5: parsed_preds.append(clean)
        elif section == "acts"  and len(parsed_acts)  < 5: parsed_acts.append(clean)

    # ── Reconcile LLM verdict against deterministic baseline ────
    # Deterministic numbers are ground truth. If LLM contradicts data, force.
    from services.verdict_reconciler import reconcile_verdict

    # Build KPI evidence dict for validation
    kpi_ev = {
        "batch":    digest.get("batch_kpis", {}),
        "sla":      digest.get("sla", {}),
        "resource": digest.get("fleet", {}),
        "redflags": digest.get("red_flags_by_risk", {}),
        "findings": digest.get("findings_summary", {}),
        "top_jobs": [
            {"Job_Name": c.get("entity")} for c in digest.get("cross_links", [])
            if c.get("entity_kind") == "job"
        ],
        "servers":  [
            {"host": c.get("entity")} for c in digest.get("cross_links", [])
            if c.get("entity_kind") == "host"
        ],
    }

    # Parse LLM decision from the text
    llm_decision_parsed = None
    llm_grade_parsed = None
    if text:
        import re as _re
        vline = _re.search(r"VERDICT:\s*(.+)", text, _re.IGNORECASE)
        if vline:
            vtext = vline.group(1).upper()
            for d in ("REMEDIATE", "HOLD", "GO"):
                if d in vtext:
                    llm_decision_parsed = d
                    break
            gm = _re.search(r"GRADE\s+([A-F])", vtext)
            if gm:
                llm_grade_parsed = gm.group(1)

    recon = reconcile_verdict(
        det_score=round(score, 1),
        det_grade=grade,
        det_decision=decision,
        det_risks=risks,
        det_actions=next_actions_default,
        llm_grade=llm_grade_parsed,
        llm_decision=llm_decision_parsed,
        llm_risks=parsed_risks or None,
        llm_actions=parsed_acts or None,
        llm_narrative=text,
        kpi_evidence=kpi_ev,
    )

    # Build the reconciliation note for the headline
    recon_note = ""
    if recon.mismatches:
        recon_note = f" [{len(recon.mismatches)} mismatch(es) reconciled]"

    return ConsultantVerdict(
        grade=recon.final_grade,
        score=recon.final_score,
        decision=recon.final_decision,
        headline=headline + recon_note,
        top_risks=recon.final_risks,
        predictions=parsed_preds or predictions_default,
        next_actions=recon.final_next_actions,
        narrative=text or "",
        model=model or "",
        agent_trace=agent_trace,
        tool_count=tool_count,
    )


# ── Endpoint ────────────────────────────────────────────────────

@router.post("/pe-consultant", response_model=PeConsultantResponse,
             summary="Senior PE Consultant — cross-pillar interconnection + LLM verdict")
def pe_consultant(body: PeConsultantRequest) -> PeConsultantResponse:
    cross, chains = _build_cross_links(body)
    accuracy      = _accuracy(body, cross)
    verdict       = _consultant_llm(_build_digest(body, cross), accuracy)
    return PeConsultantResponse(
        cross_links=cross,
        evidence_chain=chains,
        consultant=verdict,
        accuracy=accuracy,
    )
