"""
SOW Volume Baseline router.

GET  /api/sow/baseline          → stored SOW baseline values
POST /api/sow/baseline          → save SOW baseline values
POST /api/sow/parse             → upload SOW doc and extract values
POST /api/sow/compare           → compare actuals against baseline
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel, ConfigDict
from services import config_store

router = APIRouter()
_SOW_KEY = "sow_baseline"

# ── Models ────────────────────────────────────────────────────────────────────

class SowBaseline(BaseModel):
    model_config = ConfigDict(extra="allow")
    daily_dfu:         Optional[float] = None
    daily_sku:         Optional[float] = None
    daily_orders:      Optional[float] = None
    batch_jobs:        Optional[float] = None
    peak_users:        Optional[float] = None
    data_volume_gb:    Optional[float] = None
    cpu_baseline_pct:  Optional[float] = None
    mem_baseline_pct:  Optional[float] = None
    disk_baseline_pct: Optional[float] = None
    custom: Optional[List[Dict[str, Any]]] = []

class SowMetric(BaseModel):
    key:    str
    label:  str
    sow:    float
    actual: float
    pct:    float   # actual/sow*100
    status: str     # OPTIMAL | MODERATE | LOW | HIGH

class SowCompareRequest(BaseModel):
    actuals: Dict[str, float] = {}

class SowCompareResponse(BaseModel):
    metrics:        List[SowMetric]
    overall_status: str
    summary:        str
    ai_narrative:   Optional[str] = None
    ai_model:       Optional[str] = None

# ── Helpers ───────────────────────────────────────────────────────────────────

_LABELS = {
    "daily_dfu":         "Daily DFU",
    "daily_sku":         "Daily SKU Count",
    "daily_orders":      "Daily Orders",
    "batch_jobs":        "Batch Jobs/Day",
    "peak_users":        "Peak Concurrent Users",
    "data_volume_gb":    "Data Volume (GB)",
    "cpu_baseline_pct":  "CPU Utilisation %",
    "mem_baseline_pct":  "Memory Utilisation %",
    "disk_baseline_pct": "Disk Utilisation %",
}

def _status(pct: float) -> str:
    if pct < 70:   return "LOW"
    if pct < 90:   return "MODERATE"
    if pct <= 110: return "OPTIMAL"
    return "HIGH"

# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/sow/baseline")
def get_baseline() -> dict:
    return config_store.get(_SOW_KEY) or {}

@router.post("/sow/baseline")
def save_baseline(body: SowBaseline) -> dict:
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    config_store.set(_SOW_KEY, data)
    return {"ok": True, "saved": len(data)}

@router.post("/sow/parse")
async def parse_sow(file: UploadFile = File(...)) -> dict:
    raw = await file.read()
    if not raw:
        raise HTTPException(400, "Empty file")
    api_key = config_store.get_gemini_key() or ""
    try:
        from services.sow_parser import parse_sow_volumes
        volumes = parse_sow_volumes(raw, file.filename or "", api_key)
    except Exception as exc:
        raise HTTPException(422, f"Cannot parse SOW: {exc}") from exc
    return volumes

@router.post("/sow/compare", response_model=SowCompareResponse)
def compare_sow(body: SowCompareRequest) -> SowCompareResponse:
    baseline = config_store.get(_SOW_KEY) or {}
    actuals  = body.actuals or {}
    metrics: List[SowMetric] = []

    for key, label in _LABELS.items():
        sow = baseline.get(key)
        if sow is None or float(sow) <= 0:
            continue
        sow_f = float(sow)
        act_f = float(actuals.get(key, 0))
        pct   = round((act_f / sow_f) * 100, 1) if sow_f else 0.0
        metrics.append(SowMetric(key=key, label=label, sow=sow_f,
                                 actual=act_f, pct=pct, status=_status(pct)))

    # Custom metrics
    for cm in (baseline.get("custom") or []):
        sow_f = float(cm.get("baseline", 0))
        if sow_f <= 0:
            continue
        key   = cm.get("key", "custom")
        label = cm.get("label", key)
        act_f = float(actuals.get(key, 0))
        pct   = round((act_f / sow_f) * 100, 1)
        metrics.append(SowMetric(key=key, label=label, sow=sow_f,
                                 actual=act_f, pct=pct, status=_status(pct)))

    if not metrics:
        return SowCompareResponse(metrics=[], overall_status="N/A",
                                  summary="No SOW baseline values set. Enter targets in the form above.")

    highs    = sum(1 for m in metrics if m.status == "HIGH")
    lows     = sum(1 for m in metrics if m.status == "LOW")
    optimals = sum(1 for m in metrics if m.status == "OPTIMAL")
    if highs > 0:
        overall = "HIGH"
        summary = f"⚠️ {highs} metric(s) exceeding SOW baseline — review capacity and contract scope."
    elif lows > len(metrics) // 2:
        overall = "LOW"
        summary = f"📉 {lows}/{len(metrics)} metrics under-utilised vs SOW. Verify test scenarios are representative."
    elif optimals >= len(metrics) * 0.7:
        overall = "OPTIMAL"
        summary = f"✅ {optimals}/{len(metrics)} metrics within optimal SOW range. Go-live confidence HIGH."
    else:
        overall = "MODERATE"
        summary = f"🟡 Mixed results — {optimals} optimal, {lows} under-utilised, {highs} over SOW."

    resp = SowCompareResponse(metrics=metrics, overall_status=overall, summary=summary)
    try:
        from services.ai_narrator import narrate
        text, model = narrate("sow", {
            "overall_status": overall,
            "summary":        summary,
            "metrics":        [m.model_dump() for m in metrics],
        })
        if text:
            resp.ai_narrative = text
            resp.ai_model     = model
    except Exception:
        pass
    return resp
