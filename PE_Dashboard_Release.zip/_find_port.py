"""
Auto-detect the first available TCP port from a candidate list.

Usage (from start.bat):
    for /f %%P in ('python _find_port.py') do set PORT=%%P

Prints a single integer to stdout — the first port in CANDIDATES that
can be bound on 127.0.0.1.  Falls back to an OS-assigned ephemeral
port if every candidate is busy (guarantees a result on any machine).
"""
from __future__ import annotations

import socket
import sys

# Preferred ports tried in order — edit freely
CANDIDATES: list[int] = [8765, 8000, 8080, 8888, 9000, 9090, 9999, 7878, 5000]


def is_free(port: int) -> bool:
    """Return True if 127.0.0.1:<port> is available for binding."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        # SO_REUSEADDR=0 → fail if anything is already listening
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def find_free_port(candidates: list[int]) -> int:
    for port in candidates:
        if is_free(port):
            return port
    # OS fallback: bind to :0 and ask the kernel for a free port
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


if __name__ == "__main__":
    # Accept optional override list: python _find_port.py 3000 4000 5000
    overrides = [int(a) for a in sys.argv[1:] if a.isdigit()]
    port = find_free_port(overrides or CANDIDATES)
    print(port)
