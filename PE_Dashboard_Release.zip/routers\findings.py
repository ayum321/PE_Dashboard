"""
PE Audit Findings router — rule-based intelligence engine v2.

POST /api/generate-findings
    body: {
      batch_kpis, top_jobs, top_breaches, window, anomalies, sub_stats,
      resource_kpis, servers,
      issues, sla_matrix, benchmark, sow_compare, customer_name,
      sla_ceilings    # optional: from uploaded SLA XLSX
    }
    response: { findings: [{level, icon, text, sub, source}],
                summary: {critical, warning, ok, info, total},
                data_coverage: {batch, resource, sla, benchmark, sow} }

All status/buffer calculations go through services.pe_utils — never inline.
SLA ceilings read from sla_ceilings dict (uploaded XLSX) > pe_config defaults.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict

from services.pe_utils import (
    STATUS_COLOR,
    buffer_pct,
    coerce_float as _f,
    coerce_int as _i,
    detect_batch_type,
    fmt_pct,
    get_sla_hrs,
    job_status,
    safe_metric,
)

router = APIRouter()


# ── Request / Response models ──────────────────────────────────────────────────

class FindingsRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    # Batch data (full payload from /api/process-batch)
    batch_kpis:    Optional[Dict[str, Any]]       = None
    top_jobs:      Optional[List[Dict[str, Any]]] = None
    top_breaches:  Optional[List[Dict[str, Any]]] = None
    window:        Optional[List[Dict[str, Any]]] = None
    anomalies:     Optional[List[Dict[str, Any]]] = None
    sub_stats:     Optional[List[Dict[str, Any]]] = None

    # Resource data
    resource_kpis: Optional[Dict[str, Any]]       = None
    servers:       Optional[List[Dict[str, Any]]] = None

    # SLA ceilings from uploaded SLA XLSX (RULE 2)
    # {"DAILY": 4.0, "WEEKLY": 6.0, "MONTHLY": 8.0}
    sla_ceilings:  Optional[Dict[str, float]]     = None

    # Additional data sources
    issues:        Optional[List[Dict[str, Any]]] = None
    sla_matrix:    Optional[Dict[str, Any]]       = None
    benchmark:     Optional[Dict[str, Any]]       = None
    sow_compare:   Optional[Dict[str, Any]]       = None

    # Context
    customer_name: Optional[str]  = None
    sow_dfu:       Optional[float] = 0.0
    sow_dfu_base:  Optional[float] = 0.0


class Finding(BaseModel):
    level:          str          # critical | warning | info | ok
    icon:           str
    text:           str
    sub:            str = ""
    source:         str = ""     # batch | resource | sla | benchmark | sow | issues
    confidence:     int = 100    # 0-100: how confident we are in this finding
    impact:         str = ""     # business impact statement
    evidence:       str = ""     # source file / metric / calculation reference
    recommendation: str = ""     # suggested next action
    evidence_class: str = ""     # measured | inferred | defaulted | waived | unavailable
    root_cause:     str = ""     # likely root cause category


class FindingsSummary(BaseModel):
    critical: int = 0
    warning:  int = 0
    info:     int = 0
    ok:       int = 0
    total:    int = 0


class DataCoverage(BaseModel):
    batch:     bool = False
    resource:  bool = False
    sla:       bool = False
    benchmark: bool = False
    sow:       bool = False


class AuditCoverage(BaseModel):
    """PE Audit readiness coverage strip — which evidence is loaded."""
    evidence_30day:    str = "missing"   # loaded | partial | missing
    sla_source:        str = "missing"   # customer | default | missing
    waivers:           str = "missing"   # loaded | missing
    ui_signoff:        str = "missing"   # attached | missing
    automation_status: str = "missing"   # loaded | missing
    volume_vs_sow:     str = "missing"   # loaded | missing
    confidence:        int = 0           # 0-100 overall confidence
    confidence_label:  str = "INSUFFICIENT"


class FindingsResponse(BaseModel):
    findings:       List[Finding]
    summary:        FindingsSummary
    data_coverage:  DataCoverage
    audit_coverage: Optional[AuditCoverage] = None


# ── Core rule engine ───────────────────────────────────────────────────────────

def _generate(req: FindingsRequest) -> tuple[list[Finding], DataCoverage]:
    findings: list[Finding] = []
    cov = DataCoverage()

    bk          = req.batch_kpis    or {}
    rk          = req.resource_kpis or {}
    servers     = req.servers       or []
    issues      = req.issues        or []
    top_jobs    = req.top_jobs      or []
    top_breaches= req.top_breaches  or []
    window_data = req.window        or []
    anomalies   = req.anomalies     or []
    sub_stats   = req.sub_stats     or []
    sla_ceil    = req.sla_ceilings  or {}

    has_batch    = bool(bk) or bool(top_jobs)
    has_resource = bool(rk) or bool(servers)
    cov.batch    = has_batch
    cov.resource = has_resource

    def add(level, icon, text, sub="", source="", confidence=100,
            impact="", evidence="", recommendation="", evidence_class="measured",
            root_cause=""):
        findings.append(Finding(
            level=level, icon=icon, text=text, sub=sub, source=source,
            confidence=confidence, impact=impact, evidence=evidence,
            recommendation=recommendation, evidence_class=evidence_class,
            root_cause=root_cause,
        ))

    # ─── No data at all ──────────────────────────────────────────────────────
    if not has_batch and not has_resource:
        add("info", "📂",
            "No audit data loaded",
            "Upload a Ctrl-M CSV and/or Resource Utilization report to begin PE audit analysis",
            source="")
        return findings, cov

    # ═══════════════════════════════════════════════════════════════
    # PE AUDIT COVERAGE STRIP
    # ═══════════════════════════════════════════════════════════════
    # Track what evidence has been loaded for audit readiness
    batch_cov   = req.batch_kpis.get("data_coverage") if req.batch_kpis else None
    sla_loaded  = bool(sla_ceil)
    bench_loaded = bool(req.benchmark)
    sow_loaded   = bool(req.sow_compare)
    issues_loaded = bool(issues)

    # Data confidence warning (batch)
    if batch_cov:
        conf = _f(batch_cov.get("confidence"))
        conf_label = batch_cov.get("confidence_label", "")
        if conf < 60:
            add("warning", "📉",
                f"Batch data confidence: {conf:.0f}% ({conf_label})",
                "Incomplete source columns or insufficient date range. "
                "Some metrics may not be fully reliable.",
                source="batch", confidence=int(conf),
                impact="Compliance and SLA calculations may be inaccurate",
                recommendation="Upload complete Ctrl-M export with Start_Time, End_Time, Status, and 30+ days of data")

        # Warn about default SLA
        sla_src = batch_cov.get("sla_source") if batch_cov else None
        for w in (batch_cov.get("warnings") or []):
            code = w.get("code", "")
            if code == "DEFAULT_SLA" and not sla_loaded:
                add("warning", "📐",
                    "SLA Source: Assumed — no customer SLA matrix uploaded",
                    w.get("text", "") + " · Compliance results cannot be marked green for audit sign-off "
                    "while using assumed default values.",
                    source="batch", evidence_class="defaulted",
                    impact="Compliance based on assumed defaults — audit sign-off blocked",
                    recommendation="Upload a customer-approved SLA XLSX to unlock green compliance status")
            elif code == "NO_END_TIME":
                add("info", "⏳",
                    "Elapsed batch window unavailable — End_Time column missing",
                    w.get("text", ""),
                    source="batch",
                    impact="Cannot distinguish summed runtime from real wall-clock batch window",
                    recommendation="Export Ctrl-M data with both Start_Time and End_Time columns")
            elif code == "SHORT_HISTORY":
                add("warning", "📅",
                    w.get("text", "Insufficient date range for PE audit"),
                    "30-day batch history is standard PE audit evidence requirement.",
                    source="batch",
                    impact="PE sign-off may be challenged with less than 30 days of evidence",
                    recommendation="Upload at least 30 days of Ctrl-M execution history")

    # ═══════════════════════════════════════════════════════════════
    # BATCH / SLA RULES
    # ═══════════════════════════════════════════════════════════════
    if has_batch:
        compliance   = _f(bk.get("compliance_pct"))
        jobs_breach  = _i(bk.get("jobs_breach"))
        jobs_at_risk = _i(bk.get("jobs_at_risk"))
        total_jobs   = _i(bk.get("total_jobs"))
        total_runs   = _i(bk.get("total_runs"))
        fsla         = bk.get("fleet_sla_buffer") or {}

        # Default SLA hrs — will be overridden per-job by sla_ceil below
        default_sla  = get_sla_hrs("DAILY", sla_ceil)

        # R0 — Data health check: do we have meaningful batch data?
        if total_runs == 0:
            add("warning", "⚠️",
                "Ctrl-M file uploaded but no runs found",
                "Verify the CSV has Start_Time, Job_Name and Run_Sec columns",
                source="batch")

        # R1 — Job SLA Compliance (individual job peaks vs SLA)
        batch_conf = int(_f((batch_cov or {}).get("confidence", 100)))
        job_sla_comp = _f(bk.get("job_sla_compliance", bk.get("compliance_pct")))
        window_comp  = _f(bk.get("batch_window_compliance", 100))
        win_breach   = _i(bk.get("window_breach_days"))
        win_total    = _i(bk.get("window_total_days"))

        sla_evidence_class = "measured" if sla_loaded else "defaulted"
        sla_src_label = "From SLA Matrix" if sla_loaded else "Assumed"

        if jobs_breach > 0:
            add("critical", "🚨",
                f"Job SLA Compliance: {jobs_breach} job(s) breached individual SLA ceiling",
                f"Peak runtime exceeded {default_sla:.1f}h limit · SLA source: {sla_src_label}",
                source="batch", confidence=batch_conf,
                impact="PE sign-off blocked until all job-level SLA breaches are resolved",
                evidence=f"Ctrl-M peak runtime vs {default_sla:.1f}h {'customer' if sla_loaded else 'default'} SLA · Source: {sla_src_label}",
                recommendation="Investigate worst-case jobs, optimise or request SLA waiver",
                evidence_class=sla_evidence_class)
        elif jobs_at_risk > 0:
            add("warning", "⚠️",
                f"Job SLA Compliance: {job_sla_comp:.1f}% — {jobs_at_risk} job(s) at risk",
                f"Approaching SLA boundary (>85% used) · SLA source: {sla_src_label}",
                source="batch", confidence=batch_conf,
                impact="Risk of job-level SLA breach under production load conditions",
                recommendation="Monitor at-risk jobs during next batch cycle",
                evidence_class=sla_evidence_class)
        else:
            add("ok", "✅",
                f"Job SLA Compliance: {job_sla_comp:.1f}% — all individual jobs within SLA",
                f"{total_jobs} jobs · {total_runs} runs · SLA source: {sla_src_label}",
                source="batch", confidence=batch_conf,
                evidence=f"All job peaks below {default_sla:.1f}h {'customer' if sla_loaded else 'default'} SLA · Source: {sla_src_label}",
                evidence_class=sla_evidence_class)

        # R1b — Batch Window Compliance (aggregate daily total vs SLA)
        if win_total > 0 and win_breach > 0:
            add("critical", "📅",
                f"Batch Window Compliance: {window_comp:.1f}% — SLA exceeded on {win_breach}/{win_total} day(s)",
                f"Aggregate daily runtime exceeded {default_sla:.1f}h limit · "
                f"SLA source: {sla_src_label} · "
                f"This is distinct from individual job compliance — the total batch window overran.",
                source="batch", confidence=batch_conf,
                impact=f"Batch window overrun on {win_breach} day(s) blocks PE sign-off",
                evidence=f"Sum of all job runtimes per day vs {default_sla:.1f}h window · Source: {sla_src_label}",
                recommendation="Reschedule overlapping jobs or request extended batch window",
                evidence_class=sla_evidence_class)
        elif win_total > 0:
            add("ok", "✅",
                f"Batch Window Compliance: {window_comp:.1f}% — aggregate daily window within SLA",
                f"All {win_total} day(s) within {default_sla:.1f}h batch window · SLA source: {sla_src_label}",
                source="batch", confidence=batch_conf,
                evidence_class=sla_evidence_class)

        # R2 — Per-job SLA ceiling check using pe_utils.job_status (RULE 1)
        # Uses composite key Sub_Application + Job_Name (RULE 6)
        ceiling_hits: list[str] = []
        at_risk_jobs: list[str] = []
        caution_jobs: list[str] = []

        for j in (top_jobs or []):
            peak_hrs  = _f(j.get("peak_hrs"))
            j_name    = j.get("Job_Name") or j.get("job_name") or "?"
            sub_app   = j.get("Sub_Application") or j.get("sub_application") or ""
            b_type    = detect_batch_type(j_name)
            j_sla     = get_sla_hrs(b_type, sla_ceil)
            status    = job_status(peak_hrs, j_sla)
            composite = f"{sub_app}:{j_name}" if sub_app else j_name

            if status == "BREACH":
                ceiling_hits.append(f"{composite} ({peak_hrs:.2f}h/{j_sla:.1f}h)")
            elif status == "AT_RISK":
                at_risk_jobs.append(composite)
            elif status == "CAUTION":
                caution_jobs.append(composite)

        if ceiling_hits:
            names = ", ".join(ceiling_hits[:3])
            add("critical", "🔴",
                f"{len(ceiling_hits)} job(s) breaching individual SLA ceiling",
                f"{names}{'…' if len(ceiling_hits) > 3 else ''} — action required before go-live",
                source="batch")

        if at_risk_jobs and len(at_risk_jobs) != jobs_at_risk:
            # Only if different from global count (avoids duplicate)
            names = ", ".join(at_risk_jobs[:3])
            add("warning", "🔶",
                f"{len(at_risk_jobs)} job(s) within 15% of SLA ceiling (AT_RISK)",
                f"Jobs: {names}{'…' if len(at_risk_jobs) > 3 else ''}",
                source="batch")

        # R3 — Worst batch window breach detail (supplement to R1b)
        sla_default = get_sla_hrs("DAILY", sla_ceil)
        breach_days = [w for w in window_data if _f(w.get("total_hrs")) > sla_default]
        if breach_days:
            worst = max(breach_days, key=lambda d: _f(d.get("total_hrs")))
            top_j = worst.get("top_job", "")
            add("info", "📊",
                f"Worst batch window day: {worst.get('run_date','?')} at {_f(worst.get('total_hrs')):.1f}h",
                f"Top contributing job: {top_j if top_j else 'unknown'} · "
                f"SLA ceiling: {sla_default:.1f}h · "
                f"Overrun: {_f(worst.get('total_hrs')) - sla_default:.1f}h",
                source="batch", evidence_class=sla_evidence_class)

        # R4 — Fleet SLA buffer tightness
        if fsla and fsla.get("status") in ("CRITICAL", "CAUTION"):
            buf_pct = _f(fsla.get("buffer_pct"))
            buf_hrs = _f(fsla.get("buffer_hrs"))
            tight_name = fsla.get("job_name", "worst job")
            add("warning", "⏱️",
                f"Tightest SLA buffer: {buf_pct:.1f}% headroom ({fsla.get('status','')})",
                f"Worst job has only {buf_hrs:.2f}h of growth capacity — any spike breaches SLA",
                source="batch",
                impact=f"'{tight_name}' has {buf_pct:.1f}% SLA buffer — even a minor data volume increase will cause SLA breach",
                recommendation=f"Profile '{tight_name}' under load; either optimise runtime by 15%+ or request SLA extension",
                root_cause="THIN_SLA_BUFFER")

        # R5 — Statistical anomalies
        if anomalies:
            top_a = anomalies[0]
            j_name = top_a.get("job_name") or top_a.get("Job_Name") or "?"
            z      = _f(top_a.get("z_score") or top_a.get("z"))
            add("warning", "📉",
                f"{len(anomalies)} statistical anomaly/anomalies in job runtimes",
                f"Top outlier: {j_name} (z={z:.1f}σ) — investigate for runaway jobs",
                source="batch",
                impact=f"'{j_name}' ran {z:.1f} standard deviations above its own historical baseline — potential runaway or data volume spike",
                recommendation=f"Pull Ctrl-M job history for '{j_name}'; check for data volume change, code regression, or lock contention",
                root_cause="JOB_RUNTIME_ANOMALY")

        # R6 — Zero-duration jobs (may be pre-execution failures)
        zero_dur = [
            j for j in top_jobs
            if _f(j.get("peak_hrs")) == 0
            and j.get("buffer_status") not in ("EXCELLENT", "HEALTHY")
        ]
        if zero_dur:
            add("info", "⚡",
                f"{len(zero_dur)} job(s) with zero runtime detected",
                "May indicate pre-execution termination — verify in Ctrl-M console",
                source="batch")

        # R7 — Failure/non-compliance rate
        failure_rate = max(0.0, 100.0 - compliance)
        if failure_rate > 20:
            add("critical", "💥",
                f"Batch failure rate: {failure_rate:.1f}% — systemic issues detected",
                "More than 1 in 5 batch window days exceeded SLA — root cause investigation required",
                source="batch")
        elif failure_rate > 5:
            add("warning", "⚠️",
                f"Batch non-compliance: {failure_rate:.1f}% of days exceeded SLA",
                "Review window data for patterns — possible scheduling conflicts",
                source="batch")

        # R8 — Sub-application hotspots
        if sub_stats:
            hot_subs = sorted(
                sub_stats, key=lambda s: _f(s.get("total_hrs")), reverse=True
            )[:3]
            if hot_subs:
                names = ", ".join(
                    s.get("Sub_Application") or s.get("sub_application") or "?"
                    for s in hot_subs
                )
                total_hrs = sum(_f(s.get("total_hrs")) for s in hot_subs)
                top_sub = hot_subs[0]
                top_sub_hrs = _f(top_sub.get("total_hrs"))
                add("info", "📦",
                    f"Top sub-applications by runtime: {names}",
                    f"Combined: {total_hrs:.1f}h — review for parallelisation opportunities",
                    source="batch",
                    impact=f"Top sub-app '{(top_sub.get('Sub_Application') or top_sub.get('sub_application','?'))}' accounts for {top_sub_hrs:.1f}h of batch window — parallelisation could reduce total window by 20-40%",
                    recommendation="Map job dependencies within each sub-app; jobs without shared resources can run concurrently",
                    root_cause="SCHEDULING_INEFFICIENCY")

    # ═══════════════════════════════════════════════════════════════
    # RESOURCE / INFRASTRUCTURE RULES
    # ═══════════════════════════════════════════════════════════════
    if has_resource:
        grade   = rk.get("fleet_grade", "?")
        fscore  = _f(rk.get("fleet_score"))
        crit    = _i(rk.get("n_critical"))
        warn    = _i(rk.get("n_warning"))
        healthy = _i(rk.get("n_healthy"))
        total_s = _i(rk.get("total_servers", len(servers)))
        data_q  = rk.get("data_quality", "")
        r_anoms = rk.get("anomalies") or []
        n_agg   = _i(rk.get("n_agg_trap"))
        n_dual  = _i(rk.get("n_dual_pressure"))

        # Check if all servers have 0.0% metrics (IMAGE_DOCX not yet vision-enriched)
        # Uses effective_cpu (agg-adjusted) first, then cpu_pct; mem_pct for memory
        all_zero = all(
            _f(s.get("effective_cpu") or s.get("cpu_pct") or 0) == 0
            and _f(s.get("mem_pct")) == 0
            for s in servers
        ) if servers else not rk

        # Determine evidence class for resource findings
        # Snapshot-based documents (PDF/DOCX) are "inferred", not time-series "measured"
        res_evidence_class = "inferred" if not all_zero else "unavailable"

        if grade == "N/A" or all_zero:
            add("warning", "📡",
                f"Fleet Grade N/A — resource metrics unavailable ({total_s} servers, all 0.0%)",
                "Image-only DOCX detected. Gemini Vision is extracting metrics — "
                "re-upload or check Settings for Vision AI key",
                source="resource", evidence_class="unavailable",
                impact="Cannot perform infrastructure readiness assessment — fleet status unknown",
                recommendation="Re-upload resource report or configure Gemini Vision API key in Settings",
                root_cause="MONITORING_GAP")
        elif crit > 0:
            real_crit = crit  # will adjust for agg traps below
            agg_note = ""
            if n_agg > 0:
                agg_note = f" ({n_agg} high-CPU reading(s) identified as aggregation artifacts)"
            crit_hosts = [s.get('host','?').split('.')[0] for s in servers
                          if s.get('state','') == 'CRITICAL' or
                          _f(s.get('effective_cpu') or s.get('cpu_pct') or 0) >= 85 or
                          _f(s.get('mem_pct') or 0) >= 90][:3]
            host_str = f" · Hosts: {', '.join(crit_hosts)}" if crit_hosts else ""
            add("critical", "🖥️",
                f"{crit} server(s) in CRITICAL state — fleet grade {grade}{agg_note}",
                f"CPU/Memory/Disk at or above critical threshold{host_str}. "
                "Document-derived snapshot — escalate before production cutover.",
                source="resource", evidence_class=res_evidence_class,
                impact=f"Fleet grade {grade} — {crit} server(s) at critical threshold will degrade batch throughput and risk job failures under peak load",
                recommendation="Engage infrastructure owner immediately; scale capacity or reduce concurrent job load before cutover",
                root_cause="RESOURCE_SATURATION")
        elif warn > 0:
            add("warning", "🖥️",
                f"{warn} server(s) in WARNING state — fleet grade {grade} (score {fscore:.0f}/100)",
                "Resource utilization approaching thresholds — "
                "snapshot-based assessment, not continuous monitoring",
                source="resource", evidence_class=res_evidence_class,
                impact=f"{warn} server(s) approaching critical threshold — risk of degradation under peak batch load",
                recommendation="Monitor servers during next batch window; engage infra owner if trend continues",
                root_cause="RESOURCE_PRESSURE")
        else:
            add("ok", "🖥️",
                f"Fleet health grade {grade} ({fscore:.0f}/100) — all servers within thresholds",
                f"{healthy}/{total_s} servers healthy"
                + (f" · {n_agg} false alarm(s) filtered" if n_agg else "")
                + " (document-derived snapshot)",
                source="resource", evidence_class=res_evidence_class,
                root_cause="")

        # ── RULE 1: Aggregation Trap Detection (Max vs Avg) ──────
        # When Max CPU is ≥85% but Avg is <20%, the spike is a visual
        # artifact — the server is actually HEALTHY.
        agg_trap_servers = [s for s in servers if s.get("agg_trap")]
        if agg_trap_servers and not all_zero:
            names = ", ".join(
                f"{s.get('host','?').split('.')[0]} (Peak {_f(s.get('cpu_pct')):.0f}%/Eff {_f(s.get('effective_cpu')):.0f}%)"
                for s in agg_trap_servers[:3]
            )
            add("info", "🔬",
                f"{len(agg_trap_servers)} server(s) flagged as Aggregation Trap — FALSE ALARM",
                f"{names}{'…' if len(agg_trap_servers) > 3 else ''} — "
                f"Max CPU is high but Avg is very low (<20%). "
                f"This is a visual aggregation artifact from 7/30-day charts, not sustained pressure. "
                f"Servers are HEALTHY.",
                source="resource", evidence_class=res_evidence_class)

        # ── RULE 2: Role-Specific CPU Thresholds ─────────────────
        # APP servers: alarm at 60%+, DB: expect batch spikes (85%+),
        # SRE: only alarm on sustained 90%+ collision saturation.
        if not all_zero:
            _role_thresholds = {
                "APP": {"ok": 60.0, "warn": 80.0, "label": "should rarely exceed 60%"},
                "DB":  {"ok": 85.0, "warn": 95.0, "label": "batch optimization spikes expected"},
                "SRE": {"ok": 90.0, "warn": 100.0, "label": "watch for concurrent job collisions"},
            }
            for role, thresh in _role_thresholds.items():
                role_servers = [
                    s for s in servers
                    if (s.get("type") or "APP").upper() == role
                    and not s.get("agg_trap")
                    and _f(s.get("effective_cpu") or s.get("cpu_pct") or 0) >= thresh["ok"]
                ]
                if role_servers:
                    names = ", ".join(
                        f"{s.get('host','?').split('.')[0]} ({_f(s.get('effective_cpu') or s.get('cpu_pct') or 0):.0f}%)"
                        for s in role_servers[:3]
                    )
                    level = "critical" if any(
                        _f(s.get("effective_cpu") or s.get("cpu_pct") or 0) >= thresh["warn"]
                        for s in role_servers
                    ) else "warning"
                    add(level, "🏷️",
                        f"{len(role_servers)} {role} server(s) above role-specific CPU threshold",
                        f"{names}{'…' if len(role_servers) > 3 else ''} — "
                        f"{role} servers: {thresh['label']} (snapshot-based, not time-series validated)",
                        source="resource", evidence_class=res_evidence_class,
                        impact=f"{role} server CPU above operational limit — batch jobs on these hosts will compete for CPU and may breach SLA",
                        recommendation=f"Review {role} server scheduling; either reduce concurrent job count or scale CPU capacity",
                        root_cause="CPU_ROLE_BREACH")

        # ── RULE 3: Dual CPU + Memory Pressure (≥80% CPU + ≥85% Mem) ──
        # High CPU alone = working hard.  High CPU + High Memory (>85%)
        # = severe resource exhaustion, swapping, or undersized server.
        dual_hot = [s for s in servers if s.get("dual_pressure")]
        if dual_hot and not all_zero:
            names = ", ".join(s.get("host", "?").split(".")[0] for s in dual_hot[:2])
            add("critical", "⚡",
                f"{len(dual_hot)} server(s) under DUAL CPU+Memory pressure (CPU≥80% + Mem≥85%)",
                f"Hosts: {names}{'…' if len(dual_hot) > 2 else ''} — "
                f"severe resource exhaustion detected. Likely swapping or undersized server. "
                f"Must be resolved pre-cutover.",
                source="resource", evidence_class=res_evidence_class,
                impact="Dual CPU+Memory pressure causes OS memory swapping — batch jobs will stall, fail, or produce timeout SLA breaches",
                recommendation="Immediately size-up affected servers or migrate heavy jobs to alternate hosts; this is a pre-cutover blocker",
                root_cause="DUAL_PRESSURE")

        # CPU saturation — individual server rules (>= 90%, excluding agg traps)
        cpu_hot = [
            s for s in servers
            if _f(s.get("effective_cpu") or s.get("cpu_pct") or 0) >= 90
            and not s.get("agg_trap")
        ]
        if cpu_hot and not all_zero:
            names = ", ".join(s.get("host", "?") for s in cpu_hot[:3])
            add("critical", "🔥",
                f"{len(cpu_hot)} server(s) at CPU saturation (≥ 90%)",
                f"Hosts: {names}{'…' if len(cpu_hot) > 3 else ''} — batch scheduling will be impacted "
                f"(snapshot-based, not time-series validated)",
                source="resource", evidence_class=res_evidence_class,
                impact="CPU saturation will cause job queue build-up and extend batch window beyond SLA",
                recommendation="Add CPU capacity or spread jobs across more nodes; review job concurrency settings",
                root_cause="CPU_SATURATION")
        elif not all_zero:
            cpu_warn = [
                s for s in servers
                if 75 <= _f(s.get("effective_cpu") or s.get("cpu_pct") or 0) < 90
                and not s.get("agg_trap")
            ]
            if cpu_warn:
                names = ", ".join(s.get("host", "?") for s in cpu_warn[:3])
                add("warning", "🔶",
                    f"{len(cpu_warn)} server(s) with CPU warning (75–89%)",
                    f"Hosts: {names}{'…' if len(cpu_warn) > 3 else ''} — watch during peak batch window",
                    source="resource", evidence_class=res_evidence_class,
                    impact="Elevated CPU may cause job slowdowns and SLA risk during concurrent batch peaks",
                    recommendation="Monitor these hosts during the next batch window; set alerts at 85% sustained CPU",
                    root_cause="CPU_PRESSURE")

        # Memory pressure — >= 80%
        mem_hot = [s for s in servers if _f(s.get("mem_pct")) >= 80]
        if mem_hot and not all_zero:
            names = ", ".join(s.get("host", "?") for s in mem_hot[:3])
            add("warning", "💾",
                f"{len(mem_hot)} server(s) under memory pressure (≥ 80%)",
                f"Hosts: {names}{'…' if len(mem_hot) > 3 else ''} — risk of OOM during batch peak",
                source="resource", evidence_class=res_evidence_class,
                impact="High memory consumption increases OOM kill risk — batch jobs may fail mid-run and not be retried",
                recommendation="Tune JVM heap / process memory limits; review in-memory caching strategies for batch jobs",
                root_cause="MEMORY_PRESSURE")

        # Disk usage — >= 85%
        disk_hot = [s for s in servers if _f(s.get("disk_used_max")) >= 85]
        if disk_hot and not all_zero:
            names = ", ".join(s.get("host", "?") for s in disk_hot[:3])
            add("critical", "💿",
                f"{len(disk_hot)} server(s) with critical disk usage (≥ 85%)",
                f"Hosts: {names}{'…' if len(disk_hot) > 3 else ''} — batch spool jobs may fail",
                source="resource", evidence_class=res_evidence_class)

        # Infrastructure anomalies
        for ia in (r_anoms or [])[:2]:
            add("info", "📊",
                f"Infra anomaly: {ia.get('host','?')} — {ia.get('metric','?')} "
                f"at {fmt_pct(_f(ia.get('value')))}",
                f"z-score {_f(ia.get('z')):.1f}σ above fleet average",
                source="resource")

        # Data quality warning
        if data_q == "INSUFFICIENT":
            known_pct = _f(rk.get("known_pct"))
            add("info", "ℹ️",
                f"Resource data quality: INSUFFICIENT ({known_pct:.0f}% of servers have real metrics)",
                "Fleet grade and correlation analysis may be unreliable until more data is extracted",
                source="resource")

    # ═══════════════════════════════════════════════════════════════
    # CROSS-SOURCE CORRELATION RULES
    # ═══════════════════════════════════════════════════════════════
    if has_batch and has_resource:
        # Batch + CPU pressure correlation
        all_zero_res = all(
            _f(s.get("effective_cpu") or s.get("cpu_pct") or 0) == 0
            and _f(s.get("mem_pct")) == 0
            for s in servers
        ) if servers else True

        if not all_zero_res and bk.get("jobs_breach", 0) > 0:
            cpu_pct_vals = [_f(s.get("effective_cpu") or s.get("cpu_pct") or 0)
                            for s in servers
                            if _f(s.get("effective_cpu") or s.get("cpu_pct") or 0) > 0]
            if cpu_pct_vals:
                max_cpu = max(cpu_pct_vals)
                if max_cpu >= 80:
                    add("critical", "🔗",
                        f"Batch breaches correlate with server CPU pressure (max {max_cpu:.0f}%)",
                        "Resource contention is likely contributing to SLA overruns — "
                        "scale infrastructure or reschedule heaviest jobs",
                        source="resource")

    # ═══════════════════════════════════════════════════════════════
    # SLA MATRIX RULES
    # ═══════════════════════════════════════════════════════════════
    sla = req.sla_matrix or {}
    if sla:
        cov.sla = True
        sla_label   = sla.get("sla_label") or "SLA"
        sla_limit   = _f(sla.get("sla_limit_hrs"))
        sla_comp    = _f(sla.get("compliance_pct"), 100.0)
        sla_breach  = _i(sla.get("breaching_runs"))
        sla_atrisk  = _i(sla.get("at_risk_runs"))
        sla_ok      = _i(sla.get("ok_runs"))
        sla_runs    = _i(sla.get("total_runs"))
        sla_jobs    = _i(sla.get("total_jobs"))
        breach_rows = sla.get("breaches") or []
        job_summary = sla.get("job_summary") or []
        worst_job   = sla.get("worst_job") or ""
        worst_hrs   = _f(sla.get("worst_hrs"))
        worst_marg  = _f(sla.get("worst_margin_hrs"))
        # Window compliance (new fields from updated SLA Matrix engine)
        win_comp_pct   = sla.get("window_compliance_pct")   # None means not computed
        win_total_days = _i(sla.get("window_total_days") or 0)
        win_breach_days = _i(sla.get("window_breach_days") or 0)

        # Distinct breaching jobs
        breach_names: list[str] = []
        seen_b: set[str] = set()
        for r in breach_rows:
            jn = r.get("job_name") or ""
            if jn and r.get("status") == "BREACH" and jn not in seen_b:
                seen_b.add(jn); breach_names.append(jn)

        # ── PRIMARY: Window compliance verdict (matches Executive Dashboard) ──
        # Window compliance = days where elapsed wall-clock ≤ SLA ceiling.
        # Even if every individual job is under the SLA, jobs running
        # sequentially/overlapping can inflate the total batch window past SLA.
        if win_comp_pct is not None and win_total_days > 0:
            pass_days = win_total_days - win_breach_days
            if win_breach_days > 0:
                win_level = "critical" if win_comp_pct < 75 else "warning"
                add(win_level, "📅",
                    f"Batch Window Compliance: {win_comp_pct:.1f}% — {win_breach_days}/{win_total_days} day(s) breached",
                    f"Elapsed batch window exceeded {sla_limit:.2f}h SLA on {win_breach_days} day(s). "
                    f"Individual jobs may be within SLA but total batch window is not.",
                    source="sla", evidence_class="measured",
                    impact=f"PE sign-off blocked — batch window overran on {win_breach_days} of {win_total_days} days",
                    evidence=f"SLA Matrix · Window compliance · {sla_limit:.2f}h ceiling · {win_total_days} days analysed",
                    recommendation="Investigate job overlap and sequencing; parallelise or reschedule to compress total batch window",
                    root_cause="BATCH_WINDOW_OVERRUN")
            else:
                add("ok", "📅",
                    f"Batch Window Compliance: {win_comp_pct:.1f}% — all {win_total_days} day(s) within SLA",
                    f"Elapsed wall-clock window ≤ {sla_limit:.2f}h on every day",
                    source="sla", evidence_class="measured",
                    root_cause="")

        # ── SECONDARY: Per-run individual job findings ──
        if sla_breach > 0:
            head = ", ".join(breach_names[:3]) or worst_job or "?"
            add("critical", "⏰",
                f"Per-Job SLA: {sla_breach} run(s) BREACHED individual SLA ceiling",
                f"Worst: {worst_job} at {worst_hrs:.2f}h (+{worst_marg:.2f}h over {sla_limit:.2f}h). "
                f"Breaching jobs: {head}{'…' if len(breach_names) > 3 else ''}.",
                source="sla", evidence_class="measured",
                impact="Individual job SLA breaches must each have an approved fix or signed waiver",
                evidence=f"SLA Matrix · {sla_label} · {sla_runs} runs / {sla_jobs} jobs",
                recommendation="Drill into the SLA Matrix tab; for each breaching job either optimise runtime or obtain customer SLA waiver",
                root_cause="JOB_SLA_BREACH")
        elif sla_atrisk > 0:
            add("warning", "⏰",
                f"Per-Job SLA: {sla_atrisk} run(s) AT_RISK — {sla_comp:.1f}% compliance vs {sla_label}",
                f"{sla_ok} OK runs · {sla_atrisk} within 15% of ceiling — any production load spike will breach",
                source="sla", evidence_class="measured",
                impact="At-risk jobs will breach SLA under increased data volume or concurrent load",
                recommendation="Profile at-risk jobs under load-test conditions; pre-emptively engage app owner",
                root_cause="JOB_SLA_AT_RISK")
        elif sla_runs > 0:
            add("ok", "✅",
                f"Per-Job SLA: {sla_comp:.1f}% — all {sla_runs} runs within individual job SLA",
                f"{sla_jobs} job(s) analysed · 0 breaches · 0 at-risk · {sla_label}",
                source="sla", evidence_class="measured",
                root_cause="")

        # Tightest job buffer (from job_summary)
        if job_summary:
            tight = min(job_summary, key=lambda j: _f(j.get("buffer_pct"), 999))
            buf_pct = _f(tight.get("buffer_pct"), 999)
            if buf_pct < 15:
                add("warning", "⚡",
                    f"Tightest SLA buffer: {buf_pct:.1f}% — {tight.get('job_name','?')}",
                    f"Peak {_f(tight.get('peak_hrs')):.2f}h vs {sla_limit:.1f}h ceiling — "
                    "any runtime spike will breach SLA",
                    source="sla", evidence_class="measured")

        # Repeat offenders (same job breaching multiple runs)
        from collections import Counter as _Counter
        rep = _Counter(r.get("job_name") for r in breach_rows
                       if r.get("status") == "BREACH" and r.get("job_name"))
        repeats = [(j, n) for j, n in rep.items() if n >= 2]
        if repeats:
            names = ", ".join(f"{j}×{n}" for j, n in repeats[:3])
            add("critical", "🔁",
                f"{len(repeats)} job(s) breaching SLA repeatedly — pattern not anomaly",
                f"{names} — investigate trend (data volume, code regression, contention)",
                source="sla", evidence_class="measured",
                impact="Repeat breaches indicate systemic issue, not transient spike",
                recommendation="Engage app/DB owner — review last 30-day trend in SLA tab")

        # SLA ceilings notice (if we parsed them from the uploaded XLSX)
        if req.sla_ceilings:
            parts = [f"{k}: {v:.1f}h" for k, v in req.sla_ceilings.items()]
            add("info", "📐",
                f"Customer SLA ceilings loaded from XLSX",
                f"Active windows: {' · '.join(parts)} — all status calculations use these values",
                source="sla",
                impact="Customer-approved SLA values are applied — compliance results are audit-defensible",
                recommendation="Verify ceiling values match the signed PE agreement before submitting audit report",
                root_cause="")

    # ═══════════════════════════════════════════════════════════════
    # BENCHMARK RULES
    # ═══════════════════════════════════════════════════════════════
    bench = req.benchmark or {}
    if bench:
        cov.benchmark = True
        rows       = bench.get("rows") or []
        bench_summ = bench.get("summary") or {}
        total_tx   = _i(bench_summ.get("total", bench.get("total_transactions", len(rows))))
        threshold  = _f(bench.get("threshold_pct", 10.0))
        sla_breaches_b = _i(bench.get("sla_breaches", 0))

        red_rows = [r for r in rows if r.get("status") == "RED"]
        slow_pct = (len(red_rows) / total_tx * 100) if total_tx > 0 else 0

        if slow_pct > 20:
            add("critical", "🐢",
                f"Benchmark: {len(red_rows)}/{total_tx} transactions exceed {threshold:.0f}% threshold",
                f"Severe UI performance degradation ({slow_pct:.1f}% slow) — investigate top offenders",
                source="benchmark")
        elif slow_pct > 5 or sla_breaches_b > 0:
            add("warning", "🐢",
                f"Benchmark: {len(red_rows)} slow transaction(s) ({slow_pct:.1f}% of total)"
                + (f" · {sla_breaches_b} SLA breach(es)" if sla_breaches_b else ""),
                f"Transactions above {threshold:.0f}% deviation from baseline",
                source="benchmark")
        elif total_tx > 0:
            add("ok", "⚡",
                f"Benchmark: All {total_tx} transactions within {threshold:.0f}% of baseline",
                "UI performance meets contractual benchmark targets",
                source="benchmark")

        # Worst offender
        if rows:
            worst = max(rows, key=lambda r: abs(_f(r.get("delta_pct"))))
            dev   = _f(worst.get("delta_pct"))
            if abs(dev) > threshold:
                tx = worst.get("transaction") or "?"
                add("info", "🔍",
                    f"Slowest transaction: '{tx}' at {dev:+.1f}% vs baseline",
                    f"Actual: {worst.get('current_sec', '?')}s  ·  "
                    f"Baseline: {worst.get('baseline_sec', '?')}s"
                    + (f"  ·  SLA: {worst['sla_sec']}s" if worst.get('sla_sec') else ""),
                    source="benchmark")

        # Category-level findings (multi-sheet XLSX)
        for cat in bench.get("categories") or []:
            name = cat.get("name", "?")
            total_c = _i(cat.get("total", 0))
            degraded_c = _i(cat.get("degraded", 0))
            failed_c = _i(cat.get("failed", 0))
            if degraded_c > 0:
                add("warning", "📊",
                    f"{name}: {degraded_c}/{total_c} regressions detected",
                    f"Average delta: {_f(cat.get('avg_delta', 0)):+.1f}% — review environment parity",
                    source="benchmark", root_cause=f"Performance regression in {name}")

        # Fill rate drift findings
        fr = bench.get("fill_rate") or []
        fr_fails = [e for e in fr if str(e.get("status", "")).lower() not in ("pass", "")]
        if fr_fails:
            add("warning", "📉",
                f"Fill Rate: {len(fr_fails)} entries with drift between PROD & TEST",
                "Fill rate mismatch may indicate data migration or config issues",
                source="benchmark")
        elif fr:
            add("ok", "✅",
                f"Fill Rate: All {len(fr)} entries match between PROD & TEST",
                "Data fill rate is consistent across environments",
                source="benchmark")

        # SIT Observations findings
        obs = bench.get("observations") or []
        open_obs = [o for o in obs if str(o.get("status", "")).lower() not in ("closed", "resolved", "done")]
        if open_obs:
            add("warning", "🔎",
                f"SIT Observations: {len(open_obs)} open issue(s) remain",
                "; ".join(str(o.get("problem", ""))[:60] for o in open_obs[:3]),
                source="benchmark")

    # ═══════════════════════════════════════════════════════════════
    # SOW COMPARE RULES
    # ═══════════════════════════════════════════════════════════════
    sow_cmp = req.sow_compare or {}
    if sow_cmp:
        cov.sow = True
        items    = sow_cmp.get("items") or []
        exceeded = [i for i in items if i.get("zone") in ("HIGH", "EXCEEDS")]
        low_util = [i for i in items if i.get("zone") in ("LOW", "UNDER")]
        optimal  = [i for i in items if i.get("zone") in ("OPTIMAL", "OK")]

        if exceeded:
            names = ", ".join(i.get("metric") or "?" for i in exceeded[:3])
            add("critical", "📈",
                f"SOW exceeded: {len(exceeded)} metric(s) above contract ceiling",
                f"Metrics: {names} — volume above 110% of contracted SOW, commercial review required",
                source="sow")
        elif low_util:
            names = ", ".join(i.get("metric") or "?" for i in low_util[:3])
            add("warning", "📉",
                f"SOW under-utilised: {len(low_util)} metric(s) below 70%",
                f"Metrics: {names} — validate actuals with client before sign-off",
                source="sow")
        elif optimal:
            add("ok", "📊",
                f"SOW utilisation optimal: {len(optimal)} metric(s) in 90–110% zone",
                "Volume consumption aligns with contracted SOW targets",
                source="sow")

    # ── Legacy SOW DFU direct check ───────────────────────────────────────────
    sow_dfu  = _f(req.sow_dfu)
    sow_base = _f(req.sow_dfu_base or sow_dfu)
    if sow_dfu > 0 and sow_base > 0 and not sow_cmp:
        util_pct = (sow_dfu / sow_base) * 100
        if util_pct > 100:
            add("critical", "📦",
                f"SOW DFU exceeded: {util_pct:.1f}% of contracted baseline",
                "Volume above contract ceiling — commercial review required",
                source="sow")
        elif util_pct > 85:
            add("warning", "📦",
                f"SOW DFU at {util_pct:.1f}% of contracted baseline",
                "Approaching contract ceiling — plan for next cycle",
                source="sow")

    # ═══════════════════════════════════════════════════════════════
    # ISSUES REGISTER RULES
    # ═══════════════════════════════════════════════════════════════
    if issues:
        open_issues = [i for i in issues if i.get("Status") in ("Open", "In Progress")]
        if open_issues:
            crit_i = [i for i in open_issues if i.get("Severity") == "Critical"]
            if crit_i:
                ids = ", ".join(str(i.get("ID", "?")) for i in crit_i[:3])
                add("critical", "📋",
                    f"{len(crit_i)} critical open issue(s) in Issues Register",
                    f"IDs: {ids} — must be resolved before PE sign-off",
                    source="issues")
            else:
                add("warning", "📋",
                    f"{len(open_issues)} open issue(s) in Issues Register",
                    "Review and action all open issues before PE audit sign-off",
                    source="issues")

    # ═══════════════════════════════════════════════════════════════
    # INTELLIGENCE RULES — misleading green, contradictions, idle-time
    # ═══════════════════════════════════════════════════════════════

    # ── A1: Misleading Green Detection ────────────────────────────
    # Compliance looks OK only because summed runtime was used instead
    # of the full elapsed batch window.
    if has_batch:
        elapsed_info = bk.get("elapsed_window") if isinstance(bk, dict) else None
        if not elapsed_info:
            elapsed_info = (req.batch_kpis or {}).get("elapsed_window")
        summed_info = bk.get("summed_runtime") if isinstance(bk, dict) else None
        if not summed_info:
            summed_info = (req.batch_kpis or {}).get("summed_runtime")

        if elapsed_info and summed_info:
            el_worst = _f((elapsed_info.get("worst_day") or {}).get("elapsed_hrs"))
            su_worst = _f(summed_info.get("worst_day_hrs"))
            el_avail = elapsed_info.get("available", False)

            if el_avail and el_worst > 0 and su_worst > 0:
                # Use the detected SLA ceiling — never hardcode 6h
                from services import pe_config as _pec
                daily_lim = _f(bk.get("sla_ceiling") or bk.get("daily_limit_hrs") or _pec.SLA_DAILY_HRS)
                if daily_lim <= 0:
                    daily_lim = _pec.SLA_DAILY_HRS
                # Case: summed looks fine but elapsed breaches
                if su_worst <= daily_lim and el_worst > daily_lim:
                    add("critical", "🎭",
                        "Misleading compliance: summed runtime within SLA but elapsed window breaches",
                        f"Summed runtime peak: {su_worst:.1f}h (within {daily_lim:.1f}h SLA) "
                        f"but real elapsed window: {el_worst:.1f}h (exceeds SLA by {el_worst - daily_lim:.1f}h). "
                        f"Orchestration gaps, sequencing delays, or wait states inflate the real batch window.",
                        source="batch", confidence=90,
                        impact="Compliance report appears green but actual batch window breaches SLA — "
                               "customer may challenge this during sign-off review",
                        evidence=f"Summed runtime {su_worst:.1f}h vs elapsed window {el_worst:.1f}h vs SLA {daily_lim:.1f}h",
                        recommendation="Investigate orchestration gaps between jobs. Report elapsed window "
                                       "as primary metric instead of summed runtime.",
                        evidence_class="measured",
                        root_cause="ORCHESTRATION_GAP")

                # Case: large gap between elapsed and summed = idle-time anomaly (A8)
                if el_worst > su_worst * 1.3 and el_worst > 1.0:
                    idle_hrs = el_worst - su_worst
                    idle_pct = (idle_hrs / el_worst) * 100
                    if idle_pct > 20:
                        add("warning", "⏸️",
                            f"Orchestration idle-time anomaly: {idle_pct:.0f}% of batch window is idle",
                            f"Elapsed window {el_worst:.1f}h but jobs only consumed {su_worst:.1f}h — "
                            f"{idle_hrs:.1f}h of idle/wait time between jobs. "
                            f"May indicate sequential dependencies, resource waits, or scheduling gaps.",
                            source="batch", confidence=80,
                            impact="Batch window is inflated by non-productive time — "
                                   "optimisation opportunity or scheduling investigation required",
                            evidence=f"Elapsed {el_worst:.1f}h − Summed {su_worst:.1f}h = {idle_hrs:.1f}h idle ({idle_pct:.0f}%)",
                            recommendation="Review job dependency chains for unnecessary serialisation. "
                                           "Check if approved wait windows exist.",
                            evidence_class="measured",
                            root_cause="IDLE_TIME")

    # ── A4: Hidden Waiver Detection ───────────────────────────────
    # Scan SLA contracts and comments for waiver-like language that
    # isn't reflected in compliance logic.
    #
    # Rule 4 (waiver dedup): emit EXACTLY ONE finding regardless of how many
    # rows contain waiver language. Listing 3+ near-identical cards adds noise
    # without adding signal — the action is identical for all of them.
    if has_batch:
        try:
            from services import config_store as _cs
            sla_intel = _cs.get("_sla_intelligence")
        except Exception:
            sla_intel = None

        if sla_intel and isinstance(sla_intel, dict):
            waiver_keywords = ["waiver", "waived", "exception", "approved exception",
                               "no breach", "agreed", "unofficial", "not enforced",
                               "excluded", "exempted", "customer approved"]
            waiver_hits = []  # [(batch_name, source_row, found_keywords, comment_excerpt)]
            for contract in (sla_intel.get("contracts") or []):
                comments = (contract.get("comments") or "").lower()
                interp = (contract.get("interpretation_notes") or "").lower()
                combined = comments + " " + interp
                found_keywords = [k for k in waiver_keywords if k in combined]
                if found_keywords:
                    waiver_hits.append((
                        contract.get("batch_name", "?"),
                        contract.get("source_row", "?"),
                        found_keywords,
                        (contract.get("comments") or "")[:120],
                    ))

            if waiver_hits:
                n = len(waiver_hits)
                names = [h[0] for h in waiver_hits]
                rows  = [str(h[1]) for h in waiver_hits]
                # Union of all keywords seen (deduped, keep order)
                seen_kw, all_kw = set(), []
                for h in waiver_hits:
                    for k in h[2]:
                        if k not in seen_kw:
                            seen_kw.add(k)
                            all_kw.append(k)
                preview_names = ", ".join(names[:5]) + ("…" if n > 5 else "")
                title = (f"{n} possible waivers in SLA matrix — not in compliance calculations"
                         if n > 1 else
                         f"Possible waiver detected in SLA matrix: '{names[0]}'")
                detail = (f"Rows [{preview_names}] contain comment-based waiver language "
                          f"({', '.join(all_kw[:5])}). "
                          f"None of these are currently reflected in compliance calculations.")
                add("warning", "📜",
                    title,
                    detail,
                    source="sla", confidence=70,
                    impact="Compliance may be understating actual performance if "
                           "waivers should adjust SLA thresholds",
                    evidence=f"SLA matrix rows: {', '.join(rows[:10])}{'…' if n > 10 else ''}",
                    recommendation="Review with customer whether these waivers should be formally "
                                   "incorporated into SLA calculations or documented as exclusions.",
                    evidence_class="inferred",
                    root_cause="WAIVER_NOT_APPLIED")

    # ── A9: Suspicious Null/Zero Server Metrics ──────────────────
    if has_resource and servers:
        zero_cpu = [s for s in servers
                    if _f(s.get("effective_cpu") or s.get("cpu_pct") or 0) == 0
                    and _f(s.get("mem_pct")) == 0]
        nonzero  = [s for s in servers
                    if _f(s.get("effective_cpu") or s.get("cpu_pct") or 0) > 0
                    or _f(s.get("mem_pct")) > 0]
        if zero_cpu and nonzero:
            # Some servers have data, some don't — suspicious
            ratio = len(zero_cpu) / len(servers) * 100
            if ratio >= 30:
                names = ", ".join(s.get("host", "?").split(".")[0] for s in zero_cpu[:4])
                add("warning", "👻",
                    f"{len(zero_cpu)} server(s) ({ratio:.0f}%) report zero CPU + Memory",
                    f"Hosts: {names}{'…' if len(zero_cpu) > 4 else ''} — "
                    f"these servers appear in the report but have no measurable metrics. "
                    f"This may indicate monitoring gaps, powered-off hosts, or document parsing issues.",
                    source="resource", confidence=60,
                    impact="Fleet average and resource findings may be skewed by phantom servers "
                           "that dilute or inflate utilization statistics",
                    evidence=f"{len(zero_cpu)}/{len(servers)} servers with CPU=0% + Mem=0%",
                    recommendation="Verify these servers are in scope and have active monitoring. "
                                   "Exclude powered-off or decommissioned hosts from the report.",
                    evidence_class="inferred",
                    root_cause="MONITORING_GAP")

    # ── A10: Cross-File Data Contradictions ──────────────────────
    if has_batch and sla_ceil:
        # Check if SLA ceilings contradict the actual SLA used in batch analysis
        sla_src = (req.batch_kpis or {}).get("sla_source") or {}
        claimed_daily = _f(sla_src.get("daily_hrs", 0))
        ceil_daily = _f(sla_ceil.get("DAILY", 0))
        if claimed_daily > 0 and ceil_daily > 0 and abs(claimed_daily - ceil_daily) > 0.5:
            add("warning", "⚠️",
                f"SLA contradiction: batch engine uses {claimed_daily:.1f}h but SLA matrix says {ceil_daily:.1f}h",
                f"The batch compliance was calculated against {claimed_daily:.1f}h daily SLA "
                f"but the uploaded SLA matrix specifies {ceil_daily:.1f}h. "
                f"This mismatch may produce misleading compliance percentages.",
                source="batch", confidence=85,
                impact="Compliance results may be calculated against the wrong SLA value",
                evidence=f"batch_calculator daily SLA: {claimed_daily:.1f}h vs sla_ceilings DAILY: {ceil_daily:.1f}h",
                recommendation="Re-upload the SLA matrix and re-run batch analysis to align "
                               "SLA values across all engines.",
                evidence_class="measured",
                root_cause="SLA_MISMATCH")

    # ── Environment Comparison Warnings ──────────────────────────
    try:
        from services import config_store as _cs2
        env_data = None  # env detection results if available via appData
    except Exception:
        env_data = None

    # ═══════════════════════════════════════════════════════════════
    # NARRATIVE GENERATION — structured 5-7 line RCA verdict
    # ═══════════════════════════════════════════════════════════════
    # Produces a clean, technically precise PE audit verdict — each line
    # addresses one dimension: scope, compliance, root cause, impact,
    # evidence quality, and recommended action.
    crit_findings = [f for f in findings if f.level == "critical"]
    warn_findings = [f for f in findings if f.level == "warning"]
    ok_findings   = [f for f in findings if f.level == "ok"]

    # ── Line 1: Data Scope ──
    scope_parts = []
    if has_batch:
        total_runs = _i(bk.get("total_runs"))
        total_jobs = _i(bk.get("total_jobs"))
        date_span  = _i((batch_cov or {}).get("date_span_days", 0))
        scope_parts.append(f"{total_runs} batch runs across {total_jobs} jobs ({date_span}-day window)")
    if has_resource:
        scope_parts.append(f"{len(servers)} servers reviewed")
    if sla_loaded:
        scope_parts.append("customer SLA matrix applied")
    elif has_batch:
        scope_parts.append("default SLA thresholds applied (customer matrix not uploaded)")
    if bench:
        scope_parts.append("UI benchmark comparison included")
    if sow_cmp:
        scope_parts.append("SOW volume comparison included")
    line_scope = f"Scope: {'; '.join(scope_parts)}." if scope_parts else ""

    # ── Line 2: Compliance Summary ──
    if has_batch:
        comp_pct = _f(bk.get("compliance_pct"))
        breach_n = _i(bk.get("jobs_breach"))
        atrisk_n = _i(bk.get("jobs_at_risk"))
        line_compliance = (
            f"Compliance: {comp_pct:.1f}% job-level SLA compliance"
            f" — {breach_n} breach(es), {atrisk_n} at-risk."
        )
    elif has_resource:
        avg_cpu = _f(rk.get("avg_cpu"))
        avg_mem = _f(rk.get("avg_mem"))
        n_crit_s = _i(rk.get("n_critical"))
        fleet_grade = rk.get("fleet_grade", "?")
        line_compliance = (
            f"Fleet: avg CPU {avg_cpu:.1f}%, avg memory {avg_mem:.1f}%"
            f" — {n_crit_s} critical server(s), fleet grade {fleet_grade}."
        )
    else:
        line_compliance = ""

    # ── Line 3: Root Cause Analysis ──
    root_causes = set()
    for cf in crit_findings + warn_findings:
        rc = cf.root_cause
        if rc:
            root_causes.add(rc.replace("_", " ").lower())
    if root_causes:
        rc_list = sorted(root_causes)[:4]
        line_rca = f"Root causes identified: {', '.join(rc_list)}."
    elif crit_findings:
        line_rca = "Root cause: unclassified critical findings require manual investigation."
    elif warn_findings:
        line_rca = "Root cause: no critical blockers; warnings relate to threshold proximity."
    else:
        line_rca = ""

    # ── Line 4: Impact Statement ──
    if crit_findings:
        blocker_sources = set(f.source for f in crit_findings if f.source)
        line_impact = (
            f"Impact: {len(crit_findings)} critical finding(s) across "
            f"{', '.join(sorted(blocker_sources)) or 'multiple pillars'}"
            f" block PE sign-off until resolved."
        )
    elif warn_findings:
        line_impact = (
            f"Impact: {len(warn_findings)} warning(s) require documented acknowledgement "
            f"before conditional sign-off can proceed."
        )
    else:
        line_impact = "Impact: all reviewed metrics within acceptable operational thresholds."

    # ── Line 5: Evidence Quality ──
    measured_count  = sum(1 for f in findings if f.evidence_class == "measured")
    defaulted_count_n = sum(1 for f in findings if f.evidence_class == "defaulted")
    inferred_count_n  = sum(1 for f in findings if f.evidence_class == "inferred")
    total_evidence = measured_count + defaulted_count_n + inferred_count_n
    if total_evidence > 0:
        measured_pct = (measured_count / total_evidence) * 100
        line_evidence = (
            f"Evidence: {measured_pct:.0f}% of findings backed by direct measurement"
        )
        if defaulted_count_n > 0:
            line_evidence += f", {defaulted_count_n} use assumed defaults"
        if inferred_count_n > 0:
            line_evidence += f", {inferred_count_n} inferred from document snapshots"
        line_evidence += "."
    else:
        line_evidence = ""

    # ── Line 6: Decision ──
    if crit_findings:
        line_decision = (
            f"Decision: BLOCKED. Resolve all {len(crit_findings)} critical item(s) "
            f"and re-run analysis before customer review."
        )
    elif warn_findings:
        line_decision = (
            "Decision: CONDITIONAL. Obtain owner acknowledgement on each warning "
            "to proceed with sign-off."
        )
    else:
        line_decision = "Decision: APPROVED. Proceed to customer sign-off."

    # ── Line 7 (optional): Worst offender ──
    line_worst = ""
    if crit_findings:
        worst = crit_findings[0]
        worst_text = (worst.text or "")[:80]
        line_worst = f"Primary blocker: {worst_text}."

    # Assemble lines (filter empty)
    verdict_lines = [l for l in [
        line_scope, line_compliance, line_rca,
        line_impact, line_evidence, line_decision, line_worst,
    ] if l]

    narrative_text = "\n".join(verdict_lines)
    add("info", "📝",
        "Audit Narrative",
        narrative_text,
        source="", evidence_class="measured",
        root_cause="")

    # ── OPEN AUDIT GAPS ──────────────────────────────────────────
    gaps = []
    if not sla_loaded:
        gaps.append("Customer SLA matrix not uploaded — compliance uses assumed defaults")
    if not has_resource:
        gaps.append("No resource utilization report — cannot correlate infra with batch performance")
    if not bench:
        gaps.append("No UI benchmark report — cannot validate user-facing performance")
    if not sow_cmp and not (sow_dfu > 0):
        gaps.append("No SOW/volume comparison — cannot confirm workload within contract limits")
    if has_batch and not (batch_cov or {}).get("has_end_time"):
        gaps.append("End_Time column missing from Ctrl-M export — elapsed window unavailable")
    if has_batch and _i((batch_cov or {}).get("date_span_days")) < 30:
        gaps.append(f"Only {_i((batch_cov or {}).get('date_span_days'))} day(s) of batch data — "
                    "30-day minimum recommended for PE audit")
    if not issues:
        gaps.append("No issues register uploaded — open issues not tracked")

    if gaps:
        add("info", "📋",
            f"Open Audit Gaps: {len(gaps)} area(s) require attention",
            " · ".join(gaps),
            source="", evidence_class="measured",
            impact="Audit may be challenged if these gaps are not addressed",
            recommendation="Upload missing evidence files and re-run analysis to close gaps.")

    # ═══════════════════════════════════════════════════════════════
    # AUDIT READINESS SUMMARY — decision-driven, not score-driven
    # ═══════════════════════════════════════════════════════════════
    crit_count = sum(1 for f in findings if f.level == "critical")
    warn_count = sum(1 for f in findings if f.level == "warning")

    # Identify blockers for sign-off decision strip
    blockers = [f.text for f in findings if f.level == "critical"]
    blocker_causes = []
    if any("batch window" in b.lower() for b in blockers):
        blocker_causes.append("batch-window overruns")
    if any("cpu" in b.lower() or "critical state" in b.lower() for b in blockers):
        blocker_causes.append("critical CPU/resource concentration")
    if any("sla" in b.lower() and "breach" in b.lower() for b in blockers):
        blocker_causes.append("SLA breaches")
    if any("evidence" in b.lower() or "insufficient" in b.lower() for b in blockers):
        blocker_causes.append("incomplete evidence")
    if any("misleading" in b.lower() for b in blockers):
        blocker_causes.append("misleading compliance (elapsed vs summed)")
    if any("waiver" in b.lower() for b in [f.text for f in findings if f.level == "warning"]):
        blocker_causes.append("unresolved waivers in SLA matrix")

    # Count evidence classes
    defaulted_count = sum(1 for f in findings if f.evidence_class == "defaulted")
    inferred_count  = sum(1 for f in findings if f.evidence_class == "inferred")
    unavail_count   = sum(1 for f in findings if f.evidence_class == "unavailable")

    if crit_count == 0 and warn_count == 0:
        sources_loaded = sum([
            has_batch, has_resource,
            bool(sla), bool(bench), bool(sow_cmp),
        ])
        trust_note = ""
        if defaulted_count > 0:
            trust_note = f" · {defaulted_count} finding(s) use default SLA (not customer-approved)"
        if inferred_count > 0:
            trust_note += f" · {inferred_count} finding(s) from document snapshots (not time-series)"
        add("ok", "🏆",
            f"PE audit ready — no critical or warning findings across {sources_loaded} data source(s)",
            f"Customer: {req.customer_name or 'Unknown'} — all reviewed areas within acceptable thresholds"
            + trust_note,
            source="", evidence_class="measured")
    elif crit_count > 0:
        cause_str = ", ".join(blocker_causes) if blocker_causes else "see critical findings above"
        add("info", "⛔",
            f"PE sign-off blocked — {crit_count} critical finding(s), {warn_count} warning(s)",
            f"Ready for sign-off: NO · Blockers: {cause_str}. "
            f"Address all critical items and re-run analysis.",
            source="", evidence_class="measured")

    # Priority sort: critical → warning → info → ok
    _order = {"critical": 0, "warning": 1, "info": 2, "ok": 3}
    findings.sort(key=lambda f: _order.get(f.level, 9))
    return findings, cov


# ── Endpoint ───────────────────────────────────────────────────────────────────

@router.post(
    "/generate-findings",
    response_model=FindingsResponse,
    summary="Run rule-based PE Audit Findings engine v2",
)
async def generate_findings(body: FindingsRequest) -> FindingsResponse:
    findings, cov = _generate(body)
    summary = FindingsSummary(
        critical=sum(1 for f in findings if f.level == "critical"),
        warning =sum(1 for f in findings if f.level == "warning"),
        info    =sum(1 for f in findings if f.level == "info"),
        ok      =sum(1 for f in findings if f.level == "ok"),
        total   =len(findings),
    )

    # NOTE: LLM narrative refinement was intentionally removed from this path.
    # The deterministic narrative lines (Scope / Compliance / Root cause / Impact /
    # Evidence / Decision / Primary blocker) are already well-structured and appear
    # in the verdict hero immediately.  LLM polish happens via the separate
    # /api/smart-findings call that the frontend fires in the background — it never
    # blocks the rule-engine response.

    # ── Build PE Audit Coverage Strip ──────────────────────────────────────────
    batch_cov_data = (body.batch_kpis or {}).get("data_coverage") or {}
    sla_ceil = body.sla_ceilings or {}

    date_span = _i(batch_cov_data.get("date_span_days"))
    if date_span >= 30:
        ev_30 = "loaded"
    elif date_span >= 14:
        ev_30 = "partial"
    else:
        ev_30 = "missing"

    sla_src = "customer" if sla_ceil else (
        "default" if cov.batch else "missing"
    )

    # Check if waivers were detected in findings
    waiver_findings = [f for f in findings if "waiver" in (f.text or "").lower()
                       or f.root_cause == "WAIVER_NOT_APPLIED"]
    waiver_status = "loaded" if waiver_findings else "missing"

    audit_cov = AuditCoverage(
        evidence_30day    = ev_30,
        sla_source        = sla_src,
        waivers           = waiver_status,
        ui_signoff        = "missing",  # placeholder — no UI signoff upload yet
        automation_status = "missing",  # placeholder
        volume_vs_sow     = "loaded" if cov.sow else "missing",
        confidence        = int(_f(batch_cov_data.get("confidence", 0))) if cov.batch else 0,
        confidence_label  = batch_cov_data.get("confidence_label", "INSUFFICIENT") if cov.batch else "INSUFFICIENT",
    )

    resp = FindingsResponse(
        findings=findings, summary=summary,
        data_coverage=cov, audit_coverage=audit_cov,
    )
    # Cache so agent tools can list/read findings without recomputing.
    try:
        from services import session_cache
        session_cache.set("last_findings", resp.model_dump())
    except Exception:
        pass
    return resp


# ── Smart findings endpoint — Claude-grade structured briefing ─────────────
@router.post(
    "/smart-findings",
    summary="Apply FINDINGS OUTPUT RULES + Gemma verdict to the rule engine",
)
async def smart_findings(body: FindingsRequest) -> dict:
    """Run the rule engine, then post-process via services.smart_findings.

    The deterministic dedup + verdict + next-actions runs in-process.
    Gemma is invoked best-effort to produce a 15-word verdict summary;
    the call has a hard timeout and falls back to a deterministic line so
    the UI never waits more than a few seconds.
    """
    import asyncio
    from services.smart_findings import smartify

    # 1. Deterministic rule engine (fast, no LLM)
    raw_findings, cov = _generate(body)
    raw_dicts = [f.model_dump() for f in raw_findings]

    # 2. Dedup + structure (synchronous, O(N))
    # Build KPI evidence for severity mismatch detection
    kpi_ev: dict = {}
    if body.batch_kpis:
        kpi_ev["batch"] = body.batch_kpis
    if body.resource_kpis:
        kpi_ev["resource"] = body.resource_kpis
    if body.sla_matrix:
        kpi_ev["sla"] = body.sla_matrix
    smart = smartify(raw_dicts, customer_name=body.customer_name,
                     kpi_evidence=kpi_ev or None)

    # 3. LLM enrichment — two jobs in one structured call:
    #    A) Enrich findings that are missing root_cause/impact/recommendation
    #    B) Generate a concise verdict headline
    #    Both are data-driven prompts with actual numbers; LLM is not guessing.
    try:
        from services.ai_narrator import narrate
        import asyncio

        # Identify findings that need LLM enrichment (missing key fields)
        findings_needing_enrichment = [
            {"id": i, "severity": f["severity"], "title": f["title"],
             "one_line": f.get("one_line", ""), "source": f.get("source", ""),
             "root_cause": f.get("root_cause", ""), "impact": f.get("impact", ""),
             "action": f.get("action", "—")}
            for i, f in enumerate(smart["findings"])
            if f["level"] in ("critical", "warning")
            and (not f.get("root_cause") or not f.get("impact") or not f.get("action") or f.get("action") == "—")
        ][:8]  # Cap at 8 to keep prompt tight

        # Build context from KPIs for accurate enrichment
        kpi_context = {}
        if body.batch_kpis:
            bk = body.batch_kpis
            kpi_context["batch"] = {
                "compliance_pct": bk.get("compliance_pct"),
                "batch_window_compliance": bk.get("batch_window_compliance"),
                "window_breach_days": bk.get("window_breach_days"),
                "jobs_breach": bk.get("jobs_breach"),
                "total_runs": bk.get("total_runs"),
                "total_jobs": bk.get("total_jobs"),
                "daily_limit_hrs": bk.get("daily_limit_hrs"),
            }
        if body.resource_kpis:
            rk = body.resource_kpis
            kpi_context["resource"] = {
                "fleet_grade": rk.get("fleet_grade"),
                "n_critical": rk.get("n_critical"),
                "n_warning": rk.get("n_warning"),
                "avg_cpu": rk.get("avg_cpu"),
                "avg_mem": rk.get("avg_mem"),
            }
        if body.sla_matrix:
            sm = body.sla_matrix
            kpi_context["sla"] = {
                "compliance_pct": sm.get("compliance_pct"),
                "window_compliance_pct": sm.get("window_compliance_pct"),
                "window_breach_days": sm.get("window_breach_days"),
                "breaching_runs": sm.get("breaching_runs"),
                "worst_job": sm.get("worst_job"),
                "worst_hrs": sm.get("worst_hrs"),
            }

        enrichment_payload = {
            "customer": body.customer_name or "Unknown",
            "decision": smart["verdict"]["decision"],
            "findings_to_enrich": findings_needing_enrichment,
            "kpi_context": kpi_context,
        }

        # Run enrichment + verdict in parallel with a 15s budget
        async def _enrich():
            try:
                text, model = await asyncio.wait_for(
                    asyncio.to_thread(
                        narrate, "findings_enrich", enrichment_payload,
                        max_tokens=600, temperature=0.1,
                    ),
                    timeout=15.0,
                )
                return text, model
            except Exception:
                return None, None

        async def _verdict():
            try:
                verdict_payload = {
                    "decision": smart["verdict"]["decision"],
                    "blocker_count": smart["verdict"]["blocker_count"],
                    "warning_count": smart["verdict"]["warning_count"],
                    "top_findings": [
                        {"severity": f["severity"], "title": f["title"],
                         "evidence": f["evidence"], "impact": f.get("impact", "")}
                        for f in smart["findings"][:5]
                        if f["level"] in ("critical", "warning")
                    ],
                    "customer": smart["verdict"]["customer"],
                    "kpi_context": kpi_context,
                }
                text, model = await asyncio.wait_for(
                    asyncio.to_thread(
                        narrate, "smart_verdict_15w", verdict_payload,
                        max_tokens=80, temperature=0.2,
                    ),
                    timeout=12.0,
                )
                return text, model
            except Exception:
                return None, None

        (enrich_text, enrich_model), (verdict_text, verdict_model) = await asyncio.gather(
            _enrich(), _verdict()
        )

        # Apply LLM enrichment to findings
        if enrich_text:
            import json as _json
            try:
                # Expected: [{id, root_cause, impact, recommendation}]
                enrichments = _json.loads(enrich_text)
                if isinstance(enrichments, list):
                    enrich_map = {e["id"]: e for e in enrichments if isinstance(e, dict) and "id" in e}
                    for i, f in enumerate(smart["findings"]):
                        if i in enrich_map:
                            e = enrich_map[i]
                            if e.get("root_cause") and not f.get("root_cause"):
                                f["root_cause"] = str(e["root_cause"])[:80]
                            if e.get("impact") and (not f.get("impact") or f.get("impact") == "—"):
                                f["impact"] = str(e["impact"])[:150]
                            if e.get("recommendation") and (not f.get("action") or f.get("action") == "—"):
                                f["action"] = str(e["recommendation"])[:120]
                    smart["verdict"]["enrich_model"] = enrich_model
            except Exception:
                pass  # JSON parse error — enrichment silently skipped

        # Apply LLM verdict summary
        if verdict_text:
            smart["verdict"]["summary"]    = verdict_text.strip().rstrip(".") + "."
            smart["verdict"]["ai_model"]   = verdict_model
            smart["verdict"]["ai_powered"] = True
        else:
            smart["verdict"]["ai_powered"] = False
            smart["verdict"]["ai_note"]    = "AI verdict timed out — using deterministic summary"

    except Exception:
        smart["verdict"]["ai_powered"] = False

    # 4. Attach data coverage + audit coverage (re-use the rich shape)
    smart["data_coverage"] = cov.model_dump()

    # 5. Cache smart findings so PE Narrative can cross-validate verdict
    try:
        from services import session_cache
        session_cache.set("last_smart_findings", smart)
    except Exception:
        pass

    return smart
