"""
Azure resource router.

POST /api/azure/fetch-resources
    body: { hours_back?: int, resource_group?: str }
    response: same shape as /api/process-resource
              { kpis, anomalies, servers, executive_summary }

GET /api/azure/status
    Returns whether Azure SPN credentials are configured (without exposing values).

POST /api/azure/validate-spn
    Validates SPN credentials by attempting a lightweight Azure API call.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field

from services import config_store
from services.azure_monitor import (
    AzureConfigError,
    AzureFetchError,
    fetch_vm_metrics,
)
from services.resource_calculator import build_resource_payload

router = APIRouter()


class AzureFetchRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    hours_back:     int = Field(default=24, ge=1, le=720)
    resource_group: Optional[str] = None   # overrides config if supplied


class AzureValidateRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    tenant_id:     str
    client_id:     str
    client_secret: str
    subscription_id: str


@router.get("/azure/status")
def azure_status() -> Dict[str, Any]:
    """Return which Azure SPN fields are configured (values masked)."""
    cfg = config_store.get_all()
    fields = ["azure_tenant_id", "azure_client_id", "azure_client_secret",
              "azure_subscription_id", "azure_resource_group"]
    result: Dict[str, Any] = {}
    for f in fields:
        v = cfg.get(f, "")
        if v and len(str(v)) > 4:
            # Show only that it's set, not the value
            result[f + "_set"] = True
            # Masked preview — first 3 chars + ••••
            result[f + "_preview"] = str(v)[:3] + "••••"
        else:
            result[f + "_set"] = False
            result[f + "_preview"] = "(not set)"

    configured = all(
        cfg.get(k, "").strip()
        for k in ("azure_tenant_id", "azure_client_id",
                  "azure_client_secret", "azure_subscription_id")
    )
    result["configured"] = configured
    return result


@router.post("/azure/validate-spn")
def validate_spn(body: AzureValidateRequest) -> Dict[str, Any]:
    """
    Attempt a lightweight Azure Resource Manager call with the given SPN.
    Returns { valid: bool, vm_count?: int, error?: str }
    Does NOT persist any credentials — call POST /api/config to save them.
    """
    test_cfg = {
        "azure_tenant_id":      body.tenant_id.strip(),
        "azure_client_id":      body.client_id.strip(),
        "azure_client_secret":  body.client_secret.strip(),
        "azure_subscription_id": body.subscription_id.strip(),
        "azure_resource_group": "",
    }
    try:
        from azure.identity import ClientSecretCredential
        from azure.mgmt.compute import ComputeManagementClient
    except ImportError:
        return {
            "valid": False,
            "error": "Azure SDK not installed. Run: pip install azure-monitor-query azure-identity azure-mgmt-compute"
        }

    try:
        cred = ClientSecretCredential(
            tenant_id=test_cfg["azure_tenant_id"],
            client_id=test_cfg["azure_client_id"],
            client_secret=test_cfg["azure_client_secret"],
        )
        compute = ComputeManagementClient(cred, test_cfg["azure_subscription_id"])
        # list_all() is lazy; just pull one page to confirm auth works
        vm_iter = compute.virtual_machines.list_all()
        count = 0
        for vm in vm_iter:
            count += 1
            if count >= 5:  # Don't enumerate the whole subscription
                break
        return {"valid": True, "vm_count_sample": count,
                "message": f"SPN authenticated. Found at least {count} VM(s) — credentials look good."}
    except Exception as exc:
        err = str(exc)
        hint = ""
        if "AADSTS700016" in err:
            hint = "Application not found in tenant — check Tenant ID and Client ID."
        elif "AADSTS7000215" in err:
            hint = "Invalid client secret — generate a new one in App Registration → Certificates & secrets."
        elif "AuthorizationFailed" in err or "403" in err:
            hint = "SPN lacks permission. Assign 'Monitoring Reader' role on the subscription."
        elif "AADSTS90002" in err:
            hint = "Tenant not found — double-check the Tenant ID (Directory ID)."
        return {"valid": False, "error": err[:200], "hint": hint or "Check SPN credentials and RBAC assignments."}


@router.post("/azure/fetch-resources")
def fetch_azure_resources(body: AzureFetchRequest) -> Dict[str, Any]:
    """
    Fetch VM metrics from Azure Monitor using the stored SPN credentials,
    then run them through resource_calculator to produce the standard
    Resource Review payload.
    """
    cfg = config_store.get_all()

    # Allow per-request resource group override
    if body.resource_group:
        cfg = dict(cfg)
        cfg["azure_resource_group"] = body.resource_group.strip()

    try:
        servers = fetch_vm_metrics(cfg, hours_back=body.hours_back)
    except AzureConfigError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail=str(exc)) from exc
    except AzureFetchError as exc:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY,
                            detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Unexpected error fetching Azure data: {exc}") from exc

    if not servers:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="No VMs returned from Azure. Check resource group filter and SPN permissions.")

    try:
        payload = build_resource_payload(servers)
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Resource calculation failed: {exc}") from exc

    payload["source"] = "azure_monitor"
    payload["hours_back"] = body.hours_back
    payload["vm_count"] = len(servers)
    return payload
