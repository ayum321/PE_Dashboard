@echo off
REM ================================================================
REM   PE Audit Dashboard  --  Smart Self-Healing Launcher
REM   Phases 2-8: Vision AI, SLA Matrix, Benchmark, Azure Monitor
REM
REM   Capabilities:
REM     * Finds Python 3.11+ in 30+ locations (PATH, LOCALAPPDATA,
REM       ProgramFiles, WindowsApps, deep scan, winget auto-install)
REM     * Bootstraps pip with ensurepip + get-pip.py fallback
REM     * Installs packages with --user + trusted-host proxy fallback
REM     * 7-day stamp skips re-install for fast subsequent launches
REM     * Verifies all app files + uvicorn importable before starting
REM     * Finds a free port and clears any conflict automatically
REM ================================================================

setlocal ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION

set "HOST=127.0.0.1"
set "APP=main:app"
set "PORT="
set "PY="

cd /d "%~dp0"

echo.
echo  ================================================================
echo   PE Audit Dashboard  ^|  Batch Performance Intelligence
echo  ================================================================
echo   Working dir : %CD%
echo.


REM ================================================================
REM  STEP 1 -- Find Python 3.11+
REM  A  py launcher (3.14 down to 3.11)
REM  B  PATH: python3, python
REM  C  LOCALAPPDATA non-PATH layouts
REM  D  ProgramFiles system-wide
REM  E  USERPROFILE alternate layouts
REM  F  Microsoft Store WindowsApps shims
REM  G  Deep filesystem scan
REM  H  winget auto-install
REM  I  Instructions + exit
REM ================================================================
echo   [1/7] Locating Python 3.11+ ...

REM A -- py launcher
where py >nul 2>&1
if not errorlevel 1 (
    for %%V in (3.14 3.13 3.12 3.11) do (
        if "!PY!"=="" (
            py -%%V --version >nul 2>&1
            if not errorlevel 1 (
                py -%%V -c "import sys;sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>&1
                if not errorlevel 1 set "PY=py -%%V"
            )
        )
    )
)
if not "!PY!"=="" goto :found_python

REM B -- PATH
for %%C in (python3 python) do (
    if "!PY!"=="" (
        where %%C >nul 2>&1
        if not errorlevel 1 (
            %%C -c "import sys;sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>&1
            if not errorlevel 1 set "PY=%%C"
        )
    )
)
if not "!PY!"=="" goto :found_python

REM C -- LOCALAPPDATA non-PATH layouts
call :try "%LOCALAPPDATA%\Python\bin\python.exe"
call :try "%LOCALAPPDATA%\Python\python.exe"
call :try "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
call :try "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
call :try "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
call :try "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
call :try "%APPDATA%\..\Local\Python\bin\python.exe"
call :try "%APPDATA%\..\Local\Programs\Python\Python314\python.exe"
call :try "%APPDATA%\..\Local\Programs\Python\Python313\python.exe"
call :try "%APPDATA%\..\Local\Programs\Python\Python312\python.exe"
call :try "%APPDATA%\..\Local\Programs\Python\Python311\python.exe"
if not "!PY!"=="" goto :found_python

REM D -- ProgramFiles system-wide
for %%D in ("%ProgramFiles%" "%ProgramFiles(x86)%") do (
    for %%V in (Python314 Python313 Python312 Python311) do (
        call :try "%%~D\%%V\python.exe"
    )
)
if not "!PY!"=="" goto :found_python

REM E -- USERPROFILE alternate layouts
call :try "%USERPROFILE%\Python314\python.exe"
call :try "%USERPROFILE%\Python313\python.exe"
call :try "%USERPROFILE%\Python312\python.exe"
call :try "%USERPROFILE%\Python311\python.exe"
call :try "%USERPROFILE%\AppData\Local\Python\bin\python.exe"
if not "!PY!"=="" goto :found_python

REM F -- Microsoft Store / WindowsApps
for %%V in (3.14 3.13 3.12 3.11) do (
    if "!PY!"=="" (
        set "_ms=%LOCALAPPDATA%\Microsoft\WindowsApps\python%%V.exe"
        if exist "!_ms!" (
            "!_ms!" -c "import sys;sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>&1
            if not errorlevel 1 set "PY=!_ms!"
        )
    )
)
if not "!PY!"=="" goto :found_python

REM G -- Deep scan under common roots
echo        Scanning filesystem (may take a moment)...
for %%D in ("%LOCALAPPDATA%\Programs" "%LOCALAPPDATA%" "%ProgramFiles%" "%ProgramFiles(x86)%" "%USERPROFILE%") do (
    if "!PY!"=="" (
        for /f "delims=" %%F in ('dir /b /s "%%~D\python.exe" 2^>nul ^| findstr /i "python3"') do (
            if "!PY!"=="" (
                "%%F" -c "import sys;sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>&1
                if not errorlevel 1 set "PY=%%F"
            )
        )
    )
)
if not "!PY!"=="" goto :found_python

REM H -- winget auto-install
echo.
echo        Python 3.11+ not found anywhere. Attempting winget install...
where winget >nul 2>&1
if not errorlevel 1 (
    echo        Running: winget install Python.Python.3.13
    echo        (Internet required -- may take 1-3 minutes)
    winget install --id Python.Python.3.13 --source winget --accept-package-agreements --accept-source-agreements --silent
    if not errorlevel 1 (
        echo        Installed. Refreshing PATH...
        for /f "skip=2 tokens=2*" %%A in ('reg query "HKCU\Environment" /v PATH 2^>nul') do set "PATH=!PATH!;%%B"
        for /f "skip=2 tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v PATH 2^>nul') do set "PATH=!PATH!;%%B"
        call :try "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
        where python >nul 2>&1
        if not errorlevel 1 (
            python -c "import sys;sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>&1
            if not errorlevel 1 set "PY=python"
        )
        if not "!PY!"=="" goto :found_python
        echo        winget installed OK but Python unreachable in this session.
        echo        Close this window, open a NEW Command Prompt, re-run start.bat.
        echo.
    ) else (
        echo        winget install failed. Check internet connection.
    )
) else (
    echo        winget not available on this machine.
)

REM I -- Instructions + exit
echo.
echo  +==============================================================+
echo  ^|  ACTION REQUIRED: Python 3.11+ not found                    ^|
echo  +==============================================================+
echo  ^|                                                              ^|
echo  ^|  OPTION 1 -- winget (Windows 10/11, no admin needed):       ^|
echo  ^|    1. Open a NEW Command Prompt                             ^|
echo  ^|    2. Run:  winget install Python.Python.3.13               ^|
echo  ^|    3. Close all cmd windows and re-run start.bat            ^|
echo  ^|                                                              ^|
echo  ^|  OPTION 2 -- Manual installer:                              ^|
echo  ^|    1. https://www.python.org/downloads/                     ^|
echo  ^|    2. Download Python 3.13 Windows installer                ^|
echo  ^|    3. CHECK the box: "Add Python to PATH"                   ^|
echo  ^|    4. Close all cmd windows and re-run start.bat            ^|
echo  ^|                                                              ^|
echo  +==============================================================+
echo.
pause
exit /b 1

REM -- Subroutine: probe one full exe path --
:try
if "!PY!"=="" (
    if exist "%~1" (
        "%~1" -c "import sys;sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>&1
        if not errorlevel 1 set "PY=%~1"
    )
)
goto :eof


:found_python
echo        Found : !PY!
!PY! --version


REM ================================================================
REM  STEP 2 -- Ensure pip is available, bootstrap if missing
REM ================================================================
echo.
echo   [2/7] Checking pip...

!PY! -m pip --version >nul 2>&1
if not errorlevel 1 goto :pip_ok

echo        pip not found -- bootstrapping with ensurepip...
!PY! -m ensurepip --upgrade >nul 2>&1
!PY! -m pip --version >nul 2>&1
if not errorlevel 1 goto :pip_ok

echo        ensurepip failed -- trying get-pip.py download...
where curl >nul 2>&1
if not errorlevel 1 (
    curl -sS "https://bootstrap.pypa.io/get-pip.py" -o "%TEMP%\get-pip.py" 2>nul
    if exist "%TEMP%\get-pip.py" (
        !PY! "%TEMP%\get-pip.py" --quiet >nul 2>&1
        del "%TEMP%\get-pip.py" >nul 2>&1
    )
)

!PY! -m pip --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo   [ERROR] pip cannot be initialised.
    echo          Try manually: !PY! -m ensurepip --upgrade
    echo          Then re-run start.bat
    pause
    exit /b 1
)

:pip_ok
echo        pip OK


REM ================================================================
REM  STEP 3 -- Install packages
REM
REM  .pkg_stamp: skips installs when stamp < 7 days old.
REM  Set FORCE_INSTALL=1 to always re-install.
REM
REM  Per-group install cascade:
REM    1. Standard global install
REM    2. --user   (restricted / no-admin machines)
REM    3. --user + --trusted-host   (corporate TLS proxy)
REM ================================================================
echo.
echo   [3/7] Checking packages...

set "STAMP=%~dp0.pkg_stamp"

if "%FORCE_INSTALL%"=="" (
    if exist "!STAMP!" (
        !PY! -c "import os,time;age=(time.time()-os.path.getmtime(r'!STAMP!'))/86400;exit(0 if age<7 else 1)" >nul 2>&1
        if not errorlevel 1 (
            echo        Packages verified recently (stamp under 7 days). Skipping install.
            echo        Delete .pkg_stamp or set FORCE_INSTALL=1 to force reinstall.
            goto :step4
        )
    )
)

echo        Installing / upgrading all packages...

REM Upgrade pip itself
!PY! -m pip install --upgrade pip --quiet --no-warn-script-location >nul 2>&1

REM Core framework
call :pkg "fastapi>=0.111.0" "uvicorn[standard]>=0.29.0" "pydantic>=2.7.0" "jinja2>=3.1.3" "python-multipart>=0.0.9"

REM Document parsing
call :pkg "pypdf>=4.2.0" "python-docx>=1.1.0" "lxml>=5.2.0" "beautifulsoup4>=4.12.3"

REM Batch analytics
call :pkg "pandas>=2.2.0" "numpy>=1.26.0" "openpyxl>=3.1.2" "xlrd>=2.0.1"

REM Gemini AI (new SDK primary + legacy fallback)
call :pkg "google-genai>=1.0.0" "google-generativeai>=0.8.0"

REM Vision / image pipeline
call :pkg "PyMuPDF>=1.23.0" "Pillow>=10.0.0"

REM HTTP client
call :pkg "requests>=2.32.0"

REM Azure Monitor live-connect (optional but preinstalled)
call :pkg "azure-identity>=1.16.0" "azure-monitor-query>=1.3.0" "azure-mgmt-compute>=30.0.0" "azure-mgmt-resource>=23.0.0"

REM Write stamp (Python writes the file cleanly, avoids CMD redirect quirks)
!PY! -c "open(r'!STAMP!','w').write('ok')" >nul 2>&1
echo        All packages ready.
goto :step4


REM -- Package install subroutine with 3-tier fallback --
:pkg
REM Attempt 1: standard global
!PY! -m pip install --quiet --no-warn-script-location %* >nul 2>&1
if not errorlevel 1 goto :eof

REM Attempt 2: --user (no admin / restricted corporate machine)
!PY! -m pip install --quiet --no-warn-script-location --user %* >nul 2>&1
if not errorlevel 1 (
    echo        [user-mode] %*
    goto :eof
)

REM Attempt 3: --user + --trusted-host (corporate TLS inspection proxy)
!PY! -m pip install --quiet --no-warn-script-location --user --trusted-host pypi.org --trusted-host files.pythonhosted.org --trusted-host pypi.python.org %* >nul 2>&1
if not errorlevel 1 (
    echo        [proxy-mode] %*
    goto :eof
)

echo   [WARN] Could not install: %*
echo          (network/proxy issue -- app may still work if already installed)
goto :eof


:step4
REM ================================================================
REM  STEP 4 -- Verify required files and uvicorn importable
REM ================================================================
echo.
echo   [4/7] Verifying app files...

set "FILES_OK=1"
for %%F in (main.py _find_port.py _open_browser.py _seed_config.py) do (
    if not exist "%%F" (
        echo   [ERROR] Missing: %%F
        set "FILES_OK=0"
    )
)
if "!FILES_OK!"=="0" (
    echo.
    echo          Dashboard files are incomplete.
    echo          Please re-extract PE_Dashboard_Release.zip into a fresh folder.
    pause
    exit /b 1
)

!PY! -c "import uvicorn" >nul 2>&1
if errorlevel 1 (
    echo        uvicorn not importable -- forcing reinstall...
    !PY! -m pip install --quiet --user "uvicorn[standard]>=0.29.0" "fastapi>=0.111.0"
    !PY! -c "import uvicorn" >nul 2>&1
    if errorlevel 1 (
        echo   [ERROR] uvicorn still unavailable after reinstall.
        echo          Check internet/proxy and re-run start.bat.
        pause
        exit /b 1
    )
)
echo        All files and imports verified.


REM ================================================================
REM  STEP 5 -- Seed config
REM ================================================================
echo.
echo   [5/7] Seeding configuration...
!PY! _seed_config.py >nul 2>&1
if errorlevel 1 echo        [WARN] Config seed error -- defaults will apply.
echo        Config ready.


REM ================================================================
REM  STEP 6 -- Find free port, clear any conflict
REM ================================================================
echo.
echo   [6/7] Finding free port...

for /f "usebackq delims=" %%P in (`!PY! _find_port.py 2^>nul`) do set "PORT=%%P"

if "!PORT!"=="" (
    echo   [ERROR] No free port found (all ports 8765-8800 in use?).
    echo          Close other applications and re-run start.bat.
    pause
    exit /b 1
)
echo        Port : !PORT!

for /f "tokens=5" %%P in ('netstat -ano 2^>nul ^| findstr /R /C:":!PORT! .*LISTENING"') do (
    if not "%%P"=="0" (
        echo        Releasing PID %%P on port !PORT!
        taskkill /F /PID %%P >nul 2>&1
    )
)


REM ================================================================
REM  STEP 7 -- Banner, open browser, start server
REM ================================================================
echo.
echo  ================================================================
echo   Dashboard  :  http://%HOST%:!PORT!/
echo   API Docs   :  http://%HOST%:!PORT!/docs
echo   Config     :  .pe_config.json  (edit in Settings tab)
echo.
echo   Tabs: Upload+Intake  Executive  Batch  Resource  Correlation
echo         Findings  Red Flags  SLA Matrix  Benchmark  SOW  Settings
echo  ================================================================
echo.
echo   [7/7] Starting server  (Ctrl+C to stop)...
echo.

start "PE Browser" /B !PY! _open_browser.py %HOST% !PORT!
!PY! -m uvicorn %APP% --host %HOST% --port !PORT! --reload

endlocal
