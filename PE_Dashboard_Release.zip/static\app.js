// ════════════════════════════════════════════════════════════
//  PE Audit Dashboard — Phase 2 frontend (Vanilla JS, ES2020+)
//
//  Replaces st.session_state with `window.appData`.
//  Responsibilities:
//    1. Sidebar nav (show/hide views, page-title binding)
//    2. HTML5 Drag & Drop upload zone
//    3. Multipart POST to /api/upload via fetch()
//    4. Toast notifications + KPI strip rendering
//    5. Reset / clear flow
//
//  No build step. No framework. No dependencies beyond Tailwind v3
//  Play CDN + Chart.js (loaded in index.html, used in Phase 3+).
// ════════════════════════════════════════════════════════════
"use strict";

// ── Global state ────────────────────────────────────────────
//   Mirrors the role of st.session_state in the old Streamlit app.
//   Frontend code reads/writes via window.appData.* exclusively.
window.appData = {
  upload:        null,   // last resource UploadResponse JSON
  servers:       [],     // alias to upload.servers, convenience
  batch:         null,   // last BatchResponse JSON
  resource:      null,   // last ResourceResponse JSON (Phase 4)
  issues:        [],     // Issues & Waivers register (Phase 6)
  customerName:  "",     // extracted from uploaded resource document heading
  slaMatrix:     null,   // from /api/sla-matrix (Phase 7)
  slaCeilings:   null,   // from /api/sla-ceilings — customer SLA window dict
  benchmark:     null,   // from /api/benchmark  (Phase 7)
  sowCompare:    null,   // from /api/sow/compare (Phase 8)
  config:        null,   // loaded from /api/config on startup
  approvals: {           // Governance sign-off state (Phase 6)
    customer_name: "",
    env_type: "",
    checklist: { batch:false, res:false, data:false, issues:false,
                 perf:false, ctrlm:false, ui:false, sow:false, res15:false },
    pe:       { name:"", approved:false, date:"" },
    customer: { name:"", approved:false, date:"" },
    notes: "",
  },
  view:     "upload",
  loadedAt: null,
};

// Theme palette — kept in sync with tailwind.config in index.html
const THEME = {
  bg:     "#060914",
  card:   "#0d1526",
  card2:  "#111d36",
  border: "#213060",
  green:  "#10d96e",
  amber:  "#f59e0b",
  red:    "#f43f5e",
  blue:   "#3b82f6",
  purple: "#a855f7",
  cyan:   "#22d3ee",
  teal:   "#2dd4bf",
  muted:  "#6b7db3",
  white:  "#f0f4ff",
};
// SLA daily limit — kept in sync with the backend config loaded in loadConfig().
// Use `let` so loadConfig() can update it when the user changes settings.
let SLA_DAILY_HRS = 6.0;

// Live Chart.js instances — re-created on every renderBatchReview() / renderResourceReview() call
const charts = { slaBuffer: null, windowTrend: null, topJobs: null, resourceBars: null };

// Resource Review · table view state
const resourceTableState = { showAll: false, filter: "" };
const RESOURCE_TABLE_PREVIEW = 25; // initial lazy slice

// ─────────────────────────────────────────────────────────────
// Bootstrap
// ─────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  initNav();
  initDropZone();
  initResetButton();
  initJsonToggle();
  initBatchUploader();
  initResourceView();
  initGovernanceTab();
  initFindingsTab();
  initSlaIntakeUploader();
  initBenchIntakeUploader();
  initSlaModeSelect();
  initSowTab();
  setActiveView("upload");
  loadConfig();           // pull stored settings from backend
  _loadAzureStatusBadge(); // check Azure SPN status
  refreshAiStatus();      // header AI engine badge
  console.info("[pe-dashboard] full shell ready (phases 2-8)");
});


// ─────────────────────────────────────────────────────────────
// 1.  Navigation — show/hide view panels
// ─────────────────────────────────────────────────────────────
const VIEW_META = {
  upload:      { title: "Upload & Intake",        sub: "Drop any PE file — auto-classified and routed" },
  overview:    { title: "Executive Dashboard",    sub: "OSHS · RFCS · SRI · CRS — Batch × Resource × SLA correlation intelligence" },
  batch:       { title: "Batch Review",           sub: "Ctrl-M execution KPIs and SLA buffers" },
  resource:    { title: "Resource Review",        sub: "Server CPU, memory and disk health" },
  correlation: { title: "Correlation Analysis",   sub: "CTRL-M batch issues cross-referenced with server resource peaks" },
  insights:    { title: "PE Findings",            sub: "Automated audit intelligence + Gemini AI analysis" },
  redflags:    { title: "Red Flags & RCA",        sub: "PE investigation questions and risk priority matrix" },
  findings:    { title: "Governance",             sub: "Issues register, approval checklist and sign-off" },
  slamatrix:   { title: "SLA Matrix",             sub: "Detailed SLA compliance per job — daily · weekly · custom" },
  benchmark:   { title: "UI Benchmark",           sub: "Baseline vs Current response time comparison matrix" },
  sow:         { title: "DFU / SKU vs SOW",       sub: "Volume achievement against Statement of Work baseline — DFU · SKU · Orders · Capacity" },
  settings:    { title: "Settings",               sub: "Gemini API key, SLA defaults and configuration" },
};

function initNav() {
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.addEventListener("click", () => setActiveView(btn.dataset.view));
  });
  // In-panel jump targets (e.g. empty-state buttons)
  document.querySelectorAll("[data-view-target]").forEach((btn) => {
    btn.addEventListener("click", () => setActiveView(btn.dataset.viewTarget));
  });
}

function setActiveView(view) {
  if (!VIEW_META[view]) return;
  window.appData.view = view;

  // Toggle sidebar button styling
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    const active = btn.dataset.view === view;
    btn.classList.toggle("bg-CnavActiveBg", active);
    btn.classList.toggle("text-Cwhite",     active);
    btn.classList.toggle("border-l-2",      active);
    btn.classList.toggle("border-CnavActiveBorder", active);
    btn.classList.toggle("text-Cmuted",    !active);
    btn.classList.toggle("hover:text-Cwhite", !active);
    btn.classList.toggle("hover:bg-Ccard/40", !active);
  });

  // Toggle main panels
  document.querySelectorAll("[data-view-panel]").forEach((panel) => {
    panel.classList.toggle("hidden", panel.dataset.viewPanel !== view);
  });

  // Update page header
  const meta = VIEW_META[view];
  document.getElementById("page-title").textContent = meta.title;
  document.getElementById("page-sub").textContent   = meta.sub;

  // Re-evaluate the global customer-name chip — chip is permanently hidden
  // (removed from header per UX cleanup; customer still shown in Exec banner).
  const hdrChip = document.getElementById("header-customer-chip");
  if (hdrChip) {
    hdrChip.classList.add("hidden");
    hdrChip.classList.remove("inline-flex");
  }

  // Auto-refresh each intelligence tab when data is available
  const hasData = !!(window.appData.batch || window.appData.resource || window.appData.servers?.length);
  if (hasData) {
    if (view === "overview")     renderOverview();
    if (view === "insights")     triggerGenerateFindings();
    if (view === "correlation")  triggerCorrelation();
    if (view === "redflags")     triggerRedFlags();
  }

  // New tab hooks
  if (view === "settings")   loadSettings();
  if (view === "slamatrix" && window.appData.batch) triggerSlaMatrix();
  if (view === "sow")        loadSowBaseline();

  // Always refresh overview if data is present (sidebar data-status too)
  refreshDataStatus();
}


// ─────────────────────────────────────────────────────────────
// 2.  Drag & Drop upload zone
// ─────────────────────────────────────────────────────────────
function initDropZone() {
  const dropZone  = document.getElementById("drop-zone");
  const fileInput = document.getElementById("file-input");
  if (!dropZone || !fileInput) return;

  // Click → open file picker
  dropZone.addEventListener("click", () => fileInput.click());

  // File picker → upload (multi-file supported)
  fileInput.addEventListener("change", (e) => {
    const picked = [...(e.target.files || [])];
    const files = picked.filter(f => isAllowed(f));
    const skipped = picked.length - files.length;
    if (skipped > 0) {
      toast("warning", "Unsupported file(s)", "Resource Report accepts only .pdf and .docx files. Use the other upload tiles for Ctrl-M, SLA Matrix, or Benchmark files.");
    }
    if (files.length) _uploadResourceFiles(files);
    fileInput.value = ""; // allow re-selecting the same file
  });

  // Drag-over visual feedback
  ["dragenter", "dragover"].forEach((ev) =>
    dropZone.addEventListener(ev, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.add("dropzone-active");
    })
  );
  ["dragleave", "dragend"].forEach((ev) =>
    dropZone.addEventListener(ev, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.remove("dropzone-active");
    })
  );

  // Drop → validate + upload (multi-file)
  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    e.stopPropagation();
    dropZone.classList.remove("dropzone-active");

    const files = [...(e.dataTransfer?.files || [])];
    if (!files.length) return;
    const valid = files.filter(f => isAllowed(f));
    const skipped = files.length - valid.length;
    if (skipped > 0) {
      toast("warning", `${skipped} file(s) skipped`, "Resource Report accepts only .pdf and .docx files. Use the other upload tiles for Ctrl-M, SLA Matrix, or Benchmark files.");
    }
    if (valid.length) _uploadResourceFiles(valid);
  });

  // Block accidental drops on the rest of the page
  ["dragover", "drop"].forEach((ev) =>
    window.addEventListener(ev, (e) => e.preventDefault())
  );
}

function isAllowed(file) {
  const name = (file.name || "").toLowerCase();
  return name.endsWith(".pdf") || name.endsWith(".docx");
}


// ─────────────────────────────────────────────────────────────
// 3.  Upload pipeline
// ─────────────────────────────────────────────────────────────
async function uploadFile(file) {
  _renderIntakeProgress("upload-status", {
    filename: file.name,
    message:  formatBytes(file.size),
    percent:  0,
    color:    "blue",
    phase:    "uploading",
  });

  const fd = new FormData();
  fd.append("file", file, file.name);

  try {
    const { ok, status, body } = await _uploadWithProgress("/api/upload", fd, (pct, loaded, total, finished) => {
      _renderIntakeProgress("upload-status", {
        filename: file.name,
        message:  finished ? `${formatBytes(file.size)} — server-side parse…`
                           : `${formatBytes(loaded)} / ${formatBytes(total)}`,
        percent:  finished ? null : pct,
        color:    "blue",
        phase:    finished ? "processing" : "uploading",
      });
    });
    const payload = body;

    if (!ok) {
      hideUploadStatus();
      const detail = payload?.detail || `HTTP ${status}`;
      toast("error", "Upload failed", detail);
      console.error("[pe-dashboard] upload failed", payload);
      return;
    }

    // ── Persist to global state (replaces st.session_state) ──
    window.appData.upload   = payload;
    window.appData.servers  = payload.servers || [];
    window.appData.loadedAt = new Date().toISOString();
    window._execCache = null; // invalidate exec dashboard cache



    hideUploadStatus();
    renderUploadResult(payload);
    toast(
      "success",
      "Upload complete",
      `${payload.server_count} server${payload.server_count === 1 ? "" : "s"} parsed from ${payload.filename}`
    );
    console.info("[pe-dashboard] window.appData updated", window.appData);

    // ── Phase 4 · auto-run Fleet Intelligence on the parsed servers
    if (Array.isArray(payload.servers) && payload.servers.length > 0) {
      processResourceServers(payload.servers).catch((err) => {
        console.error("[pe-dashboard] resource processing failed", err);
      });
    }
    refreshDataStatus();
  } catch (err) {
    hideUploadStatus();
    toast("error", "Network error", String(err?.message || err));
    console.error("[pe-dashboard] network error", err);
  }
}


/** Upload multiple resource files sequentially — merges server lists. */
async function _uploadResourceFiles(files) {
  const MAX = 8;
  const batch = files.slice(0, MAX);
  if (files.length > MAX) toast("info", `Processing first ${MAX} files`, `${files.length - MAX} file(s) queued — re-upload remaining after this batch.`);

  let allServers = [...(window.appData.servers || [])];
  let lastPayload = null;
  let totalNew = 0;

  for (let i = 0; i < batch.length; i++) {
    const f = batch[i];
    const prefix = `${i + 1}/${batch.length}`;
    _renderIntakeProgress("upload-status", {
      filename: f.name,
      message:  `File ${prefix} · ${formatBytes(f.size)}`,
      percent:  0,
      color:    "blue",
      phase:    "uploading",
    });
    const fd = new FormData();
    fd.append("file", f, f.name);
    try {
      const { ok, status, body } = await _uploadWithProgress("/api/upload", fd, (pct, loaded, total, finished) => {
        _renderIntakeProgress("upload-status", {
          filename: f.name,
          message:  finished ? `${prefix} · ${formatBytes(f.size)} — parsing…`
                             : `${prefix} · ${formatBytes(loaded)} / ${formatBytes(total)}`,
          percent:  finished ? null : pct,
          color:    "blue",
          phase:    finished ? "processing" : "uploading",
        });
      });
      const payload = body;
      if (!ok) {
        toast("error", `${f.name} failed`, (payload?.detail || `HTTP ${status}`).slice(0, 120));
        continue;
      }
      // Merge servers — avoid duplicates by hostname
      const newServers = (payload.servers || []).filter(s => {
        const h = (s.host || s.server || "").toLowerCase();
        return !allServers.some(e => (e.host || e.server || "").toLowerCase() === h);
      });
      allServers = [...allServers, ...newServers];
      totalNew += newServers.length;
      lastPayload = payload;
    } catch (err) {
      toast("error", `${f.name} error`, String(err?.message || err));
    }
  }

  hideUploadStatus();
  if (!lastPayload) return;



  // Update global state with merged server list
  window.appData.upload  = { ...lastPayload, servers: allServers, server_count: allServers.length };
  window.appData.servers = allServers;
  window.appData.loadedAt = new Date().toISOString();
  renderUploadResult(window.appData.upload);
  toast("success", `${batch.length} file(s) processed`, `${totalNew} new server(s) merged · ${allServers.length} total`);
  if (allServers.length > 0) processResourceServers(allServers).catch(() => {});
  refreshDataStatus();
}




// ─────────────────────────────────────────────────────────────
// 4.  Result rendering (KPI strip + raw JSON dump)
// ─────────────────────────────────────────────────────────────
function renderUploadResult(payload) {
  const card = document.getElementById("upload-result");
  if (!card) return;
  card.classList.remove("hidden");

  setText("kpi-filename",     payload.filename);
  setText("kpi-filetype",     (payload.file_type || "").toUpperCase());
  setText("kpi-server-count", String(payload.server_count ?? 0));
  setText("kpi-mode",         payload.image_only ? "Image-only" : "Text-extracted");

  // Header chip + reset button
  const chip = document.getElementById("dataset-chip");
  if (chip) {
    chip.textContent = `${payload.filename} · ${payload.server_count} servers`;
    chip.classList.remove("hidden");
  }
  document.getElementById("reset-btn")?.classList.remove("hidden");

  // Pre-stage the JSON dump (collapsed by default)
  const dump = document.getElementById("json-dump");
  if (dump) dump.textContent = JSON.stringify(payload, null, 2);

  // Keep the intake card concise; do not surface the post-upload AI
  // briefing on the first page even if the API returns it.
  const aiCard  = document.getElementById("upload-ai-card");
  const aiText  = document.getElementById("upload-ai-text");
  const aiModel = document.getElementById("upload-ai-model");
  if (aiCard && aiText) {
    aiText.textContent = "";
    if (aiModel) aiModel.textContent = "—";
    aiCard.classList.add("hidden");
  }

  // ── Unified intake page: show status card + resource dot ──
  document.getElementById("intake-status-row")?.classList.remove("hidden");
  document.getElementById("upload-next-prompt")?.classList.remove("hidden");
  const dot = document.getElementById("res-status-dot");
  if (dot) { dot.classList.remove("bg-Cmuted/40"); dot.classList.add("bg-Cblue", "animate-pulse"); }
}

function _renderBatchIntakeCard(payload) {
  // Show the batch result card in the Upload & Intake page
  const card = document.getElementById("batch-result-card");
  if (card) card.classList.remove("hidden");
  setText("batch-filename-kpi",   payload.filename);
  setText("batch-runs-kpi",       (payload.kpis.total_runs || 0).toLocaleString());
  setText("batch-compliance-kpi", (payload.kpis.compliance_pct ?? 0).toFixed(1) + "%");
  const breachEl = document.getElementById("batch-breach-kpi");
  if (breachEl) {
    breachEl.textContent = payload.kpis.jobs_breach ?? 0;
    breachEl.className   = `text-xl font-extrabold mt-0.5 ${payload.kpis.jobs_breach > 0 ? "text-Cred" : "text-Cgreen"}`;
  }
  document.getElementById("intake-status-row")?.classList.remove("hidden");
  document.getElementById("upload-next-prompt")?.classList.remove("hidden");
  const dot = document.getElementById("batch-status-dot");
  if (dot) { dot.classList.remove("bg-Cmuted/40"); dot.classList.add("bg-Cgreen", "animate-pulse"); }
  // Batch tab: hide no-data prompt, show loaded chip
  document.getElementById("batch-no-data-prompt")?.classList.add("hidden");
  const chip = document.getElementById("batch-loaded-chip");
  if (chip) chip.classList.remove("hidden");
  setText("batch-dataset-chip", `${payload.filename} · ${payload.kpis.total_runs.toLocaleString()} runs`);

  // Customer name — sourced ONLY from the Ctrl-M filename (server-side extraction).
  const cust = (payload.customer_name || "").trim();
  window.appData.customerName = cust;
  const totalRuns = payload?.kpis?.total_runs || 0;
  applyCustomerName(cust, { runs: totalRuns, filename: payload.filename });
}

/**
 * Single source of truth for customer-name UI updates.
 * Updates: in-page Batch Review chip, global header chip, and Executive Dashboard banner.
 * Pass an empty string to hide everything.
 */
function applyCustomerName(name, opts = {}) {
  const cust = (name || "").trim();
  window.appData.customerName = cust;

  // 1. Batch Review chip (under the "loaded" chip)
  const cnChip = document.getElementById("customer-name-chip");
  const cnText = document.getElementById("customer-name-text");
  if (cnChip && cnText) {
    if (cust) {
      cnText.textContent = cust;
      cnChip.classList.remove("hidden");
      cnChip.classList.add("flex");
    } else {
      cnChip.classList.add("hidden");
      cnChip.classList.remove("flex");
    }
  }

  // 2. Global header chip — permanently hidden (removed per UX cleanup;
  //    customer name still appears in the Executive view banner).
  const hdrChip = document.getElementById("header-customer-chip");
  if (hdrChip) {
    hdrChip.classList.add("hidden");
    hdrChip.classList.remove("inline-flex");
  }

  // 3. Executive Dashboard banner (large) + Audit Pulse strip
  const exBanner = document.getElementById("exec-customer-banner");
  const exName   = document.getElementById("exec-customer-name");
  if (exBanner && exName) {
    if (cust) {
      exName.textContent = cust;
      const runs = opts.runs ?? (window.appData?.batch?.kpis?.total_runs || 0);
      const fn   = opts.filename || window.appData?.batch?.filename || "";
      _renderAuditPulse({ customer: cust, runs, filename: fn });
      exBanner.classList.remove("hidden");
      exBanner.classList.add("flex");
    } else {
      exBanner.classList.add("hidden");
      exBanner.classList.remove("flex");
    }
  }
}

// ── Audit Pulse ── Grafana-style multi-tile strip with sparkline + audit id
function _renderAuditPulse({ customer, runs, filename }) {
  const wrap = document.getElementById("exec-audit-pulse");
  if (!wrap) return;
  wrap.classList.remove("hidden");
  wrap.classList.add("flex");

  // ── Compute date span from window data (server day buckets) ──
  const winRows = window.appData?.batch?.window || [];
  const dates = winRows
    .map(w => w?.run_date)
    .filter(Boolean)
    .map(d => new Date(d))
    .filter(d => !isNaN(d))
    .sort((a, b) => a - b);
  const fmtShort = (d) => d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  let rangeStr = "—", spanStr = "—";
  if (dates.length) {
    const dMin = dates[0], dMax = dates[dates.length - 1];
    rangeStr = `${fmtShort(dMin)} → ${fmtShort(dMax)}`;
    const days = Math.round((dMax - dMin) / 86400000) + 1;
    spanStr = `${days} day${days !== 1 ? "s" : ""} · ${(runs || 0).toLocaleString()} runs`;
  } else {
    rangeStr = (runs || 0).toLocaleString() + " runs";
    spanStr  = filename ? _truncMid(filename, 28) : "—";
  }
  setText("exec-pulse-range", rangeStr);
  setText("exec-pulse-span",  spanStr);

  // ── Sparkline of daily run counts (with breach overlay) ──
  const svg = document.getElementById("exec-pulse-sparkline");
  const sla = window.appData?.batch?.kpis?.sla_daily_hrs || 6;
  if (svg && winRows.length) {
    const vals    = winRows.map(w => Number(w.runs || w.total_runs || 0));
    const breach  = winRows.map(w => (Number(w.total_hrs || 0) > sla) ? 1 : 0);
    const W = 160, H = 30, P = 2;
    const max = Math.max(1, ...vals);
    const step = vals.length > 1 ? (W - 2 * P) / (vals.length - 1) : 0;
    const points = vals.map((v, i) => {
      const x = P + i * step;
      const y = H - P - (v / max) * (H - 2 * P);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(" ");
    const areaPath =
      `M ${P},${H - P} L ${points.split(" ").join(" L ")} L ${(W - P).toFixed(1)},${H - P} Z`;
    const dots = vals.map((v, i) => {
      const x = P + i * step;
      const y = H - P - (v / max) * (H - 2 * P);
      const c = breach[i] ? "#f43f5e" : "#22d3ee";
      return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="1.6" fill="${c}"/>`;
    }).join("");
    svg.innerHTML = `
      <defs>
        <linearGradient id="pulseGrad" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stop-color="#22d3ee" stop-opacity="0.55"/>
          <stop offset="100%" stop-color="#22d3ee" stop-opacity="0.05"/>
        </linearGradient>
      </defs>
      <path d="${areaPath}" fill="url(#pulseGrad)" stroke="none"/>
      <polyline points="${points}" fill="none" stroke="#22d3ee" stroke-width="1.4"
                stroke-linecap="round" stroke-linejoin="round"/>
      ${dots}
    `;
    const breachDays = breach.reduce((a, b) => a + b, 0);
    setText("exec-pulse-total", `↑ peak ${max}`);
    const legend = breachDays > 0
      ? `${breachDays} breach day${breachDays !== 1 ? "s" : ""} · ${vals.length} pts`
      : `✓ ${vals.length} clean days`;
    const legEl = document.getElementById("exec-pulse-legend");
    if (legEl) {
      legEl.textContent = legend;
      legEl.className = `text-[9px] mt-0.5 ${breachDays > 0 ? "text-Cred" : "text-Cgreen"}`;
    }
  } else if (svg) {
    svg.innerHTML = `<text x="80" y="18" text-anchor="middle" fill="#475569" font-size="9" font-family="Sora">No daily data yet</text>`;
    setText("exec-pulse-total", (runs || 0).toLocaleString());
    setText("exec-pulse-legend", "awaiting batch processing");
  }

  // ── Audit ID + freshness ──
  const seed   = `${customer}|${filename || ""}|${runs || 0}|${(dates[0] || new Date()).toISOString().slice(0, 10)}`;
  const idHash = _shortHash(seed);
  setText("exec-pulse-id", `#${idHash}`);
  const now = new Date();
  setText("exec-pulse-time",
    `live · ${now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`);
  const dot = document.getElementById("exec-pulse-dot");
  if (dot) {
    const compliance = window.appData?.batch?.kpis?.compliance_pct ?? 100;
    dot.style.background = compliance >= 95 ? "#10d96e" : compliance >= 80 ? "#f59e0b" : "#f43f5e";
  }
}

function _shortHash(s) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  return h.toString(36).toUpperCase().slice(0, 6).padStart(6, "0");
}

function _truncMid(s, n) {
  if (!s || s.length <= n) return s || "";
  const half = Math.floor((n - 1) / 2);
  return s.slice(0, half) + "…" + s.slice(-half);
}

function showUploadStatus(filename, message, busy = false) {
  _renderIntakeProgress("upload-status", {
    filename, message,
    percent: busy ? null : 100,
    color:   "blue",
    phase:   busy ? "uploading" : "done",
  });
}

function hideUploadStatus() {
  document.getElementById("upload-status")?.classList.add("hidden");
}

// ── Beautiful progress card (shared by all 4 intake zones) ─────────────────
// opts: { filename, message, percent (0..100|null=indeterminate), color, phase }
const _INTAKE_PALETTE = {
  blue:   { hex: "#3b82f6", g1: "#3b82f6", g2: "#22d3ee", g3: "#a855f7", glow: "59,130,246"  },
  green:  { hex: "#10b981", g1: "#10b981", g2: "#22d3ee", g3: "#3b82f6", glow: "16,185,129"  },
  amber:  { hex: "#f59e0b", g1: "#f59e0b", g2: "#fb923c", g3: "#ef4444", glow: "245,158,11"  },
  purple: { hex: "#a855f7", g1: "#a855f7", g2: "#6366f1", g3: "#3b82f6", glow: "168,85,247"  },
};

function _renderIntakeProgress(containerId, opts = {}) {
  const wrap = document.getElementById(containerId);
  if (!wrap) return;
  const colorKey = opts.color || wrap.dataset.color || "blue";
  const pal      = _INTAKE_PALETTE[colorKey] || _INTAKE_PALETTE.blue;
  const filename = opts.filename || "—";
  const message  = opts.message  || "";
  const phase    = (opts.phase   || "uploading").toLowerCase();
  const pct      = (opts.percent === null || opts.percent === undefined)
                   ? null : Math.max(0, Math.min(100, Math.round(opts.percent)));
  const indeterminate = pct === null;
  const pctText  = indeterminate ? "···" : `${pct}%`;

  const PHASE = {
    uploading:  { label: "Uploading",  icon: "↑" },
    processing: { label: "Processing", icon: "⚙" },
    parsing:    { label: "Parsing",    icon: "⌬" },
    analysing:  { label: "Analysing",  icon: "✦" },
    done:       { label: "Done",       icon: "✓" },
    error:      { label: "Error",      icon: "✕" },
  };
  const ph = PHASE[phase] || PHASE.uploading;
  const active = phase !== "done" && phase !== "error";

  const grad = `linear-gradient(90deg, ${pal.g1} 0%, ${pal.g2} 50%, ${pal.g3} 100%)`;
  const cardBg = `linear-gradient(135deg, rgba(${pal.glow},0.08) 0%, rgba(20,25,45,0.4) 60%, rgba(10,12,24,0.4) 100%)`;

  wrap.classList.remove("hidden");
  wrap.style.cssText = `
    border:1px solid rgba(${pal.glow},0.35);
    background:${cardBg};
    border-radius:0.75rem;
    padding:0.75rem;
    box-shadow:0 0 24px -6px rgba(${pal.glow},0.35);
    transition:all 0.2s ease;
  `;
  wrap.innerHTML = `
    <div class="flex items-center gap-2.5 mb-2">
      <div class="relative w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
           style="background:rgba(${pal.glow},0.15);border:1px solid rgba(${pal.glow},0.45)">
        <span style="color:${pal.hex};font-size:14px;font-weight:700">${ph.icon}</span>
        ${active
          ? `<span class="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full animate-ping" style="background:${pal.hex}"></span>
             <span class="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full" style="background:${pal.hex}"></span>`
          : ""}
      </div>
      <div class="flex-1 min-w-0">
        <div class="text-[11px] font-semibold text-Cwhite truncate" title="${_esc(filename)}">${_esc(filename)}</div>
        <div class="text-[9px] text-Cmuted truncate flex items-center gap-1.5">
          <span class="font-bold uppercase tracking-wider" style="color:${pal.hex}">${ph.label}</span>
          ${message ? `<span class="text-Cborder">·</span><span class="truncate">${_esc(message)}</span>` : ""}
        </div>
      </div>
      <div class="text-[13px] font-bold font-mono tabular-nums shrink-0"
           style="color:${pal.hex}">${pctText}</div>
    </div>
    <div class="relative h-1.5 rounded-full overflow-hidden"
         style="background:rgba(8,11,22,0.8);border:1px solid rgba(${pal.glow},0.2)">
      ${indeterminate
        ? `<div style="position:absolute;top:0;bottom:0;width:33%;border-radius:9999px;background:${grad};box-shadow:0 0 12px rgba(${pal.glow},0.7);animation:intake-shimmer 1.4s ease-in-out infinite"></div>`
        : `<div style="height:100%;width:${pct}%;border-radius:9999px;background:${grad};box-shadow:0 0 12px rgba(${pal.glow},0.6);transition:width 0.2s ease-out"></div>`}
    </div>`;
}

// One-time keyframes for the indeterminate shimmer
(function _injectIntakeProgressCSS() {
  if (typeof document === "undefined") return;
  if (document.getElementById("intake-progress-css")) return;
  const s = document.createElement("style");
  s.id = "intake-progress-css";
  s.textContent = `@keyframes intake-shimmer { 0% { left:-33%; } 100% { left:100%; } }`;
  document.head.appendChild(s);
})();

// XHR uploader that emits real upload-percent for the progress card.
// Falls back to indeterminate after upload completes (server-side processing).
function _uploadWithProgress(url, formData, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && typeof onProgress === "function") {
        onProgress(Math.round((e.loaded / e.total) * 100), e.loaded, e.total);
      }
    };
    xhr.upload.onload = () => {
      // Bytes finished sending — flip to indeterminate "processing"
      if (typeof onProgress === "function") onProgress(100, 0, 0, true);
    };
    xhr.onload = () => {
      const text = xhr.responseText || "";
      let body;
      try { body = JSON.parse(text); } catch { body = { detail: text }; }
      resolve({ ok: xhr.status >= 200 && xhr.status < 300, status: xhr.status, body, text });
    };
    xhr.onerror = () => reject(new Error("Network error"));
    xhr.send(formData);
  });
}

function initResetButton() {
  document.getElementById("reset-btn")?.addEventListener("click", () => {
    window.appData.upload   = null;
    window.appData.servers  = [];
    window.appData.resource = null;
    window.appData.loadedAt = null;

    document.getElementById("upload-result")?.classList.add("hidden");
    document.getElementById("dataset-chip")?.classList.add("hidden");
    document.getElementById("reset-btn")?.classList.add("hidden");
    // Clear customer name everywhere (header chip + banner + batch chip)
    applyCustomerName("");
    const dump = document.getElementById("json-dump");
    if (dump) {
      dump.textContent = "";
      dump.classList.add("hidden");
    }
    document.getElementById("toggle-json").textContent = "Show raw JSON";

    // Reset Resource Review panel
    document.getElementById("resource-review-body")?.classList.add("hidden");
    document.getElementById("resource-empty")?.classList.remove("hidden");
    destroyChart("resourceBars");
    const tbody = document.getElementById("resource-tbody");
    if (tbody) tbody.innerHTML = "";
    const heatmap = document.getElementById("resource-heatmap");
    if (heatmap) heatmap.innerHTML = "";

    toast("info", "Cleared", "Workspace has been reset.");
  });
}

function initJsonToggle() {
  const btn  = document.getElementById("toggle-json");
  const dump = document.getElementById("json-dump");
  if (!btn || !dump) return;
  btn.addEventListener("click", () => {
    const hidden = dump.classList.toggle("hidden");
    btn.textContent = hidden ? "Show raw JSON" : "Hide raw JSON";
  });
}


// ─────────────────────────────────────────────────────────────
// 5.  Toast notifications
// ─────────────────────────────────────────────────────────────
const TOAST_STYLES = {
  success: {
    bar:  "bg-Cgreen",
    icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.2" stroke="currentColor" class="w-5 h-5 text-Cgreen"><path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5"/></svg>',
  },
  error: {
    bar:  "bg-Cred",
    icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.2" stroke="currentColor" class="w-5 h-5 text-Cred"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z"/></svg>',
  },
  info: {
    bar:  "bg-Cblue",
    icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.2" stroke="currentColor" class="w-5 h-5 text-Cblue"><path stroke-linecap="round" stroke-linejoin="round" d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z"/></svg>',
  },
};

function toast(kind, title, message, ttlMs = 4500) {
  const stack = document.getElementById("toast-stack");
  if (!stack) return;
  const style = TOAST_STYLES[kind] || TOAST_STYLES.info;

  const el = document.createElement("div");
  el.className =
    "toast pointer-events-auto rounded-xl border border-Cborder bg-Ccard/95 backdrop-blur " +
    "shadow-panel flex items-start gap-3 p-3 pr-4 overflow-hidden relative";
  el.innerHTML = `
    <span class="absolute left-0 top-0 bottom-0 w-1 ${style.bar}"></span>
    <div class="pl-2">${style.icon}</div>
    <div class="flex-1 min-w-0">
      <div class="text-[13px] font-bold text-Cwhite leading-tight">${escapeHtml(title)}</div>
      <div class="text-[11px] text-Cmuted mt-0.5 leading-snug">${escapeHtml(message)}</div>
    </div>
    <button class="text-Cmuted hover:text-Cwhite transition-colors -mt-0.5 text-lg leading-none"
            aria-label="Dismiss">&times;</button>
  `;
  el.querySelector("button").addEventListener("click", () => removeToast(el));
  stack.appendChild(el);

  if (ttlMs > 0) setTimeout(() => removeToast(el), ttlMs);
}

function removeToast(el) {
  if (!el || !el.parentNode) return;
  el.style.transition = "opacity .18s ease, transform .18s ease";
  el.style.opacity = "0";
  el.style.transform = "translateY(8px)";
  setTimeout(() => el.remove(), 200);
}


// ─────────────────────────────────────────────────────────────
// 6.  Tiny helpers
// ─────────────────────────────────────────────────────────────
function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value ?? "—";
}

function formatBytes(n) {
  if (!n && n !== 0) return "—";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${_n(v).toFixed(_n(v) >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function hexA(hex, alpha) {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}


// ════════════════════════════════════════════════════════════
//  PHASE 3 · BATCH REVIEW
//  - Ctrl-M file upload zone
//  - POST /api/process-batch
//  - renderBatchReview(data) → KPIs + 3 Chart.js charts + table
// ════════════════════════════════════════════════════════════

const BATCH_ALLOWED = [".csv", ".xlsx", ".xls"];

function initBatchUploader() {
  const dz    = document.getElementById("batch-drop-zone");
  const input = document.getElementById("batch-file-input");
  if (!dz || !input) return;

  dz.addEventListener("click", () => input.click());

  input.addEventListener("change", (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length) processBatchFiles(files);
    input.value = "";
  });

  ["dragenter", "dragover"].forEach((ev) =>
    dz.addEventListener(ev, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dz.classList.add("dropzone-active");
    })
  );
  ["dragleave", "dragend"].forEach((ev) =>
    dz.addEventListener(ev, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dz.classList.remove("dropzone-active");
    })
  );
  dz.addEventListener("drop", (e) => {
    e.preventDefault();
    e.stopPropagation();
    dz.classList.remove("dropzone-active");
    const dropped = Array.from(e.dataTransfer?.files || []);
    if (!dropped.length) return;
    const valid = dropped.filter(f => isBatchAllowed(f));
    const invalid = dropped.length - valid.length;
    if (invalid > 0) {
      toast("warning", "Skipped files", `${invalid} file(s) ignored — only .csv, .xlsx and .xls are accepted.`);
    }
    if (valid.length > 8) {
      toast("error", "Too many files", "Maximum 8 Ctrl-M files at a time.");
      return;
    }
    if (valid.length) processBatchFiles(valid);
  });
}

function isBatchAllowed(file) {
  const name = (file.name || "").toLowerCase();
  return BATCH_ALLOWED.some((ext) => name.endsWith(ext));
}

async function processBatchFiles(files) {
  if (!files.length) return;

  // Validate all files first
  const invalid = files.filter(f => !isBatchAllowed(f));
  if (invalid.length) {
    toast("error", "Unsupported file(s)", `${invalid.map(f=>f.name).join(", ")} — only .csv, .xlsx, .xls accepted.`);
    return;
  }
  if (files.length > 8) {
    toast("error", "Too many files", "Maximum 8 Ctrl-M files at a time.");
    return;
  }

  const names = files.map(f => f.name).join(", ");
  const totalSize = files.reduce((s, f) => s + f.size, 0);
  _renderIntakeProgress("batch-status", {
    filename: files.length === 1 ? files[0].name : `${files.length} files`,
    message:  `${formatBytes(totalSize)} \u00b7 ${names}`.slice(0, 80),
    percent:  0,
    color:    "green",
    phase:    "uploading",
  });

  const fd = new FormData();
  if (files.length === 1) {
    // Single file → use existing endpoint for backward compat
    fd.append("file", files[0], files[0].name);
  } else {
    // Multiple files → use multi endpoint
    for (const f of files) {
      fd.append("files", f, f.name);
    }
  }

  const endpoint = files.length === 1 ? "/api/process-batch" : "/api/process-batch/multi";

  try {
    const { ok, status, body } = await _uploadWithProgress(endpoint, fd, (pct, loaded, total, finished) => {
      _renderIntakeProgress("batch-status", {
        filename: files.length === 1 ? files[0].name : `${files.length} files`,
        message:  finished ? `${formatBytes(totalSize)} \u2014 parsing Ctrl-M runs\u2026`
                           : `${formatBytes(loaded)} / ${formatBytes(total)}`,
        percent:  finished ? null : pct,
        color:    "green",
        phase:    finished ? "parsing" : "uploading",
      });
    });
    const payload = body;

    if (!ok) {
      hideBatchStatus();
      toast("error", "Batch processing failed", payload?.detail || `HTTP ${status}`);
      console.error("[pe-dashboard] batch failed", payload);
      return;
    }

    window.appData.batch    = payload;
    window.appData.loadedAt = new Date().toISOString();
    window._execCache = null; // invalidate exec dashboard cache
    // Hardwired interconnection: batch response now embeds full-dataset SLA Matrix.
    // Capture it so PE Findings + Red Flags + PE Consultant all see ALL runs.
    if (payload.sla_matrix) {
      window.appData.slaMatrix = payload.sla_matrix;
    }
    hideBatchStatus();
    renderBatchReview(payload);
    _renderBatchIntakeCard(payload);
    refreshDataStatus();

    // Trigger environment detection
    triggerEnvDetection(payload);

    // Pre-AI: auto-generate findings immediately on batch upload
    triggerGenerateFindings().catch(() => {});
    triggerRedFlags().catch(() => {});

    toast(
      "success",
      "Batch analysis complete",
      `${files.length} file(s) · ${payload.kpis.total_runs.toLocaleString()} runs · ${payload.kpis.total_jobs} jobs · ${_n(payload.kpis.compliance_pct).toFixed(1)}% compliant`
    );
    console.info("[pe-dashboard] window.appData.batch updated", payload);
  } catch (err) {
    hideBatchStatus();
    toast("error", "Network error", String(err?.message || err));
    console.error("[pe-dashboard] batch network error", err);
  }
}

function showBatchStatus(msg) {
  _renderIntakeProgress("batch-status", {
    filename: "Ctrl-M batch",
    message:  msg,
    percent:  null,
    color:    "green",
    phase:    "processing",
  });
}

// ── Environment Detection ─────────────────────────────────────
async function triggerEnvDetection(batchPayload) {
  const panel = document.getElementById("env-detection-panel");
  if (!panel) return;

  // Build rows sample from batch top_jobs for env detection
  const rows = (batchPayload?.top_jobs || []).map(j => ({
    Job_Name: j.Job_Name || j.job_name || "",
    Sub_Application: j.Sub_Application || j.sub_application || "",
  }));

  // Also include filename
  const filename = batchPayload?.filename || "unknown";

  const files = [{ filename, rows }];

  // Add resource data if available
  if (window.appData.servers?.length) {
    files.push({
      filename: window.appData.resource?.filename || "resource",
      rows: window.appData.servers.slice(0, 50).map(s => ({
        host: s.host || "", server: s.server || "", source_env: s.source_env || "",
      })),
    });
  }

  try {
    const res = await fetch("/api/detect-environment", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ files }),
    });
    if (!res.ok) return;
    const data = await res.json();
    window.appData.envDetection = data;
    renderEnvDetection(data);
  } catch (e) {
    console.warn("[env-detect]", e);
  }
}

function renderEnvDetection(data) {
  const panel = document.getElementById("env-detection-panel");
  const results = document.getElementById("env-detect-results");
  const status = document.getElementById("env-detect-status");
  const summaryText = document.getElementById("env-detect-summary-text");
  if (!panel || !results) return;

  panel.classList.remove("hidden");

  const items = data.results || [];
  if (!items.length) {
    results.innerHTML = '<span class="text-Cmuted text-[10px]">No files analyzed.</span>';
    return;
  }

  const confColor = c => c >= 80 ? THEME.green : c >= 50 ? THEME.amber : THEME.red;

  // Store env data for confirmation overrides
  window._envDetectionData = data;

  // Compact chips — just env label + filename + confidence + confirm buttons
  results.innerHTML = items.map((r, i) => {
    const confirmUI = r.needs_confirmation
      ? `<span class="flex gap-0.5 ml-1">
           <button onclick="confirmEnvOverride(${i},'PROD')" class="text-[8px] font-bold px-1.5 py-0.5 rounded bg-Cgreen/15 border border-Cgreen/40 text-Cgreen hover:bg-Cgreen/25">P</button>
           <button onclick="confirmEnvOverride(${i},'TEST')" class="text-[8px] font-bold px-1.5 py-0.5 rounded bg-Cblue/15 border border-Cblue/40 text-Cblue hover:bg-Cblue/25">T</button>
           <button onclick="confirmEnvOverride(${i},'DR')" class="text-[8px] font-bold px-1.5 py-0.5 rounded bg-Cpurple/15 border border-Cpurple/40 text-Cpurple hover:bg-Cpurple/25">D</button>
         </span>`
      : "";

    return `<span class="inline-flex items-center gap-1.5 px-2 py-1 rounded-lg border border-Cborder bg-Cbg/40" id="env-row-${i}">
      <span class="font-bold text-[10px]" style="color:${confColor(r.confidence)}">${escapeHtml(r.detected_env)}</span>
      <span class="text-[9px] text-Cmuted font-mono">${escapeHtml((r.filename || "").substring(0, 25))}</span>
      <span class="text-[9px] font-semibold" style="color:${confColor(r.confidence)}">${r.confidence}%</span>
      ${r.needs_confirmation ? '<span class="text-[8px] text-Cred font-bold">⚠</span>' : ""}
      ${confirmUI}
    </span>`;
  }).join("");

  // Summary text
  const envNames = [...new Set(items.map(r => r.detected_env))];
  const needsConfirm = items.filter(r => r.needs_confirmation).length;
  if (summaryText) {
    summaryText.textContent = `${items.length} file(s) → ${envNames.join(", ")}` +
      (needsConfirm > 0 ? ` · ${needsConfirm} need confirmation` : "");
  }

  // Show batch families
  const comp = data.comparison || {};
  const families = comp.batch_families || [];
  const famPanel = document.getElementById("env-families");
  const famList = document.getElementById("env-families-list");
  if (famPanel && families.length > 0) {
    famPanel.classList.remove("hidden");
    famList.innerHTML = families.map(f => {
      const envEntries = Object.entries(f.environments || {});
      const hasProd = envEntries.some(([env]) => env.includes("PROD"));
      const hasTest = envEntries.some(([env]) => env.includes("TEST") || env.includes("UAT"));
      const compLabel = (hasProd && hasTest)
        ? ' <span class="text-[8px] font-bold text-Cpurple bg-Cpurple/10 border border-Cpurple/30 px-1.5 py-0.5 rounded">PROD vs TEST</span>'
        : "";
      return `<span class="text-[10px]"><strong>${escapeHtml(f.base_name)}</strong>${compLabel} ` +
        envEntries.map(([env, fn]) =>
          `<span class="text-Cpurple font-semibold">${env}</span>`
        ).join(" · ") + "</span>";
    }).join(" · ");
  }

  // Update status badge
  const ambigCount = (comp.ambiguous || []).length;
  if (status) {
    if (ambigCount > 0) {
      status.textContent = `${ambigCount} AMBIGUOUS`;
      status.style.color = THEME.amber;
      status.style.borderColor = THEME.amber;
    } else {
      const envCount = Object.keys(comp.environments || {}).length;
      status.textContent = `${envCount} env(s)`;
      status.style.color = THEME.green;
      status.style.borderColor = THEME.green;
    }
  }
}

// ── Interactive environment confirmation/override ──────────────
function confirmEnvOverride(index, overrideEnv) {
  const data = window._envDetectionData;
  if (!data || !data.results || !data.results[index]) return;

  // Update the result
  data.results[index].detected_env = overrideEnv;
  data.results[index].confidence = 100;
  data.results[index].needs_confirmation = false;
  data.results[index].override_by_user = true;

  // Re-render
  renderEnvDetection(data);
  toast("success", "Environment Override", `Set to ${overrideEnv}`);
}

function hideBatchStatus() {
  document.getElementById("batch-status")?.classList.add("hidden");
}


// ─────────────────────────────────────────────────────────────
// renderBatchReview(payload) — main entrypoint after upload
// ─────────────────────────────────────────────────────────────
function renderBatchReview(data) {
  if (!data || !data.kpis) {
    console.warn("[pe-dashboard] renderBatchReview called with empty payload");
    return;
  }

  // Reveal the body, hide empty state
  document.getElementById("batch-empty")?.classList.add("hidden");
  document.getElementById("batch-review-body")?.classList.remove("hidden");

  // Dataset chip
  const chip = document.getElementById("batch-dataset-chip");
  if (chip) {
    chip.textContent = `${data.filename} · ${data.kpis.total_runs.toLocaleString()} runs`;
    chip.classList.remove("hidden");
  }

  // Data source watermark
  const srcWm = document.getElementById("batch-source-watermark");
  if (srcWm) {
    srcWm.classList.remove("hidden");
    srcWm.classList.add("flex");
    setText("batch-source-label", `Ctrl-M CSV: ${data.filename || "unknown"}`);
    const slaSrc = data.sla_source;
    const slaSrcEl = document.getElementById("batch-sla-source-label");
    if (slaSrcEl && slaSrc) {
      const slaType = slaSrc.type || "default";
      const ms = slaSrc.match_stats;
      if (slaType === "sla_matrix") {
        const matchInfo = ms?.total_jobs > 0
          ? ` · ${ms.sla_matrix}/${ms.total_jobs} jobs matched`
          : "";
        slaSrcEl.textContent = `SLA: Customer Matrix (${slaSrc.filename || "uploaded"})${matchInfo}`;
        slaSrcEl.style.borderColor = THEME.green;
        slaSrcEl.style.color = THEME.green;
      } else {
        slaSrcEl.textContent = `SLA: System Default (${data.kpis.daily_limit_hrs || 6}h)`;
        slaSrcEl.style.borderColor = THEME.amber;
        slaSrcEl.style.color = THEME.amber;
      }
    }
  }

  // 1. KPI cards
  // Sync the global SLA_DAILY_HRS to the resolved ceiling from this dataset
  // so every chart/component that reads it reflects the actual customer SLA,
  // not the hardcoded 6h default.
  if (data.kpis?.daily_limit_hrs) {
    SLA_DAILY_HRS = Number(data.kpis.daily_limit_hrs) || SLA_DAILY_HRS;
  }
  renderBatchKpis(data.kpis);
  renderBatchLayerCards(data);
  renderBatchCoverageStrip(data.data_coverage || null);
  renderBatchDataWarnings(data.data_coverage?.warnings || []);
  renderBatchSlaSourceTags(data.sla_source || null, data.kpis);

  // 2. Charts
  renderSlaBufferChart(data.kpis);
  renderWindowTrendChart(data.window || []);
  renderTopJobsChart(data.top_jobs || [], data.kpis);

  // 3. Top 10 breaching jobs table
  renderTopBreachesTable(data.top_breaches || [], data.kpis);

  // 4. Heatmaps (only shown when data is present)
  renderSlaHeatmap(data.sla_heatmap  || null);
  renderHourHeatmap(data.hour_heatmap || null);
}


// ── SLA source annotations on charts ──────────────────────────
function renderBatchSlaSourceTags(sla, kpis) {
  const tag1 = document.getElementById("chart-sla-source-tag");
  const tag2 = document.getElementById("chart-window-source-tag");
  const ceiling = document.getElementById("chart-sla-ceiling-tag");

  if (sla) {
    // Determine source label
    let srcLabel;
    if (sla.type === "sla_matrix") {
      srcLabel = `From SLA Matrix (${sla.filename || "uploaded"})`;
    } else if (sla.type === "customer_fallback") {
      srcLabel = "From Customer Fallback";
    } else {
      srcLabel = "Assumed (no SLA file)";
    }

    // Build rich label with model info
    const modelTag = sla.schema_type ? ` · ${sla.schema_type.toUpperCase()} model` : "";
    const validTag = sla.valid_rows > 0 ? ` · ${sla.valid_rows} rules` : "";
    const matchStats = sla.match_stats;
    const matchTag = matchStats?.total_jobs > 0
      ? ` · ${matchStats.sla_matrix}/${matchStats.total_jobs} matched`
        + (matchStats.assumed > 0 ? ` (${matchStats.assumed} assumed)` : "")
      : "";
    const label = `SLA: ${srcLabel}${modelTag}${validTag}${matchTag} · Daily ${sla.daily_hrs?.toFixed(1) || "6.0"}h`;

    if (tag1) { tag1.textContent = label; tag1.classList.remove("hidden"); }
    if (tag2) { tag2.textContent = label; tag2.classList.remove("hidden"); }
    if (ceiling) { ceiling.textContent = `${sla.daily_hrs?.toFixed(1) || "6.0"} h`; }

    // Show blocked warning if SLA is assumed
    if (sla.blocked) {
      if (tag1) tag1.style.color = THEME.red;
      if (tag2) tag2.style.color = THEME.red;
    } else if (sla.type === "sla_matrix") {
      if (tag1) tag1.style.color = THEME.green;
      if (tag2) tag2.style.color = THEME.green;
    }

    // Surface SLA warnings inline
    const warnEl = document.getElementById("chart-sla-warnings");
    if (warnEl && sla.warnings?.length) {
      warnEl.innerHTML = sla.warnings.slice(0, 3).map(w =>
        `<span class="text-[9px] px-1.5 py-0.5 rounded border ${w.severity === "critical" ? "text-Cred border-Cred/30" : "text-Camber border-Camber/30"}">${escapeHtml(w.text || "").substring(0, 80)}</span>`
      ).join(" ");
      warnEl.classList.remove("hidden");
    }
  } else if (kpis) {
    if (ceiling) { ceiling.textContent = `${kpis.daily_limit_hrs?.toFixed(1) || "6.0"} h`; }
  }
}


// ─────────────────────────────────────────────────────────────
// KPI cards
// ─────────────────────────────────────────────────────────────
function renderBatchKpis(k) {
  // Job SLA Compliance (individual job peaks vs SLA)
  const compEl = document.getElementById("bk-compliance");
  if (compEl) {
    const jsc = _n(k.job_sla_compliance ?? k.compliance_pct);
    compEl.textContent = `${jsc.toFixed(1)}%`;
    compEl.style.color =
      jsc >= 95 ? THEME.green :
      jsc >= 80 ? THEME.amber : THEME.red;
  }

  // Show both compliance types in subtitle
  const bwc = k.batch_window_compliance;
  const wbd = k.window_breach_days || 0;
  const wtd = k.window_total_days || 0;
  let compSub = `${k.jobs_ok} OK · ${k.total_jobs} total`;
  if (bwc != null) {
    compSub += ` · Window: ${_n(bwc).toFixed(0)}%`;
    if (wbd > 0) compSub += ` (${wbd}d breached)`;
  }
  setText("bk-compliance-sub", compSub);

  // Window SLA Rate — prominently displayed as its own KPI
  const winCompEl = document.getElementById("bk-window-compliance");
  if (winCompEl && bwc != null) {
    winCompEl.textContent = `${_n(bwc).toFixed(1)}%`;
    winCompEl.style.color =
      bwc >= 95 ? THEME.green :
      bwc >= 80 ? THEME.amber : THEME.red;
  }
  const winSubEl = document.getElementById("bk-window-compliance-sub");
  if (winSubEl) {
    if (bwc != null) {
      const passD = wtd - wbd;
      winSubEl.textContent = `${passD}/${wtd} days pass · ${wbd} breach`;
    } else {
      winSubEl.textContent = "Needs End_Time column";
    }
  }

  setText("bk-breach", String(k.jobs_breach));
  setText("bk-atrisk", String(k.jobs_at_risk));
  setText("bk-ok",     String(k.jobs_ok));
  setText(
    "bk-breach-sub",
    `SLA ${_n(k.daily_limit_hrs, 6).toFixed(1)}h`
  );

  // Failed Runs (execution failures — ENDED NOT OK / ABENDED / TERMINATED).
  // Separate signal from SLA breach: a run can be FAILED without breaching
  // SLA, and a run can breach SLA while ending OK.
  const failed   = Number(k.failed_runs || 0);
  const failRate = Number(k.fail_rate_pct || 0);
  const totalRuns= Number(k.total_runs   || 0);
  const okRuns   = Number(k.ok_runs      || Math.max(0, totalRuns - failed));
  setText("bk-failed", String(failed));
  setText(
    "bk-failed-sub",
    totalRuns
      ? `${failRate.toFixed(2)}% of ${totalRuns} runs · ${okRuns} OK`
      : "no run data",
  );
}


// ── Separated analysis layer cards ────────────────────────────
function renderBatchLayerCards(data) {
  const ew  = data.elapsed_window || {};
  const sr  = data.summed_runtime || {};
  const wj  = data.worst_job || {};
  const sla = data.sla_source || {};

  // ── Elapsed Window ──
  const ewEl = document.getElementById("bk-elapsed");
  if (ewEl) {
    if (ew.available && ew.worst_day) {
      ewEl.textContent = `${_n(ew.worst_day.elapsed_hrs).toFixed(1)}h`;
      ewEl.style.color = ew.worst_day.elapsed_hrs > (data.kpis?.daily_limit_hrs || 6) ? THEME.red : THEME.purple;
      setText("bk-elapsed-sub", `Worst day: ${ew.worst_day.run_date} · Avg ${(ew.avg_elapsed_hrs || 0).toFixed(1)}h`);
    } else {
      ewEl.textContent = "N/A";
      ewEl.style.color = THEME.muted;
      setText("bk-elapsed-sub", "End_Time missing — cannot compute");
    }
  }

  // ── Summed Runtime ──
  const srEl = document.getElementById("bk-summed");
  if (srEl) {
    srEl.textContent = `${sr.total_hrs?.toFixed(1) || "0"}h`;
    setText("bk-summed-sub", `Worst day ${sr.worst_day_hrs?.toFixed(1) || "0"}h · Avg ${sr.avg_day_hrs?.toFixed(1) || "0"}h/day`);
  }

  // ── Worst-Job Peak ──
  const wjEl = document.getElementById("bk-worst");
  if (wjEl) {
    if (wj.peak_hrs > 0) {
      wjEl.textContent = `${_n(wj.peak_hrs).toFixed(2)}h`;
      wjEl.style.color = _n(wj.buffer_pct) < 0 ? THEME.red : _n(wj.buffer_pct) < 15 ? THEME.amber : THEME.green;
      const jobName = (wj.job_name || "?").length > 25 ? wj.job_name.substring(0, 22) + "…" : wj.job_name;
      setText("bk-worst-sub", `${jobName} · ${_n(wj.buffer_pct).toFixed(0)}% buffer`);
    } else {
      wjEl.textContent = "—";
      setText("bk-worst-sub", "No runtime data");
    }
  }

  // ── SLA Source ──
  const slaEl = document.getElementById("bk-sla-source");
  if (slaEl) {
    const isMatrix = sla.type === "sla_matrix";
    const isAssumed = !sla.type || sla.type === "default" || sla.type === "assumed";
    if (isMatrix) {
      slaEl.textContent = "From SLA Matrix";
      slaEl.style.color = THEME.green;
      const model = sla.detected_model || sla.schema_type || "";
      setText("bk-sla-source-sub",
        `${model ? model + " · " : ""}Daily ${sla.daily_hrs?.toFixed(1) || "6.0"}h · Weekly ${sla.weekly_hrs?.toFixed(1) || "8.0"}h`
      );
    } else if (isAssumed) {
      slaEl.textContent = sla.blocked ? "BLOCKED" : "Assumed";
      slaEl.style.color = sla.blocked ? THEME.red : THEME.amber;
      setText("bk-sla-source-sub",
        sla.blocked
          ? "Cannot produce green compliance — upload SLA matrix"
          : `Default Daily ${sla.daily_hrs?.toFixed(1) || "6.0"}h · Weekly ${sla.weekly_hrs?.toFixed(1) || "8.0"}h`
      );
    } else {
      slaEl.textContent = "Customer Fallback";
      slaEl.style.color = THEME.amber;
      setText("bk-sla-source-sub",
        `Daily ${sla.daily_hrs?.toFixed(1) || "6.0"}h · Weekly ${sla.weekly_hrs?.toFixed(1) || "8.0"}h`
      );
    }
  }
}


// ── PE Audit Coverage Strip ───────────────────────────────────
function renderBatchCoverageStrip(dc) {
  const strip = document.getElementById("batch-coverage-strip");
  if (!strip) return;
  if (!dc) { strip.classList.add("hidden"); return; }

  strip.classList.remove("hidden");

  const badge = (id, label, status) => {
    const el = document.getElementById(id);
    if (!el) return;
    const colors = {
      loaded:  { bg: THEME.green, border: THEME.green, text: THEME.green },
      partial: { bg: THEME.amber, border: THEME.amber, text: THEME.amber },
      customer:{ bg: THEME.green, border: THEME.green, text: THEME.green },
      default: { bg: THEME.amber, border: THEME.amber, text: THEME.amber },
      missing: { bg: THEME.muted, border: THEME.muted, text: THEME.muted },
    };
    const c = colors[status] || colors.missing;
    el.textContent = `${label}: ${status.toUpperCase()}`;
    el.style.color = c.text;
    el.style.borderColor = hexA(c.border, 0.4);
    el.style.background = hexA(c.bg, 0.1);
  };

  const span = dc.date_span_days || 0;
  badge("cov-30day", "30-Day Evidence",
    span >= 30 ? "loaded" : span >= 14 ? "partial" : "missing");

  // SLA source quality from sla_source metadata
  const batchSla = (window.appData.batch || {}).sla_source || {};
  const slaStatus = batchSla.type === "sla_matrix" ? "customer" :
                    batchSla.type === "customer_fallback" ? "partial" : "default";
  badge("cov-sla", "SLA Source", slaStatus);

  badge("cov-confidence", `Confidence ${dc.confidence || 0}%`,
    dc.confidence >= 80 ? "loaded" : dc.confidence >= 60 ? "partial" : "missing");
  badge("cov-waivers", "Waivers", "missing");
  badge("cov-sow", "Volume vs SOW", "missing");
}


// ── Data Warnings ─────────────────────────────────────────────
function renderBatchDataWarnings(warnings) {
  const wrap = document.getElementById("batch-data-warnings");
  if (!wrap) return;
  if (!warnings || !warnings.length) { wrap.classList.add("hidden"); return; }

  wrap.classList.remove("hidden");
  wrap.innerHTML = warnings.map(w => {
    const sev = w.severity === "warning" ? THEME.amber : THEME.cyan;
    return `<div class="rounded-lg border-l-2 px-3 py-2 text-[11px]"
                 style="border-left-color:${sev};background:${hexA(sev, 0.06)}">
      <span style="color:${sev}" class="font-bold">${w.severity === "warning" ? "⚠️" : "ℹ️"}</span>
      <span class="text-Cmuted ml-1">${escapeHtml(w.text)}</span>
    </div>`;
  }).join("");
}


// ─────────────────────────────────────────────────────────────
// Chart 1 — SLA Buffer Gauge (Plotly gauge → Chart.js doughnut)
// ─────────────────────────────────────────────────────────────
function renderSlaBufferChart(k) {
  const canvas = document.getElementById("chart-sla-buffer");
  if (!canvas) return;
  destroyChart("slaBuffer");

  const buf = k.fleet_sla_buffer;
  const bufferPct = buf ? Math.max(0, Math.min(100, buf.buffer_pct)) : 0;
  const usedPct   = 100 - bufferPct;
  const bufferColor =
    !buf                       ? THEME.muted :
    buf.status === "EXCELLENT" ? THEME.green :
    buf.status === "HEALTHY"   ? THEME.green :
    buf.status === "CAUTION"   ? THEME.amber : THEME.red;

  charts.slaBuffer = new Chart(canvas, {
    type: "doughnut",
    data: {
      labels: ["Buffer remaining", "SLA used"],
      datasets: [{
        data: [bufferPct, usedPct],
        backgroundColor: [bufferColor, hexA(THEME.border, 0.55)],
        borderColor: [THEME.card2, THEME.card2],
        borderWidth: 2,
        hoverOffset: 4,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: "72%",
      rotation: -90,
      circumference: 180,
      layout: { padding: { bottom: 20 } },
      plugins: {
        legend: {
          position: "bottom",
          labels: {
            color: THEME.muted,
            font: { family: "Sora", size: 10, weight: "600" },
            boxWidth: 10,
            boxHeight: 10,
          },
        },
        tooltip: {
          backgroundColor: THEME.card,
          borderColor: THEME.border,
          borderWidth: 1,
          titleColor: THEME.white,
          bodyColor: THEME.muted,
          callbacks: {
            label: (ctx) => `${ctx.label}: ${_n(ctx.parsed).toFixed(1)}%`,
          },
        },
      },
    },
    plugins: [centerTextPlugin(buf ? `${_n(buf.buffer_pct).toFixed(0)}%` : "N/A", buf?.status || "")],
  });
}

// Chart.js plugin: center text inside the doughnut hole
function centerTextPlugin(big, sub) {
  return {
    id: "centerText",
    afterDraw(chart) {
      const { ctx, chartArea } = chart;
      if (!chartArea) return;
      const cx = (chartArea.left + chartArea.right) / 2;
      const cy = chartArea.bottom - 8;
      ctx.save();
      ctx.textAlign = "center";
      ctx.textBaseline = "alphabetic";
      ctx.fillStyle = THEME.white;
      ctx.font = '800 30px "Sora", sans-serif';
      ctx.fillText(big, cx, cy - 22);
      ctx.fillStyle = THEME.muted;
      ctx.font = '700 10px "Sora", sans-serif';
      ctx.fillText(sub, cx, cy - 4);
      ctx.restore();
    },
  };
}


// ─────────────────────────────────────────────────────────────
// Chart 2 — Daily Window Trend (Plotly bar → Chart.js bar)
// ─────────────────────────────────────────────────────────────
function renderWindowTrendChart(window) {
  const canvas = document.getElementById("chart-window-trend");
  if (!canvas) return;
  destroyChart("windowTrend");

  const labels = window.map((w) => w.run_date);
  const values = window.map((w) => w.total_hrs);
  const colors = window.map((w) => (w.breach ? THEME.red : THEME.blue));
  const counts = window.map((w) => w.job_count);
  const topJobs= window.map((w) => w.top_job || "");

  // Find the tallest bar index for annotation
  let peakIdx = 0;
  let peakVal = 0;
  values.forEach((v, i) => { if (v > peakVal) { peakVal = v; peakIdx = i; } });

  // Plugin: label the tallest bar with its top contributing job
  const peakAnnotationPlugin = {
    id: "peakDayAnnotation",
    afterDatasetsDraw(chart) {
      if (!topJobs[peakIdx]) return;
      const meta = chart.getDatasetMeta(0);
      if (!meta || !meta.data[peakIdx]) return;
      const bar = meta.data[peakIdx];
      const ctx = chart.ctx;
      const jobName = topJobs[peakIdx].length > 18
        ? topJobs[peakIdx].slice(0, 16) + "…"
        : topJobs[peakIdx];
      ctx.save();
      ctx.fillStyle = THEME.white;
      ctx.font = '600 9px "Sora", sans-serif';
      ctx.textAlign = "center";
      ctx.fillText(jobName, bar.x, bar.y - 10);
      ctx.fillStyle = THEME.amber;
      ctx.font = '700 8px "Sora", sans-serif';
      ctx.fillText("▲ Peak", bar.x, bar.y - 2);
      ctx.restore();
    },
  };

  // Plugin: breach overlay — marks breached days with "BREACH" label
  const breachCount = window.filter(w => w.breach).length;
  const breachOverlayPlugin = {
    id: "breachOverlay",
    afterDatasetsDraw(chart) {
      const meta = chart.getDatasetMeta(0);
      if (!meta) return;
      const ctx = chart.ctx;
      ctx.save();
      window.forEach((w, i) => {
        if (!w.breach || !meta.data[i]) return;
        const bar = meta.data[i];
        ctx.fillStyle = hexA(THEME.red, 0.15);
        ctx.fillRect(bar.x - bar.width / 2 - 2, chart.chartArea.top, bar.width + 4, chart.chartArea.bottom - chart.chartArea.top);
        ctx.fillStyle = THEME.red;
        ctx.font = 'bold 7px "Sora", sans-serif';
        ctx.textAlign = "center";
        ctx.fillText("BREACH", bar.x, chart.chartArea.bottom - 4);
      });
      // Summary annotation at top-right
      if (breachCount > 0) {
        ctx.fillStyle = THEME.red;
        ctx.font = 'bold 10px "Sora", sans-serif';
        ctx.textAlign = "right";
        ctx.fillText(
          `${breachCount}/${window.length} days breached (${Math.round(breachCount/window.length*100)}%)`,
          chart.chartArea.right - 4, chart.chartArea.top + 12
        );
      }
      ctx.restore();
    },
  };

  charts.windowTrend = new Chart(canvas, {
    type: "bar",
    data: {
      labels,
      datasets: [{
        label: "Daily Total (h)",
        data: values,
        backgroundColor: colors.map((c) => hexA(c, 0.85)),
        borderColor: colors,
        borderWidth: 1,
        borderRadius: 4,
        barPercentage: 0.85,
        categoryPercentage: 0.85,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      layout: { padding: { top: 24 } },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: THEME.card,
          borderColor: THEME.border,
          borderWidth: 1,
          titleColor: THEME.white,
          bodyColor: THEME.muted,
          callbacks: {
            label: (ctx) => {
              let line = `Total: ${ctx.parsed.y.toFixed(2)} h  ·  Jobs: ${counts[ctx.dataIndex]}`;
              if (topJobs[ctx.dataIndex]) line += `  ·  Top: ${topJobs[ctx.dataIndex]}`;
              return line;
            },
          },
        },
        annotation: undefined,
      },
      scales: {
        x: {
          ticks: {
            color: THEME.muted,
            font: { family: "Sora", size: 9 },
            maxRotation: 45,
            minRotation: 45,
          },
          grid: { color: hexA(THEME.border, 0.4), drawBorder: false },
        },
        y: {
          beginAtZero: true,
          title: { display: true, text: "Hours", color: THEME.muted, font: { size: 10 } },
          ticks: { color: THEME.muted, font: { family: "Sora", size: 9 } },
          grid: { color: hexA(THEME.border, 0.4), drawBorder: false },
        },
      },
    },
    plugins: [slaLinePlugin(SLA_DAILY_HRS), peakAnnotationPlugin, breachOverlayPlugin],
  });
}

// Chart.js plugin: dashed horizontal SLA line on the y-axis
function slaLinePlugin(slaHrs) {
  return {
    id: "slaLine",
    afterDatasetsDraw(chart) {
      const yScale = chart.scales.y;
      if (!yScale) return;
      const y = yScale.getPixelForValue(slaHrs);
      const { left, right } = chart.chartArea;
      const ctx = chart.ctx;
      ctx.save();
      ctx.strokeStyle = THEME.red;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 4]);
      ctx.beginPath();
      ctx.moveTo(left, y);
      ctx.lineTo(right, y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = THEME.red;
      ctx.font = '700 10px "Sora", sans-serif';
      ctx.textAlign = "left";
      ctx.fillText(`${slaHrs}h SLA`, left + 6, y - 4);
      ctx.restore();
    },
  };
}


// ─────────────────────────────────────────────────────────────
// Chart 3 — Top 15 jobs horizontal bar (Plotly grouped → Chart.js bar)
// ─────────────────────────────────────────────────────────────
function renderTopJobsChart(topJobs, kpis) {
  const canvas = document.getElementById("chart-top-jobs");
  if (!canvas) return;
  destroyChart("topJobs");

  // Use the resolved SLA ceiling from this dataset (per compute_metrics),
  // falls back to the global SLA_DAILY_HRS which is already synced above.
  const chartSla = kpis?.daily_limit_hrs ?? SLA_DAILY_HRS;

  // Sort ascending so the largest peak appears at the top of a horizontal bar
  const sorted = [...topJobs].sort((a, b) => a.peak_hrs - b.peak_hrs);
  const labels = sorted.map((j) => truncate(j.Job_Name, 32));
  const peak   = sorted.map((j) => j.peak_hrs);
  const avg    = sorted.map((j) => j.avg_hrs);

  // Colour each bar against its own per-job SLA ceiling (sla_hrs from payload)
  // Falls back to chartSla (global ceiling) when sla_hrs not present.
  const peakColors = sorted.map((j, i) => {
    const jobSla = j.sla_hrs ?? chartSla;
    return peak[i] > jobSla           ? THEME.red  :
           peak[i] > jobSla * 0.8    ? THEME.amber : THEME.blue;
  });

  charts.topJobs = new Chart(canvas, {
    type: "bar",
    data: {
      labels,
      datasets: [
        {
          label: "Avg (h)",
          data: avg,
          backgroundColor: hexA(THEME.blue, 0.45),
          borderColor: THEME.blue,
          borderWidth: 1,
          borderRadius: 3,
          barPercentage: 0.95,
          categoryPercentage: 0.85,
          stack: "runtime",
        },
        {
          label: "Peak (h)",
          data: peak,
          backgroundColor: peakColors.map((c) => hexA(c, 0.85)),
          borderColor: peakColors,
          borderWidth: 1,
          borderRadius: 3,
          barPercentage: 0.95,
          categoryPercentage: 0.85,
          stack: "peak",
        },
      ],
    },
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: "index", intersect: false },
      plugins: {
        legend: {
          position: "bottom",
          labels: {
            color: THEME.muted,
            font: { family: "Sora", size: 10, weight: "600" },
            boxWidth: 10,
            boxHeight: 10,
          },
        },
        tooltip: {
          backgroundColor: THEME.card,
          borderColor: THEME.border,
          borderWidth: 1,
          titleColor: THEME.white,
          bodyColor: THEME.muted,
          callbacks: {
            label: (ctx) => `${ctx.dataset.label}: ${ctx.parsed.x.toFixed(3)} h`,
          },
        },
      },
      scales: {
        x: {
          beginAtZero: true,
          title: { display: true, text: "Runtime (hrs)", color: THEME.muted, font: { size: 10 } },
          ticks: { color: THEME.muted, font: { family: "Sora", size: 9 } },
          grid: { color: hexA(THEME.border, 0.4), drawBorder: false },
        },
        y: {
          ticks: { color: THEME.muted, font: { family: "Sora", size: 9 }, autoSkip: false },
          grid: { display: false },
        },
      },
    },
    plugins: [verticalSlaLinePlugin(chartSla)],
function verticalSlaLinePlugin(slaHrs) {
  return {
    id: "verticalSlaLine",
    afterDatasetsDraw(chart) {
      const xScale = chart.scales.x;
      if (!xScale) return;
      const x = xScale.getPixelForValue(slaHrs);
      const { top, bottom } = chart.chartArea;
      const ctx = chart.ctx;
      ctx.save();
      ctx.strokeStyle = THEME.amber;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 4]);
      ctx.beginPath();
      ctx.moveTo(x, top);
      ctx.lineTo(x, bottom);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = THEME.amber;
      ctx.font = '700 10px "Sora", sans-serif';
      ctx.textAlign = "left";
      ctx.fillText(`SLA ${slaHrs}h`, x + 4, top + 12);
      ctx.restore();
    },
  };
}


// ─────────────────────────────────────────────────────────────
// Top breaches HTML table
// Shows true breaches (buffer<0) when present, otherwise shows
// top 10 jobs by peak hours as a ranked heat-map fallback.
// ─────────────────────────────────────────────────────────────
function renderTopBreachesTable(rows, kpis) {
  const tbody    = document.getElementById("top-jobs-tbody");
  const wrap     = document.getElementById("top-jobs-wrap");
  const empty    = document.getElementById("top-jobs-empty");
  const title    = document.getElementById("top-jobs-title");
  const subtitle = document.getElementById("top-jobs-subtitle");
  const badge    = document.getElementById("top-jobs-badge");
  if (!tbody) return;

  tbody.innerHTML = "";

  const all = rows || [];
  if (all.length === 0) {
    empty?.classList.remove("hidden");
    wrap?.classList.add("hidden");
    badge?.classList.add("hidden");
    return;
  }

  // Separate true breaches vs at-risk/healthy
  const trueBreaches = all.filter((r) => (r.buffer_pct ?? 100) < 0);
  const displayRows  = trueBreaches.length > 0 ? trueBreaches : all.slice(0, 10);
  const isFallback   = trueBreaches.length === 0;
  const defaultSla   = kpis?.daily_limit_hrs ?? SLA_DAILY_HRS;

  // Update title / subtitle dynamically
  if (title) {
    title.textContent = isFallback
      ? "Top 10 Jobs by Peak Runtime"
      : `Top ${trueBreaches.length} Breaching Jobs`;
  }
  if (subtitle) {
    subtitle.textContent = isFallback
      ? "No SLA breaches — showing ranked jobs by peak runtime"
      : `${trueBreaches.length} job(s) exceeded their SLA window`;
  }
  // Badge
  if (badge) {
    if (!isFallback) {
      badge.textContent  = `${trueBreaches.length} breach${trueBreaches.length !== 1 ? "es" : ""}`;
      badge.className    = "metric-badge metric-badge-red";
      badge.classList.remove("hidden");
    } else {
      badge.classList.add("hidden");
    }
  }

  empty?.classList.add("hidden");
  wrap?.classList.remove("hidden");

  const statusClass = (status) => {
    switch ((status || "").toUpperCase()) {
      case "BREACH":    return "metric-badge metric-badge-red";
      case "CRITICAL":  return "metric-badge metric-badge-amber";
      case "CAUTION":   return "metric-badge metric-badge-amber";
      case "HEALTHY":   return "metric-badge metric-badge-green";
      case "EXCELLENT": return "metric-badge metric-badge-green";
      default:          return "metric-badge metric-badge-blue";
    }
  };

  for (const row of displayRows) {
    const tr = document.createElement("tr");
    tr.className = "hover:bg-Cblue/5 transition-colors";

    const bufPct  = typeof row.buffer_pct   === "number" ? row.buffer_pct   : null;
    const slaUsed = typeof row.sla_used_pct === "number" ? row.sla_used_pct : null;
    const peak    = typeof row.peak_hrs     === "number" ? row.peak_hrs     : 0;
    const avg     = typeof row.avg_hrs      === "number" ? row.avg_hrs      : 0;
    const status  = row.buffer_status || (bufPct < 0 ? "BREACH" : "HEALTHY");
    const jobName = row.Job_Name || row.job_name || "—";

    const bufferClass =
      bufPct === null   ? "text-Cmuted"  :
      bufPct < 0        ? "text-Cred font-bold"   :
      bufPct < 10       ? "text-Camber font-bold"  :
      bufPct < 30       ? "text-Camber" : "text-Cgreen";

    const slaBarPct   = Math.min(100, slaUsed ?? (peak / (row.sla_hrs ?? defaultSla) * 100));
    const slaBarColor = slaBarPct >= 100 ? "#f43f5e" : slaBarPct >= 80 ? "#f59e0b" : "#3b82f6";
    const jobSla = row.sla_hrs ?? defaultSla;

    tr.innerHTML = `
      <td class="px-3 py-2 font-mono text-Cwhite text-[11px]">
        <div class="truncate max-w-[150px]" title="${escapeHtml(jobName)}">${escapeHtml(jobName)}</div>
      </td>
      <td class="px-3 py-2 text-right font-mono font-bold text-Cwhite text-[11px]">
        ${peak.toFixed(2)}h
        ${peak > jobSla ? '<span class="ml-1 text-[9px] text-Cred font-bold">▲SLA</span>' : ""}
      </td>
      <td class="px-3 py-2 text-right font-mono text-Cmuted text-[11px]">${avg.toFixed(2)}h</td>
      <td class="px-3 py-2 text-right font-mono text-[11px] ${bufferClass}">
        ${bufPct !== null ? (bufPct >= 0 ? "+" : "") + bufPct.toFixed(1) + "%" : "—"}
      </td>
      <td class="px-3 py-2 text-right text-[11px]">
        <div class="flex items-center justify-end gap-1.5">
          <div class="pe-progress-track w-14">
            <div class="pe-progress-fill" style="width:${slaBarPct.toFixed(0)}%;background:${slaBarColor}"></div>
          </div>
          <span class="font-mono text-[10px] text-Cmuted">${slaBarPct.toFixed(0)}%</span>
        </div>
      </td>
      <td class="px-3 py-2">
        <span class="${statusClass(status)}">${escapeHtml(status)}</span>
      </td>
    `;
    tbody.appendChild(tr);
  }
}


// ─────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────
function destroyChart(key) {
  if (charts[key]) {
    try { charts[key].destroy(); } catch { /* noop */ }
    charts[key] = null;
  }
}

function truncate(s, n) {
  if (!s) return "";
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
}


// ════════════════════════════════════════════════════════════
//  PHASE 4 · RESOURCE REVIEW
//  - POST /api/process-resource (auto-fired after upload)
//  - 6 KPI cards + Z-score anomaly strip
//  - Chart.js horizontal grouped bar (CPU/Mem/Disk top servers)
//  - HTML/CSS metric heatmap (no chartjs-chart-matrix dep)
//  - Lazy server detail table with filter + show-all toggle
// ════════════════════════════════════════════════════════════

// Thresholds aligned with services/pe_config.py defaults
const RESOURCE_THRESHOLDS = {
  cpu_ok:   75,  cpu_warn:  90,   // Warning: 75%, Critical: 90%
  mem_ok:   70,  mem_warn:  80,   // Warning: 70%, Critical: 80%
  disk_ok:  70,  disk_warn: 85,   // Warning: 70%, Critical: 85%
};

const GRADE_COLORS = {
  A: THEME.green,
  B: THEME.cyan,
  C: THEME.amber,
  D: "#fb923c",
  F: THEME.red,
};

const STATUS_COLORS = {
  Critical: THEME.red,
  Warning:  THEME.amber,
  Healthy:  THEME.green,
  Unknown:  THEME.muted,
};

function metricColor(val, ok, warn) {
  if (val >= warn) return THEME.red;
  if (val >= ok)   return THEME.amber;
  return THEME.green;
}

// ── Wiring ────────────────────────────────────────────────────
function initResourceView() {
  const toggle = document.getElementById("resource-table-toggle");
  toggle?.addEventListener("click", () => {
    resourceTableState.showAll = !resourceTableState.showAll;
    toggle.textContent = resourceTableState.showAll ? "Show preview" : "Show all";
    if (window.appData.resource) {
      renderResourceTable(window.appData.resource.servers);
    }
  });

  const search = document.getElementById("resource-table-search");
  search?.addEventListener("input", (e) => {
    resourceTableState.filter = (e.target.value || "").trim().toLowerCase();
    if (window.appData.resource) {
      renderResourceTable(window.appData.resource.servers);
    }
  });
}

// ── Pipeline ──────────────────────────────────────────────────
async function processResourceServers(servers) {
  try {
    const res = await fetch("/api/process-resource", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ servers }),
    });
    const text = await res.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      payload = { detail: text || "Server returned a non-JSON response" };
    }
    if (!res.ok) {
      const detail = payload?.detail || `HTTP ${res.status}`;
      toast("error", "Resource processing failed", detail);
      console.error("[pe-dashboard] /api/process-resource failed", payload);
      return;
    }

    window.appData.resource = payload;
    window._execCache = null; // invalidate exec dashboard cache
    renderResourceReview(payload);

    // Pre-AI: auto-generate findings immediately on resource processing
    triggerGenerateFindings().catch(() => {});

    const k = payload.kpis || {};

    // Fleet grade N/A warning
    const gradeLabel = k.fleet_grade === "N/A"
      ? `Grade N/A — Resource data insufficient (${k.known_pct || 0}% known)`
      : `Grade ${k.fleet_grade || "?"} · ${k.known_servers}/${k.total_servers} servers scored`;

    toast(
      k.fleet_grade === "N/A" ? "warning" : "info",
      "Fleet Intelligence ready",
      gradeLabel,
      3500
    );
    console.info("[pe-dashboard] window.appData.resource updated", payload);
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
    console.error("[pe-dashboard] resource network error", err);
  }
}

// ── Top-level renderer ────────────────────────────────────────
function renderResourceReview(data) {
  if (!data) return;

  document.getElementById("resource-empty")?.classList.add("hidden");
  document.getElementById("resource-review-body")?.classList.remove("hidden");

  // Vision AI confidence indicator — show when data came from image parsing
  const visionBanner = document.getElementById("resource-vision-banner");
  if (visionBanner) {
    const imageOnlyServers = (data.servers || []).filter(s => s.image_only);
    if (imageOnlyServers.length > 0) {
      visionBanner.classList.remove("hidden");
      const label = visionBanner.querySelector("[data-vision-label]");
      if (label) label.textContent =
        `${imageOnlyServers.length}/${data.servers.length} server(s) parsed via Vision AI from embedded images — values carry ±5-10% accuracy. Verify critical readings manually.`;
    } else {
      visionBanner.classList.add("hidden");
    }
  }

  renderResourceKpis(data.kpis || {});
  renderResourceExecutiveSummary(data.executive_summary || null);
  renderResourceAnomalies(data.anomalies || []);
  renderResourceBarChart(data.servers || []);
  renderResourceHeatmap(data.servers || []);
  renderResourceTable(data.servers || []);
}

// ── KPI cards ─────────────────────────────────────────────────
function renderResourceKpis(k) {
  setText("rk-servers", String(k.total_servers ?? 0));
  setText("rk-servers-sub", `${k.n_app ?? 0} APP · ${k.n_db ?? 0} DB${k.n_sre ? " · " + k.n_sre + " SRE" : ""}`);

  const grade = k.fleet_grade || "?";
  const gradeEl = document.getElementById("rk-grade");
  if (gradeEl) {
    if (grade === "N/A") {
      gradeEl.textContent = "N/A";
      gradeEl.style.color = THEME.amber;
    } else {
      gradeEl.textContent = grade;
      gradeEl.style.color = GRADE_COLORS[grade] || THEME.muted;
    }
  }
  if (grade === "N/A") {
    setText("rk-grade-sub", "Resource data required");
  } else {
    setText("rk-grade-sub", `Score ${(k.fleet_score ?? 0).toFixed(1)}/100`);
  }

  const t = k.thresholds || RESOURCE_THRESHOLDS;
  const setMetric = (id, val, ok, warn) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = `${(val ?? 0).toFixed(1)}%`;
    el.style.color = metricColor(val ?? 0, ok, warn);
  };
  setMetric("rk-cpu",  k.avg_cpu,  t.cpu_ok,  t.cpu_warn);
  setMetric("rk-mem",  k.avg_mem,  t.mem_ok,  t.mem_warn);
  setMetric("rk-disk", k.avg_disk, t.disk_ok, t.disk_warn);

  // Donut rings (Prompt 3) — fleet averages with threshold ticks
  drawDonutRing("rk-cpu-ring",  k.avg_cpu  ?? 0, 80);
  drawDonutRing("rk-mem-ring",  k.avg_mem  ?? 0, 80);
  drawDonutRing("rk-disk-ring", k.avg_disk ?? 0, 85);

  const healthEl = document.getElementById("rk-health");
  if (healthEl) {
    const c = k.n_critical ?? 0;
    const w = k.n_warning  ?? 0;
    const o = k.n_healthy  ?? 0;
    const a = k.n_agg_trap ?? 0;
    const d = k.n_dual_pressure ?? 0;
    let html =
      `<span style="color:${THEME.red}">${c}C</span> ` +
      `<span style="color:${THEME.amber}">${w}W</span> ` +
      `<span style="color:${THEME.green}">${o}✓</span>`;
    if (a > 0) {
      html += ` <span style="color:${THEME.cyan}" title="${a} server(s) with aggregation trap (false alarm)">${a}🔬</span>`;
    }
    if (d > 0) {
      html += ` <span style="color:${THEME.red}" title="${d} server(s) under dual CPU+Memory pressure">${d}⚡</span>`;
    }
    healthEl.innerHTML = html;
  }
}

// ── Z-score anomaly strip ─────────────────────────────────────
function renderResourceExecutiveSummary(exec) {
  const card = document.getElementById("resource-exec-summary");
  if (!card) {
    // Create the card dynamically if not in HTML (injected after KPI strip)
    const kpiParent = document.getElementById("resource-review-body");
    if (!kpiParent) return;
    let existing = document.getElementById("resource-exec-summary");
    if (!existing) {
      existing = document.createElement("div");
      existing.id = "resource-exec-summary";
      existing.className = "mt-4";
      // Insert after the anomalies card area or after the first child
      const anomCard = document.getElementById("resource-anomalies-card");
      if (anomCard) {
        anomCard.parentNode.insertBefore(existing, anomCard);
      } else {
        kpiParent.appendChild(existing);
      }
    }
    return renderResourceExecutiveSummary(exec);
  }

  if (!exec || exec.verdict === "NO DATA") {
    card.classList.add("hidden");
    return;
  }

  card.classList.remove("hidden");

  const verdictColors = {
    HEALTHY:  THEME.green,
    WARNING:  THEME.amber,
    CRITICAL: THEME.red,
  };
  const vc = verdictColors[exec.verdict] || THEME.muted;

  // Build false alarms HTML
  let falseAlarmsHtml = "";
  if (exec.false_alarms && exec.false_alarms.length) {
    const faRows = exec.false_alarms.map(fa =>
      `<div class="flex items-center gap-2 py-1 text-[11px]">
        <span class="font-mono font-bold" style="color:${THEME.cyan}">${escapeHtml(fa.host.split('.')[0])}</span>
        <span class="text-Cmuted">${escapeHtml(fa.type)}</span>
        <span class="text-Cmuted">Max ${fa.cpu_max.toFixed(0)}% → Avg ${fa.cpu_avg.toFixed(0)}%</span>
        <span class="text-[8px] font-bold uppercase px-1 py-0.5 rounded" style="color:${THEME.cyan};background:${hexA(THEME.cyan,0.15)}">FALSE ALARM</span>
      </div>`
    ).join("");
    falseAlarmsHtml = `
      <div class="mt-2">
        <div class="text-[10px] uppercase tracking-wider text-Cmuted font-bold mb-1">🔬 False Alarms Detected (${exec.false_alarms.length})</div>
        ${faRows}
      </div>`;
  }

  // Build bottlenecks HTML
  let bottlenecksHtml = "";
  if (exec.bottlenecks && exec.bottlenecks.length) {
    const bnRows = exec.bottlenecks.map(bn =>
      `<div class="flex items-start gap-2 py-1 text-[11px]">
        <span class="font-mono font-bold" style="color:${THEME.red}">${escapeHtml(bn.host.split('.')[0])}</span>
        <span class="text-Cmuted">${escapeHtml(bn.type)}</span>
        <span style="color:${STATUS_COLORS[bn.status] || THEME.muted}">${escapeHtml(bn.issues.join(' · '))}</span>
      </div>`
    ).join("");
    bottlenecksHtml = `
      <div class="mt-2">
        <div class="text-[10px] uppercase tracking-wider text-Cmuted font-bold mb-1">🔥 Actual Bottlenecks (${exec.bottlenecks.length})</div>
        ${bnRows}
      </div>`;
  }

  card.innerHTML = `
    <div class="rounded-xl border p-4" style="border-color:${hexA(vc, 0.4)};background:${hexA(vc, 0.06)}">
      <div class="flex items-center gap-3 mb-2">
        <div class="text-[10px] uppercase tracking-wider text-Cmuted font-bold">Executive Resource Summary</div>
        <span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border" style="color:${vc};border-color:${hexA(vc, 0.5)};background:${hexA(vc, 0.12)}">${exec.verdict}</span>
      </div>
      <div class="text-[12px] text-Cwhite mb-1">${escapeHtml(exec.verdict_detail)}</div>
      ${falseAlarmsHtml}
      ${bottlenecksHtml}
      <div class="mt-3 pt-2 border-t" style="border-color:${hexA(THEME.border, 0.5)}">
        <div class="text-[11px] text-Cwhite font-semibold">${escapeHtml(exec.summary_line1)}</div>
        <div class="text-[11px] text-Cmuted mt-0.5">${escapeHtml(exec.summary_line2)}</div>
      </div>
    </div>
  `;
}

// ── Z-score anomaly strip (original) ─────────────────────────
function renderResourceAnomalies(anomalies) {
  const card = document.getElementById("resource-anomalies-card");
  const list = document.getElementById("resource-anomalies-list");
  if (!card || !list) return;

  if (!anomalies || !anomalies.length) {
    card.classList.add("hidden");
    list.innerHTML = "";
    return;
  }

  card.classList.remove("hidden");
  list.innerHTML = "";
  for (const a of anomalies) {
    const sev = Math.abs(a.z) >= 3 ? THEME.red : THEME.amber;
    const host = (a.host || "?").split(".")[0];
    const item = document.createElement("div");
    item.className = "rounded-md border-l-2 p-2 text-[11px] flex items-center justify-between gap-2";
    item.style.borderLeftColor = sev;
    item.style.background = hexA(sev, 0.08);
    item.innerHTML = `
      <div class="min-w-0">
        <div class="font-bold truncate" style="color:${sev}">${escapeHtml(host)}</div>
        <div class="text-Cmuted">${escapeHtml(a.metric)} · ${_n(a.value).toFixed(1)}%</div>
      </div>
      <div class="text-right shrink-0">
        <div class="font-mono text-[10px]" style="color:${sev}">z=${_n(a.z) >= 0 ? "+" : ""}${_n(a.z).toFixed(2)}</div>
      </div>
    `;
    list.appendChild(item);
  }
}

// ── Horizontal grouped bar (CPU / Mem / Disk × top 12) ────────
function renderResourceBarChart(servers) {
  const canvas = document.getElementById("chart-resource-bars");
  if (!canvas) return;

  const known = (servers || []).filter(
    (s) => !s.image_only && Math.max(s.cpu_pct || 0, s.mem_pct || 0, s.disk_pct || 0) > 0
  );
  destroyChart("resourceBars");
  if (!known.length) {
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = THEME.muted;
    ctx.font = "12px Sora, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("No metric data — upload a Zabbix file with CPU/Mem/Disk values.", canvas.width / 2, 40);
    return;
  }

  const top = [...known].sort((a, b) => (b.cpu_pct || 0) - (a.cpu_pct || 0)).slice(0, 12);
  const labels = top.map((s) => truncate(s.server, 22));

  charts.resourceBars = new Chart(canvas.getContext("2d"), {
    type: "bar",
    data: {
      labels,
      datasets: [
        { label: "CPU %",  data: top.map((s) => s.cpu_pct  || 0), backgroundColor: hexA(THEME.blue,   0.85), borderColor: THEME.blue,   borderWidth: 1, borderRadius: 3 },
        { label: "Mem %",  data: top.map((s) => s.mem_pct  || 0), backgroundColor: hexA(THEME.cyan,   0.85), borderColor: THEME.cyan,   borderWidth: 1, borderRadius: 3 },
        { label: "Disk %", data: top.map((s) => s.disk_pct || 0), backgroundColor: hexA(THEME.purple, 0.85), borderColor: THEME.purple, borderWidth: 1, borderRadius: 3 },
      ],
    },
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 380 },
      layout: { padding: { right: 12 } },
      plugins: {
        legend: {
          position: "bottom",
          labels: { color: THEME.muted, font: { size: 10 }, boxWidth: 10 },
        },
        tooltip: {
          backgroundColor: THEME.card2,
          borderColor: THEME.border,
          borderWidth: 1,
          titleColor: THEME.white,
          bodyColor: THEME.white,
          callbacks: {
            label: (ctx) => `${ctx.dataset.label}: ${ctx.parsed.x.toFixed(1)}%`,
          },
        },
      },
      scales: {
        x: {
          min: 0, max: 105,
          grid:   { color: hexA(THEME.border, 0.5), drawBorder: false },
          ticks:  { color: THEME.muted, font: { size: 10 }, callback: (v) => `${v}%` },
          title:  { display: true, text: "% Used", color: THEME.muted, font: { size: 10 } },
        },
        y: {
          grid:  { color: hexA(THEME.border, 0.25), drawBorder: false },
          ticks: { color: THEME.muted, font: { size: 10 } },
        },
      },
    },
    plugins: [resourceThresholdLinesPlugin(75, 90)],
  });
}

// Plugin: dashed amber line at 75% and dashed red line at 90%
function resourceThresholdLinesPlugin(okT, warnT) {
  return {
    id: "resourceThresholds",
    afterDatasetsDraw(chart) {
      const { ctx, chartArea, scales } = chart;
      if (!chartArea || !scales?.x) return;
      const drawLine = (val, color) => {
        const x = scales.x.getPixelForValue(val);
        ctx.save();
        ctx.beginPath();
        ctx.setLineDash([4, 4]);
        ctx.lineWidth = 1.2;
        ctx.strokeStyle = color;
        ctx.moveTo(x, chartArea.top);
        ctx.lineTo(x, chartArea.bottom);
        ctx.stroke();
        ctx.restore();
      };
      drawLine(okT,   THEME.amber);
      drawLine(warnT, THEME.red);
    },
  };
}

// ── Per-server metric bars (replaces the old heatmap) ─────────
//
// Each row shows: hostname + role, then horizontal bars for CPU/MEM/DISK
// with threshold lines. Memory >90% gets a pulsing red dot. Disk uses a
// segmented used-vs-available look. Trend arrow placeholder for future
// time-series. The table below is still the primary view — these bars
// are an embedded per-cell visualization, not a duplicate chart.
function renderResourceHeatmap(servers) {
  const wrap = document.getElementById("resource-heatmap");
  if (!wrap) return;

  const known = (servers || []).filter(
    (s) => !s.image_only && Math.max(s.cpu_pct || 0, s.mem_pct || 0, s.disk_pct || 0) > 0
  );
  if (!known.length) {
    wrap.innerHTML = `<div class="text-center text-Cmuted text-[11px] py-8">No metric data available — upload a Zabbix file with CPU/Mem/Disk values.</div>`;
    return;
  }
  const top = [...known].sort((a, b) =>
    Math.max(b.cpu_pct||0, b.mem_pct||0, b.disk_pct||0)
    - Math.max(a.cpu_pct||0, a.mem_pct||0, a.disk_pct||0)
  ).slice(0, 20);

  const trendArrow = (t) => {
    if (t == null) return `<span class="text-Cmuted text-[10px]" title="No trend — snapshot only">→</span>`;
    if (t > 5)  return `<span class="text-Cred text-[11px]" title="Up vs 7-day avg">↑</span>`;
    if (t < -5) return `<span class="text-Cgreen text-[11px]" title="Down vs 7-day avg">↓</span>`;
    return `<span class="text-Cmuted text-[10px]" title="Flat vs 7-day avg">→</span>`;
  };

  const barCell = (val, ok = 60, warn = 80, opts = {}) => {
    if (val == null || isNaN(Number(val)) || val < 0) {
      return `<div class="metric-bar-track" title="No data"><div class="metric-bar-fill" style="width:0%;background:#475569"></div></div>
              <div class="text-[9px] text-Cmuted text-right mt-0.5">N/A</div>`;
    }
    const v = Math.max(0, Math.min(100, Number(val)));
    let color;
    if (v >= warn)      color = "#ef4444";  // red
    else if (v >= ok)   color = "#f59e0b";  // amber
    else                color = "#10b981";  // green
    const threshold = opts.threshold ?? warn;
    const pulse = (opts.pulseAt != null && v >= opts.pulseAt)
      ? `<span class="pulse-red" style="position:absolute;right:-3px;top:-3px;width:8px;height:8px;border-radius:50%;background:#ef4444"></span>`
      : "";
    let bar = `<div class="metric-bar-fill" style="width:${v}%;background:${color}"></div>`;
    if (opts.segmented) {
      // Used-vs-available pattern: solid + striped track
      bar = `<div class="metric-bar-fill" style="width:${v}%;background:repeating-linear-gradient(45deg,${color} 0 6px,${color}cc 6px 12px)"></div>`;
    }
    return `<div class="metric-bar-track" title="${v.toFixed(1)}% (threshold ${threshold}%)">
              ${bar}
              <div class="metric-bar-threshold" style="left:${threshold}%"></div>
              ${pulse}
            </div>
            <div class="text-[9px] font-mono text-right mt-0.5" style="color:${color}">${v.toFixed(0)}%${opts.trendArrow ? ' ' + opts.trendArrow : ''}</div>`;
  };

  const rows = top.map((s) => {
    const host = (s.host || s.server || "?").split(".")[0];
    const type = (s.type || "?").toUpperCase();
    const typeColor = type === "DB" ? "#a855f7" : (type === "SRE" ? "#06b6d4" : "#3b82f6");
    const cpuTrend  = trendArrow(s.cpu_trend_pct);
    const memTrend  = trendArrow(s.mem_trend_pct);
    const diskTrend = trendArrow(s.disk_trend_pct);

    return `<div class="grid items-center gap-3 py-1.5 border-b border-Cborder/30"
                 style="grid-template-columns:minmax(120px,1fr) 1.6fr 1.6fr 1.6fr">
      <div class="min-w-0 flex items-center gap-1.5">
        <span class="text-[8px] font-bold uppercase tracking-wider px-1 py-0.5 rounded shrink-0"
              style="color:${typeColor};background:${hexA(typeColor, 0.12)};border:1px solid ${hexA(typeColor, 0.4)}">${escapeHtml(type)}</span>
        <span class="text-[11px] font-mono text-Cwhite truncate" title="${escapeHtml(s.host || s.server || '')}">${escapeHtml(host)}</span>
      </div>
      <div>${barCell(s.cpu_pct,  60, 80, { threshold: 80, trendArrow: cpuTrend })}</div>
      <div>${barCell(s.mem_pct,  60, 80, { threshold: 80, pulseAt: 90, trendArrow: memTrend })}</div>
      <div>${barCell(s.disk_pct, 70, 85, { threshold: 85, segmented: true, trendArrow: diskTrend })}</div>
    </div>`;
  }).join("");

  wrap.innerHTML = `
    <div class="grid items-center gap-3 pb-1.5 border-b border-Cborder/60 text-[9px] uppercase tracking-wider text-Cmuted font-bold"
         style="grid-template-columns:minmax(120px,1fr) 1.6fr 1.6fr 1.6fr">
      <div>Server</div>
      <div>CPU (threshold 80%)</div>
      <div>Memory (threshold 80%)</div>
      <div>Disk (threshold 85%)</div>
    </div>
    ${rows}
  `;
}

// ── Donut ring helper (used for fleet AVG CPU/MEM/DISK tiles) ─
// Draws a 64×64 ring on a canvas where:
//   - the fill arc is the metric value (green/amber/red by threshold)
//   - a thin tick marks the threshold position
function drawDonutRing(canvasId, value, threshold = 80) {
  const c = document.getElementById(canvasId);
  if (!c || !c.getContext) return;
  const v = Math.max(0, Math.min(100, Number(value) || 0));
  const ctx = c.getContext("2d");
  const W = c.width, H = c.height;
  ctx.clearRect(0, 0, W, H);
  const cx = W / 2, cy = H / 2;
  const r = Math.min(W, H) / 2 - 6;
  const lw = 8;

  // Track
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.lineWidth = lw;
  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.stroke();

  // Color by zone
  let color;
  if (v >= threshold)        color = "#ef4444";
  else if (v >= threshold-20) color = "#f59e0b";
  else                        color = "#10b981";

  // Fill arc — start at top (-π/2)
  const start = -Math.PI / 2;
  const end   = start + (v / 100) * Math.PI * 2;
  ctx.beginPath();
  ctx.arc(cx, cy, r, start, end);
  ctx.lineWidth = lw;
  ctx.strokeStyle = color;
  ctx.lineCap = "round";
  ctx.stroke();

  // Threshold tick — outer notch
  const tA = start + (threshold / 100) * Math.PI * 2;
  const tx1 = cx + Math.cos(tA) * (r - lw / 2 - 1);
  const ty1 = cy + Math.sin(tA) * (r - lw / 2 - 1);
  const tx2 = cx + Math.cos(tA) * (r + lw / 2 + 2);
  const ty2 = cy + Math.sin(tA) * (r + lw / 2 + 2);
  ctx.beginPath();
  ctx.moveTo(tx1, ty1); ctx.lineTo(tx2, ty2);
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = "rgba(255,255,255,0.6)";
  ctx.lineCap = "butt";
  ctx.stroke();
}

// ── Lazy server detail table ──────────────────────────────────
function renderResourceTable(servers) {
  const tbody = document.getElementById("resource-tbody");
  const empty = document.getElementById("resource-table-empty");
  const toggle = document.getElementById("resource-table-toggle");
  if (!tbody) return;

  let rows = [...(servers || [])];
  rows.sort((a, b) => (b.cpu_pct || 0) - (a.cpu_pct || 0));

  // Filter
  const f = resourceTableState.filter;
  if (f) {
    rows = rows.filter(
      (s) =>
        (s.server || "").toLowerCase().includes(f) ||
        (s.host   || "").toLowerCase().includes(f)
    );
  }

  // Show all vs preview
  const total = rows.length;
  const showAll = resourceTableState.showAll;
  const slice = showAll ? rows : rows.slice(0, RESOURCE_TABLE_PREVIEW);

  // Toggle button label/visibility
  if (toggle) {
    if (total <= RESOURCE_TABLE_PREVIEW) {
      toggle.classList.add("hidden");
    } else {
      toggle.classList.remove("hidden");
      toggle.textContent = showAll
        ? `Show preview (${RESOURCE_TABLE_PREVIEW})`
        : `Show all (${total})`;
    }
  }

  if (!slice.length) {
    tbody.innerHTML = "";
    empty?.classList.remove("hidden");
    return;
  }
  empty?.classList.add("hidden");

  tbody.innerHTML = "";
  for (const r of slice) {
    const tr = document.createElement("tr");
    tr.className = "transition-colors";
    tr.style.background = statusRowTint(r.status);

    // Role-specific CPU thresholds (from backend), fallback to global
    const cpuOk   = r.role_cpu_ok   ?? RESOURCE_THRESHOLDS.cpu_ok;
    const cpuWarn = r.role_cpu_warn ?? RESOURCE_THRESHOLDS.cpu_warn;

    // Build CPU cell with aggregation trap badge
    const cpuAvail = r.cpu_available !== false && r.cpu_pct != null;
    const cpuVal = cpuAvail ? r.cpu_pct.toFixed(1) : null;
    const cpuColor = cpuAvail ? metricColor(r.effective_cpu ?? r.cpu_pct ?? 0, cpuOk, cpuWarn) : '';
    let cpuExtra = "";
    if (r.agg_trap) {
      cpuExtra = ` <span class="text-[8px] font-bold uppercase tracking-wider px-1 py-0.5 rounded" style="color:${THEME.cyan};background:${hexA(THEME.cyan,0.15)};border:1px solid ${hexA(THEME.cyan,0.4)}" title="Aggregation Trap: Max CPU ${cpuVal}% but Avg only ${(r.cpu_avg_pct||0).toFixed(1)}% — false alarm, server is healthy">FALSE ALARM</span>`;
    }

    // Build dual pressure badge
    let dualBadge = "";
    if (r.dual_pressure) {
      dualBadge = ` <span class="text-[8px] font-bold uppercase tracking-wider px-1 py-0.5 rounded" style="color:${THEME.red};background:${hexA(THEME.red,0.15)};border:1px solid ${hexA(THEME.red,0.4)}" title="DUAL PRESSURE: CPU ≥80% + Memory ≥85% — severe resource exhaustion">DUAL</span>`;
    }

    // Null-safe metric display
    const memAvail = r.mem_available !== false && r.mem_pct != null;
    const memGbAvail = r.mem_available !== false && r.mem_gb != null;
    const cpuAvgAvail = r.cpu_available !== false && r.cpu_avg_pct != null;

    tr.innerHTML = `
      <td class="py-2 pr-3 font-semibold text-Cwhite truncate max-w-[220px]" title="${escapeHtml(r.host || r.server)}">${escapeHtml(r.server)}${dualBadge}</td>
      <td class="py-2 pr-3 text-Cmuted">${escapeHtml(r.type || "")}</td>
      <td class="py-2 pr-3 text-right font-mono ${!cpuAvail ? 'text-Cmuted' : ''}" style="color:${cpuColor}">${cpuAvail ? cpuVal + '%' + cpuExtra : '<span title="Data unavailable">N/A</span>'}</td>
      <td class="py-2 pr-3 text-right font-mono text-Cmuted">${cpuAvgAvail ? r.cpu_avg_pct.toFixed(1) + '%' : 'N/A'}</td>
      <td class="py-2 pr-3 text-right font-mono ${!memAvail ? 'text-Cmuted' : ''}" style="color:${memAvail ? metricColor(r.mem_pct, RESOURCE_THRESHOLDS.mem_ok, RESOURCE_THRESHOLDS.mem_warn) : ''}">${memAvail ? r.mem_pct.toFixed(1) + '%' : '<span title="Data unavailable">N/A</span>'}</td>
      <td class="py-2 pr-3 text-right font-mono text-Cmuted">${memGbAvail ? r.mem_gb.toFixed(1) : 'N/A'}</td>
      <td class="py-2 pr-3 text-right font-mono ${r.disk_pct == null ? 'text-Cmuted' : ''}" style="color:${r.disk_pct != null ? metricColor(r.disk_pct, RESOURCE_THRESHOLDS.disk_ok, RESOURCE_THRESHOLDS.disk_warn) : ''}">${r.disk_pct != null ? (r.disk_pct).toFixed(1) + '%' : 'N/A'}</td>
      <td class="py-2 pr-3"><span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border" style="${statusPillStyle(r.status)}">${escapeHtml(r.status || "Unknown")}</span></td>
      <td class="py-2 pr-3 text-Cmuted truncate max-w-[180px]" title="${escapeHtml(r.source_env || "")}">${escapeHtml(truncate(r.source_env || "", 28))}</td>
    `;
    tbody.appendChild(tr);
  }
}

function statusRowTint(status) {
  switch (status) {
    case "Critical": return hexA(THEME.red,    0.10);
    case "Warning":  return hexA(THEME.amber,  0.08);
    case "Healthy":  return hexA(THEME.green,  0.06);
    default:         return "transparent";
  }
}

function statusPillStyle(status) {
  const c = STATUS_COLORS[status] || THEME.muted;
  return `color:${c};border-color:${hexA(c, 0.5)};background:${hexA(c, 0.12)}`;
}


// ════════════════════════════════════════════════════════════
//  PHASE 6 · GOVERNANCE & APPROVAL
//  - Issues / Waivers register (pure client-side state)
//  - PE Validation Checklist (9 toggles, progress bar)
//  - Dual sign-off (PE + Customer)
//  - Export HTML Report → POST /api/export-report → blob download
// ════════════════════════════════════════════════════════════

const SEV_COLORS = {
  Critical:      THEME.red,
  High:          "#fb923c",
  Medium:        THEME.amber,
  Low:           THEME.green,
  Informational: THEME.blue,
};
const STAT_COLORS = {
  Open:         THEME.red,
  "In Progress":THEME.amber,
  Waived:       THEME.amber,
  Resolved:     THEME.green,
  Deferred:     THEME.muted,
};

// ── Bootstrap ─────────────────────────────────────────────────
function initGovernanceTab() {
  // Issue form accordion toggle
  const formToggle  = document.getElementById("issue-form-toggle");
  const formBody    = document.getElementById("issue-form-body");
  const chevron     = document.getElementById("issue-form-chevron");
  formToggle?.addEventListener("click", () => {
    const open = !formBody.classList.contains("hidden");
    formBody.classList.toggle("hidden", open);
    chevron?.classList.toggle("rotate-180", !open);
  });

  // Add Issue button
  document.getElementById("add-issue-btn")?.addEventListener("click", addIssue);

  // Checklist checkboxes
  document.querySelectorAll(".chk-item").forEach((cb) => {
    cb.addEventListener("change", onChecklistChange);
  });

  // PE sign-off checkbox
  document.getElementById("pe-approve-chk")?.addEventListener("change", onPeApprove);

  // Customer sign-off checkbox
  document.getElementById("cust-approve-chk")?.addEventListener("change", onCustApprove);

  // Live name sync
  document.getElementById("pe-name")?.addEventListener("input", (e) => {
    window.appData.approvals.pe.name = e.target.value.trim();
    refreshGoLiveBanner();
  });
  document.getElementById("cust-name")?.addEventListener("input", (e) => {
    window.appData.approvals.customer.name = e.target.value.trim();
    refreshGoLiveBanner();
  });

  // Notes sync
  document.getElementById("approval-notes")?.addEventListener("input", (e) => {
    window.appData.approvals.notes = e.target.value;
  });

  // Export CSV button
  document.getElementById("export-issues-csv-btn")?.addEventListener("click", exportIssuesCsv);

  // Export HTML Report button
  document.getElementById("export-report-btn")?.addEventListener("click", exportHtmlReport);
}

// ── Add Issue ─────────────────────────────────────────────────
function addIssue() {
  const desc = document.getElementById("iss-desc")?.value.trim();
  const errEl = document.getElementById("issue-form-error");
  if (!desc) {
    errEl?.classList.remove("hidden");
    return;
  }
  errEl?.classList.add("hidden");

  const issues = window.appData.issues;
  const autoId = `ISS-${String(issues.length + 1).padStart(3, "0")}`;
  issues.push({
    ID:          document.getElementById("iss-id")?.value.trim() || autoId,
    Type:        document.getElementById("iss-type")?.value || "Bug",
    Severity:    document.getElementById("iss-sev")?.value  || "Medium",
    Status:      document.getElementById("iss-stat")?.value || "Open",
    Owner:       document.getElementById("iss-owner")?.value.trim() || "",
    ETA:         document.getElementById("iss-eta")?.value.trim()   || "N/A",
    Description: desc,
    Mitigation:  document.getElementById("iss-mit")?.value.trim()   || "",
    Logged:      new Date().toISOString().slice(0, 10),
  });

  // Clear form fields
  ["iss-id","iss-owner","iss-eta","iss-desc","iss-mit"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.value = "";
  });

  renderIssuesRegister();
  toast("success", "Issue added", `${issues[issues.length - 1].ID} added to register.`, 3000);
}

// ── Render Issues Register ────────────────────────────────────
function renderIssuesRegister() {
  const issues  = window.appData.issues;
  const wrap    = document.getElementById("issues-register-wrap");
  const emptyEl = document.getElementById("issues-empty-note");
  const cards   = document.getElementById("issues-cards");
  if (!wrap || !cards) return;

  if (!issues.length) {
    wrap.classList.add("hidden");
    emptyEl?.classList.remove("hidden");
    return;
  }
  wrap.classList.remove("hidden");
  emptyEl?.classList.add("hidden");

  // KPI counts
  const nOpen    = issues.filter((i) => ["Open","In Progress"].includes(i.Status)).length;
  const nWaived  = issues.filter((i) => i.Status === "Waived").length;
  const nResolved= issues.filter((i) => i.Status === "Resolved").length;
  setText("iss-kpi-total",   String(issues.length));
  setText("iss-kpi-open",    String(nOpen));
  setText("iss-kpi-waived",  String(nWaived));
  setText("iss-kpi-resolved",String(nResolved));

  // Update open KPI color dynamically
  const openEl = document.getElementById("iss-kpi-open");
  if (openEl) openEl.style.color = nOpen > 0 ? THEME.red : THEME.green;

  // Cards
  cards.innerHTML = "";
  issues.forEach((iss, idx) => {
    const sevColor  = SEV_COLORS[iss.Severity]  || THEME.muted;
    const statColor = STAT_COLORS[iss.Status]   || THEME.muted;
    const card = document.createElement("div");
    card.className = "rounded-xl border-l-4 bg-Ccard2 border border-Cborder px-4 py-3";
    card.style.borderLeftColor = sevColor;
    card.innerHTML = `
      <div class="flex items-start justify-between flex-wrap gap-2 mb-2">
        <div class="flex items-center gap-2 flex-wrap">
          <span class="text-sm font-bold" style="color:${sevColor}">${escapeHtml(iss.ID)}</span>
          <span class="text-[10px] text-Cmuted">${escapeHtml(iss.Type)} · ${escapeHtml(iss.Severity)}</span>
        </div>
        <div class="flex items-center gap-2 flex-wrap">
          <span class="text-[10px] font-bold px-2 py-0.5 rounded-full border"
                style="color:${statColor};border-color:${hexA(statColor,.4)};background:${hexA(statColor,.1)}">
            ${escapeHtml(iss.Status)}
          </span>
          <span class="text-[10px] text-Cmuted">Owner: ${escapeHtml(iss.Owner||"—")} · ETA: ${escapeHtml(iss.ETA||"N/A")}</span>
          <button data-remove-idx="${idx}" class="text-[10px] text-Cmuted hover:text-Cred transition ml-1">✕ Remove</button>
        </div>
      </div>
      <p class="text-xs text-Cwhite leading-relaxed mb-1">${escapeHtml(iss.Description)}</p>
      ${iss.Mitigation ? `<p class="text-[11px] text-Cmuted">🛡 ${escapeHtml(iss.Mitigation)}</p>` : ""}
      <p class="text-[10px] text-Cmuted mt-1">Logged: ${escapeHtml(iss.Logged)}</p>
    `;
    card.querySelector("[data-remove-idx]")?.addEventListener("click", (e) => {
      const i = parseInt(e.target.dataset.removeIdx, 10);
      window.appData.issues.splice(i, 1);
      renderIssuesRegister();
    });
    cards.appendChild(card);
  });
}

// ── Checklist ─────────────────────────────────────────────────
function onChecklistChange(e) {
  const key = e.target.dataset.chk;
  window.appData.approvals.checklist[key] = e.target.checked;
  refreshChecklistProgress();
}

function refreshChecklistProgress() {
  const chk   = window.appData.approvals.checklist;
  const done  = Object.values(chk).filter(Boolean).length;
  const total = Object.keys(chk).length;
  const pct   = Math.round((done / total) * 100);
  const bar   = document.getElementById("chk-progress-bar");
  const label = document.getElementById("chk-progress-label");
  if (bar) {
    bar.style.width = `${pct}%`;
    bar.style.background = pct === 100 ? THEME.green : pct >= 67 ? THEME.amber : THEME.red;
  }
  if (label) label.textContent = `Checklist ${done}/${total} complete`;

  const allDone = done === total;
  const peLabel = document.getElementById("pe-approve-label");
  const peChk   = document.getElementById("pe-approve-chk");
  const hint    = document.getElementById("pe-checklist-hint");
  if (peLabel) peLabel.classList.toggle("opacity-50",       !allDone);
  if (peLabel) peLabel.classList.toggle("pointer-events-none", !allDone);
  if (peChk)  peChk.disabled = !allDone;
  if (hint)   hint.classList.toggle("hidden", allDone);
}

// ── PE sign-off ───────────────────────────────────────────────
function onPeApprove(e) {
  const approved = e.target.checked;
  window.appData.approvals.pe.approved = approved;
  if (approved && !window.appData.approvals.pe.date) {
    window.appData.approvals.pe.date = new Date().toISOString().slice(0, 10);
  }
  const badge = document.getElementById("pe-status-badge");
  if (badge) {
    badge.textContent = approved
      ? `✅ PE Approved — ${window.appData.approvals.pe.date}`
      : "⏳ PE Approval Pending";
    badge.style.color = approved ? THEME.green : THEME.amber;
  }
  refreshGoLiveBanner();
}

// ── Customer sign-off ─────────────────────────────────────────
function onCustApprove(e) {
  const approved = e.target.checked;
  window.appData.approvals.customer.approved = approved;
  if (approved && !window.appData.approvals.customer.date) {
    window.appData.approvals.customer.date = new Date().toISOString().slice(0, 10);
  }
  const badge = document.getElementById("cust-status-badge");
  if (badge) {
    badge.textContent = approved
      ? `✅ Customer Approved — ${window.appData.approvals.customer.date}`
      : "⏳ Customer Approval Pending";
    badge.style.color = approved ? THEME.green : THEME.amber;
  }
  refreshGoLiveBanner();
}

// ── Go-Live banner ────────────────────────────────────────────
function refreshGoLiveBanner() {
  const a       = window.appData.approvals;
  const bothOk  = a.pe.approved && a.customer.approved;
  const banner  = document.getElementById("golive-banner");
  const label   = document.getElementById("golive-label");
  const meta    = document.getElementById("golive-meta");
  const color   = bothOk ? THEME.green : THEME.amber;
  if (banner) {
    banner.style.borderColor  = hexA(color, 0.5);
    banner.style.background   = hexA(color, 0.1);
  }
  if (label) {
    label.textContent = `Go-Live Sign-Off Status: ${bothOk ? "APPROVED ✅" : "PENDING ⏳"}`;
    label.style.color = color;
  }
  if (meta) {
    const peName   = a.pe.name       || "—";
    const custName = a.customer.name || "—";
    meta.textContent = `PE: ${peName}  |  Customer: ${custName}`;
  }
}

// ── Export Issues CSV ─────────────────────────────────────────
function exportIssuesCsv() {
  const issues = window.appData.issues;
  if (!issues.length) {
    toast("info", "Nothing to export", "Add issues to the register first.");
    return;
  }
  const cols = ["ID","Type","Severity","Status","Owner","ETA","Description","Mitigation","Logged"];
  const csvRows = [cols.join(",")];
  for (const iss of issues) {
    csvRows.push(cols.map((c) => `"${String(iss[c] || "").replace(/"/g,'""')}"`).join(","));
  }
  const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href     = url;
  a.download = `issues_register_${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ── Export HTML Report ────────────────────────────────────────
async function exportHtmlReport() {
  const btn = document.getElementById("export-report-btn");
  if (btn) { btn.disabled = true; btn.textContent = "Generating…"; }

  // Sync text inputs into appData right before sending
  const a = window.appData.approvals;
  a.pe.name       = document.getElementById("pe-name")?.value.trim()   || a.pe.name;
  a.customer.name = document.getElementById("cust-name")?.value.trim() || a.customer.name;
  a.notes         = document.getElementById("approval-notes")?.value   || a.notes;

  // Build payload — entire appData snapshot
  const payload = {
    upload:    window.appData.upload,
    servers:   window.appData.servers,
    batch:     window.appData.batch,
    resource:  window.appData.resource,
    issues:    window.appData.issues,
    approvals: window.appData.approvals,
  };

  try {
    const res = await fetch("/api/export-report", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.text();
      toast("error", "Export failed", err.slice(0, 200));
      return;
    }
    const blob     = await res.blob();
    const url      = URL.createObjectURL(blob);
    const anchor   = document.createElement("a");
    const dateStr  = new Date().toISOString().slice(0, 10);
    anchor.href    = url;
    anchor.download= `PE_Audit_Report_${dateStr}.html`;
    anchor.click();
    URL.revokeObjectURL(url);
    toast("success", "Report downloaded", "Standalone HTML report saved to your Downloads folder.", 5000);
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
  } finally {
    if (btn) { btn.disabled = false; btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke-width="2.2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3"/></svg> Export HTML Report`; }
  }
}


// ════════════════════════════════════════════════════════════
//  PHASE 5 — PE Findings Engine + Gemini AI Insight
// ════════════════════════════════════════════════════════════

// ── Constants ────────────────────────────────────────────────
const FINDING_STYLES = {
  critical: { border: "border-Cred",   bg: "bg-Cred/5",   badge: "bg-Cred/20 text-Cred",   dot: "bg-Cred"   },
  warning:  { border: "border-Camber", bg: "bg-Camber/5", badge: "bg-Camber/20 text-Camber",dot: "bg-Camber"  },
  info:     { border: "border-Cblue",  bg: "bg-Cblue/5",  badge: "bg-Cblue/20 text-Cblue",  dot: "bg-Cblue"  },
  ok:       { border: "border-Cgreen", bg: "bg-Cgreen/5", badge: "bg-Cgreen/20 text-Cgreen", dot: "bg-Cgreen" },
};

// ── Init ──────────────────────────────────────────────────────
function initFindingsTab() {
  // Nothing to wire at boot — buttons use inline onclick handlers.
  // Findings auto-fire when the insights tab becomes active (setActiveView).
}

// ── Trigger AI-driven findings (Gemini / NIM cross-pillar synthesis) ─────
// ── Build the rule-engine payload from whatever is currently in appData ─
function _buildFindingsPayload() {
  const ad = window.appData || {};
  return {
    batch_kpis:    ad.batch?.kpis        || null,
    top_jobs:      ad.batch?.top_jobs    || null,
    top_breaches:  ad.batch?.top_breaches|| null,
    window:        ad.batch?.window      || null,
    anomalies:     ad.batch?.anomalies   || null,
    sub_stats:     ad.batch?.sub_stats   || null,
    resource_kpis: ad.resource?.kpis     || null,
    servers:       ad.resource?.servers  || ad.servers || null,
    sla_matrix:    ad.slaMatrix          || null,
    sla_ceilings:  ad.slaCeilings        || null,
    benchmark:     ad.benchmark          || null,
    sow_compare:   ad.sowCompare         || null,
    issues:        ad.issues             || null,
    customer_name: ad.customerName       || null,
  };
}

async function triggerGenerateFindings() {
  const loading = document.getElementById("findings-loading");
  if (loading) loading.classList.remove("hidden");

  // Call the deterministic rule engine — fast, always works, no LLM needed.
  // The LLM runs in the background via triggerSmartFindings afterwards.
  const payload = _buildFindingsPayload();

  // Skip if there's nothing to analyse
  const ad = window.appData || {};
  const hasData = !!(ad.batch || ad.resource) ||
                  !!(payload.batch_kpis || payload.resource_kpis ||
                     (payload.top_jobs && payload.top_jobs.length));
  if (!hasData) {
    if (loading) loading.classList.add("hidden");
    return;
  }

  try {
    const res = await fetch("/api/generate-findings", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(payload),
    });
    if (!res.ok) {
      const msg = await res.text();
      toast("error", "Findings error", msg.slice(0, 200));
      return;
    }
    const data = await res.json();

    // /api/generate-findings already returns the Finding shape directly —
    // no field remapping needed (text, recommendation, evidence_class, etc.)
    const findings = Array.isArray(data.findings) ? data.findings : [];

    window.appData.findings = { findings, summary: data.summary };
    renderFindings(findings);
    renderFindingsSummary(data.summary || {});
    renderFindingsDonut(data.summary || {});

    // Background: LLM smart analysis (non-blocking — never delays the table)
    triggerSmartFindings(payload).catch(() => {});

    // Cross-pillar cascade
    triggerPeConsultant().catch(() => {});
    triggerPeNarrative().catch(() => {});
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
  } finally {
    const loading = document.getElementById("findings-loading");
    if (loading) loading.classList.add("hidden");
  }
}



// ════════════════════════════════════════════════════════════════
// SMART FINDINGS — Gemma-powered verdict block + Next Actions table
// Calls /api/smart-findings asynchronously (never blocks the UI thread).
// ════════════════════════════════════════════════════════════════
async function triggerSmartFindings(payload) {
  // Reuse the same payload as /api/generate-findings — the endpoint runs
  // the rule engine first, then dedupes, structures, and asks Gemma for
  // a 15-word verdict (with a hard 12s timeout).
  let data;
  try {
    const res = await fetch("/api/smart-findings", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(await res.text());
    data = await res.json();
  } catch (err) {
    console.warn("smart-findings failed:", err);
    return;
  }
  window.appData.smartFindings = data;
  renderSmartVerdict(data.verdict || null);
  renderSmartNextActions(data.next_actions || []);
  renderSmartOpenGaps(data.open_gaps || []);
}

// ════════════════════════════════════════════════════════════════
// POST-LOAD DATA REVIEW (OpenAI gpt-oss-120b reasoning model)
// Cross-checks every dashboard number for internal contradictions and
// suggests corrections. Runs in parallel with the rule engine — UI never
// waits for it.
// ════════════════════════════════════════════════════════════════
async function triggerReviewData() {
  // Panel removed — bail early so we don't waste an API call.
  if (!document.getElementById("review-data-panel")) return;

  const ad = window.appData || {};
  const body = {
    batch:         ad.batch       || null,
    resource:      ad.resource    || (ad.upload ? { kpis: ad.upload?.kpis, servers: ad.servers } : null),
    sla_matrix:    ad.slaMatrix   || ad.sla_matrix || null,
    findings:      ad.findings    || null,
    customer_name: ad.customerName || null,
  };

  let result;
  try {
    const res = await fetch("/api/review-data", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(body),
    });
    if (!res.ok) throw new Error(await res.text());
    result = await res.json();
  } catch (err) {
    console.warn("review-data failed:", err);
    return;
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.2" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 0 1-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 0 1 4.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0 1 12 15a9.065 9.065 0 0 0-6.23-.693L5 14.5m14.8.8 1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0 1 12 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5"/></svg> Review with gpt-oss`;
    }
  }
  window.appData.dataReview = result;
  renderDataReview(result);
}

function renderDataReview(r) {
  const panel = document.getElementById("review-data-panel");
  if (!panel || !r) return;
  panel.classList.remove("hidden");

  const verdict = r.verdict || "CLEAN";
  const verdictEl = document.getElementById("review-data-verdict");
  if (verdictEl) {
    const isClean = verdict === "CLEAN";
    const c = isClean ? THEME.green : THEME.red;
    verdictEl.textContent = verdict;
    verdictEl.style.color = c;
    verdictEl.style.borderColor = hexA(c, 0.5);
    verdictEl.style.background = hexA(c, 0.12);
  }

  setText("review-data-confidence", `confidence ${r.confidence ?? 0}%`);
  setText("review-data-engine",     r.engine || "");
  setText("review-data-summary",    r.summary || "—");

  const cWrap = document.getElementById("review-data-contradictions");
  const cList = document.getElementById("review-data-contradictions-list");
  const contradictions = r.internal_contradictions || [];
  if (cWrap && cList) {
    if (contradictions.length) {
      cWrap.classList.remove("hidden");
      cList.innerHTML = contradictions.map((s) =>
        `<li>${escapeHtml(String(s))}</li>`).join("");
    } else cWrap.classList.add("hidden");
  }

  const aWrap = document.getElementById("review-data-anomalies");
  const aList = document.getElementById("review-data-anomalies-list");
  const anomalies = r.anomalies || [];
  if (aWrap && aList) {
    if (anomalies.length) {
      aWrap.classList.remove("hidden");
      aList.innerHTML = anomalies.map((s) =>
        `<li>${escapeHtml(String(s))}</li>`).join("");
    } else aWrap.classList.add("hidden");
  }

  const corrWrap  = document.getElementById("review-data-corrections");
  const corrTbody = document.getElementById("review-data-corrections-tbody");
  const corrections = r.corrections || [];
  if (corrWrap && corrTbody) {
    if (corrections.length) {
      corrWrap.classList.remove("hidden");
      const sevColor = (s) => ({
        high: THEME.red, med: THEME.amber, low: THEME.blue,
      }[String(s || "").toLowerCase()] || THEME.muted);
      corrTbody.innerHTML = corrections.map((c) => {
        const sc = sevColor(c.severity);
        return `<tr class="hover:bg-Ccard/40">
          <td class="py-1 pr-2 font-mono text-Cwhite text-[10px]">${escapeHtml(String(c.field || "—"))}</td>
          <td class="py-1 pr-2 text-right text-Cmuted font-mono">${escapeHtml(String(c.current ?? "—"))}</td>
          <td class="py-1 pr-2 text-right text-Cgreen font-mono">${escapeHtml(String(c.suggested ?? "—"))}</td>
          <td class="py-1 pr-2 text-Cmuted">${escapeHtml(String(c.reason || "").slice(0, 200))}</td>
          <td class="py-1">
            <span class="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded"
                  style="color:${sc};background:${hexA(sc, 0.15)}">
              ${escapeHtml(String(c.severity || "—"))}
            </span>
          </td>
        </tr>`;
      }).join("");
    } else corrWrap.classList.add("hidden");
  }
}

function renderSmartVerdict(v) {
  // Smart verdict now merged into findings verdict hero — no separate panel
}

function renderSmartNextActions(actions) {
  // Next actions now rendered by smart findings panel (if present)
}

function renderSmartOpenGaps(gaps) {
  // Open gaps now rendered by smart findings panel (if present)
}

// ── Findings audit coverage strip ─────────────────────────────
function renderFindingsAuditCoverage(ac) {
  const wrap = document.getElementById("findings-audit-coverage");
  if (!wrap) return;
  if (!ac) { wrap.classList.add("hidden"); return; }

  wrap.classList.remove("hidden");

  const setBadge = (id, label, status) => {
    const el = document.getElementById(id);
    if (!el) return;
    const c = status === "loaded" || status === "customer" ? THEME.green
            : status === "partial" || status === "default" ? THEME.amber
            : THEME.muted;
    el.textContent = `${label}: ${(status || "missing").toUpperCase()}`;
    el.style.color = c;
    el.style.borderColor = hexA(c, 0.4);
    el.style.background = hexA(c, 0.1);
  };

  setBadge("fac-evidence", "Evidence", ac.evidence_30day || "missing");
  setBadge("fac-sla", "SLA Source", ac.sla_source || "missing");
  setBadge("fac-confidence", `Confidence ${ac.confidence || 0}%`,
    (ac.confidence || 0) >= 80 ? "loaded" : (ac.confidence || 0) >= 60 ? "partial" : "missing");
}

// ── Findings severity donut chart ─────────────────────────────
let _findingsDonutChart = null;
function renderFindingsDonut(summary) {
  // Donut removed — severity counts are now in the verdict hero
}

// ── Render findings verdict hero + table ──────────────────────
function renderFindings(findings) {
  window._lastFindings = findings;
  try {
    if (document.getElementById("exec-evidence-ribbon")) {
      _renderExecEvidenceRibbon(findings || []);
    }
  } catch (_) {}

  const tbody   = document.getElementById("findings-tbody");
  const emptyEl = document.getElementById("findings-empty");
  const loading = document.getElementById("findings-loading");
  if (loading) loading.classList.add("hidden");
  if (!tbody) return;

  // Filter out narrative/gaps meta-findings — they go into the hero
  const narrativeFinding = findings.find(f => f.text === "Audit Narrative" && f.icon === "📝");
  const gapsFinding      = findings.find(f => (f.text || "").startsWith("Open Audit Gaps"));
  const realFindings     = findings.filter(f => f !== narrativeFinding && f !== gapsFinding);
  window._lastRealFindings = realFindings;

  if (!realFindings.length) {
    if (emptyEl) emptyEl.classList.remove("hidden");
    tbody.innerHTML = "";
    return;
  }
  if (emptyEl) emptyEl.classList.add("hidden");

  // ── Verdict hero ────────────────────────────────────────────
  const critFindings = realFindings.filter(f => f.level === "critical");
  const warnFindings = realFindings.filter(f => f.level === "warning");
  const critCount = critFindings.length;
  const warnCount = warnFindings.length;
  const okCount   = realFindings.filter(f => f.level === "ok").length;
  const infoCount = realFindings.filter(f => f.level === "info").length;

  // Decision logic: only MEASURED criticals are hard blockers.
  // Inferred/unavailable criticals (e.g., Vision AI parsed resource data)
  // result in REMEDIATE (action required) rather than outright BLOCKED.
  const hardBlockers = critFindings.filter(f =>
    f.evidence_class === "measured" || f.evidence_class === "defaulted");
  const softCriticals = critFindings.filter(f =>
    f.evidence_class === "inferred" || f.evidence_class === "unavailable" || !f.evidence_class);

  let decision, glowColor;
  if (hardBlockers.length > 0) {
    decision = "BLOCKED"; glowColor = THEME.red;
  } else if (softCriticals.length > 0) {
    decision = "REMEDIATE"; glowColor = THEME.amber;
  } else if (warnCount > 0) {
    decision = "CONDITIONAL"; glowColor = THEME.amber;
  } else {
    decision = "APPROVED"; glowColor = THEME.green;
  }

  // Grade — weighted: hard-blocker criticals count double
  const total = realFindings.length;
  const grade = hardBlockers.length >= 3 ? "F"
    : hardBlockers.length >= 1 ? "D"
    : (softCriticals.length + warnCount) >= 4 ? "C"
    : (softCriticals.length + warnCount) >= 1 ? "B"
    : "A";
  const gradeColors = { F: THEME.red, D: THEME.red, C: THEME.amber, B: THEME.amber, A: THEME.green };
  const gc = gradeColors[grade] || THEME.muted;

  // Animate verdict hero
  const pill = document.getElementById("findings-decision-pill");
  if (pill) {
    pill.textContent = decision;
    pill.style.cssText = `color:${glowColor};border-color:${glowColor};background:${hexA(glowColor,.15)};text-shadow:0 0 20px ${hexA(glowColor,.4)}`;
  }
  const gradePill = document.getElementById("findings-grade-pill");
  if (gradePill) {
    gradePill.textContent = `Grade ${grade}`;
    gradePill.style.cssText = `color:${gc};border-color:${hexA(gc,.5)};background:${hexA(gc,.12)}`;
  }

  // Customer tag
  const custTag = document.getElementById("findings-customer-tag");
  if (custTag) custTag.textContent = window.appData.customerName ? `Customer: ${window.appData.customerName}` : "";

  // Severity counts in hero
  setText("hero-crit", critCount);
  setText("hero-warn", warnCount);
  setText("hero-ok", okCount);
  setText("hero-info", infoCount);

  // Ambient glow
  const glow = document.getElementById("findings-glow");
  if (glow) {
    glow.style.setProperty("--glow-color", hexA(glowColor, .15));
    glow.style.opacity = "1";
  }

  // Verdict border glow
  const hero = document.getElementById("findings-verdict-hero");
  if (hero) hero.style.borderColor = hexA(glowColor, .5);

  // Narrative text
  const verdictText = document.getElementById("findings-verdict-text");
  if (verdictText && narrativeFinding && narrativeFinding.sub) {
    const raw = narrativeFinding.sub;
    const lines = raw.split("\n").map(l => l.trim()).filter(Boolean);
    // Strip labels (Scope:, Impact:, etc.) and join as flowing prose
    const labelPattern = /^(Scope|Compliance|Root causes? identified|Impact|Evidence|Decision|Primary blocker):\s*/i;
    const cleanLines = lines.map(l => l.replace(labelPattern, ""));
    verdictText.textContent = cleanLines.join(" ");
  }

  // Evidence confidence bar
  const measured = realFindings.filter(f => f.evidence_class === "measured").length;
  const confPct = total > 0 ? Math.round((measured / total) * 100) : 0;
  const confBar = document.getElementById("findings-confidence-bar");
  const confLabel = document.getElementById("findings-confidence-pct");
  if (confBar) confBar.style.width = confPct + "%";
  if (confLabel) confLabel.textContent = confPct + "%";

  // Count badge
  const countBadge = document.getElementById("findings-count-badge");
  if (countBadge) countBadge.textContent = realFindings.length;

  // ── Findings table ──────────────────────────────────────────
  if (!window._findingsSort)   window._findingsSort   = { col: "severity", dir: 1 };
  if (!window._findingsCols)   window._findingsCols   = {};
  if (!window._findingsFilter) window._findingsFilter = "critical"; // default: show only critical
  _renderFindingsColPicker();
  _updateFindingsFilterCounts();
  _applyFindingsSort();
}

// ── Findings: column defs + sort / column-picker helpers ─────
const _FCOL_DEFS = [
  { id: "severity",   label: "Severity",       w: "w-24" },
  { id: "root_cause", label: "Root Cause",      w: "w-36" },
  { id: "impact",     label: "Impact",          w: "w-44" },
  { id: "action",     label: "Action Required", w: "w-44" },
  { id: "evidence",   label: "Evidence",        w: "w-20", center: true },
];

function _filterFindings(fid) {
  window._findingsFilter = fid;
  _updateFindingsFilterCounts();
  _applyFindingsSort();
}

function _updateFindingsFilterCounts() {
  const all = window._lastRealFindings || [];
  const crit = all.filter(f => f.level === "critical").length;
  const lp   = all.filter(f => f.level === "critical" || f.level === "warning").length;
  const ok   = all.filter(f => f.level === "ok" || f.level === "info").length;

  const setN = (id, n) => { const el = document.getElementById(id); if (el) el.textContent = n ? `(${n})` : ""; };
  setN("ffil-all-n",     all.length);
  setN("ffil-crit-n",    crit);
  setN("ffil-lp-n",      lp);
  setN("ffil-improved-n",ok);

  // Active state on filter pills
  const cur = window._findingsFilter || "critical";
  document.querySelectorAll(".findings-filter-btn").forEach(b => {
    const fid = b.getAttribute("onclick")?.match(/'([^']+)'/)?.[1];
    b.classList.toggle("active-filter", fid === cur);
    b.setAttribute("data-fid", fid || "");
  });

  // Ambient card glow + alert bar
  const card  = document.getElementById("findings-table-card");
  const bar   = document.getElementById("findings-alert-bar");
  const msg   = document.getElementById("findings-alert-msg");
  const showCrit = (cur === "critical" || cur === "lp") && crit > 0;
  if (card) card.classList.toggle("findings-card-alert", showCrit);
  if (bar)  bar.classList.toggle("hidden", !showCrit);
  if (msg && showCrit) {
    msg.textContent = `${crit} critical finding${crit !== 1 ? "s" : ""} require immediate attention before PE sign-off`;
  }
}

function _updateFindingsSortBtns() {
  const col = (window._findingsSort || {}).col || "severity";
  document.querySelectorAll(".findings-sort-btn").forEach(b => {
    const sc = b.getAttribute("onclick")?.match(/'([^']+)'/)?.[1];
    b.classList.toggle("active-sort", sc === col);
  });
}

function _sortFindings(colId) {
  if (!window._findingsSort) window._findingsSort = { col: "severity", dir: 1 };
  if (window._findingsSort.col === colId) {
    window._findingsSort.dir *= -1;
  } else {
    window._findingsSort = { col: colId, dir: 1 };
  }
  _updateFindingsSortBtns();
  _applyFindingsSort();
}

function _toggleFindingsCol(colId) {
  if (!window._findingsCols) window._findingsCols = {};
  window._findingsCols[colId] = window._findingsCols[colId] === false ? true : false;
  _renderFindingsColPicker();
  _applyFindingsSort();
}

function _renderFindingsColPicker() {
  const picker = document.getElementById("findings-col-picker");
  if (!picker) return;
  if (!window._findingsCols) window._findingsCols = {};
  picker.innerHTML =
    `<div class="px-3 py-1 mb-1 text-[8px] uppercase tracking-widest text-Cmuted/70 font-bold border-b border-Cborder/30">Toggle Columns</div>` +
    _FCOL_DEFS.map(c => {
      const on = window._findingsCols[c.id] !== false;
      return `<label class="flex items-center gap-2.5 px-3 py-1.5 cursor-pointer hover:bg-white/5 rounded-lg select-none">
        <span class="relative inline-flex w-7 h-4 shrink-0">
          <input type="checkbox" ${on ? "checked" : ""} onchange="_toggleFindingsCol('${c.id}')" class="sr-only peer">
          <span class="absolute inset-0 rounded-full transition-colors peer-checked:bg-Cpurple/70 bg-white/10 border border-white/20 pointer-events-none"></span>
          <span class="absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white shadow transition-transform peer-checked:translate-x-3 pointer-events-none"></span>
        </span>
        <span class="text-[11px] text-Cwhite/80">${c.label}</span>
      </label>`;
    }).join("");

  // Close picker when clicking outside (attach once)
  if (!window._findingsPickerListenerAdded) {
    window._findingsPickerListenerAdded = true;
    document.addEventListener("click", (e) => {
      const p = document.getElementById("findings-col-picker");
      const t = document.getElementById("findings-col-toggle");
      if (p && t && !p.contains(e.target) && !t.contains(e.target)) {
        p.classList.add("hidden");
      }
    });
  }
}

function _applyFindingsSort() {
  const allFindings = window._lastRealFindings;
  if (!allFindings || !allFindings.length) return;
  if (!window._findingsSort)   window._findingsSort   = { col: "severity", dir: 1 };
  if (!window._findingsCols)   window._findingsCols   = {};
  if (!window._findingsFilter) window._findingsFilter = "critical";
  const { col, dir } = window._findingsSort;
  const vis = window._findingsCols;
  const flt = window._findingsFilter;

  // Apply filter
  let findings;
  switch (flt) {
    case "critical":  findings = allFindings.filter(f => f.level === "critical"); break;
    case "lp":        findings = allFindings.filter(f => f.level === "critical" || f.level === "warning"); break;
    case "improved":  findings = allFindings.filter(f => f.level === "ok" || f.level === "info"); break;
    default:          findings = allFindings; // "all"
  }

  // Update sort button states
  _updateFindingsSortBtns();

  const SEV = { critical: 0, warning: 1, info: 2, ok: 3 };
  const EC  = { measured: 0, inferred: 1, defaulted: 2, waived: 3, unavailable: 4 };
  const SRC = { batch: 0, sla: 1, resource: 2, benchmark: 3, sow: 4, issues: 5 };

  const sorted = [...findings].sort((a, b) => {
    let d = 0;
    switch (col) {
      case "severity":
        d = (SEV[a.level] ?? 9) - (SEV[b.level] ?? 9);
        if (!d) d = (EC[a.evidence_class] ?? 9) - (EC[b.evidence_class] ?? 9);
        if (!d) d = (SRC[a.source] ?? 9) - (SRC[b.source] ?? 9);
        break;
      case "root_cause":
        d = (a.root_cause || "zzz").replace(/_/g, " ").localeCompare((b.root_cause || "zzz").replace(/_/g, " "));
        break;
      case "impact":     d = (a.impact || "").localeCompare(b.impact || ""); break;
      case "action":     d = (a.recommendation || "").localeCompare(b.recommendation || ""); break;
      case "evidence":   d = (EC[a.evidence_class] ?? 9) - (EC[b.evidence_class] ?? 9); break;
      case "finding":    d = (a.text || "").localeCompare(b.text || ""); break;
      default:           d = (SEV[a.level] ?? 9) - (SEV[b.level] ?? 9);
    }
    return d * dir;
  });

  // ── thead ────────────────────────────────────────────────────
  const thead = document.getElementById("findings-thead");
  if (thead) {
    const si = (id) => col === id
      ? `<span class="ml-0.5 text-[8px]" style="color:${THEME.purple}">${dir === 1 ? "▲" : "▼"}</span>`
      : `<span class="ml-0.5 text-[8px] opacity-25">⇅</span>`;
    const th = `cursor-pointer select-none hover:text-Cwhite/80 transition-colors font-semibold px-3 py-2.5`;
    const visCols = _FCOL_DEFS.filter(c => vis[c.id] !== false);
    thead.innerHTML = `<tr class="border-b border-Cborder/60 text-[10px] uppercase tracking-wider text-Cmuted bg-Ccard2/20">
      <th class="pl-4 pr-2 py-2.5 w-8"></th>
      <th class="${th} min-w-[220px]" onclick="_sortFindings('finding')">Finding ${si("finding")}</th>
      ${visCols.map(c => `<th class="${th} ${c.w || ""} ${c.center ? "text-center" : ""}" onclick="_sortFindings('${c.id}')">${c.label} ${si(c.id)}</th>`).join("")}
      <th class="px-3 py-2.5 w-8"></th>
    </tr>`;
  }

  // ── tbody ────────────────────────────────────────────────────
  const tbody = document.getElementById("findings-tbody");
  if (!tbody) return;
  const visSet  = new Set(_FCOL_DEFS.filter(c => vis[c.id] !== false).map(c => c.id));
  const colspan = 3 + visSet.size;

  // Empty filter state
  if (!sorted.length) {
    const emptyMsgs = {
      critical: { icon: "✅", title: "No Critical Findings", sub: "All critical issues resolved — good to proceed." },
      lp:       { icon: "✅", title: "No Critical / Warning Findings", sub: "No LP blockers found." },
      improved: { icon: "ℹ", title: "No OK / Info Findings", sub: "No informational findings in this dataset." },
      all:      { icon: "📭", title: "No Findings", sub: "No audit findings generated yet." },
    };
    const em = emptyMsgs[flt] || emptyMsgs.all;
    tbody.innerHTML = `<tr><td colspan="${colspan}" class="py-10 text-center">
      <div class="text-2xl mb-2">${em.icon}</div>
      <div class="text-sm font-semibold text-Cwhite">${em.title}</div>
      <div class="text-[11px] text-Cmuted mt-1">${em.sub}</div>
    </td></tr>`;
    return;
  }

  const SV_ST = {
    critical: { dot: THEME.red,   bg: "bg-Cred/10",   bd: "border-Cred/40",   tx: "text-Cred"   },
    warning:  { dot: THEME.amber, bg: "bg-Camber/10", bd: "border-Camber/40", tx: "text-Camber" },
    info:     { dot: THEME.blue,  bg: "bg-Cblue/10",  bd: "border-Cblue/40",  tx: "text-Cblue"  },
    ok:       { dot: THEME.green, bg: "bg-Cgreen/10", bd: "border-Cgreen/40", tx: "text-Cgreen" },
  };
  const EC_CLR  = { measured: THEME.green, inferred: THEME.cyan, defaulted: THEME.amber, waived: THEME.purple, unavailable: THEME.muted };
  const EC_LBL  = { measured: "MEASURED", inferred: "INFERRED", defaulted: "ASSUMED",   waived: "WAIVED",     unavailable: "N/A" };
  const SRC_LBL = { batch: "BATCH", sla: "SLA", resource: "INFRA", benchmark: "BENCH", sow: "SOW", issues: "ISSUES" };
  const SRC_CLR = { batch: THEME.blue, sla: THEME.amber, resource: THEME.purple, benchmark: THEME.cyan, sow: THEME.muted, issues: THEME.red };
  const SEV_BDR = { critical: THEME.red, warning: THEME.amber, info: THEME.blue, ok: THEME.green };

  const _col = (v, max = 45) => {
    const s = (v || "—").trim();
    return s.length > max
      ? `<span title="${_esc(s)}" class="cursor-help">${_esc(s.slice(0, max))}…</span>`
      : `<span title="${_esc(s)}">${_esc(s)}</span>`;
  };

  tbody.innerHTML = sorted.map((f, idx) => {
    const sv      = SV_ST[f.level] || SV_ST.info;
    const rc      = (f.root_cause || "").replace(/_/g, " ").trim() || "—";
    const impact  = (f.impact || "").trim() || "—";
    const action  = (f.recommendation || "").trim() || "—";
    const ecColor = EC_CLR[f.evidence_class] || THEME.muted;
    const ecLbl   = EC_LBL[f.evidence_class] || "—";
    const srcLbl  = SRC_LBL[f.source] || (f.source || "").toUpperCase() || "—";
    const srcClr  = SRC_CLR[f.source] || THEME.muted;
    const detId   = `finding-det-${idx}`;
    const bdrClr  = SEV_BDR[f.level] || THEME.muted;
    const bdrAlpha = f.level === "critical" ? 0.7 : f.level === "warning" ? 0.45 : 0.2;
    // Root cause cell color: amber for critical, amber/70 for warning, default for others
    const rcColor = f.level === "critical" ? THEME.amber
                  : f.level === "warning"  ? hexA(THEME.amber, .8)
                  : "rgba(240,244,255,.75)";
    // Only show ec badge in finding cell when Evidence column is hidden
    const showEcBadge = !visSet.has("evidence");
    const isCrit = f.level === "critical";

    return `<tr data-idx="${idx}"
  class="hover:bg-white/[0.04] transition-colors cursor-pointer border-b border-white/5 group${isCrit ? " findings-crit-row" : ""}"
  style="border-left:3px solid ${hexA(bdrClr, bdrAlpha)};${isCrit ? `background:rgba(244,63,94,.025)` : ""}"
  onclick="const d=document.getElementById('${detId}');d.classList.toggle('hidden');this.querySelector('.fchev').textContent=d.classList.contains('hidden')?'▸':'▾'">
  <td class="pl-3 pr-2 py-2.5 w-8">
    <span class="inline-block w-2.5 h-2.5 rounded-full shrink-0${isCrit ? " findings-crit-blink" : ""}"
          style="background:${sv.dot};box-shadow:0 0 ${isCrit ? "12" : "8"}px ${hexA(sv.dot, isCrit ? .75 : .45)}"></span>
  </td>
  <td class="px-2 py-2.5" style="min-width:220px;max-width:340px">
    <div class="text-[11px] font-semibold text-Cwhite leading-snug">${_esc(f.text)}</div>
    ${f.sub ? `<div class="text-[9px] text-Cmuted mt-0.5 leading-relaxed line-clamp-2" title="${_esc(f.sub)}">${_esc(f.sub)}</div>` : ""}
    <div class="flex items-center gap-1.5 mt-1 flex-wrap">
      <span class="text-[8px] font-bold px-1.5 py-0.5 rounded"
            style="background:${hexA(srcClr,.15)};color:${srcClr};border:1px solid ${hexA(srcClr,.3)}">${srcLbl}</span>
      ${showEcBadge ? `<span class="text-[8px] px-1.5 py-0.5 rounded"
            style="background:${hexA(ecColor,.1)};color:${ecColor};border:1px solid ${hexA(ecColor,.25)}">${ecLbl}</span>` : ""}
    </div>
  </td>
  ${visSet.has("severity") ? `<td class="px-3 py-2.5 w-24">
    <span class="inline-flex items-center text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${sv.bg} ${sv.tx} ${sv.bd} border">${f.level}</span>
  </td>` : ""}
  ${visSet.has("root_cause") ? `<td class="px-3 py-2.5 text-[10px] font-medium w-36" style="color:${rcColor}">${_col(rc, 30)}</td>` : ""}
  ${visSet.has("impact")     ? `<td class="px-3 py-2.5 text-[10px] text-Cwhite/70 w-44">${_col(impact, 50)}</td>` : ""}
  ${visSet.has("action")     ? `<td class="px-3 py-2.5 text-[10px] text-Cwhite/70 w-44">${_col(action, 50)}</td>` : ""}
  ${visSet.has("evidence")   ? `<td class="px-3 py-2.5 w-20 text-center">
    <span class="inline-flex text-[8px] px-1.5 py-0.5 rounded"
          style="background:${hexA(ecColor,.1)};color:${ecColor};border:1px solid ${hexA(ecColor,.25)}"
          title="${_esc(f.evidence || ecLbl)}">${ecLbl}</span>
  </td>` : ""}
  <td class="px-2 py-2.5 w-8 text-center">
    <span class="fchev text-[11px] text-Cmuted/50 group-hover:text-Cmuted transition-colors">▸</span>
  </td>
</tr>
<tr id="${detId}" class="hidden border-b border-white/5"
    style="background:${hexA(bdrClr, .04)};border-left:3px solid ${hexA(bdrClr, bdrAlpha)}">
  <td colspan="${colspan}" class="pl-5 pr-4 py-3.5">
    <div class="grid grid-cols-3 gap-6 text-[10px]">
      <div>
        <div class="text-[8px] uppercase tracking-widest font-bold mb-1.5" style="color:${THEME.amber}">⚡ Root Cause</div>
        <div class="text-Cwhite/85 leading-relaxed">${_esc(rc)}</div>
      </div>
      <div>
        <div class="text-[8px] uppercase tracking-widest font-bold mb-1.5" style="color:${THEME.blue}">📋 Business Impact</div>
        <div class="text-Cwhite/85 leading-relaxed">${_esc(impact)}</div>
      </div>
      <div>
        <div class="text-[8px] uppercase tracking-widest font-bold mb-1.5" style="color:${THEME.green}">→ Recommended Action</div>
        <div class="text-Cwhite/85 leading-relaxed">${_esc(action)}</div>
        ${f.evidence ? `<div class="text-Cmuted mt-2 text-[8px] italic">${_esc(f.evidence)}</div>` : ""}
      </div>
    </div>
  </td>
</tr>`;
  }).join("");
}

// ── PE Review Narrative (structured 4-section report) ────────
async function triggerPeNarrative() {
  const card    = document.getElementById("pe-narrative-card");
  const loading = document.getElementById("pe-narr-loading");
  const btn     = document.getElementById("pe-narr-refresh-btn");
  if (!card) return;
  card.classList.remove("hidden");
  if (loading) loading.classList.remove("hidden");
  if (btn) btn.disabled = true;

  const ad = window.appData || {};
  const payload = {
    batch:         ad.batch        || null,
    resource:      ad.resource     || null,
    sla_matrix:    ad.slaMatrix    || null,
    sla_intel:     ad.slaIntel     || null,
    sow_compare:   ad.sowCompare   || null,
    benchmark:     ad.benchmark    || null,
    red_flags:     ad.redFlags     || null,
    findings:      ad.findings     || null,
    customer_name: ad.customerName || null,
  };

  try {
    const res = await fetch("/api/pe-narrative", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      toast("error", "PE Narrative error", (await res.text()).slice(0, 200));
      return;
    }
    const data = await res.json();
    window.appData.peNarrative = data;
    renderPeNarrative(data);
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
  } finally {
    if (loading) loading.classList.add("hidden");
    if (btn) btn.disabled = false;
  }
}

function renderPeNarrative(data) {
  if (!data) return;
  const card = document.getElementById("pe-narrative-card");
  if (!card) return;
  card.classList.remove("hidden");

  // Verdict pill
  const verdictColors = {
    APPROVED:    { bg: "bg-Cgreen/20",  fg: "text-Cgreen",  bd: "border-Cgreen/40"  },
    CONDITIONAL: { bg: "bg-Camber/20",  fg: "text-Camber",  bd: "border-Camber/40"  },
    BLOCKED:     { bg: "bg-Cred/20",    fg: "text-Cred",    bd: "border-Cred/40"    },
  };
  const v = (data.verdict || "CONDITIONAL").toUpperCase();
  const vc = verdictColors[v] || verdictColors.CONDITIONAL;
  const vEl = document.getElementById("pe-narr-verdict");
  if (vEl) {
    vEl.textContent = v;
    vEl.className = `text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${vc.bg} ${vc.fg} ${vc.bd}`;
  }

  // Model badge
  setText("pe-narr-model", (data.model || "deterministic").replace("models/", ""));

  // Summary paragraph
  setText("pe-narr-summary", data.summary || "—");

  // Sections + tables
  const wrap = document.getElementById("pe-narr-sections");
  if (!wrap) return;
  wrap.innerHTML = "";

  const sectionAccent = {
    data_volume:    THEME.cyan,
    batch_sla:      THEME.amber,
    infrastructure: THEME.purple,
    uat:            THEME.green,
  };

  (data.sections || []).forEach((sec, idx) => {
    const accent = sectionAccent[sec.id] || THEME.cyan;
    const block = document.createElement("div");
    block.className = "rounded-xl border border-Cborder/60 bg-Ccard/40 overflow-hidden";

    // Header
    const headHtml = `
      <div class="px-4 py-3 flex items-center gap-3 border-b border-Cborder/40"
           style="background:${hexA(accent, 0.06)}">
        <span class="text-xs font-mono px-2 py-0.5 rounded border"
              style="color:${accent};border-color:${hexA(accent,0.4)};background:${hexA(accent,0.1)}">${idx + 1}</span>
        <h3 class="text-sm font-bold text-Cwhite">${_esc(sec.title || "")}</h3>
      </div>`;

    const proseHtml = sec.prose
      ? `<p class="px-4 py-3 text-xs text-Cwhite/80 leading-relaxed border-b border-Cborder/30">${_esc(sec.prose)}</p>`
      : "";

    // Table
    const tbl = sec.table || {};
    const headers = tbl.headers || [];
    const rows    = tbl.rows    || [];
    const isAllNa = rows.length === 0
      || rows.every(r => (r || []).every(c => String(c).trim().toUpperCase() === "NA"
                                            || String(c).trim().toUpperCase().startsWith("NA")));
    const tableHtml = headers.length
      ? `<div class="overflow-x-auto">
           <table class="w-full text-left border-collapse text-xs">
             <thead>
               <tr style="background:${hexA(accent, 0.08)}">
                 ${headers.map(h => `<th class="px-3 py-2 font-semibold uppercase tracking-wider text-[10px]"
                                          style="color:${accent}">${_esc(String(h))}</th>`).join("")}
               </tr>
             </thead>
             <tbody>
               ${rows.map(r => `<tr class="border-t border-Cborder/30 ${isAllNa ? 'opacity-60' : ''}">
                 ${(r || []).map(c => `<td class="px-3 py-2 text-Cwhite/85">${_esc(String(c))}</td>`).join("")}
               </tr>`).join("")}
             </tbody>
           </table>
         </div>`
      : "";

    block.innerHTML = headHtml + proseHtml + tableHtml;
    wrap.appendChild(block);
  });
}

// ── Update summary badge counts ───────────────────────────────
function renderFindingsSummary(summary) {
  // Summary counts now rendered inline in the verdict hero by renderFindings
}

// ── Escape HTML to prevent XSS in dynamic content ─────────────
function _esc(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Safe number coerce — never returns null/undefined/NaN */
function _n(v, fallback) { const n = Number(v); return Number.isFinite(n) ? n : (fallback ?? 0); }

// ── Toggle API key visibility ──────────────────────────────────
function toggleAiKeyVisibility() {
  const inp = document.getElementById("ai-api-key");
  const eye = document.getElementById("ai-key-eye");
  if (!inp) return;
  if (inp.type === "password") {
    inp.type = "text";
    if (eye) eye.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88"/>`;
  } else {
    inp.type = "password";
    if (eye) eye.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.641 0-8.574-3.007-9.964-7.178Z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"/>`;
  }
}

// ── Copy AI result to clipboard ───────────────────────────────
async function copyAiResult() {
  const el = document.getElementById("ai-result-text");
  if (!el?.textContent) return;
  try {
    await navigator.clipboard.writeText(el.textContent);
    toast("success", "Copied", "AI analysis copied to clipboard.");
  } catch {
    toast("info", "Copy failed", "Select and copy the text manually.");
  }
}

// ── Trigger Gemini AI Insight ─────────────────────────────────
async function triggerAiInsight() {
  // Panel removed — bail early.
  if (!document.getElementById("ai-result-area")) return;
  // Key is stored in Settings — read from config cache (no visible input field)
  const apiKey    = window.appData.config?.gemini_api_key
                 || window.appData.geminiKey
                 || "";
  const typeEl    = document.getElementById("ai-type");
  const analysisType = typeEl?.value || "full";

  // UI refs
  const genBtn    = document.getElementById("ai-generate-btn");
  const loadingEl = document.getElementById("ai-loading");
  const resultArea= document.getElementById("ai-result-area");
  const resultEl  = document.getElementById("ai-result-text");
  const errorEl   = document.getElementById("ai-error");
  const badgeEl   = document.getElementById("ai-model-badge");

  // Reset state
  if (errorEl)   { errorEl.classList.add("hidden");    errorEl.textContent = ""; }
  if (resultArea){ resultArea.classList.add("hidden"); }
  if (loadingEl) { loadingEl.classList.remove("hidden"); }
  if (genBtn)    { genBtn.disabled = true; }

  // Build KPI context — handle both nested (.kpis) and flat shapes
  const bk = window.appData.batch?.kpis    || window.appData.batch    || {};
  const rk = window.appData.resource?.kpis || window.appData.resource || {};
  const topJobs = window.appData.batch?.top_jobs
               || window.appData.batch?.jobs
               || [];

  const payload = {
    type:          analysisType,
    api_key:       apiKey,
    batch_kpis:    Object.keys(bk).length ? bk : null,
    resource_kpis: Object.keys(rk).length ? rk : null,
    servers:       window.appData.servers || [],
    issues:        window.appData.issues  || [],
    top_jobs:      Array.isArray(topJobs) ? topJobs.slice(0, 30) : [],
  };

  try {
    const res = await fetch("/api/ai-insight", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(payload),
    });

    const data = await res.json();

    if (!res.ok) {
      const detail = data?.detail || JSON.stringify(data);
      if (errorEl) {
        errorEl.textContent = detail;
        errorEl.classList.remove("hidden");
      } else {
        toast("error", "AI error", detail.slice(0, 200));
      }
      return;
    }

    // Display result
    if (resultEl)  resultEl.textContent = data.text || "(empty response)";
    if (resultArea) resultArea.classList.remove("hidden");

    // Show model badge
    if (badgeEl && data.model) {
      badgeEl.textContent = data.model.replace("models/", "");
      badgeEl.classList.remove("hidden");
    }

    toast("success", "AI Insight ready", `Generated with ${data.model || "Gemini"}.`, 4000);

  } catch (err) {
    const msg = String(err?.message || err);
    if (errorEl) {
      errorEl.textContent = `Network error: ${msg}`;
      errorEl.classList.remove("hidden");
    } else {
      toast("error", "Network error", msg);
    }
  } finally {
    if (loadingEl) loadingEl.classList.add("hidden");
    if (genBtn) {
      genBtn.disabled = false;
      genBtn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-4 h-4 text-Cpurple"><path stroke-linecap="round" stroke-linejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09Z"/></svg> Generate AI Insight`;
    }
  }
}


// ════════════════════════════════════════════════════════════
//  PHASE 7 — Overview, Correlation, Red Flags, Data Status
// ════════════════════════════════════════════════════════════

// ── Sidebar data-status dots (Grafana-style color-coded) ─────
function refreshDataStatus() {
  // Clear all classes then set the right status-dot class
  const setDot = (id, active, label = "") => {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove("status-dot-green", "status-dot-amber", "status-dot-red",
                        "status-dot-blue",  "status-dot-muted", "animate-pulse");
    if (active) {
      el.classList.add("status-dot-green", "animate-pulse");
    } else {
      el.classList.add("status-dot-muted");
    }
    // Update companion label if it exists
    const labelEl = document.getElementById(id + "-label");
    if (labelEl) labelEl.textContent = label;
  };

  const hasResource  = !!(window.appData.servers?.length || window.appData.resource);
  const hasBatch     = !!(window.appData.batch);
  const hasIssues    = !!(window.appData.issues?.length);
  const hasBenchmark = !!(window.appData.benchmark);
  const hasGemini    = !!(window.appData.geminiKey || window.appData.config?.gemini_api_key);

  const resourceCount = window.appData.servers?.length || 0;
  const batchJobs     = window.appData.batch?.kpis?.total_jobs || 0;

  setDot("ds-resource",  hasResource,  resourceCount ? `${resourceCount} srv` : "");
  setDot("ds-batch",     hasBatch,     batchJobs ? `${batchJobs} jobs` : "");
  setDot("ds-issues",    hasIssues);
  setDot("ds-benchmark", hasBenchmark);
  setDot("ds-gemini",    hasGemini);

  // Show/hide vision-status chip in header
  const visionChip = document.getElementById("vision-status-chip");
  if (visionChip) {
    if (hasGemini) visionChip.classList.remove("hidden"), visionChip.classList.add("flex");
    else visionChip.classList.add("hidden"), visionChip.classList.remove("flex");
  }
}

// ── Shared chart palette ──────────────────────────────────────
const OV_CHARTS = { window: null, subapp: null, corDonut: null };

// ════════════════════════════════════════════════════════════════
//  EXECUTIVE DASHBOARD — Plotly Correlation Charts + KPI Strip
// ════════════════════════════════════════════════════════════════
const _EXEC_LAYOUT_BASE = {
  paper_bgcolor: "rgba(0,0,0,0)",
  plot_bgcolor:  "rgba(13,21,38,0.6)",
  font:          { family: "Sora, sans-serif", color: "#6b7db3", size: 11 },
  margin:        { l: 50, r: 20, t: 30, b: 40 },
  xaxis:         { gridcolor: "rgba(33,48,96,0.5)", zerolinecolor: "rgba(33,48,96,0.5)" },
  yaxis:         { gridcolor: "rgba(33,48,96,0.5)", zerolinecolor: "rgba(33,48,96,0.5)" },
};
const _EXEC_CFG = { responsive: true, displayModeBar: false };

function _execColor(val) {
  if (val >= 90) return "#f43f5e";
  if (val >= 75) return "#f59e0b";
  if (val >= 50) return "#3b82f6";
  return "#10d96e";
}

async function renderOverview() {
  const hasData = !!(window.appData.batch || window.appData.resource || window.appData.servers?.length);
  const noData  = document.getElementById("exec-no-data");
  const content = document.getElementById("exec-content");
  const loading = document.getElementById("exec-loading");
  if (!hasData) {
    if (noData)  noData.classList.remove("hidden");
    if (content) content.classList.add("hidden");
    if (loading) loading.classList.add("hidden");
    return;
  }
  // Show loading spinner, hide content until API returns
  if (loading) loading.classList.remove("hidden");
  if (noData)  noData.classList.add("hidden");
  if (content) content.classList.add("hidden");

  // Gather payload
  const bk = window.appData.batch?.kpis || window.appData.batch || {};
  const rk = window.appData.resource?.kpis || window.appData.resource || {};
  const payload = {
    batch_kpis:    bk,
    top_jobs:      window.appData.batch?.top_jobs     || [],
    top_breaches:  window.appData.batch?.top_breaches || [],
    resource_kpis: rk,
    servers:       window.appData.servers || [],
    sla_data:      window.appData.slaMatrix || {},
    sub_stats:     window.appData.batch?.sub_stats    || [],
    window:        window.appData.batch?.window       || [],
    hourly_counts: window.appData.batch?.hourly_counts || {},
    benchmark:     window.appData.benchmark || null,
    sow_compare:   window.appData.sowCompare || null,
    findings:      window._lastFindings || [],
    daily_jobs:    window.appData.batch?.daily_jobs   || {},
    customer_name: window.appData.customerName || null,
  };

  // ── Fast-path: if cached exec data exists and source data unchanged, reuse
  const payloadHash = JSON.stringify(payload).length; // cheap proxy
  if (window._execCache && window._execCacheHash === payloadHash) {
    if (loading) loading.classList.add("hidden");
    if (content) content.classList.remove("hidden");
    const data = window._execCache;
    _renderExecDecisionStrip(data);
    _renderExecKPIs(data.kpis);
    _renderExecNarrative(data.narrative);
    _renderExecBenchmarkSummary(window.appData.benchmark);
    _renderExecHotSpots(data);
    _renderExecSubAppTable(data.sub_app_summary);
    _renderExecSowPanel(data.sow_panel);
    requestAnimationFrame(() => {
      _renderExecSLABars(data.job_sla_bars);
      _renderExecHeatmap(data.server_heatmap);
      _renderExecTemporal(data.temporal, data.kpis);
      _renderExecBreachCalendar(data.breach_calendar);
      _renderExecConcurrency(data.concurrency);
      _renderExecForecast(window.appData?.batch?.window || [], data.kpis?.sla_daily_hrs || 6);
      _renderSignoffChecklistV2(data.decision);
    });
    return;
  }

  try {
    // Fire findings + exec-dashboard in parallel — don't block exec on findings
    const findingsReady = (!window._lastFindings || !window._lastFindings.length)
      ? triggerGenerateFindings().catch(() => {})
      : Promise.resolve();

    const res = await fetch("/api/executive-dashboard", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) { toast("error", "Executive dashboard error", (await res.text()).slice(0, 200)); return; }
    const data = await res.json();

    // Cache for fast tab re-entry
    window._execCache = data;
    window._execCacheHash = payloadHash;

    // Data arrived — swap spinner for content
    if (loading) loading.classList.add("hidden");
    if (content) content.classList.remove("hidden");

    // ── Phase 1: instant — lightweight DOM writes (KPIs, strips, narrative)
    _renderExecDecisionStrip(data);
    _renderExecKPIs(data.kpis);
    _renderExecNarrative(data.narrative);
    _renderExecBenchmarkSummary(window.appData.benchmark);
    _renderExecHotSpots(data);
    _renderExecSubAppTable(data.sub_app_summary);
    _renderExecSowPanel(data.sow_panel);

    // ── Phase 2: deferred — heavy Plotly charts staggered across frames
    const deferredCharts = [
      () => _renderExecSLABars(data.job_sla_bars),
      () => _renderExecHeatmap(data.server_heatmap),
      () => _renderExecTemporal(data.temporal, data.kpis),
      () => _renderExecBreachCalendar(data.breach_calendar),
      () => _renderExecConcurrency(data.concurrency),
      () => _renderExecForecast(
             window.appData?.batch?.window || [],
             data.kpis?.sla_daily_hrs || 6),
      () => _renderSignoffChecklistV2(data.decision),
    ];
    // Render one chart per animation frame so KPIs paint immediately
    let ci = 0;
    function _nextChart() {
      if (ci < deferredCharts.length) {
        deferredCharts[ci++]();
        requestAnimationFrame(_nextChart);
      }
    }
    requestAnimationFrame(_nextChart);

    // Auto-trigger Final Judgment in the background (no manual button)
    if (typeof runFinalJudgment === "function") {
      runFinalJudgment().catch(() => {});
    }
  } catch (err) {
    if (loading) loading.classList.add("hidden");
    if (content) content.classList.remove("hidden");
    toast("error", "Network error", String(err?.message || err));
  }
}

// ── KPI Strip ────────────────────────────────────────────────
function _renderExecKPIs(kpis) {
  if (!kpis) return;

  const colorFor = (v, good, warn) =>
    v >= good ? "#10d96e" : (v >= warn ? "#f59e0b" : "#f43f5e");

  // Helper: animate a ring (circumference 2πr ≈ 201 for r=32)
  const setRing = (ringId, pct, color) => {
    const ring = document.getElementById(ringId);
    if (!ring) return;
    const C = 2 * Math.PI * 32;
    const p = Math.max(0, Math.min(100, pct));
    ring.setAttribute("stroke-dasharray", C.toFixed(1));
    ring.setAttribute("stroke-dashoffset", (C * (1 - p / 100)).toFixed(1));
    ring.setAttribute("stroke", color);
  };

  // ── OSHS ring ──
  const oshs = _n(kpis.oshs_score);
  const oshsCol = colorFor(oshs, 75, 60);
  const oshsEl = document.getElementById("exec-oshs");
  if (oshsEl) { oshsEl.textContent = oshs.toFixed(1); oshsEl.style.color = oshsCol; }
  setRing("exec-oshs-ring", oshs, oshsCol);
  const gradeEl = document.getElementById("exec-oshs-grade");
  if (gradeEl) {
    gradeEl.textContent = `Grade ${kpis.oshs_grade}`;
    gradeEl.style.color = oshsCol;
  }
  setText("exec-oshs-delta", kpis.oshs_label || "—");

  // ── Job SLA Rate ring + sparkline ──
  const br = _n(kpis.batch_rate);
  const brCol = colorFor(br, 95, 80);
  const brEl = document.getElementById("exec-batch-rate");
  if (brEl) { brEl.textContent = _fmtPctCompact(br); brEl.style.color = brCol; }
  setRing("exec-batch-ring", br, brCol);
  setText("exec-batch-sub", `${kpis.total_jobs || 0} jobs`);
  _drawMiniSparkline("exec-batch-spark",
    (window.appData?.batch?.window || []).map(w =>
      Number(w.success_rate ?? w.sla_rate ?? w.compliance ?? br)
    ), brCol);

  // ── Window Rate ring + sparkline ──
  const wr = _n(kpis.window_compliance ?? kpis.batch_rate);
  const wrCol = colorFor(wr, 95, 80);
  const wrEl = document.getElementById("exec-window-rate");
  if (wrEl) { wrEl.textContent = _fmtPctCompact(wr); wrEl.style.color = wrCol; }
  setRing("exec-window-ring", wr, wrCol);
  const wbd = kpis.window_breach_days ?? 0;
  setText("exec-window-sub", wbd > 0 ? `${wbd} day(s) breached` : "All days OK");
  _drawMiniSparkline("exec-window-spark",
    (window.appData?.batch?.window || []).map(w => {
      const sla = kpis.sla_daily_hrs || 6;
      const hrs = Number(w.total_hrs || 0);
      return hrs > 0 ? Math.max(0, 100 - ((hrs - sla) / sla) * 100) : 100;
    }), wrCol);

  // ── Fleet Grade — letter + gradient bullet bar ──
  const flEl = document.getElementById("exec-fleet");
  const gradePct = { "A": 95, "B": 80, "C": 65, "D": 50, "F": 25, "N/A": 0 };
  const gc = { "A": "#10d96e", "B": "#10d96e", "C": "#f59e0b", "D": "#f43f5e", "F": "#f43f5e", "N/A": "#6b7db3" };
  if (flEl) {
    flEl.textContent = kpis.fleet_grade || "—";
    flEl.style.color = gc[kpis.fleet_grade] || "#f0f4ff";
  }
  setText("exec-fleet-sub", `${kpis.total_servers || 0} servers`);
  const flBar = document.getElementById("exec-fleet-bar");
  if (flBar) flBar.style.width = (gradePct[kpis.fleet_grade] || 0) + "%";

  // ── RFCS — number + bullet marker on gradient ──
  const rfEl = document.getElementById("exec-rfcs");
  const rfcs = _n(kpis.rfcs);
  if (rfEl) {
    rfEl.textContent = rfcs.toFixed(0);
    rfEl.style.color = rfcs >= 60 ? "#f43f5e" : (rfcs >= 30 ? "#f59e0b" : "#10d96e");
  }
  const rfMarker = document.getElementById("exec-rfcs-marker");
  if (rfMarker) {
    const rfPct = Math.max(0, Math.min(100, rfcs));
    rfMarker.style.marginLeft = `calc(${rfPct}% - 1px)`;
  }
  setText("exec-rfcs-sub",
    rfcs >= 60 ? "High risk · escalate" : rfcs >= 30 ? "Moderate risk" : "Low risk");
}

// ── Compact percentage formatter (fits inside small KPI rings) ──
function _fmtPctCompact(v) {
  const n = _n(v);
  if (n >= 99.95) return "100%";
  if (n >= 10)    return n.toFixed(0) + "%";
  return n.toFixed(1) + "%";
}

// ── Mini SVG sparkline drawer (used inside KPI cards) ────────
function _drawMiniSparkline(svgId, values, color) {
  const svg = document.getElementById(svgId);
  if (!svg) return;
  const vals = (values || []).filter(v => Number.isFinite(v));
  if (!vals.length) {
    svg.innerHTML = `<text x="40" y="14" text-anchor="middle" fill="#475569" font-size="7" font-family="Sora">no trend</text>`;
    return;
  }
  const W = 80, H = 22, P = 1.5;
  const min = Math.min(...vals), max = Math.max(...vals);
  const span = max - min || 1;
  const step = vals.length > 1 ? (W - 2 * P) / (vals.length - 1) : 0;
  const pts = vals.map((v, i) => {
    const x = P + i * step;
    const y = H - P - ((v - min) / span) * (H - 2 * P);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  const last = pts.split(" ").slice(-1)[0].split(",");
  const gradId = svgId + "-grad";
  svg.innerHTML = `
    <defs>
      <linearGradient id="${gradId}" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0%" stop-color="${color}" stop-opacity="0.5"/>
        <stop offset="100%" stop-color="${color}" stop-opacity="0.02"/>
      </linearGradient>
    </defs>
    <path d="M ${P},${H - P} L ${pts.split(" ").join(" L ")} L ${(W - P).toFixed(1)},${H - P} Z" fill="url(#${gradId})"/>
    <polyline points="${pts}" fill="none" stroke="${color}" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="${last[0]}" cy="${last[1]}" r="1.6" fill="${color}"/>
  `;
}


// ═════════════════════════════════════════════════════════════
//  V2 RENDERERS — Decision Strip · Sub-App Table · Breach Cal ·
//                 Concurrency · SOW · Auto-FJ
// ═════════════════════════════════════════════════════════════

// ── Decision Strip + Next Actions ─────────────────────────────
function _renderExecDecisionStrip(data) {
  const dec   = data?.decision || {};
  const strip = document.getElementById("exec-decision-strip");
  if (!strip) return;

  const status = (dec.status || "").toUpperCase();
  const isReady   = status === "READY";
  const isBlocked = status === "BLOCKED";
  const tone =
    isReady   ? { fg: "#10d96e", bd: "#10d96e", bg: "rgba(16,217,110,0.06)", lbl: "READY FOR SIGN-OFF" } :
    isBlocked ? { fg: "#f43f5e", bd: "#f43f5e", bg: "rgba(244,63,94,0.06)",  lbl: "BLOCKED" } :
                { fg: "#94a3b8", bd: "#475569", bg: "rgba(148,163,184,0.06)", lbl: "PENDING" };

  strip.style.borderLeftColor = tone.bd;
  strip.style.background      = tone.bg;

  setText("exec-dec-customer", dec.customer || window.appData.customerName || "—");
  const statusEl = document.getElementById("exec-dec-status");
  if (statusEl) {
    statusEl.textContent = tone.lbl;
    statusEl.style.color = tone.fg;
    statusEl.style.borderColor = tone.bd;
    statusEl.style.background  = hexA(tone.fg, 0.12);
  }
  setText("exec-dec-grade",    dec.grade || "—");
  setText("exec-dec-blockers", String(dec.blockers_count ?? 0));
  setText("exec-dec-reason",   dec.reason || "—");
  setText("exec-dec-days",     String(dec.days_covered ?? "—"));
  const now = new Date();
  setText("exec-dec-time",     now.toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}));

  // Next Actions (3 owner-tagged flat cards)
  const wrap = document.getElementById("exec-next-actions");
  if (wrap) {
    const actions = dec.next_actions || [];
    wrap.innerHTML = actions.map(a => `
      <div class="rounded-xl border border-Cborder/60 bg-Ccard/40 px-4 py-3">
        <div class="text-[9px] uppercase tracking-[0.18em] text-Cmuted font-bold mb-1">${_esc(a.owner || "")}</div>
        <div class="text-[12px] text-Cwhite/90 leading-snug">${_esc(a.action || "—")}</div>
      </div>
    `).join("");
  }
}

// ── 5-Condition Checklist (V2 — replaces _renderSignoffChecklist) ──
function _renderSignoffChecklistV2(decision) {
  const wrap = document.getElementById("exec-signoff-checklist");
  if (!wrap) return;
  const conds = decision?.conditions || [];
  wrap.innerHTML = conds.map(c => {
    const tone = c.pass ? "#10d96e" : "#f43f5e";
    const icon = c.pass ? "✓" : "✗";
    return `
      <div class="flex items-center gap-3 text-[11px]">
        <span class="w-5 text-center font-bold" style="color:${tone}">${icon}</span>
        <span class="text-Cwhite/90 font-semibold w-40">${_esc(c.label)}</span>
        <span class="text-Cmuted">actual: <span class="text-Cwhite font-mono">${_esc(c.actual)}</span></span>
        <span class="text-Cmuted">required: <span class="text-Cwhite font-mono">${_esc(c.required)}</span></span>
        ${c.blocker ? `<span class="text-[10px] ml-auto" style="color:${tone}">${_esc(c.blocker)}</span>` : ""}
      </div>`;
  }).join("");
}

// ── Sub-App Summary Table ─────────────────────────────────────
function _renderExecSubAppTable(summary) {
  const wrap  = document.getElementById("exec-subapp-table");
  const tipEl = document.getElementById("exec-subapp-tip");
  if (!wrap) return;
  const rows = summary?.rows || [];
  if (!rows.length) {
    wrap.innerHTML = `<p class="text-[11px] text-Cmuted py-6 text-center">No sub-app data available.</p>`;
    if (tipEl) tipEl.textContent = "";
    return;
  }
  const statusTone = (s) => s === "BREACH" ? "#f43f5e" : s === "AT_RISK" ? "#f59e0b" : "#10d96e";
  const head = `
    <thead>
      <tr class="text-[9px] uppercase tracking-wider text-Cmuted">
        <th class="text-left py-2 px-2">Sub-app</th>
        <th class="text-right py-2 px-2">Jobs</th>
        <th class="text-right py-2 px-2">Peak (h)</th>
        <th class="text-right py-2 px-2">Ceiling (h)</th>
        <th class="text-right py-2 px-2">Buffer %</th>
        <th class="text-right py-2 px-2">Status</th>
      </tr>
    </thead>`;
  const body = rows.map(r => `
    <tr class="border-t border-Cborder/30">
      <td class="py-2 px-2 text-Cwhite/90 font-semibold truncate max-w-[140px]">${_esc(r.sub_app)}</td>
      <td class="py-2 px-2 text-right text-Cwhite/80">${r.job_count}</td>
      <td class="py-2 px-2 text-right text-Cwhite/80 font-mono">${r.peak_hrs}</td>
      <td class="py-2 px-2 text-right text-Cmuted font-mono">${r.ceiling}</td>
      <td class="py-2 px-2 text-right font-mono ${r.buffer_pct < 0 ? 'text-Cred' : 'text-Cwhite/80'}">${r.buffer_pct}%</td>
      <td class="py-2 px-2 text-right">
        <span class="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded"
              style="color:${statusTone(r.status)};background:${hexA(statusTone(r.status),0.12)}">${_esc(r.status)}</span>
      </td>
    </tr>`).join("");
  wrap.innerHTML = `<table class="w-full">${head}<tbody>${body}</tbody></table>`;
  if (tipEl) tipEl.textContent = summary?.tip || "";
}

// ── Enhanced Breach Calendar (with SLA ceiling overlay) ───────
function _renderExecBreachCalendar(payload) {
  const el = document.getElementById("exec-chart-breach-cal");
  const sumEl = document.getElementById("exec-breach-cal-summary");
  if (!el || typeof Plotly === "undefined") return;
  // Backwards-compat: legacy callers passed (window, ceiling)
  let days, ceiling, summary;
  if (Array.isArray(payload)) {
    days    = payload;
    ceiling = arguments[1] || 6;
    summary = "";
  } else {
    days    = payload?.days    || [];
    ceiling = payload?.ceiling || 6;
    summary = payload?.summary || "";
  }
  if (!days.length) {
    el.innerHTML = `<p class="text-[11px] text-Cmuted py-12 text-center">No breach calendar data.</p>`;
    if (sumEl) sumEl.textContent = "";
    return;
  }
  const x = days.map(d => d.date || d.run_date || "");
  const y = days.map(d => Number(d.hours ?? d.total_hrs ?? 0));
  const colors = days.map(d => {
    const s = d.status || (d.is_breach ? "breach" : "ok");
    return s === "breach" ? "#f43f5e" : s === "near" ? "#f59e0b" : "#10d96e";
  });
  const hover = days.map(d => {
    const dow = d.day_of_week ? `${d.day_of_week} ` : "";
    const over = (d.over_by ?? 0) >= 0 ? `+${d.over_by}h` : `${d.over_by}h`;
    const tj = (d.top_jobs || []).filter(Boolean).join(", ") || "—";
    return `${dow}${d.date}<br>Window: ${(d.hours ?? 0).toFixed?.(2) ?? d.hours}h<br>Ceiling: ${d.ceiling ?? ceiling}h<br>Δ: ${over}<br>Top jobs: ${tj}`;
  });

  const trace = {
    type: "bar", x, y,
    marker: { color: colors, line: { color: "#0f172a", width: 1 } },
    text: y.map(v => v.toFixed ? v.toFixed(1) : v),
    textposition: "outside",
    textfont: { size: 9, color: "#94a3b8" },
    hovertemplate: hover.map(h => h + "<extra></extra>"),
  };

  const layout = {
    paper_bgcolor: "transparent",
    plot_bgcolor:  "transparent",
    margin: { l: 36, r: 60, t: 12, b: 40 },
    xaxis: { tickfont: { size: 9, color: "#94a3b8" }, gridcolor: "rgba(148,163,184,0.08)" },
    yaxis: {
      title: { text: "Hours", font: { size: 10, color: "#94a3b8" } },
      tickfont: { size: 9, color: "#94a3b8" },
      gridcolor: "rgba(148,163,184,0.08)",
    },
    shapes: [{
      type: "line",
      xref: "paper", x0: 0, x1: 1,
      y0: ceiling, y1: ceiling,
      line: { color: "#f43f5e", width: 1.6, dash: "dash" },
    }],
    annotations: [{
      xref: "paper", yref: "y",
      x: 1, y: ceiling, xanchor: "left", yanchor: "middle",
      text: `SLA: ${ceiling}h`,
      font: { size: 10, color: "#f43f5e", family: "monospace" },
      showarrow: false,
    }],
    showlegend: false,
  };
  Plotly.react(el, [trace], layout, { displayModeBar: false, responsive: true });
  if (sumEl) sumEl.textContent = summary || "";
}

// ── Job Concurrency Timeline (worst-day Gantt) ────────────────
function _renderExecConcurrency(payload) {
  const el       = document.getElementById("exec-chart-concurrency");
  const empty    = document.getElementById("exec-concurrency-empty");
  const sumEl    = document.getElementById("exec-concurrency-summary");
  const dateSel  = document.getElementById("exec-concurrency-date");
  if (!el) return;

  if (!payload?.available || !payload.bars?.length) {
    el.innerHTML = "";
    if (empty) empty.classList.remove("hidden");
    if (sumEl) sumEl.textContent = payload?.reason || "";
    if (dateSel) dateSel.innerHTML = "";
    return;
  }
  if (empty) empty.classList.add("hidden");

  // Date dropdown — populated once per render of fresh payload
  if (dateSel) {
    const dates = payload.available_dates || [payload.selected_date];
    dateSel.innerHTML = dates.map(d =>
      `<option value="${_esc(d)}" ${d === payload.selected_date ? "selected" : ""}>${_esc(d)}</option>`
    ).join("");
    dateSel.onchange = () => _renderExecConcurrencyForDate(dateSel.value);
  }

  _drawConcurrencyChart(payload, payload.bars);
  if (sumEl) sumEl.textContent = payload.summary || "";
}

function _renderExecConcurrencyForDate(date) {
  const dailyJobs = window.appData?.batch?.daily_jobs || {};
  const ceiling   = window._execCache?.kpis?.sla_daily_hrs || 6;
  const raw = dailyJobs[date] || [];
  if (!raw.length) return;
  // Sort by end_hr desc, top 15
  const bars = raw.slice().sort((a,b) => (b.end_hr||0) - (a.end_hr||0)).slice(0, 15)
    .map(j => ({
      job:       j.job,
      start_hr:  Number(j.start_hr || 0),
      end_hr:    Number(j.end_hr   || 0),
      duration:  Number((j.end_hr || 0) - (j.start_hr || 0)),
      exceeds_sla: ((j.end_hr || 0) - (j.start_hr || 0)) > ceiling,
    }));
  const window_start = Math.min(...bars.map(b => b.start_hr));
  const window_end   = Math.max(...bars.map(b => b.end_hr));
  const top3 = bars.slice(0, 3).map(b => b.job);
  const summary = `On ${date}, ${bars.length} jobs span ${(window_end - window_start).toFixed(2)}h. Top 3: ${top3.join(", ")}.`;
  _drawConcurrencyChart({ ceiling, selected_date: date, summary }, bars);
  setText("exec-concurrency-summary", summary);
}

function _drawConcurrencyChart(meta, bars) {
  const el = document.getElementById("exec-chart-concurrency");
  if (!el || typeof Plotly === "undefined") return;
  const ceiling = meta.ceiling || 6;
  // Sort: latest-ending at top → earliest-ending at bottom (Plotly flips, so push descending)
  const sorted = bars.slice().sort((a,b) => a.end_hr - b.end_hr);
  const yLabels = sorted.map(b => b.job);
  // Use error_x as a span trick: x = start_hr, base = 0, but better: use horizontal bars
  // We use a stacked bar: invisible "spacer" up to start_hr, then duration bar.
  const spacer = {
    type: "bar", orientation: "h",
    y: yLabels, x: sorted.map(b => b.start_hr),
    marker: { color: "rgba(0,0,0,0)" },
    hoverinfo: "skip",
    showlegend: false,
  };
  const main = {
    type: "bar", orientation: "h",
    y: yLabels, x: sorted.map(b => b.duration),
    marker: {
      color: sorted.map(b => b.exceeds_sla ? "#f43f5e" : "#10d96e"),
      line:  { color: "#0f172a", width: 0.5 },
    },
    hovertemplate: sorted.map(b =>
      `${b.job}<br>Start: ${b.start_hr}h<br>End: ${b.end_hr}h<br>Duration: ${b.duration}h<extra></extra>`),
    showlegend: false,
  };
  const layout = {
    paper_bgcolor: "transparent",
    plot_bgcolor:  "transparent",
    barmode: "stack",
    margin: { l: 130, r: 24, t: 10, b: 36 },
    xaxis: {
      title: { text: "Hour of day", font: { size: 10, color: "#94a3b8" } },
      tickfont: { size: 9, color: "#94a3b8" },
      gridcolor: "rgba(148,163,184,0.08)",
    },
    yaxis: {
      tickfont: { size: 9, color: "#cbd5e1" },
      automargin: true,
    },
    shapes: [{
      type: "line",
      x0: ceiling, x1: ceiling,
      yref: "paper", y0: 0, y1: 1,
      line: { color: "#f43f5e", width: 1.6, dash: "dash" },
    }],
    annotations: [{
      x: ceiling, xanchor: "left",
      yref: "paper", y: 1.02,
      text: `SLA ceiling ${ceiling}h`,
      font: { size: 9, color: "#f43f5e", family: "monospace" },
      showarrow: false,
    }],
  };
  Plotly.react(el, [spacer, main], layout, { displayModeBar: false, responsive: true });
}

// ── SOW vs Actual panel (3-column) ────────────────────────────
function _renderExecSowPanel(panel) {
  const card  = document.getElementById("exec-sow-card");
  const grid  = document.getElementById("exec-sow-grid");
  const empty = document.getElementById("exec-sow-empty");
  const stat  = document.getElementById("exec-sow-status");
  if (!card) return;

  if (!panel?.available) {
    if (grid)  grid.classList.add("hidden");
    if (empty) empty.classList.remove("hidden");
    if (stat)  {
      stat.textContent = "NOT LOADED";
      stat.style.color = "#94a3b8";
      stat.style.borderColor = "#475569";
      stat.style.background  = "rgba(148,163,184,0.12)";
    }
    return;
  }
  if (grid)  grid.classList.remove("hidden");
  if (empty) empty.classList.add("hidden");

  const overall = (panel.overall_status || "").toUpperCase();
  const tone =
    overall === "OPTIMAL"  ? "#10d96e" :
    overall === "MODERATE" ? "#22d3ee" :
    overall === "HIGH"     ? "#f43f5e" :
    overall === "LOW"      ? "#f59e0b" : "#94a3b8";
  if (stat) {
    stat.textContent = overall || "OK";
    stat.style.color = tone;
    stat.style.borderColor = hexA(tone, 0.5);
    stat.style.background  = hexA(tone, 0.12);
  }

  // Col 1: Volume bars (Plotly grouped bar)
  const volumeRows = panel.volume || [];
  const volEl = document.getElementById("exec-sow-volume");
  const deltaEl = document.getElementById("exec-sow-volume-delta");
  if (volEl && typeof Plotly !== "undefined") {
    if (volumeRows.length) {
      const labels = volumeRows.map(r => r.label || r.key);
      const sow    = volumeRows.map(r => Number(r.sow    || 0));
      const actual = volumeRows.map(r => Number(r.actual || 0));
      const traces = [
        { type: "bar", name: "SOW",    x: labels, y: sow,
          marker: { color: "#475569" } },
        { type: "bar", name: "Actual", x: labels, y: actual,
          marker: { color: "#22d3ee" } },
      ];
      Plotly.react(volEl, traces, {
        paper_bgcolor: "transparent", plot_bgcolor: "transparent",
        margin: { l: 40, r: 12, t: 12, b: 36 },
        barmode: "group",
        legend: { font: { size: 9, color: "#94a3b8" }, orientation: "h", y: 1.15 },
        xaxis: { tickfont: { size: 8, color: "#94a3b8" } },
        yaxis: { tickfont: { size: 8, color: "#94a3b8" }, gridcolor: "rgba(148,163,184,0.08)" },
      }, { displayModeBar: false, responsive: true });
      // Delta label — biggest deviation
      const deltas = volumeRows.map(r => ({
        label: r.label || r.key,
        delta: Number(r.actual || 0) - Number(r.sow || 0),
        pct:   Number(r.pct || 0),
      })).sort((a,b) => Math.abs(b.delta) - Math.abs(a.delta));
      const top = deltas[0];
      if (deltaEl && top) {
        const sign = top.delta >= 0 ? "+" : "";
        const tone2 = top.pct > 110 ? "#f43f5e" : top.pct < 70 ? "#f59e0b" : "#10d96e";
        deltaEl.textContent = `${top.label}: ${sign}${top.pct.toFixed(1)}% vs SOW`;
        deltaEl.style.color = tone2;
      }
    } else {
      volEl.innerHTML = `<p class="text-[11px] text-Cmuted py-8 text-center">No volume metrics in SOW.</p>`;
      if (deltaEl) deltaEl.textContent = "";
    }
  }

  // Col 2: SLA narrative
  const slaSum = document.getElementById("exec-sow-sla-summary");
  if (slaSum) {
    const ceiling = window._execCache?.kpis?.sla_daily_hrs ?? "—";
    const breachCount = window._execCache?.decision?.breach_days ?? 0;
    const totalDays   = window._execCache?.decision?.total_days  ?? 0;
    slaSum.textContent = totalDays
      ? `Contracted ceiling: ${ceiling}h. ${breachCount} of ${totalDays} days breached.`
      : `Contracted ceiling: ${ceiling}h.`;
  }

  // Col 3: Capacity
  const capEl = document.getElementById("exec-sow-capacity");
  if (capEl) {
    const cap = panel.capacity || [];
    if (!cap.length) {
      capEl.innerHTML = `<p class="text-[11px] text-Cmuted">No capacity baselines in SOW.</p>`;
    } else {
      capEl.innerHTML = cap.map(c => {
        const tone3 = c.status === "Within baseline" ? "#10d96e"
                    : c.status === "Approaching limit" ? "#f59e0b" : "#f43f5e";
        const pct = Math.min(100, Math.max(0, c.actual / Math.max(c.sow, 1) * 100));
        return `
          <div>
            <div class="flex items-center justify-between text-[10px] text-Cmuted mb-1">
              <span class="font-semibold text-Cwhite/90">${_esc(c.label)}</span>
              <span style="color:${tone3}" class="font-mono">${c.actual}% / ${c.sow}%</span>
            </div>
            <div class="h-1.5 rounded-full bg-Cborder/40 overflow-hidden relative">
              <div class="h-full" style="width:${pct.toFixed(1)}%;background:${tone3}"></div>
              <div class="absolute top-0 bottom-0 border-r border-dashed" style="left:80%;border-color:${hexA(tone3,0.6)}"></div>
            </div>
            <div class="text-[10px] mt-0.5" style="color:${tone3}">${_esc(c.status)}</div>
          </div>`;
      }).join("");
    }
  }
}

// Stubs for legacy renderers — actual implementations below have null
// guards for missing DOM elements, so duplicates are harmless. We removed
// any conflicting redeclarations above.


// ── Sign-off Readiness Strip + Audit Readiness Cards ─────────
function _renderExecSignoffStrip(data) {
  // Sign-off verdict strip
  const verdictEl = document.getElementById("exec-signoff-verdict");
  const detailEl  = document.getElementById("exec-signoff-detail");
  if (!verdictEl) return;

  // Audit readiness cards — declare sla FIRST to avoid TDZ
  const dc  = (window.appData.batch || {}).data_coverage || {};
  const sla = (window.appData.batch || {}).sla_source || {};

  const findings  = window._lastFindings || [];
  const critCount = findings.filter(f => f.level === "critical").length;
  const warnCount = findings.filter(f => f.level === "warning").length;

  const blockers = findings.filter(f => f.level === "critical").map(f => f.text);
  const slaBlocked = sla.blocked;
  const causes = [];
  if (blockers.some(b => /batch window/i.test(b))) causes.push("batch-window overruns");
  if (blockers.some(b => /cpu|critical state/i.test(b))) causes.push("critical CPU concentration");
  if (blockers.some(b => /sla.*breach/i.test(b))) causes.push("SLA breaches");
  if (blockers.some(b => /evidence|insufficient/i.test(b))) causes.push("incomplete evidence");
  if (slaBlocked) causes.push("SLA from assumed defaults");

  if (critCount === 0 && warnCount === 0 && !slaBlocked) {
    verdictEl.textContent = "READY FOR SIGN-OFF";
    verdictEl.style.color = THEME.green;
    verdictEl.style.borderColor = THEME.green;
    verdictEl.style.background = hexA(THEME.green, 0.1);
    detailEl.textContent = "No critical or warning findings. All reviewed areas within thresholds.";
  } else if (critCount > 0 || slaBlocked) {
    verdictEl.textContent = "SIGN-OFF BLOCKED";
    verdictEl.style.color = THEME.red;
    verdictEl.style.borderColor = THEME.red;
    verdictEl.style.background = hexA(THEME.red, 0.1);
    detailEl.textContent = `${critCount} critical, ${warnCount} warnings · Blockers: ${causes.join(", ") || "see findings"}`;
  } else {
    verdictEl.textContent = "CONDITIONAL";
    verdictEl.style.color = THEME.amber;
    verdictEl.style.borderColor = THEME.amber;
    verdictEl.style.background = hexA(THEME.amber, 0.1);
    detailEl.textContent = `${warnCount} warning(s) require review before sign-off.`;
  }

  const span = dc.date_span_days || 0;
  const evEl = document.getElementById("exec-evidence");
  if (evEl) {
    evEl.textContent = span >= 30 ? "30d+" : span >= 14 ? `${span}d` : span > 0 ? `${span}d` : "NONE";
    evEl.style.color = span >= 30 ? THEME.green : span >= 14 ? THEME.amber : THEME.red;
    setText("exec-evidence-sub", span >= 30 ? "Full coverage" : span > 0 ? "Partial — need 30d" : "No batch data");
  }

  const conf = dc.confidence || 0;
  const confEl = document.getElementById("exec-confidence");
  if (confEl) {
    confEl.textContent = `${conf}%`;
    confEl.style.color = conf >= 80 ? THEME.green : conf >= 60 ? THEME.amber : THEME.red;
    setText("exec-confidence-sub", dc.confidence_label || "—");
  }

  const sqEl = document.getElementById("exec-sla-quality");
  if (sqEl) {
    const isMatrix = sla.type === "sla_matrix";
    const isAssumed = !sla.type || sla.type === "default" || sla.type === "assumed";
    const slaBlocked = sla.blocked;
    if (isMatrix) {
      sqEl.textContent = "MATRIX";
      sqEl.style.color = THEME.green;
      setText("exec-sla-quality-sub",
        `${sla.detected_model || sla.schema_type || "SLA file"} · ${sla.valid_rows || "?"} rules`);
    } else if (isAssumed) {
      sqEl.textContent = slaBlocked ? "BLOCKED" : "DEFAULT";
      sqEl.style.color = slaBlocked ? THEME.red : THEME.amber;
      setText("exec-sla-quality-sub",
        slaBlocked ? "Assumed defaults — green blocked" : "Using system defaults");
    } else {
      sqEl.textContent = "FALLBACK";
      sqEl.style.color = THEME.amber;
      setText("exec-sla-quality-sub", "Customer fallback — partial confidence");
    }
  }

  const srEl = document.getElementById("exec-signoff-ready");
  if (srEl) {
    srEl.textContent = critCount === 0 ? (warnCount === 0 ? "YES" : "COND") : "NO";
    srEl.style.color = critCount === 0 ? (warnCount === 0 ? THEME.green : THEME.amber) : THEME.red;
    setText("exec-signoff-ready-sub",
      critCount > 0 ? `${critCount} blockers` : warnCount > 0 ? `${warnCount} warnings` : "All clear");
  }

  const vsEl = document.getElementById("exec-vol-sow");
  if (vsEl) {
    const hasSow = !!(window.appData.sowCompare);
    vsEl.textContent = hasSow ? "LOADED" : "N/A";
    vsEl.style.color = hasSow ? THEME.green : THEME.muted;
    setText("exec-vol-sow-sub", hasSow ? "SOW comparison active" : "No SOW data");
  }
}


// ── Breach Calendar (legacy v1 removed; v2 implementation lives above) ──


// ── Evidence-Confidence Ribbon ───────────────────────────────
function _renderExecEvidenceRibbon(findings) {
  const el = document.getElementById("exec-evidence-ribbon");
  if (!el) return;

  const classes = { measured: 0, inferred: 0, defaulted: 0, waived: 0, unavailable: 0 };
  for (const f of (findings || [])) {
    const ec = f.evidence_class || "measured";
    if (ec in classes) classes[ec]++;
  }
  const total = Object.values(classes).reduce((a, b) => a + b, 0);
  if (!total) {
    el.innerHTML = `<div class="flex flex-col items-center justify-center text-center py-8 px-4">
      <div class="text-3xl opacity-40 mb-2">🔍</div>
      <div class="text-[12px] text-Cmuted leading-snug">Findings still computing — ribbon will appear once PE Findings finishes.</div>
    </div>`;
    return;
  }

  const colorMap = {
    measured:    THEME.green,
    inferred:    THEME.cyan,
    defaulted:   THEME.amber,
    waived:      THEME.purple,
    unavailable: THEME.muted,
  };
  const labelMap = {
    measured:    "Source-backed",
    inferred:    "Document-derived",
    defaulted:   "Default SLA",
    waived:      "Waived",
    unavailable: "Unavailable",
  };

  // Horizontal stacked bar
  const barHtml = Object.entries(classes).filter(([, v]) => v > 0).map(([cls, v]) => {
    const pct = (v / total * 100).toFixed(0);
    return `<div style="width:${pct}%;background:${hexA(colorMap[cls], 0.6)};min-width:20px"
                 class="h-6 flex items-center justify-center text-[9px] font-bold text-Cwhite"
                 title="${labelMap[cls]}: ${v} finding(s) (${pct}%)">${pct}%</div>`;
  }).join("");

  const legendHtml = Object.entries(classes).filter(([, v]) => v > 0).map(([cls, v]) =>
    `<span class="inline-flex items-center gap-1 text-[10px]">
      <span class="w-2 h-2 rounded-full inline-block" style="background:${colorMap[cls]}"></span>
      ${labelMap[cls]} (${v})
    </span>`
  ).join(" ");

  el.innerHTML = `
    <div class="flex rounded-lg overflow-hidden">${barHtml}</div>
    <div class="flex flex-wrap gap-3 mt-2">${legendHtml}</div>
    <p class="text-[10px] text-Cmuted mt-1">PE audit decisions depend on evidence trust level. Defaulted and inferred findings require additional validation.</p>
  `;
}

function _renderExecBenchmarkSummary(bench) {
  const el = document.getElementById("exec-benchmark-summary");
  if (!el) return;
  if (!bench) { el.classList.add("hidden"); return; }
  el.classList.remove("hidden");
  const cats = bench.categories || [];
  const fr = bench.fill_rate || [];
  const obs = bench.observations || [];
  const totalTx = bench.total_transactions || 0;
  const degraded = bench.degraded || 0;
  const passRate = totalTx > 0 ? Math.round((totalTx - degraded) / totalTx * 100) : 0;
  const color = degraded > 0 ? "border-Camber/40 bg-Camber/5" : "border-Cgreen/40 bg-Cgreen/5";

  let catCards = "";
  cats.forEach(c => {
    const pct = c.total > 0 ? Math.round(c.passed / c.total * 100) : 0;
    const badge = c.degraded > 0 ? "text-Cred" : "text-Cgreen";
    catCards += `<div class="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-Ccard/50 border border-Cborder/30">
      <span class="text-lg font-bold ${badge}">${pct}%</span>
      <div class="text-[10px]"><div class="text-Cwhite font-semibold">${_esc(c.name)}</div>
        <div class="text-Cmuted">${c.passed}/${c.total} pass${c.degraded > 0 ? ` · ${c.degraded} red` : ""}</div>
      </div></div>`;
  });

  el.innerHTML = `<div class="rounded-xl border ${color} p-4">
    <div class="flex items-center gap-3 mb-3">
      <span class="text-lg">⚡</span>
      <div>
        <div class="text-sm font-bold text-Cwhite">UI Performance Benchmark</div>
        <div class="text-[10px] text-Cmuted">${totalTx} transactions · ${passRate}% pass rate${fr.length ? ` · ${fr.length} fill rate entries` : ""}${obs.length ? ` · ${obs.length} SIT obs` : ""}</div>
      </div>
    </div>
    ${catCards ? `<div class="flex flex-wrap gap-2 mt-2">${catCards}</div>` : ""}
  </div>`;
}

// ── Panel A: Batch Runtime vs SLA Ceiling (Horizontal Bar) ───
function _renderExecSLABars(jobs) {
  const el = document.getElementById("exec-chart-sla-bars");
  if (!el || !jobs?.length) return;

  const labels = jobs.map(j => j.job_name.length > 25 ? j.job_name.slice(0, 22) + "…" : j.job_name);
  const peaks  = jobs.map(j => j.peak_hrs);
  const colors = jobs.map(j => j.status === "BREACH" ? "#f43f5e" : (j.status === "AT_RISK" ? "#f59e0b" : "#10d96e"));
  const sla    = jobs.length ? jobs[0].sla_ceiling : 6;

  const traces = [
    {
      type: "bar", orientation: "h",
      y: labels, x: peaks,
      marker: { color: colors, line: { width: 0 } },
      text: jobs.map(j => `SRI: ${_n(j.sri).toFixed(2)}`),
      textposition: "outside",
      textfont: { size: 9, color: "#6b7db3" },
      hovertemplate: "%{y}<br>Peak: %{x:.2f}h<br>Buffer: %{customdata:.0f}%<extra></extra>",
      customdata: jobs.map(j => j.buffer_pct),
      name: "Peak Runtime",
    },
  ];

  const layout = {
    ..._EXEC_LAYOUT_BASE,
    margin: { l: 140, r: 60, t: 10, b: 35 },
    xaxis: { ..._EXEC_LAYOUT_BASE.xaxis, title: { text: "Hours", font: { size: 10 } } },
    yaxis: { ..._EXEC_LAYOUT_BASE.yaxis, autorange: "reversed" },
    shapes: [{
      type: "line", x0: sla, x1: sla, y0: -0.5, y1: labels.length - 0.5,
      line: { color: "#f43f5e", width: 2, dash: "dash" },
    }],
    annotations: [{
      x: sla, y: -0.3, text: `SLA ${sla}h`, showarrow: false,
      font: { size: 9, color: "#f43f5e" }, xanchor: "left",
    }],
    showlegend: false,
    bargap: 0.15,
  };

  Plotly.newPlot(el, traces, layout, _EXEC_CFG);
}

// ── Panel B: Server Resource Heatmap ─────────────────────────
function _renderExecHeatmap(servers) {
  const el = document.getElementById("exec-chart-heatmap");
  if (!el || !servers?.length) return;

  const hosts = servers.map(s => s.host.length > 20 ? s.host.slice(0, 17) + "…" : s.host);
  const metrics = ["CPU %", "Mem %", "Disk %"];
  const z = servers.map(s => [s.cpu, s.mem, s.disk]);

  // Annotation text: actual values in cells
  const annotations = [];
  for (let i = 0; i < hosts.length; i++) {
    for (let j = 0; j < 3; j++) {
      annotations.push({
        x: metrics[j], y: hosts[i],
        text: z[i][j].toFixed(1) + "%",
        showarrow: false,
        font: { size: 10, color: z[i][j] >= 75 ? "#fff" : "#c0c0c0" },
      });
    }
  }

  const traces = [{
    type: "heatmap",
    z: z, x: metrics, y: hosts,
    colorscale: [
      [0.0,  "#0d4429"], [0.50, "#1a6d1a"],
      [0.55, "#7a6d0a"], [0.75, "#b5700a"],
      [0.80, "#c4430a"], [1.0,  "#f43f5e"],
    ],
    zmin: 0, zmax: 100,
    showscale: true,
    colorbar: { len: 0.5, thickness: 12, tickfont: { size: 9, color: "#6b7db3" }, title: { text: "%", font: { size: 9 } } },
    hovertemplate: "%{y}<br>%{x}: %{z:.1f}%<extra></extra>",
  }];

  const layout = {
    ..._EXEC_LAYOUT_BASE,
    margin: { l: 130, r: 80, t: 10, b: 35 },
    annotations: annotations,
    yaxis: { ..._EXEC_LAYOUT_BASE.yaxis, autorange: "reversed" },
  };

  Plotly.newPlot(el, traces, layout, _EXEC_CFG);
}

// ── Panel C: Sub-App Risk Distribution (Bar) ─────────────────
function _renderExecSubAppBars(subs) {
  const el = document.getElementById("exec-chart-subapp-bars");
  if (!el || !subs?.length) return;

  // Treemap — tile size by job count, color by SRI severity
  const colorFor = (sri) => sri > 1.0 ? "#f43f5e" : sri > 0.85 ? "#f59e0b" : "#10d96e";

  const labels = subs.map(s => s.sub_app);
  const parents = subs.map(() => "");
  const values = subs.map(s => Math.max(1, s.job_count || 1));
  const colors = subs.map(s => colorFor(s.sri));
  const text = subs.map(s =>
    `<b>${s.sub_app}</b><br>SRI ${_n(s.sri).toFixed(2)} · ${s.job_count} jobs`);

  const traces = [{
    type: "treemap",
    labels, parents, values,
    text, textinfo: "text",
    textfont: { size: 11, color: "#ffffff", family: "Sora" },
    marker: {
      colors,
      line: { color: "#0b1530", width: 2 },
      pad: { t: 2, l: 2, r: 2, b: 2 },
    },
    hovertemplate: "<b>%{label}</b><br>SRI: %{customdata:.3f}<br>Jobs: %{value}<extra></extra>",
    customdata: subs.map(s => s.sri),
    tiling: { packing: "squarify", pad: 2 },
  }];

  const layout = {
    ..._EXEC_LAYOUT_BASE,
    margin: { l: 4, r: 4, t: 4, b: 4 },
    showlegend: false,
  };

  Plotly.newPlot(el, traces, layout, _EXEC_CFG);
}

// ── Panel D: 3-Way Risk Matrix (Bubble) ──────────────────────
function _renderExecBubble(subs) {
  const el = document.getElementById("exec-chart-bubble");
  if (!el || !subs?.length) return;

  const rfcsCols = { red: "#f43f5e", amber: "#f59e0b", green: "#10d96e" };

  const traces = [{
    type: "scatter", mode: "markers",
    x: subs.map(s => s.resource_pressure),
    y: subs.map(s => s.sri),
    text: subs.map(s => s.sub_app),
    marker: {
      size: subs.map(s => Math.max(12, s.crs * 60)),
      color: subs.map(s => rfcsCols[s.rfcs_band] || "#3b82f6"),
      opacity: 0.85,
      line: { width: 1.5, color: "rgba(255,255,255,0.3)" },
    },
    hovertemplate: "<b>%{text}</b><br>Resource: %{x:.1f}%<br>SRI: %{y:.3f}<br>CRS: %{customdata:.3f}<extra></extra>",
    customdata: subs.map(s => s.crs),
  }];

  const layout = {
    ..._EXEC_LAYOUT_BASE,
    xaxis: {
      ..._EXEC_LAYOUT_BASE.xaxis,
      title: { text: "Resource Pressure (%)", font: { size: 10 } },
      range: [0, 110],
    },
    yaxis: {
      ..._EXEC_LAYOUT_BASE.yaxis,
      title: { text: "SLA Risk Index (SRI)", font: { size: 10 } },
    },
    shapes: [
      { type: "line", x0: 75, x1: 75, y0: 0, y1: 2, line: { color: "rgba(244,63,94,0.3)", width: 1, dash: "dot" } },
      { type: "line", y0: 0.85, y1: 0.85, x0: 0, x1: 110, line: { color: "rgba(244,63,94,0.3)", width: 1, dash: "dot" } },
    ],
    annotations: [
      { x: 92, y: 1.5, text: "CRITICAL", showarrow: false, font: { size: 9, color: "#f43f5e" } },
      { x: 20, y: 1.5, text: "SLA RISK", showarrow: false, font: { size: 9, color: "#f59e0b" } },
      { x: 92, y: 0.3, text: "RESOURCE RISK", showarrow: false, font: { size: 8, color: "#f59e0b" } },
      { x: 20, y: 0.3, text: "SAFE", showarrow: false, font: { size: 9, color: "#10d96e" } },
    ],
    showlegend: false,
  };

  Plotly.newPlot(el, traces, layout, _EXEC_CFG);
}

// ── Panel E: Temporal Correlation (Dual-Axis) ────────────────
function _renderExecTemporal(temporal, kpis) {
  const el = document.getElementById("exec-chart-temporal");
  if (!el || !temporal?.length) return;

  const hours  = temporal.map(t => t.hour);
  const jobs   = temporal.map(t => t.jobs);
  const fails  = temporal.map(t => t.failures);
  const barCol = temporal.map(t => t.fail_rate > 20 ? "#f43f5e" : (t.fail_rate > 5 ? "#f59e0b" : "#3b82f6"));

  // Create CPU line (constant at avg_cpu to show overlap)
  const cpuLine = temporal.map(() => kpis?.avg_cpu ?? 0);

  const traces = [
    {
      type: "bar", name: "Jobs / hour",
      x: hours, y: jobs,
      marker: { color: barCol, opacity: 0.8 },
      yaxis: "y",
      hovertemplate: "Hour %{x}<br>Jobs: %{y}<br>Failures: %{customdata}<extra></extra>",
      customdata: fails,
    },
    {
      type: "scatter", mode: "lines+markers", name: "Avg CPU %",
      x: hours, y: cpuLine,
      line: { color: "#f43f5e", width: 2, dash: "dash" },
      marker: { size: 0 },
      yaxis: "y2",
      hovertemplate: "CPU: %{y:.1f}%<extra></extra>",
    },
  ];

  const layout = {
    ..._EXEC_LAYOUT_BASE,
    xaxis: { ..._EXEC_LAYOUT_BASE.xaxis, title: { text: "Hour of Day", font: { size: 10 } }, dtick: 1 },
    yaxis: { ..._EXEC_LAYOUT_BASE.yaxis, title: { text: "Job Count", font: { size: 10 } }, side: "left" },
    yaxis2: {
      title: { text: "CPU %", font: { size: 10, color: "#f43f5e" } },
      overlaying: "y", side: "right", range: [0, 100],
      gridcolor: "rgba(0,0,0,0)",
      tickfont: { color: "#f43f5e" },
    },
    legend: { font: { size: 9 }, x: 0, y: 1.12, orientation: "h" },
    // Batch window shading (20:00-04:00)
    shapes: [{
      type: "rect", x0: 20, x1: 23, y0: 0, y1: 1, yref: "paper",
      fillcolor: "rgba(168,85,247,0.08)", line: { width: 0 },
    }, {
      type: "rect", x0: 0, x1: 4, y0: 0, y1: 1, yref: "paper",
      fillcolor: "rgba(168,85,247,0.08)", line: { width: 0 },
    }],
    annotations: [
      { x: 22, y: 1.03, yref: "paper", text: "Batch Window", showarrow: false, font: { size: 8, color: "#a855f7" } },
    ],
    bargap: 0.05,
  };

  Plotly.newPlot(el, traces, layout, _EXEC_CFG);
}

// ── Panel F: OSHS Waterfall ──────────────────────────────────
function _renderExecWaterfall(wf, oshs) {
  const el = document.getElementById("exec-chart-waterfall");
  if (!el || !wf) return;
  if (typeof Plotly === "undefined") return;

  // Multi-arc radial gauge: each pillar is its own concentric ring.
  // Score = (contribution / weight_pts) * 100 (compliance %).
  const pillars = [
    { name: "Batch",    val: wf.batch_contribution,    max: 40, color: "#22d3ee" },
    { name: "Resource", val: wf.resource_contribution, max: 35, color: "#a78bfa" },
    { name: "SLA",      val: wf.sla_contribution,      max: 25, color: "#fbbf24" },
  ];
  const total = _n(wf.total);
  const totalCol = total >= 75 ? "#10d96e" : total >= 60 ? "#f59e0b" : "#f43f5e";
  const grade = oshs?.grade || "?";

  // Build SVG: concentric arcs, semicircle from -180° → 0°
  const W = 320, H = 240, CX = 160, CY = 200;
  const radii = [110, 85, 60];
  const stroke = 14;

  // Path generator for an arc from angle a0 → a1 (degrees, 180 = left, 0 = right)
  const arcPath = (cx, cy, r, a0, a1) => {
    const rad = a => (a * Math.PI) / 180;
    const x0 = cx + r * Math.cos(rad(a0)), y0 = cy + r * Math.sin(rad(a0));
    const x1 = cx + r * Math.cos(rad(a1)), y1 = cy + r * Math.sin(rad(a1));
    const large = Math.abs(a1 - a0) > 180 ? 1 : 0;
    const sweep = a1 > a0 ? 1 : 0;
    return `M ${x0.toFixed(1)},${y0.toFixed(1)} A ${r},${r} 0 ${large} ${sweep} ${x1.toFixed(1)},${y1.toFixed(1)}`;
  };

  let arcs = "";
  pillars.forEach((p, i) => {
    const r = radii[i];
    arcs += `<path d="${arcPath(CX, CY, r, 180, 360)}" fill="none" stroke="#1e2a52" stroke-width="${stroke}" stroke-linecap="round"/>`;
    const pct = Math.max(0, Math.min(1, p.val / p.max));
    if (pct > 0.001) {
      const a1 = 180 + 180 * pct;
      arcs += `<path d="${arcPath(CX, CY, r, 180, a1)}" fill="none" stroke="${p.color}" stroke-width="${stroke}" stroke-linecap="round" style="filter:drop-shadow(0 0 4px ${p.color}aa);"/>`;
    }
  });

  el.innerHTML = `
    <div class="relative h-full w-full flex flex-col items-center justify-center">
      <svg viewBox="0 0 ${W} ${H}" class="w-full max-w-[340px]" preserveAspectRatio="xMidYMid meet">
        ${arcs}
        <text x="${CX}" y="${CY - 38}" text-anchor="middle" fill="${totalCol}" font-size="44" font-weight="900" font-family="Sora">${total.toFixed(1)}</text>
        <text x="${CX}" y="${CY - 18}" text-anchor="middle" fill="#6b7db3" font-size="9" font-family="Sora" letter-spacing="1.5">/ 100 · GRADE ${grade}</text>
      </svg>
      <div class="flex flex-wrap justify-center gap-x-4 gap-y-1 text-[10px] mt-2 px-2">
        ${pillars.map(p => `
          <span class="flex items-center gap-1.5">
            <span class="inline-block w-2 h-2 rounded-full" style="background:${p.color};box-shadow:0 0 6px ${p.color};"></span>
            <span class="text-Cmuted">${p.name}</span>
            <span class="font-bold" style="color:${p.color};">${_n(p.val).toFixed(1)}<span class="text-Cmuted/60 font-normal">/${p.max}</span></span>
            <span class="text-[9px] text-Cmuted">(${Math.round((p.val / p.max) * 100)}%)</span>
          </span>`).join("")}
      </div>
    </div>
  `;
}

// ── Narrative Panel ──────────────────────────────────────────
function _renderExecNarrative(findings) {
  const el = document.getElementById("exec-narrative");
  if (!el) return;

  // Normalise input — server returns a list of {key, icon, level, text} dicts
  if (!findings) findings = [];
  else if (typeof findings === "string") {
    findings = findings.trim() ? [{ key: "coverage", icon: "🛡️", level: "info", text: findings }] : [];
  } else if (!Array.isArray(findings)) {
    findings = (typeof findings === "object") ? [findings] : [];
  }
  if (!findings.length) {
    el.innerHTML = '<p class="text-Cmuted text-[12px] py-4 text-center">No narrative data — upload batch + resource files to generate insights.</p>';
    return;
  }

  const STEPS = [
    { key: "coverage", label: "Coverage", icon: "🛡️", color: "#22d3ee", desc: "What we measured" },
    { key: "risk",     label: "Risk",     icon: "⚠️", color: "#f59e0b", desc: "What's at stake" },
    { key: "cause",    label: "Cause",    icon: "🔍", color: "#a78bfa", desc: "Why it's happening" },
    { key: "impact",   label: "Impact",   icon: "📉", color: "#f43f5e", desc: "Business effect" },
    { key: "action",   label: "Action",   icon: "🎯", color: "#10d96e", desc: "Recommended decision" },
  ];

  // Build a key→text map from incoming findings
  const byKey = {};
  findings.forEach(f => {
    const k = f.key || f.step || "";
    if (k) byKey[k] = f;
  });

  // If the server sent a keyed list (new structured format), render directly
  const hasKeys = Object.keys(byKey).length >= 3;
  if (hasKeys) {
    const cards = STEPS.map(step => {
      const f = byKey[step.key] || {};
      const text = f.text || "—";
      const dim = !f.text;
      return `
        <div class="rounded-lg border border-Cborder/40 bg-Ccard/40 p-3 flex gap-3 ${dim ? "opacity-40" : ""}"
             style="border-left:3px solid ${step.color};">
          <div class="flex flex-col items-center gap-0.5 min-w-[36px]">
            <div class="text-base">${step.icon}</div>
            <div class="text-[8px] uppercase tracking-widest font-bold" style="color:${step.color};">${step.label}</div>
          </div>
          <div class="flex-1 min-w-0">
            <div class="text-[9px] text-Cmuted uppercase tracking-wider mb-1">${step.desc}</div>
            <div class="text-[12px] text-Cwhite leading-relaxed">${_esc(text)}</div>
          </div>
        </div>`;
    }).join("");
    el.innerHTML = `<div class="grid grid-cols-1 sm:grid-cols-2 gap-2">${cards}</div>`;
    return;
  }

  // ── Fallback: render findings list with severity badges (legacy path) ──
  const LEVEL_STYLE = {
    critical: { badge: "bg-red-900/40 text-red-300 border border-red-500/30",       dot: "🔴", accent: "#f43f5e" },
    warning:  { badge: "bg-amber-900/40 text-amber-300 border border-amber-500/30", dot: "🟠", accent: "#f59e0b" },
    info:     { badge: "bg-blue-900/40 text-blue-300 border border-blue-500/30",    dot: "🔵", accent: "#22d3ee" },
  };
  el.innerHTML = findings.map(f => {
    const s = LEVEL_STYLE[f.level] || LEVEL_STYLE.info;
    return `<div class="flex items-start gap-3 p-3 rounded-lg bg-Ccard/60 border border-Cborder/40"
                 style="border-left:3px solid ${s.accent};">
      <span class="text-lg mt-0.5">${f.icon || s.dot}</span>
      <div class="flex-1 min-w-0">
        <span class="inline-block text-[9px] uppercase font-bold px-2 py-0.5 rounded-full ${s.badge} mr-2">${f.level || "info"}</span>
        <span class="text-[12px] text-Cwhite leading-relaxed">${_esc(f.text || "")}</span>
      </div>
    </div>`;
  }).join("");
}

// ── Hot Spots — crux strip above the narrative ───────────────
// Pulls the worst job, worst server, peak-load hour, total breach hours,
// and trend direction from the cross-pillar data already on the page.
function _renderExecHotSpots(data) {
  const el = document.getElementById("exec-hotspots");
  if (!el) return;

  const tiles = [];

  // 1. Worst Sub-App (highest SRI)
  const subs = (data?.sub_app_metrics || []).slice().sort((a, b) => (b.sri || 0) - (a.sri || 0));
  if (subs.length) {
    const w = subs[0];
    const col = w.sri > 1 ? "#f43f5e" : w.sri > 0.85 ? "#f59e0b" : "#10d96e";
    tiles.push({
      label: "Worst Sub-App",
      value: w.sub_app,
      sub: `SRI ${_n(w.sri).toFixed(2)} · ${w.job_count} jobs`,
      color: col,
      icon: "🎯",
    });
  }

  // 2. Hottest Server (highest CPU or memory pressure)
  const heat = data?.server_heatmap;
  if (heat?.servers?.length && heat?.values?.length) {
    let worstIdx = 0, worstVal = -1;
    heat.values.forEach((row, i) => {
      const peak = Math.max(...row.map(Number).filter(Number.isFinite));
      if (peak > worstVal) { worstVal = peak; worstIdx = i; }
    });
    const sname = heat.servers[worstIdx] || "—";
    const col = worstVal >= 80 ? "#f43f5e" : worstVal >= 60 ? "#f59e0b" : "#10d96e";
    tiles.push({
      label: "Hottest Server",
      value: sname.length > 18 ? sname.slice(0, 15) + "…" : sname,
      sub: `peak ${worstVal.toFixed(0)}%`,
      color: col,
      icon: "🔥",
    });
  }

  // 3. Peak Load Hour (from temporal correlation)
  const temp = data?.temporal;
  if (temp?.hours?.length && temp?.job_counts?.length) {
    let peakHour = -1, peakJobs = -1;
    temp.job_counts.forEach((c, i) => {
      const n = Number(c);
      if (n > peakJobs) { peakJobs = n; peakHour = temp.hours[i]; }
    });
    if (peakHour >= 0) {
      tiles.push({
        label: "Peak Load Hour",
        value: `${String(peakHour).padStart(2, "0")}:00`,
        sub: `${peakJobs} jobs running`,
        color: "#22d3ee",
        icon: "⏰",
      });
    }
  }

  // 4. Total Breach Hours (from breach calendar data)
  const win = window.appData?.batch?.window || [];
  const sla = data?.kpis?.sla_daily_hrs || 6;
  const totalOverrun = win.reduce((s, w) => s + Math.max(0, Number(w.total_hrs || 0) - sla), 0);
  const breachDays = win.filter(w => Number(w.total_hrs || 0) > sla).length;
  if (win.length) {
    const col = totalOverrun > 10 ? "#f43f5e" : totalOverrun > 0 ? "#f59e0b" : "#10d96e";
    tiles.push({
      label: "Total Overrun",
      value: totalOverrun > 0 ? `+${totalOverrun.toFixed(1)}h` : "0h",
      sub: breachDays > 0 ? `${breachDays} breach day${breachDays !== 1 ? "s" : ""}` : "All within SLA",
      color: col,
      icon: "⏱️",
    });
  }

  if (!tiles.length) {
    el.classList.add("hidden");
    return;
  }
  el.classList.remove("hidden");
  el.innerHTML = tiles.map(t => `
    <div class="rounded-lg bg-Ccard/40 border border-Cborder/40 p-2.5 flex items-center gap-2.5"
         style="border-left:3px solid ${t.color};">
      <div class="text-lg flex-shrink-0">${t.icon}</div>
      <div class="min-w-0 flex-1">
        <div class="text-[8px] uppercase tracking-widest text-Cmuted font-semibold">${_esc(t.label)}</div>
        <div class="text-[12px] font-bold truncate" style="color:${t.color};" title="${_esc(t.value)}">${_esc(t.value)}</div>
        <div class="text-[9px] text-Cmuted truncate">${_esc(t.sub)}</div>
      </div>
    </div>
  `).join("");
}

// ── Sign-Off Readiness Checklist ─────────────────────────────
// Replaces the flat YES/NO/COND tile with an itemized blocker list.
// Each rule: criterion · target · actual · pass/warn/fail status.
function _renderSignoffChecklist(data) {
  const wrap = document.getElementById("exec-signoff-checklist");
  const toggle = document.getElementById("exec-signoff-toggle");
  if (!wrap || !toggle) return;

  const kpis = data?.kpis || {};
  const dc   = (window.appData.batch || {}).data_coverage || {};
  const findings = window._lastFindings || [];
  const critCount = findings.filter(f => f.level === "critical").length;
  const warnCount = findings.filter(f => f.level === "warning").length;
  const sowLoaded = !!(window.appData.sowCompare);
  const evidenceDays = dc.date_span_days || 0;
  const confidence = _n(kpis.confidence_pct ?? 100);
  const winRate = _n(kpis.window_compliance ?? kpis.batch_rate ?? 100);
  const slaQuality = (window.appData.batch || {}).sla_source?.quality || "—";

  // Each rule: { label, target, actual, pass, severity }
  // severity: "blocker" → fails block sign-off, "warning" → conditional only
  const rules = [
    {
      label: "Evidence coverage ≥ 30 days",
      actual: `${evidenceDays}d`,
      pass: evidenceDays >= 30,
      severity: "blocker",
      hint: evidenceDays < 30 ? `Only ${evidenceDays} day(s) on file — need ${30 - evidenceDays} more for full audit confidence.` : "Sufficient history.",
    },
    {
      label: "Confidence ≥ 90%",
      actual: confidence.toFixed(0) + "%",
      pass: confidence >= 90,
      severity: confidence >= 75 ? "warning" : "blocker",
      hint: confidence < 90 ? "Low evidence quality — recheck source data." : "High confidence in measurements.",
    },
    {
      label: "No critical findings",
      actual: `${critCount} critical`,
      pass: critCount === 0,
      severity: "blocker",
      hint: critCount > 0 ? `${critCount} blocker finding(s) require resolution.` : "Clean.",
    },
    {
      label: "Window breach rate < 20%",
      actual: `${(100 - winRate).toFixed(1)}% breached`,
      pass: (100 - winRate) < 20,
      severity: (100 - winRate) > 30 ? "blocker" : "warning",
      hint: (100 - winRate) >= 20 ? "Batch windows missing SLA on too many days." : "Within tolerance.",
    },
    {
      label: "SLA source verified",
      actual: slaQuality,
      pass: !["assumed", "default", "—"].includes(String(slaQuality).toLowerCase()),
      severity: "warning",
      hint: ["assumed", "default", "—"].includes(String(slaQuality).toLowerCase())
        ? "SLA values inferred — confirm with customer contract." : "Source-backed SLA.",
    },
    {
      label: "SOW volume validated",
      actual: sowLoaded ? "loaded" : "N/A",
      pass: sowLoaded,
      severity: "warning",
      hint: sowLoaded ? "SOW comparison active." : "Upload SOW for commercial accountability.",
    },
    {
      label: "No warnings outstanding",
      actual: `${warnCount} warning(s)`,
      pass: warnCount === 0,
      severity: "warning",
      hint: warnCount > 0 ? "Review warnings before final approval." : "All clear.",
    },
  ];

  const blockers = rules.filter(r => !r.pass && r.severity === "blocker").length;
  const warnings = rules.filter(r => !r.pass && r.severity === "warning").length;
  const passed   = rules.filter(r => r.pass).length;

  // Render rows
  wrap.innerHTML = `
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
      ${rules.map(r => {
        const icon = r.pass ? "✓" : (r.severity === "blocker" ? "✗" : "⚠");
        const col  = r.pass ? "#10d96e" : (r.severity === "blocker" ? "#f43f5e" : "#f59e0b");
        return `
          <div class="flex items-start gap-2 px-2.5 py-1.5 rounded bg-Ccard/40 border border-Cborder/30 text-[11px]">
            <div class="font-mono font-bold text-sm leading-none mt-0.5" style="color:${col};">${icon}</div>
            <div class="flex-1 min-w-0">
              <div class="flex items-baseline justify-between gap-2">
                <span class="text-Cwhite font-medium">${_esc(r.label)}</span>
                <span class="font-bold text-[10px] flex-shrink-0" style="color:${col};">${_esc(r.actual)}</span>
              </div>
              ${!r.pass ? `<div class="text-[9px] text-Cmuted mt-0.5 leading-tight">${_esc(r.hint)}</div>` : ""}
            </div>
          </div>`;
      }).join("")}
    </div>
    <div class="flex items-center gap-3 mt-3 pt-2 border-t border-Cborder/40 text-[10px] text-Cmuted">
      <span class="text-Cgreen font-bold">${passed}/${rules.length} passed</span>
      ${blockers > 0 ? `<span class="text-Cred font-bold">${blockers} blocker${blockers !== 1 ? "s" : ""}</span>` : ""}
      ${warnings > 0 ? `<span class="text-Camber font-bold">${warnings} warning${warnings !== 1 ? "s" : ""}</span>` : ""}
    </div>
  `;

  // Toggle behavior — install once
  if (!toggle._wired) {
    toggle.addEventListener("click", () => {
      const isHidden = wrap.classList.contains("hidden");
      wrap.classList.toggle("hidden");
      toggle.textContent = isHidden ? "Hide checklist ▴" : "Show checklist ▾";
    });
    toggle._wired = true;
  }
}

// ── Predictive SLA Breach Forecaster ─────────────────────────
// Linear regression over the existing daily window data.
// Projects the next 14 days; flags the day it crosses SLA.
function _renderExecForecast(windowData, slaHrs) {
  const el = document.getElementById("exec-forecast");
  if (!el) return;
  windowData = (Array.isArray(windowData) ? windowData : [])
    .filter(w => w && w.run_date && Number.isFinite(Number(w.elapsed_hrs ?? w.total_hrs)));

  if (windowData.length < 2) {
    el.innerHTML = `<div class="h-full flex flex-col items-center justify-center text-center px-6">
      <div class="text-3xl opacity-40 mb-2">📈</div>
      <div class="text-[12px] text-Cmuted leading-snug">Need 2+ days of run data to forecast — current: ${windowData.length} day(s).</div>
    </div>`;
    return;
  }

  // Sort by date
  windowData = windowData.slice().sort((a, b) => new Date(a.run_date) - new Date(b.run_date));
  const dates = windowData.map(w => new Date(w.run_date));
  const ys = windowData.map(w => Number(w.elapsed_hrs > 0 ? w.elapsed_hrs : w.total_hrs));
  const xs = dates.map((_, i) => i);

  // Simple linear regression: y = a + b*x
  const n = xs.length;
  const sumX = xs.reduce((a, b) => a + b, 0);
  const sumY = ys.reduce((a, b) => a + b, 0);
  const meanX = sumX / n, meanY = sumY / n;
  let num = 0, den = 0;
  for (let i = 0; i < n; i++) {
    num += (xs[i] - meanX) * (ys[i] - meanY);
    den += (xs[i] - meanX) ** 2;
  }
  const slope = den === 0 ? 0 : num / den;
  const intercept = meanY - slope * meanX;

  // Residual std-dev for confidence band
  let ssRes = 0;
  for (let i = 0; i < n; i++) {
    const yhat = intercept + slope * xs[i];
    ssRes += (ys[i] - yhat) ** 2;
  }
  const sigma = n > 2 ? Math.sqrt(ssRes / (n - 2)) : 0;
  const ci = 1.96 * sigma; // 95% band

  // Forecast next 14 days
  const horizon = 14;
  const fxs = [], fys = [], fLow = [], fHigh = [], fDates = [];
  const lastDate = dates[dates.length - 1];
  for (let i = 1; i <= horizon; i++) {
    const x = (n - 1) + i;
    const yhat = intercept + slope * x;
    fxs.push(x);
    fys.push(yhat);
    fLow.push(yhat - ci);
    fHigh.push(yhat + ci);
    const d = new Date(lastDate);
    d.setDate(d.getDate() + i);
    fDates.push(d);
  }

  // Find first day forecast crosses SLA
  let breachIdx = -1;
  for (let i = 0; i < fys.length; i++) {
    if (fys[i] > slaHrs) { breachIdx = i; break; }
  }

  // Plot via Plotly
  if (typeof Plotly === "undefined") return;
  const fmtDate = d => d.toISOString().slice(0, 10);

  const traces = [
    // Confidence band (high)
    {
      x: fDates.map(fmtDate), y: fHigh, type: "scatter", mode: "lines",
      line: { width: 0 }, showlegend: false, hoverinfo: "skip", name: "Upper",
    },
    // Confidence band (low) — fill to previous (high)
    {
      x: fDates.map(fmtDate), y: fLow, type: "scatter", mode: "lines",
      line: { width: 0 }, fill: "tonexty", fillcolor: "rgba(167,139,250,0.18)",
      showlegend: false, hoverinfo: "skip", name: "Lower",
    },
    // Historical line
    {
      x: dates.map(fmtDate), y: ys, type: "scatter", mode: "lines+markers",
      line: { color: "#22d3ee", width: 2 },
      marker: { size: 5, color: "#22d3ee" },
      name: "Actual",
      hovertemplate: "%{x}<br>%{y:.1f}h<extra></extra>",
    },
    // Forecast line
    {
      x: fDates.map(fmtDate), y: fys, type: "scatter", mode: "lines",
      line: { color: "#a78bfa", width: 2, dash: "dot" },
      name: "Forecast",
      hovertemplate: "%{x}<br>≈ %{y:.1f}h<extra></extra>",
    },
  ];

  // Mark predicted breach day
  if (breachIdx >= 0) {
    traces.push({
      x: [fmtDate(fDates[breachIdx])], y: [fys[breachIdx]],
      type: "scatter", mode: "markers+text",
      marker: { size: 12, color: "#f43f5e", symbol: "diamond", line: { color: "#fff", width: 1 } },
      text: ["⚠ Breach"], textposition: "top center",
      textfont: { color: "#f43f5e", size: 10, family: "Sora" },
      showlegend: false, hoverinfo: "skip",
    });
  }

  const layout = {
    margin: { l: 35, r: 10, t: 10, b: 35 },
    plot_bgcolor: "rgba(0,0,0,0)", paper_bgcolor: "rgba(0,0,0,0)",
    font: { family: "Sora", color: "#a8b3d9", size: 9 },
    xaxis: { gridcolor: "rgba(33,48,96,0.4)", color: "#6b7db3", showspikes: false, tickangle: -30, tickfont: { size: 8 } },
    yaxis: { gridcolor: "rgba(33,48,96,0.4)", color: "#6b7db3", title: { text: "Runtime (hrs)", font: { size: 9 } } },
    showlegend: true,
    legend: { orientation: "h", y: -0.22, font: { size: 9, color: "#a8b3d9" } },
    shapes: [{
      type: "line", xref: "paper", x0: 0, x1: 1, y0: slaHrs, y1: slaHrs,
      line: { color: "#f43f5e", width: 1.5, dash: "dash" },
    }],
    annotations: [{
      xref: "paper", x: 0.99, y: slaHrs, xanchor: "right", yanchor: "bottom",
      text: `SLA ${slaHrs}h`, showarrow: false,
      font: { color: "#f43f5e", size: 9 },
    }],
  };
  if (breachIdx >= 0) {
    const daysOut = breachIdx + 1;
    layout.annotations.push({
      xref: "paper", yref: "paper", x: 0.02, y: 0.97, xanchor: "left", yanchor: "top",
      text: `<b>Predicted breach in ~${daysOut} day${daysOut !== 1 ? "s" : ""}</b><br>` +
            `<span style="font-size:9px;">${fmtDate(fDates[breachIdx])} · ${fys[breachIdx].toFixed(1)}h</span>`,
      showarrow: false, align: "left",
      font: { color: "#f43f5e", size: 11, family: "Sora" },
      bgcolor: "rgba(244,63,94,0.12)", bordercolor: "#f43f5e", borderwidth: 1, borderpad: 4,
    });
  } else {
    const trendDir = slope > 0 ? "↑ rising" : slope < 0 ? "↓ improving" : "→ flat";
    const trendCol = slope > 0 ? "#f59e0b" : slope < 0 ? "#10d96e" : "#22d3ee";
    layout.annotations.push({
      xref: "paper", yref: "paper", x: 0.02, y: 0.97, xanchor: "left", yanchor: "top",
      text: `<b style="color:${trendCol};">${trendDir}</b> · No breach in 14d horizon<br>` +
            `<span style="font-size:9px;color:#a8b3d9;">Δ ${(slope * 7).toFixed(2)}h / week</span>`,
      showarrow: false, align: "left",
      font: { color: trendCol, size: 11, family: "Sora" },
      bgcolor: `${trendCol}1a`, bordercolor: trendCol, borderwidth: 1, borderpad: 4,
    });
  }

  Plotly.newPlot(el, traces, layout, { responsive: true, displayModeBar: false });
}


// ── Correlation Analysis ──────────────────────────────────────
async function triggerCorrelation() {
  const btn = document.getElementById("cor-refresh-btn");
  if (btn) { btn.disabled = true; btn.textContent = "Analysing…"; }

  const payload = {
    batch_kpis:    window.appData.batch?.kpis    || window.appData.batch    || null,
    top_jobs:      window.appData.batch?.top_jobs     || [],
    top_breaches:  window.appData.batch?.top_breaches || [],
    resource_kpis: window.appData.resource?.kpis || window.appData.resource || null,
    servers:       window.appData.servers || [],
    anomalies:     window.appData.batch?.anomalies    || [],
    sub_stats:     window.appData.batch?.sub_stats    || [],
  };

  try {
    const res  = await fetch("/api/correlate", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    if (!res.ok) { toast("error", "Correlation error", (await res.text()).slice(0, 200)); return; }
    const data = await res.json();
    _renderCorrelationResults(data);
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.2" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" /></svg> Run Correlation`;
    }
  }
}

function _renderCorrelationResults(data) {
  const rows    = data.rows    || [];
  const summary = data.summary || {};
  const insights= data.insights|| [];

  // Summary pills
  setText("cor-total",        summary.total        ?? "—");
  setText("cor-resource-pct", summary.resource_caused_pct != null ? summary.resource_caused_pct + "%" : "—");
  setText("cor-sched-pct",    summary.scheduling_pct       != null ? summary.scheduling_pct       + "%" : "—");
  setText("cor-constraint",   summary.primary_constraint   || "—");

  // ── Cross-tab warning banner when resource data is missing ──
  const warnBanner = document.getElementById("cor-resource-warning");
  if (summary.resource_data_available === false || summary.resource_warning) {
    if (warnBanner) {
      warnBanner.classList.remove("hidden");
      warnBanner.innerHTML = `<span class="text-Camber mr-1">⚠️</span>${_esc(summary.resource_warning || "Resource data not yet available — root cause classification is based on scheduling analysis only.")}`;
    }
  } else if (warnBanner) {
    warnBanner.classList.add("hidden");
  }

  // Insights strip
  const insEl = document.getElementById("cor-insights-list");
  if (insEl) {
    if (insights.length) {
      insEl.classList.remove("hidden");
      insEl.innerHTML = insights.map((t) =>
        `<div class="flex items-start gap-2 text-xs text-Cwhite">
           <span class="text-Cblue mt-0.5 shrink-0">→</span><span>${_esc(t)}</span>
         </div>`
      ).join("");
    } else {
      insEl.classList.add("hidden");
    }
  }

  // Empty / table visibility
  const emptyEl = document.getElementById("cor-empty");
  const tableEl = document.getElementById("cor-table-wrap");
  if (!rows.length) {
    if (emptyEl) emptyEl.classList.remove("hidden");
    if (tableEl) tableEl.classList.add("hidden");
  } else {
    if (emptyEl) emptyEl.classList.add("hidden");
    if (tableEl) tableEl.classList.remove("hidden");

    const RISK_BADGE = {
      CRITICAL: "bg-Cred/20 text-Cred",
      HIGH:     "bg-Camber/20 text-Camber",
      MEDIUM:   "bg-Cblue/20 text-Cblue",
      LOW:      "bg-Cgreen/20 text-Cgreen",
    };
    const STATUS_COL = { BREACH: "text-Cred font-bold", AT_RISK: "text-Camber font-semibold", OK: "text-Cgreen" };
    const RC_LABEL = {
      RESOURCE_CPU: "Resource (CPU)", RESOURCE_MEM: "Resource (Mem)",
      CAPACITY: "Capacity", SCHEDULING: "Scheduling",
      UNDETERMINED: "Undetermined (no data)", UNKNOWN: "Undetermined (no data)",
    };

    const tbody = document.getElementById("cor-tbody");
    if (tbody) {
      tbody.innerHTML = rows.map((r) =>
        `<tr class="hover:bg-Ccard/40 transition-colors">
          <td class="py-2 pr-3 font-mono text-Cwhite text-[11px]">${_esc(r.job)}</td>
          <td class="py-2 pr-3 ${STATUS_COL[r.status] || "text-Cmuted"}">${r.status}</td>
          <td class="py-2 pr-3 text-right text-Camber">${_n(r.peak_hrs).toFixed(2)}</td>
          <td class="py-2 pr-3 text-Cmuted font-mono text-[11px]">${_esc(r.server)}</td>
          <td class="py-2 pr-3 text-right ${r.cpu_pct != null && r.cpu_pct >= 90 ? "text-Cred font-bold" : r.cpu_pct != null && r.cpu_pct >= 80 ? "text-Camber" : "text-Cmuted"}">${r.cpu_pct != null ? _n(r.cpu_pct).toFixed(0) + '%' : 'N/A'}</td>
          <td class="py-2 pr-3 text-right ${r.mem_pct != null && r.mem_pct >= 90 ? "text-Cred font-bold" : r.mem_pct != null && r.mem_pct >= 70 ? "text-Camber" : "text-Cmuted"}">${r.mem_pct != null ? _n(r.mem_pct).toFixed(0) + '%' : 'N/A'}</td>
          <td class="py-2 pr-3 text-Cmuted">${RC_LABEL[r.root_cause] || r.root_cause}</td>
          <td class="py-2"><span class="px-1.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${RISK_BADGE[r.risk] || ""}">${r.risk}</span></td>
        </tr>`
      ).join("");
    }
  }

  // Donut chart
  _renderCorDonut(summary);
}

function _renderCorDonut(summary) {
  const canvas = document.getElementById("cor-donut-chart");
  if (!canvas || !summary.total) return;

  if (OV_CHARTS.corDonut) OV_CHARTS.corDonut.destroy();

  const labels = ["Resource CPU/Mem", "Scheduling", "Capacity", "Undetermined"];
  const vals   = [
    summary.resource_caused_pct || 0,
    summary.scheduling_pct      || 0,
    summary.capacity_pct        || 0,
    summary.undetermined_pct ?? summary.unknown_pct ?? 0,
  ];
  const colors = [THEME.red, THEME.amber, THEME.blue, THEME.muted];

  OV_CHARTS.corDonut = new Chart(canvas.getContext("2d"), {
    type: "doughnut",
    data: {
      labels, datasets: [{
        data: vals, backgroundColor: colors.map((c) => c + "bb"),
        borderColor: colors, borderWidth: 1,
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: true, cutout: "58%",
      plugins: { legend: { display: false } },
    },
  });

  // Legend
  const legend = document.getElementById("cor-donut-legend");
  if (legend) {
    legend.innerHTML = labels.map((l, i) =>
      `<div class="flex items-center gap-2">
         <span class="w-3 h-3 rounded-full shrink-0" style="background:${colors[i]}"></span>
         <span>${l}: <strong class="text-Cwhite">${vals[i]}%</strong></span>
       </div>`
    ).join("");
  }
}


// ── Red Flags & RCA ───────────────────────────────────────────
async function triggerRedFlags() {
  const btn = document.getElementById("rf-refresh-btn");
  if (btn) { btn.disabled = true; btn.textContent = "Generating…"; }

  const payload = {
    batch_kpis:    window.appData.batch?.kpis    || window.appData.batch    || null,
    resource_kpis: window.appData.resource?.kpis || window.appData.resource || null,
    servers:       window.appData.servers  || [],
    anomalies:     window.appData.batch?.anomalies    || [],
    issues:        window.appData.issues   || [],
    top_breaches:  window.appData.batch?.top_breaches || [],
    sub_stats:     window.appData.batch?.sub_stats    || [],
    // Hardwired interconnection — SLA Matrix output drives matched red flags
    sla_matrix:    window.appData.slaMatrix || null,
  };

  try {
    const res  = await fetch("/api/red-flags", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    if (!res.ok) { toast("error", "Red flags error", (await res.text()).slice(0, 200)); return; }
    const data = await res.json();
    window.appData.redFlags = data;
    _renderRedFlagsResults(data);
    // Cross-pillar cascade — if findings + sla matrix are also loaded, run consultant
    triggerPeConsultant().catch(() => {});
  } catch (err) {
    // Distinguish fetch failures (TypeError) from render-time exceptions
    const isNet = err instanceof TypeError;
    toast("error", isNet ? "Network error" : "Red flags render error", String(err?.message || err));
    if (!isNet) console.error("[red-flags]", err);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M3 3v1.5M3 21v-6m0 0 2.77-.693a9 9 0 0 1 6.208.682l.108.054a9 9 0 0 0 6.086.71l3.114-.732a48.524 48.524 0 0 1-.005-10.499l-3.11.732a9 9 0 0 1-6.085-.711l-.108-.054a9 9 0 0 0-6.208-.682L3 4.5M3 15V4.5"/></svg> Refresh Flags`;
    }
  }
}

function _renderRedFlagsResults(data) {
  // The Red Flags & RCA UI panel was removed (consolidated into PE Findings).
  // Bail early if the DOM is missing so we don't crash on null .innerHTML.
  // Data is still cached on window.appData.redFlags for Final Judgment etc.
  if (!document.getElementById("rf-questions-list")) return;

  const flags  = data.flags       || [];
  const matrix = data.risk_matrix || [];
  const byRisk = data.by_risk     || {};

  // Counts
  setText("rf-critical", byRisk.CRITICAL ?? 0);
  setText("rf-high",     byRisk.HIGH     ?? 0);
  setText("rf-medium",   byRisk.MEDIUM   ?? 0);
  setText("rf-low",      byRisk.LOW      ?? 0);

  const emptyEl = document.getElementById("rf-empty");
  const listEl  = document.getElementById("rf-questions-list");

  if (!flags.length) {
    if (emptyEl) emptyEl.classList.remove("hidden");
    if (listEl)  listEl.classList.add("hidden");
  } else {
    if (emptyEl) emptyEl.classList.add("hidden");
    if (listEl)  listEl.classList.remove("hidden");

    const RISK_COLORS = {
      CRITICAL: { border: "border-Cred",   bg: "bg-Cred/5",   badge: "bg-Cred/20 text-Cred" },
      HIGH:     { border: "border-Camber", bg: "bg-Camber/5", badge: "bg-Camber/20 text-Camber" },
      MEDIUM:   { border: "border-Cblue",  bg: "bg-Cblue/5",  badge: "bg-Cblue/20 text-Cblue" },
      LOW:      { border: "border-Cgreen", bg: "bg-Cgreen/5", badge: "bg-Cgreen/20 text-Cgreen" },
    };

    listEl.innerHTML = flags.map((f) => {
      const s = RISK_COLORS[f.risk] || RISK_COLORS.MEDIUM;
      return `<div class="rounded-xl border-l-4 ${s.border} ${s.bg} border border-Cborder/60 px-4 py-3">
        <div class="flex items-start gap-2.5">
          <span class="text-xs font-bold text-Cmuted mt-0.5 shrink-0 font-mono">${_esc(f.id)}</span>
          <div class="flex-1">
            <div class="flex items-center gap-2 flex-wrap mb-1">
              <span class="text-[10px] font-bold uppercase tracking-wider text-Cmuted">${_esc(f.category)}</span>
              <span class="px-1.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${s.badge}">${f.risk}</span>
              <span class="text-[10px] text-Cmuted font-mono">${_esc(f.data_point)}</span>
            </div>
            <p class="text-xs text-Cmuted mb-1.5 leading-relaxed">${_esc(f.context)}</p>
            <p class="text-xs text-Cwhite font-semibold leading-relaxed">❓ ${_esc(f.question)}</p>
          </div>
        </div>
      </div>`;
    }).join("");
  }

  // Risk matrix
  const matEmptyEl = document.getElementById("rf-matrix-empty");
  const matWrapEl  = document.getElementById("rf-matrix-wrap");
  const matTbody   = document.getElementById("rf-matrix-tbody");
  if (!matrix.length) {
    if (matEmptyEl) matEmptyEl.classList.remove("hidden");
    if (matWrapEl)  matWrapEl.classList.add("hidden");
  } else {
    if (matEmptyEl) matEmptyEl.classList.add("hidden");
    if (matWrapEl)  matWrapEl.classList.remove("hidden");

    const RISK_COL = { CRITICAL: "text-Cred", HIGH: "text-Camber", MEDIUM: "text-Cblue", LOW: "text-Cgreen" };
    if (matTbody) {
      matTbody.innerHTML = matrix.map((m) =>
        `<tr class="hover:bg-Ccard/40 transition-colors">
          <td class="py-2 pr-4 font-semibold text-Cwhite text-xs">${_esc(m.area)}</td>
          <td class="py-2 pr-4 font-bold text-xs uppercase ${RISK_COL[m.risk] || "text-Cmuted"}">${m.risk}</td>
          <td class="py-2 pr-4 text-Cmuted text-xs leading-relaxed">${_esc(m.impact)}</td>
          <td class="py-2 text-Cmuted text-xs leading-relaxed">${_esc(m.recommendation)}</td>
        </tr>`
      ).join("");
    }
  }
}


// ─────────────────────────────────────────────────────────────
// SENIOR PE CONSULTANT — cross-pillar interconnection
// Hardwires SLA Matrix + PE Findings + Red Flags into a single
// consultant verdict. Renders into #pe-consultant-panel.
// ─────────────────────────────────────────────────────────────
async function triggerPeConsultant() {
  // Only run when at least 2 of 3 pillars are loaded — otherwise
  // there is nothing meaningful to interconnect.
  const sm = window.appData.slaMatrix;
  const fd = window.appData.findings;
  const rf = window.appData.redFlags;
  const loaded = [sm, fd, rf].filter(Boolean).length;
  if (loaded < 2) return;

  const payload = {
    sla_matrix:    sm || null,
    findings:      fd || null,
    red_flags:     rf || null,
    batch_kpis:    window.appData.batch?.kpis || null,
    top_jobs:      window.appData.batch?.top_jobs || [],
    top_breaches:  window.appData.batch?.top_breaches || [],
    resource_kpis: window.appData.resource?.kpis || null,
    servers:       window.appData.servers || [],
    customer_name: window.appData.customerName || null,
  };

  try {
    const res = await fetch("/api/pe-consultant", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) return;
    const data = await res.json();
    window.appData.peConsultant = data;
    _renderPeConsultant(data);
  } catch (err) {
    /* silent — consultant is best-effort */
  }
}

function _renderPeConsultant(data) {
  const panels = document.querySelectorAll("[data-pe-consultant-panel]");
  if (!panels.length) return;

  const v = data.consultant || {};
  const links = data.cross_links || [];
  const chains = data.evidence_chain || [];
  const acc = data.accuracy || {};

  const decColor = {
    GO:                "text-Cgreen border-Cgreen/50 bg-Cgreen/10",
    HOLD:              "text-Camber border-Camber/50 bg-Camber/10",
    REMEDIATE:         "text-Cred   border-Cred/50   bg-Cred/10",
    INSUFFICIENT_DATA: "text-Cmuted border-Cborder   bg-Ccard/40",
  }[v.decision] || "text-Cmuted border-Cborder bg-Ccard/40";

  const gradeColor = ({ A: "text-Cgreen", B: "text-Cgreen",
                        C: "text-Camber", D: "text-Cred", F: "text-Cred" })[v.grade] || "text-Cmuted";

  const sevColor = {
    CRITICAL: "border-Cred bg-Cred/10 text-Cred",
    HIGH:     "border-Camber bg-Camber/10 text-Camber",
    MEDIUM:   "border-Cblue bg-Cblue/10 text-Cblue",
    LOW:      "border-Cgreen bg-Cgreen/10 text-Cgreen",
  };

  const linksHtml = links.length ? links.slice(0, 8).map((c) => {
    const sev = sevColor[c.severity] || sevColor.MEDIUM;
    const pill = c.pillars.map((p) =>
      `<span class="px-1.5 py-0.5 rounded bg-Ccard text-[9px] uppercase tracking-wider text-Cmuted">${_esc(p)}</span>`
    ).join(" ");
    const slaBits = c.sla_evidence ? Object.entries(c.sla_evidence)
      .filter(([_, vv]) => vv !== "" && vv !== null && vv !== undefined)
      .map(([k, vv]) => `<span class="text-[10px] text-Cmuted">${_esc(k)}: <span class="text-Cwhite font-mono">${_esc(typeof vv === "number" ? Number(vv).toFixed(2) : vv)}</span></span>`)
      .join(" · ") : "";
    const fEvd = (c.findings_evidence || []).slice(0, 2).map((f) =>
      `<li class="text-[11px] text-Cmuted">⚑ <span class="text-Cwhite">${_esc(f.text)}</span></li>`).join("");
    const rEvd = (c.redflags_evidence || []).slice(0, 2).map((r) =>
      `<li class="text-[11px] text-Cmuted">${_esc(r.id)} · <span class="font-bold ${(sevColor[r.risk]||"").split(" ")[2]||""}">${_esc(r.risk)}</span> — <span class="text-Cwhite">${_esc(r.question)}</span></li>`).join("");
    return `<div class="rounded-xl border ${sev} px-3 py-2.5">
      <div class="flex items-center gap-2 flex-wrap mb-1.5">
        <span class="font-mono font-bold text-xs text-Cwhite">${_esc(c.entity)}</span>
        <span class="px-1.5 py-0.5 rounded text-[9px] uppercase tracking-wider bg-Ccard text-Cmuted">${_esc(c.entity_kind)}</span>
        <span class="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${sev}">${_esc(c.severity)}</span>
        ${pill}
        <span class="ml-auto text-[10px] text-Cmuted">conf ${c.confidence}%</span>
      </div>
      ${slaBits ? `<div class="text-[10px] mb-1">${slaBits}</div>` : ""}
      ${fEvd || rEvd ? `<ul class="space-y-0.5 mt-1">${fEvd}${rEvd}</ul>` : ""}
    </div>`;
  }).join("") : `<p class="text-xs text-Cmuted italic">No cross-pillar overlap detected — pillars are mutually consistent.</p>`;

  const list = (arr, color) => (arr || []).slice(0, 5).map((x) =>
    `<li class="text-[11px] text-Cwhite leading-relaxed before:content-['•'] before:mr-2 before:${color}">${_esc(x)}</li>`).join("");

  const chainHtml = chains.length ? chains.slice(0, 4).map((ch) => {
    const steps = (ch.chain || []).map((s) =>
      `<div class="flex gap-2 text-[11px]">
        <span class="text-Cmuted shrink-0 w-32">${_esc(s.pillar)}</span>
        <span class="text-Cwhite">${_esc(s.fact)}</span>
      </div>`).join("");
    return `<div class="rounded-lg border border-Cborder/60 bg-Ccard/40 px-3 py-2">
      <div class="flex items-center justify-between mb-1.5">
        <span class="font-mono font-bold text-xs text-Cwhite">${_esc(ch.job_name)}</span>
        <span class="text-[10px] text-Camber">${_esc(ch.verdict)}</span>
      </div>
      <div class="space-y-0.5">${steps}</div>
    </div>`;
  }).join("") : "";

  const html = `
    <div class="rounded-2xl border-2 border-Cblue/40 bg-gradient-to-br from-Ccard to-Ccard2 shadow-panel p-6">
      <div class="flex items-start justify-between mb-4 gap-3 flex-wrap">
        <div>
          <div class="flex items-center gap-2 mb-1">
            <span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-Cblue/20 text-Cblue border border-Cblue/40">Senior PE Consultant</span>
            <span class="px-2 py-0.5 rounded-full text-[9px] uppercase tracking-wider bg-Ccard text-Cmuted">${_esc(v.model || "")}</span>
          </div>
          <h2 class="text-base font-bold text-Cwhite">Cross-Pillar Interconnected Verdict</h2>
          <p class="text-[11px] text-Cmuted mt-0.5">SLA Matrix · PE Findings · Red Flags — hardwired & analyzed by senior PE persona</p>
        </div>
        <div class="flex items-center gap-3">
          <div class="text-center">
            <div class="text-[9px] uppercase tracking-wider text-Cmuted">Grade</div>
            <div class="text-3xl font-black ${gradeColor}">${_esc(v.grade)}</div>
          </div>
          <div class="text-center">
            <div class="text-[9px] uppercase tracking-wider text-Cmuted">Score</div>
            <div class="text-3xl font-black text-Cwhite">${(v.score || 0).toFixed(1)}</div>
          </div>
          <div class="text-center">
            <div class="text-[9px] uppercase tracking-wider text-Cmuted">Decision</div>
            <div class="px-2.5 py-1 rounded-lg border font-bold text-sm ${decColor}">${_esc(v.decision)}</div>
          </div>
        </div>
      </div>

      <p class="text-xs text-Cwhite leading-relaxed mb-4 px-3 py-2 rounded-lg bg-Ccard/40 border border-Cborder/40">${_esc(v.headline)}</p>

      <div class="grid lg:grid-cols-3 gap-4 mb-4">
        <div>
          <h3 class="text-[10px] uppercase tracking-widest text-Cred font-bold mb-2">Top Risks</h3>
          <ul class="space-y-1.5">${list(v.top_risks, "text-Cred")}</ul>
        </div>
        <div>
          <h3 class="text-[10px] uppercase tracking-widest text-Camber font-bold mb-2">Predictions</h3>
          <ul class="space-y-1.5">${list(v.predictions, "text-Camber")}</ul>
        </div>
        <div>
          <h3 class="text-[10px] uppercase tracking-widest text-Cgreen font-bold mb-2">Next 48h Actions</h3>
          <ul class="space-y-1.5">${list(v.next_actions, "text-Cgreen")}</ul>
        </div>
      </div>

      <div class="mb-4">
        <h3 class="text-[10px] uppercase tracking-widest text-Cblue font-bold mb-2">
          Cross-Pillar Links (${links.length})
          <span class="ml-2 text-Cmuted font-normal normal-case">— same evidence appearing in 2+ pillars</span>
        </h3>
        <div class="grid md:grid-cols-2 gap-2">${linksHtml}</div>
      </div>

      ${chainHtml ? `<div class="mb-4">
        <h3 class="text-[10px] uppercase tracking-widest text-Cmuted font-bold mb-2">Evidence Chains (per job)</h3>
        <div class="grid md:grid-cols-2 gap-2">${chainHtml}</div>
      </div>` : ""}

      <details class="rounded-lg border border-Cborder/40 bg-Ccard/30 px-3 py-2">
        <summary class="text-[11px] text-Cmuted cursor-pointer hover:text-Cwhite">Full consultant narrative + accuracy signal</summary>
        <pre class="mt-2 text-[11px] text-Cwhite whitespace-pre-wrap font-mono leading-relaxed">${_esc(v.narrative || "")}</pre>
        <div class="mt-2 pt-2 border-t border-Cborder/40 text-[10px] text-Cmuted">
          Coverage: <span class="text-Cwhite font-bold">${acc.coverage_pct || 0}%</span> ·
          Confidence: <span class="text-Cwhite font-bold">${acc.confidence || 0}%</span>
          ${(acc.missing_inputs || []).length ? ` · Missing: <span class="text-Camber">${_esc((acc.missing_inputs || []).join("; "))}</span>` : ""}
          ${(acc.notes || []).length ? `<div class="mt-1">${_esc((acc.notes || []).join(" · "))}</div>` : ""}
        </div>
      </details>

      ${(v.tool_count || 0) > 0 ? `
      <details class="mt-2 rounded-lg border border-Cpurple/30 bg-Cpurple/5 px-3 py-2">
        <summary class="text-[11px] text-Cpurple cursor-pointer hover:text-Cwhite">
          🔍 Agent inspected <span class="font-bold">${v.tool_count}</span> piece${v.tool_count === 1 ? "" : "s"} of evidence — show trace
        </summary>
        <div class="mt-2 space-y-1.5">
          ${(v.agent_trace || []).filter((t) => t.kind === "tool_call").map((t) => {
            const args = t.args && typeof t.args === "object" && Object.keys(t.args).length
              ? Object.entries(t.args).map(([k, vv]) => `${_esc(k)}=${_esc(String(vv))}`).join(" · ")
              : "";
            const result = t.result || {};
            const rowCount = result.n_total != null ? result.n_total
                            : Array.isArray(result.rows) ? result.rows.length : null;
            const errMsg = result.error || "";
            const preview = errMsg
              ? `<span class="text-Cred">${_esc(errMsg)}</span>`
              : (rowCount != null
                   ? `<span class="text-Cgreen">${rowCount} row${rowCount === 1 ? "" : "s"}</span>`
                   : `<span class="text-Cgreen">ok</span>`);
            return `<div class="flex items-start gap-2 text-[11px]">
              <span class="font-mono text-Cpurple shrink-0">${t.step}.</span>
              <div class="flex-1">
                <span class="font-mono text-Cwhite">${_esc(t.name || "?")}</span><span class="text-Cmuted">(${args})</span>
                <span class="ml-2">${preview}</span>
              </div>
            </div>`;
          }).join("")}
        </div>
      </details>` : ""}
    </div>
  `;
  panels.forEach((p) => {
    p.classList.remove("hidden");
    p.innerHTML = html;
  });
}


// ── _lastFindings cached in renderFindings() above ──────────


// ─────────────────────────────────────────────────────────────
// Heatmap render functions
// ─────────────────────────────────────────────────────────────

/**
 * renderSlaHeatmap(data)
 *
 * Renders a Job × Date SLA compliance grid into #sla-heatmap-container.
 *
 * data = {
 *   jobs:  string[],                          // top 40 job names
 *   dates: string[],                          // last 21 run dates (YYYY-MM-DD)
 *   cells: [{job, date, hrs, breach}, ...],   // one entry per job×date
 *   limit: number                             // daily SLA hrs (default 6.0)
 * }
 *
 * Color key:
 *   #0f3d24  → no run (dark green)
 *   #10d96e  → OK (< 85 % of limit)
 *   #f59e0b  → near SLA (85–100 % of limit)
 *   #f43f5e  → BREACH (> limit)
 */
function renderSlaHeatmap(data) {
  const section   = document.getElementById("sla-heatmap-section");
  const container = document.getElementById("sla-heatmap-container");
  if (!container || !data) return;

  const { jobs = [], dates = [], cells = [], limit = 6.0 } = data;
  if (!jobs.length || !dates.length) {
    if (section) section.classList.add("hidden");
    return;
  }

  // Build O(1) lookup: "job||date" → cell object
  const lookup = {};
  for (const c of cells) {
    lookup[`${c.job}||${c.date}`] = c;
  }

  // Shorten date strings: "2024-01-15" → "01-15"
  const fmtDate = (d) => {
    const s = String(d);
    const parts = s.split(/[-/]/);
    if (parts.length === 3) return `${parts[1]}-${parts[2]}`;
    return s.slice(-5);
  };

  // Cell background colour
  const cellColor = (c) => {
    if (!c || c.hrs === null || c.hrs === undefined) return "#0f3d24";
    if (c.breach)                return "#f43f5e";
    if (c.hrs > limit * 0.85)   return "#f59e0b";
    return "#10d96e";
  };

  // Tooltip text
  const cellTitle = (c) => {
    if (!c || c.hrs === null || c.hrs === undefined) return "No run";
    return `${c.hrs.toFixed(2)} h — ${c.breach ? "BREACH" : "OK"}`;
  };

  const shortDates = dates.map(fmtDate);

  let html = `
    <table class="text-[10px] border-collapse min-w-max">
      <thead>
        <tr>
          <th class="sticky left-0 z-10 bg-Ccard text-left pr-3 pb-1 text-Cmuted font-semibold
                      whitespace-nowrap" style="min-width:150px">Job</th>
          ${shortDates.map((d, i) =>
            `<th class="pb-1 px-0.5 text-Cmuted font-normal text-center whitespace-nowrap"
                 title="${_esc(dates[i])}">${_esc(d)}</th>`
          ).join("")}
        </tr>
      </thead>
      <tbody>`;

  for (const job of jobs) {
    html += `<tr class="hover:brightness-125 transition-[filter]">
      <td class="sticky left-0 z-10 bg-Ccard pr-3 py-0.5 text-Cwhite font-mono
                 whitespace-nowrap max-w-[200px] truncate" title="${_esc(job)}">${_esc(job)}</td>
      ${dates.map((date) => {
        const c  = lookup[`${job}||${date}`];
        const bg = cellColor(c);
        const tt = cellTitle(c);
        return `<td class="px-0.5 py-0.5 text-center" title="${tt}" style="min-width:22px">
          <div style="width:20px;height:15px;background:${bg};border-radius:2px;margin:auto"></div>
        </td>`;
      }).join("")}
    </tr>`;
  }

  html += `</tbody></table>`;
  container.innerHTML = html;
  if (section) section.classList.remove("hidden");
}


/**
 * renderHourHeatmap(data)
 *
 * Renders a Sub-App × Hour-of-Day execution density grid into
 * #hour-heatmap-container.  Cell intensity is proportional to
 * the job count for that sub-app × hour combination.
 *
 * data = {
 *   sub_apps: string[],                              // top 10 sub-apps
 *   hours:    number[],                              // [0..23]
 *   cells:    [{sub_app, hour, count, total_hrs}…]   // sparse (missing = no jobs)
 * }
 */
function renderHourHeatmap(data) {
  const section   = document.getElementById("hour-heatmap-section");
  const container = document.getElementById("hour-heatmap-container");
  if (!container || !data) return;

  const { sub_apps = [], hours = [], cells = [] } = data;
  if (!sub_apps.length || !cells.length) {
    if (section) section.classList.add("hidden");
    return;
  }

  // Build lookup: "sub_app||hour" → cell; track global max for normalisation
  const lookup = {};
  let maxCount = 1;
  for (const c of cells) {
    lookup[`${c.sub_app}||${c.hour}`] = c;
    if ((c.count || 0) > maxCount) maxCount = c.count;
  }

  // Hour label "8" → "08:00"
  const fmtHr = (h) => String(h).padStart(2, "0") + ":00";

  // Cell background — low: near-transparent navy, high: vivid cyan
  const cellBg = (c) => {
    if (!c || !c.count) return "rgba(33,48,96,0.25)";
    const t = Math.min(c.count / maxCount, 1);           // 0..1
    const a = (0.10 + t * 0.80).toFixed(2);              // alpha 0.10→0.90
    return `rgba(34,211,238,${a})`;
  };

  const cellTitle = (c) => {
    if (!c || !c.count) return "No jobs";
    return `${c.sub_app} @ ${fmtHr(c.hour)}: ${c.count} job(s), ${(c.total_hrs || 0).toFixed(1)} h total`;
  };

  // Columns: show every other hour label on narrow screens
  const useHours = hours.length ? hours : Array.from({ length: 24 }, (_, i) => i);

  let html = `
    <table class="text-[10px] border-collapse min-w-max">
      <thead>
        <tr>
          <th class="sticky left-0 z-10 bg-Ccard text-left pr-3 pb-1 text-Cmuted font-semibold
                      whitespace-nowrap" style="min-width:130px">Sub-App</th>
          ${useHours.map((h) =>
            `<th class="pb-1 text-Cmuted font-normal text-center whitespace-nowrap"
                 style="min-width:28px;font-size:9px">${fmtHr(h)}</th>`
          ).join("")}
        </tr>
      </thead>
      <tbody>`;

  for (const app of sub_apps) {
    html += `<tr class="hover:brightness-125 transition-[filter]">
      <td class="sticky left-0 z-10 bg-Ccard pr-3 py-0.5 text-Cwhite font-mono
                 whitespace-nowrap max-w-[180px] truncate" title="${_esc(app)}">${_esc(app)}</td>
      ${useHours.map((h) => {
        const c  = lookup[`${app}||${h}`];
        const bg = cellBg(c);
        const tt = cellTitle(c);
        return `<td class="px-0.5 py-0.5" title="${tt}">
          <div style="width:22px;height:16px;border-radius:2px;margin:auto;background:${bg}"></div>
        </td>`;
      }).join("")}
    </tr>`;
  }

  html += `</tbody></table>`;

  // Gradient legend
  const stops = [0.10, 0.26, 0.42, 0.58, 0.74, 0.90]
    .map((a) => `rgba(34,211,238,${a})`)
    .join(",");
  html += `
    <div class="mt-3 flex items-center gap-2.5 text-[10px] text-Cmuted">
      <span>Low</span>
      <div style="height:8px;width:120px;border-radius:4px;
                  background:linear-gradient(to right,${stops})"></div>
      <span>High</span>
      <span class="ml-4 italic">Bright columns = peak scheduling contention windows</span>
    </div>`;

  container.innerHTML = html;
  if (section) section.classList.remove("hidden");
}


// ═══════════════════════════════════════════════════════════════
//  SETTINGS — persistent config + Gemini API key
// ═══════════════════════════════════════════════════════════════

async function loadConfig() {
  try {
    const res  = await fetch("/api/config");
    if (!res.ok) return;
    const cfg  = await res.json();
    window.appData.geminiKey = cfg.gemini_api_key || "";
    window.appData.config    = cfg;               // cache full config for threshold lookups

    // Keep the chart SLA line in sync with the user-configured threshold
    if (cfg.daily_sla_hrs) SLA_DAILY_HRS = Number(cfg.daily_sla_hrs) || 6.0;

    const keyEl = document.getElementById("settings-api-key");
    if (keyEl && cfg.gemini_api_key) keyEl.value = cfg.gemini_api_key;

    const maskedEl = document.getElementById("settings-key-masked");
    if (maskedEl) maskedEl.textContent = cfg.gemini_api_key_masked || "(not set)";

    const nvKeyEl = document.getElementById("settings-nvidia-key");
    if (nvKeyEl && cfg.nvidia_api_key) nvKeyEl.value = cfg.nvidia_api_key;
    const nvMaskedEl = document.getElementById("settings-nvidia-masked");
    if (nvMaskedEl) nvMaskedEl.textContent = cfg.nvidia_api_key_masked || "(not set)";

    const daily    = document.getElementById("cfg-daily-sla");
    const weekly   = document.getElementById("cfg-weekly-sla");
    const biweekly = document.getElementById("cfg-biweekly-sla");
    const monthly  = document.getElementById("cfg-monthly-sla");
    const bench    = document.getElementById("cfg-bench-thresh");
    if (daily    && cfg.daily_sla_hrs)        daily.value    = cfg.daily_sla_hrs;
    if (weekly   && cfg.weekly_sla_hrs)       weekly.value   = cfg.weekly_sla_hrs;
    if (biweekly && cfg.biweekly_sla_hrs)     biweekly.value = cfg.biweekly_sla_hrs;
    if (monthly  && cfg.monthly_sla_hrs)      monthly.value  = cfg.monthly_sla_hrs;
    if (bench    && cfg.benchmark_threshold)  bench.value    = cfg.benchmark_threshold;

    // Restore customer chip from persisted config (set when last Ctrl-M file was uploaded)
    if (cfg.customer_name) {
      applyCustomerName(cfg.customer_name);
    }

    refreshDataStatus();
  } catch (_) {}

}

/** Refresh the AI engine badge in the header (provider + model). */
async function refreshAiStatus() {
  try {
    const res = await fetch("/api/ai-status");
    if (!res.ok) return;
    const s    = await res.json();
    const chip = document.getElementById("ai-status-chip");
    const lbl  = document.getElementById("ai-status-label");
    // AI engine chip is permanently hidden per UX cleanup; only the
    // Verify button remains so users can still live-test the engine.
    if (chip) { chip.classList.add("hidden"); chip.classList.remove("flex"); }
    if (lbl)  { lbl.textContent = ""; }
    const ready = !!(s.nvidia_key || s.gemini_key);
    const verifyBtn = document.getElementById("ai-verify-btn");
    if (verifyBtn) {
      verifyBtn.classList.toggle("hidden", !ready);
    }
  } catch (_) {}
}


/**
 * Live-probe every text model + Vision and render the result in a modal.
 * Confirms the LLM is actually answering — not just that the keys exist.
 */
async function runAiSelfTest() {
  const btn = document.getElementById("ai-verify-btn");
  if (btn) { btn.disabled = true; btn.textContent = "Probing…"; }
  let modal = document.getElementById("ai-selftest-modal");
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "ai-selftest-modal";
    modal.className = "fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm";
    modal.innerHTML = `
      <div class="bg-Ccard border border-Cborder rounded-2xl shadow-panel p-5 w-[640px] max-h-[80vh] overflow-auto">
        <div class="flex items-center justify-between mb-3">
          <h3 class="text-sm font-bold text-Cwhite">AI Engine Live Self-Test</h3>
          <button onclick="document.getElementById('ai-selftest-modal').remove()"
                  class="text-Cmuted hover:text-Cwhite text-lg leading-none">×</button>
        </div>
        <div id="ai-selftest-body" class="text-xs text-Cmuted">Running probes…</div>
      </div>`;
    document.body.appendChild(modal);
  }
  const body = document.getElementById("ai-selftest-body");
  body.innerHTML = '<div class="text-Cblue">⏳ Pinging every model — this can take 10-30 seconds…</div>';

  try {
    const res = await fetch("/api/ai-self-test");
    const data = await res.json();
    const rowFor = (r) => {
      const dot = r.status === "ok"   ? '<span class="w-2 h-2 rounded-full bg-Cgreen inline-block"></span>'
              : r.status === "no_key" ? '<span class="w-2 h-2 rounded-full bg-Cmuted inline-block"></span>'
              :                         '<span class="w-2 h-2 rounded-full bg-Cred inline-block"></span>';
      const stat = r.status === "ok" ? "OK" : r.status === "no_key" ? "no key" : "fail";
      const sample = (r.sample || "").replace(/[<>&]/g, c => ({"<":"&lt;",">":"&gt;","&":"&amp;"}[c]));
      const reasonText = (r.reason || "").replace(/[<>&]/g, c => ({"<":"&lt;",">":"&gt;","&":"&amp;"}[c]));
      const detailLine = r.status === "fail" && reasonText
        ? `<div class="text-[10px] text-Cred/80 mt-0.5 truncate" title="${reasonText}">${reasonText}</div>`
        : "";
      return `<tr class="border-b border-Cborder/40 align-top">
        <td class="py-1 pr-2">${dot}</td>
        <td class="py-1 pr-2 font-mono text-[11px] text-Cwhite">
          ${r.provider}:${r.model}
          ${detailLine}
        </td>
        <td class="py-1 pr-2 text-right ${r.status==='ok'?'text-Cgreen':r.status==='fail'?'text-Cred':'text-Cmuted'}">${stat}</td>
        <td class="py-1 pr-2 text-right text-Cmuted">${r.ms||0}ms</td>
        <td class="py-1 text-Cmuted truncate max-w-[180px]" title="${sample}">${sample}</td>
      </tr>`;
    };

    const v = data.vision || {};
    const visionDot = v.status === "ok" ? "🟢" : v.status === "fail" ? "🔴" : "⚪";
    const visionMetrics = (v.metrics || []).map(m =>
      `<span class="inline-block px-2 py-0.5 mr-1 mb-1 rounded bg-Cpurple/10 border border-Cpurple/30 text-Cpurple text-[10px]">
        ${m.metric_type || "?"}: ${m.max_value ?? m.raw_value ?? "—"}${m.unit||""}
       </span>`).join("");

    body.innerHTML = `
      <div class="mb-3 p-3 rounded-lg bg-Ccard/60 border border-Cborder/40">
        <div class="text-[11px] text-Cmuted mb-1">Summary</div>
        <div class="text-Cwhite font-semibold">
          Text models: ${data.summary.text_ok}/${data.summary.text_total} responding ·
          Vision: ${data.summary.vision_ok ? '<span class="text-Cgreen">OK</span>' : '<span class="text-Cred">not ready</span>'}
        </div>
        <div class="text-[11px] text-Cmuted mt-1">Active model: <span class="font-mono text-Cwhite">${data.summary.active_text_model || '—'}</span></div>
        ${data.summary.promoted_to ? `
          <div class="mt-2 text-[10px] text-Cgreen bg-Cgreen/10 border border-Cgreen/30 rounded px-2 py-1">
            ⚡ Auto-promoted active model to
            <span class="font-mono font-bold">${data.summary.promoted_to}</span>
            — your previous default was unreachable on this account.
            All future calls will use this model first.
          </div>` : ""}
      </div>

      <div class="mb-2 text-[11px] font-bold text-Cwhite uppercase tracking-wider">Text generation (per model probe)</div>
      <table class="w-full text-[11px] mb-4">
        <thead class="text-Cmuted text-[10px]"><tr>
          <th class="py-1"></th><th class="py-1 text-left">Model</th>
          <th class="py-1 text-right">Status</th><th class="py-1 text-right">Latency</th>
          <th class="py-1 text-left">Sample</th>
        </tr></thead>
        <tbody>${(data.text || []).map(rowFor).join("")}</tbody>
      </table>

      <div class="mb-2 text-[11px] font-bold text-Cwhite uppercase tracking-wider">Image → text (Gemini Vision)</div>
      <div class="p-3 rounded-lg bg-Ccard/60 border border-Cborder/40">
        <div>${visionDot} Status: <span class="text-Cwhite">${v.status||'skipped'}</span> · ${v.ms||0}ms</div>
        ${v.error ? `<div class="text-Cred mt-1">${v.error}</div>` : ""}
        ${visionMetrics ? `<div class="mt-2">${visionMetrics}</div>` : ""}
      </div>
    `;
  } catch (err) {
    body.innerHTML = `<div class="text-Cred">Self-test request failed: ${String(err?.message || err)}</div>`;
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Verify"; }
  }
}


/**
 * Run the unified cross-pillar AI judgment. Pulls every cached payload
 * from window.appData (resource, batch, SLA, benchmark, correlation,
 * SOW, red-flags, executive) and POSTs to /api/final-judgment.
 */
async function runFinalJudgment() {
  const btn = document.getElementById("fj-run-btn"); // legacy — may be null
  if (btn) { btn.disabled = true; btn.textContent = "⏳ Computing…"; }
  const stamp = document.getElementById("fj-last-run");
  if (stamp) stamp.textContent = "Last run: computing…";

  const ad = window.appData || {};
  const body = {
    resource:    ad.upload      || null,
    batch:       ad.batch       || null,
    sla_matrix:  ad.slaMatrix   || ad.sla_matrix || null,
    benchmark:   ad.benchmark   || null,
    correlation: ad.correlation || null,
    sow:         ad.sowCompare  || ad.sow         || null,
    redflags:    ad.redflags    || ad.redFlags    || null,
    executive:   ad.executive   || null,
  };

  try {
    const res = await fetch("/api/final-judgment", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(body),
    });
    if (!res.ok) {
      const txt = await res.text();
      toast("error", "Judgment failed", txt.slice(0, 160));
      return;
    }
    const r = await res.json();

    // Reveal result, hide empty state
    document.getElementById("fj-empty")?.classList.add("hidden");
    document.getElementById("fj-result")?.classList.remove("hidden");

    // KPI tiles
    setText("fj-grade",          r.grade || "—");
    setText("fj-score",          (r.score ?? 0).toFixed(1));
    setText("fj-pillars-count",  String((r.pillars_present || []).length));
    const decEl = document.getElementById("fj-decision");
    if (decEl) {
      decEl.textContent = r.decision || "—";
      decEl.className   = "text-base font-extrabold mt-0.5 " + (
        r.decision === "GO"        ? "text-Cgreen" :
        r.decision === "HOLD"      ? "text-Camber" :
        r.decision === "REMEDIATE" ? "text-Cred"   : "text-Cwhite"
      );
    }
    setText("fj-model", r.ai_model || "deterministic");

    // Pillar score chips
    const pwrap = document.getElementById("fj-pillars");
    if (pwrap) {
      pwrap.innerHTML = "";
      Object.entries(r.pillars || {}).forEach(([k, v]) => {
        const tone = v >= 90 ? "text-Cgreen border-Cgreen/40" :
                     v >= 75 ? "text-Cblue  border-Cblue/40"  :
                     v >= 60 ? "text-Camber border-Camber/40" :
                               "text-Cred   border-Cred/40";
        const div = document.createElement("div");
        div.className = `rounded-md border bg-Cbg/40 px-2 py-1.5 ${tone}`;
        div.innerHTML = `<div class="text-[9px] uppercase tracking-widest opacity-70">${k}</div>
                         <div class="text-sm font-bold">${Number(v).toFixed(1)}</div>`;
        pwrap.appendChild(div);
      });
    }

    // Narrative + actions
    const narEl = document.getElementById("fj-narrative");
    if (narEl) narEl.textContent = r.narrative || r.verdict || "";
    const actEl = document.getElementById("fj-actions");
    if (actEl) {
      actEl.innerHTML = "";
      (r.next_actions || []).forEach(a => {
        const li = document.createElement("li");
        li.textContent = a;
        actEl.appendChild(li);
      });
    }

    toast("success", "Final judgment ready",
          `${r.grade || "?"} · ${r.decision || "?"} · ${(r.pillars_present || []).length} pillars`);
    if (stamp) {
      const t = new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit", second:"2-digit"});
      stamp.textContent = `Last run: ${t} · ${r.grade || "?"} · ${r.decision || "?"}`;
    }
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
    if (stamp) stamp.textContent = "Last run: failed";
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "⚡ Run Final Judgment"; }
  }
}

function loadSettings() { loadConfig(); _loadAzureStatusBadge(); }

function toggleSettingsKey() {
  const el = document.getElementById("settings-api-key");
  if (!el) return;
  el.type = el.type === "password" ? "text" : "password";
}

async function saveApiKey() {
  const keyEl    = document.getElementById("settings-api-key");
  const statusEl = document.getElementById("settings-key-status");
  if (!keyEl || !statusEl) return;

  const key = keyEl.value.trim();
  if (!key) { statusEl.textContent = "⚠ Key is empty"; statusEl.className = "text-xs text-Camber"; return; }

  statusEl.textContent = "Validating…";
  statusEl.className   = "text-xs text-Cmuted";

  try {
    const vRes  = await fetch("/api/config/test-key", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ api_key: key }),
    });
    const vData = await vRes.json();

    if (!vData.valid) {
      statusEl.textContent = `❌ Invalid: ${vData.error || "unknown"}`;
      statusEl.className   = "text-xs text-Cred";
      return;
    }

    await fetch("/api/config", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gemini_api_key: key }),
    });

    window.appData.geminiKey = key;
    refreshDataStatus();

    const maskedEl = document.getElementById("settings-key-masked");
    if (maskedEl) maskedEl.textContent = key.slice(0, 6) + "••••" + key.slice(-4);

    statusEl.textContent = `✅ Valid — ${vData.recommended || "model ready"}`;
    statusEl.className   = "text-xs text-Cgreen";
    toast("success", "API key saved", "Gemini Vision + AI Insights are now active");
  } catch (err) {
    statusEl.textContent = "❌ Network error";
    statusEl.className   = "text-xs text-Cred";
  }
}

function toggleNvidiaKey() {
  const el = document.getElementById("settings-nvidia-key");
  if (!el) return;
  el.type = el.type === "password" ? "text" : "password";
}

async function saveNvidiaKey() {
  const keyEl    = document.getElementById("settings-nvidia-key");
  const statusEl = document.getElementById("settings-nvidia-status");
  if (!keyEl || !statusEl) return;

  const key = keyEl.value.trim();
  if (!key) { statusEl.textContent = "⚠ Key is empty"; statusEl.className = "text-xs text-Camber"; return; }

  statusEl.textContent = "Validating…";
  statusEl.className   = "text-xs text-Cmuted";

  try {
    const vRes  = await fetch("/api/config/test-nvidia-key", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ api_key: key }),
    });
    const vData = await vRes.json();

    if (!vData.valid) {
      statusEl.textContent = `❌ Invalid: ${vData.error || "unknown"}`;
      statusEl.className   = "text-xs text-Cred";
      return;
    }

    await fetch("/api/config", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nvidia_api_key: key }),
    });

    const maskedEl = document.getElementById("settings-nvidia-masked");
    if (maskedEl) maskedEl.textContent = key.slice(0, 8) + "••••" + key.slice(-4);

    statusEl.textContent = `✅ Valid — ${vData.model || "model ready"}`;
    statusEl.className   = "text-xs text-Cgreen";
    toast("success", "NVIDIA key saved", "LLM fallback for resource reports is now active");
  } catch (err) {
    statusEl.textContent = "❌ Network error";
    statusEl.className   = "text-xs text-Cred";
  }
}

async function saveConfig() {
  const daily    = parseFloat(document.getElementById("cfg-daily-sla")?.value    || 6);
  const weekly   = parseFloat(document.getElementById("cfg-weekly-sla")?.value   || 17);
  const biweekly = parseFloat(document.getElementById("cfg-biweekly-sla")?.value || 17);
  const monthly  = parseFloat(document.getElementById("cfg-monthly-sla")?.value  || 17);
  const bench    = parseFloat(document.getElementById("cfg-bench-thresh")?.value || 10);
  const statusEl = document.getElementById("settings-save-status");

  try {
    await fetch("/api/config", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        daily_sla_hrs:    daily,
        weekly_sla_hrs:   weekly,
        biweekly_sla_hrs: biweekly,
        monthly_sla_hrs:  monthly,
        benchmark_threshold: bench,
      }),
    });
    if (statusEl) { statusEl.textContent = "✅ Saved"; statusEl.className = "text-xs text-Cgreen"; }
    toast("success", "Settings saved", "SLA defaults and benchmark threshold updated");
  } catch (_) {
    if (statusEl) { statusEl.textContent = "❌ Failed to save"; statusEl.className = "text-xs text-Cred"; }
  }
}

// ═══════════════════════════════════════════════════════════════
//  AZURE MONITOR — SPN live-fetch integration
// ═══════════════════════════════════════════════════════════════

function toggleAzureSecret() {
  const el = document.getElementById("az-client-secret");
  if (el) el.type = el.type === "password" ? "text" : "password";
}

async function saveAzureConfig() {
  const statusEl = document.getElementById("azure-config-test-status");
  const payload = {
    azure_tenant_id:       (document.getElementById("az-tenant-id")?.value       || "").trim(),
    azure_client_id:       (document.getElementById("az-client-id")?.value       || "").trim(),
    azure_client_secret:   (document.getElementById("az-client-secret")?.value   || "").trim(),
    azure_subscription_id: (document.getElementById("az-subscription-id")?.value || "").trim(),
    azure_resource_group:  (document.getElementById("az-resource-group")?.value  || "").trim(),
  };

  if (!payload.azure_tenant_id || !payload.azure_client_id || !payload.azure_client_secret || !payload.azure_subscription_id) {
    if (statusEl) { statusEl.textContent = "⚠ Fill in Tenant ID, Client ID, Secret, and Subscription ID"; statusEl.className = "text-xs text-Camber"; }
    return;
  }

  try {
    await fetch("/api/config", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (statusEl) { statusEl.textContent = "✅ Credentials saved"; statusEl.className = "text-xs text-Cgreen"; }
    // Refresh badge
    _loadAzureStatusBadge();
    toast("success", "Azure credentials saved", "Click 'Test Connection' to verify SPN access.");
  } catch (_) {
    if (statusEl) { statusEl.textContent = "❌ Save failed"; statusEl.className = "text-xs text-Cred"; }
  }
}

async function validateAzureSpn() {
  const statusEl = document.getElementById("azure-config-test-status");
  const payload = {
    tenant_id:       (document.getElementById("az-tenant-id")?.value       || "").trim(),
    client_id:       (document.getElementById("az-client-id")?.value       || "").trim(),
    client_secret:   (document.getElementById("az-client-secret")?.value   || "").trim(),
    subscription_id: (document.getElementById("az-subscription-id")?.value || "").trim(),
  };

  if (!payload.tenant_id || !payload.client_id || !payload.client_secret || !payload.subscription_id) {
    if (statusEl) { statusEl.textContent = "⚠ Fill all four fields before testing"; statusEl.className = "text-xs text-Camber"; }
    return;
  }

  if (statusEl) { statusEl.textContent = "Testing…"; statusEl.className = "text-xs text-Cmuted"; }
  try {
    const res  = await fetch("/api/azure/validate-spn", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (data.valid) {
      if (statusEl) { statusEl.textContent = `✅ ${data.message || "SPN authenticated"}  (${data.vm_count_sample || 0}+ VMs found)`; statusEl.className = "text-xs text-Cgreen"; }
      toast("success", "Azure SPN valid", data.message || "Connection successful");
    } else {
      const hint = data.hint ? ` — ${data.hint}` : "";
      if (statusEl) { statusEl.textContent = `❌ ${(data.error || "auth failed").slice(0, 80)}${hint}`; statusEl.className = "text-xs text-Cred"; }
      toast("error", "Azure SPN invalid", data.hint || data.error || "Check credentials");
    }
  } catch (err) {
    if (statusEl) { statusEl.textContent = `❌ Network error: ${err?.message || err}`; statusEl.className = "text-xs text-Cred"; }
  }
}

async function _loadAzureStatusBadge() {
  try {
    const res  = await fetch("/api/azure/status");
    const data = await res.json();
    const badge = document.getElementById("azure-config-status-badge");
    if (!badge) return;
    if (data.configured) {
      badge.textContent = "✅ Configured";
      badge.className   = "text-[10px] px-2 py-0.5 rounded-full border border-Cgreen/40 text-Cgreen";
    } else {
      badge.textContent = "Not configured";
      badge.className   = "text-[10px] px-2 py-0.5 rounded-full border border-Cmuted/40 text-Cmuted";
    }
    // Pre-fill previews in the inputs (only show if already saved)
    const fields = ["tenant_id", "client_id", "subscription_id", "resource_group"];
    fields.forEach(f => {
      const el = document.getElementById(`az-${f.replace("_","-")}`);
      if (el && data[`azure_${f}_preview`] && data[`azure_${f}_set`]) {
        el.placeholder = data[`azure_${f}_preview`] + " (saved)";
      }
    });
    return data.configured;
  } catch (_) { return false; }
}

function openAzureModal() {
  _loadAzureStatusBadge().then(configured => {
    const modal       = document.getElementById("azure-fetch-modal");
    const notConf     = document.getElementById("azure-modal-not-configured");
    const form        = document.getElementById("azure-modal-form");
    const statusDiv   = document.getElementById("azure-fetch-status");
    if (modal) modal.classList.remove("hidden");
    if (notConf) notConf.classList.toggle("hidden", !!configured);
    if (form)   form.classList.toggle("hidden",    !configured);
    if (statusDiv) { statusDiv.textContent = ""; statusDiv.classList.add("hidden"); }
  });
}

function closeAzureModal() {
  const modal = document.getElementById("azure-fetch-modal");
  if (modal) modal.classList.add("hidden");
}

async function runAzureFetch() {
  const btn      = document.getElementById("azure-fetch-btn");
  const statusEl = document.getElementById("azure-fetch-status");
  const hours    = parseInt(document.getElementById("azure-modal-hours")?.value || "24");
  const rg       = (document.getElementById("azure-modal-rg")?.value || "").trim();

  if (btn) { btn.disabled = true; btn.textContent = "Fetching…"; }
  if (statusEl) { statusEl.textContent = `Contacting Azure Monitor — pulling last ${hours}h of metrics…`; statusEl.classList.remove("hidden"); statusEl.className = "text-xs text-Cmuted"; }

  try {
    const body = { hours_back: hours };
    if (rg) body.resource_group = rg;

    const res  = await fetch("/api/azure/fetch-resources", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const text = await res.text();
    let payload;
    try { payload = JSON.parse(text); } catch { payload = { detail: text }; }

    if (!res.ok) {
      if (statusEl) { statusEl.textContent = `❌ ${payload?.detail || `HTTP ${res.status}`}`; statusEl.className = "text-xs text-Cred"; }
      toast("error", "Azure fetch failed", payload?.detail || `HTTP ${res.status}`);
      return;
    }

    // Feed into the same resource review rendering pipeline
    window.appData.resource = payload;
    window._execCache = null;
    closeAzureModal();
    setActiveView("resource");

    const rBody = document.getElementById("resource-review-body");
    const rEmpty = document.getElementById("resource-empty");
    if (rBody)  rBody.classList.remove("hidden");
    if (rEmpty) rEmpty.classList.add("hidden");

    renderResourceReview(payload);
    triggerGenerateFindings().catch(() => {});

    const k = payload.kpis || {};
    toast("success", `Azure: ${payload.vm_count || k.total_servers || "?"} VMs fetched`,
          `Grade ${k.fleet_grade || "?"} · Last ${hours}h average · ${rg || "all RGs"}`);

  } catch (err) {
    if (statusEl) { statusEl.textContent = `❌ Network error: ${err?.message || err}`; statusEl.className = "text-xs text-Cred"; }
    toast("error", "Network error", String(err?.message || err));
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Fetch Metrics"; }
  }
}


// ═══════════════════════════════════════════════════════════════
//  SLA MATRIX
// ═══════════════════════════════════════════════════════════════

function initSlaModeSelect() {
  const sel = document.getElementById("sla-mode-select");
  const customField = document.getElementById("sla-custom-field");
  if (!sel || !customField) return;
  sel.addEventListener("change", () => {
    customField.classList.toggle("hidden", sel.value !== "custom");
  });
}

async function triggerSlaMatrix() {
  const btn = document.getElementById("sla-run-btn");
  if (btn) { btn.disabled = true; btn.textContent = "Calculating…"; }

  const batchData = window.appData.batch;
  if (!batchData) {
    document.getElementById("sla-empty")?.classList.remove("hidden");
    if (btn) { btn.disabled = false; btn.textContent = "Calculate SLA Matrix"; }
    toast("warning", "No batch data", "Upload a Ctrl-M file on the Upload page first.");
    return;
  }

  // Prefer the full-dataset SLA Matrix embedded in the batch response — it has
  // job_baselines / outliers / resource_linked from EVERY run, not just the
  // truncated top_jobs sample we'd send via the JSON endpoint.
  if (batchData.sla_matrix && batchData.sla_matrix.job_baselines) {
    _renderSlaMatrix(batchData.sla_matrix);
    if (btn) { btn.disabled = false; btn.textContent = "Calculate SLA Matrix"; }
    return;
  }

  const mode      = document.getElementById("sla-mode-select")?.value || "daily";
  const customHrs = parseFloat(document.getElementById("sla-custom-hrs")?.value || 6);

  // Use all available job data
  const rowMap = new Map();
  for (const r of [...(batchData.top_jobs || []), ...(batchData.top_breaches || [])]) {
    const k = r.Job_Name || r.job_name || "";
    if (k && !rowMap.has(k)) rowMap.set(k, r);
  }
  const rows = [...rowMap.values()];

  const payload = { rows, sla_mode: mode, sla_hrs: mode === "custom" ? customHrs : 0 };

  try {
    const res  = await fetch("/api/sla-matrix/json", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) { toast("error", "SLA Matrix error", (await res.text()).slice(0, 200)); return; }
    const data = await res.json();
    _renderSlaMatrix(data);
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Calculate SLA Matrix"; }
  }
}

function _renderSlaMatrix(data) {
  document.getElementById("sla-empty")?.classList.add("hidden");
  document.getElementById("sla-kpi-row")?.classList.remove("hidden");

  // Use window compliance as headline when available (matches Executive Dashboard)
  const headlineComp = data.compliance_pct;
  const compColor = headlineComp >= 95 ? "text-Cgreen" :
                    headlineComp >= 80 ? "text-Camber" : "text-Cred";
  const compEl = document.getElementById("slak-compliance");
  if (compEl) {
    compEl.textContent = _n(headlineComp).toFixed(1) + "%";
    compEl.className = `text-2xl font-bold ${compColor}`;
  }
  // Show window context if available (X of Y days breached)
  const compSubEl = document.getElementById("slak-compliance-sub");
  if (compSubEl && data.window_total_days != null && data.window_breach_days != null) {
    const pass = data.window_total_days - data.window_breach_days;
    compSubEl.textContent = `${pass}/${data.window_total_days} days pass · Window`;
    compSubEl.className = `text-[10px] ${data.window_breach_days > 0 ? "text-Cred" : "text-Cmuted"}`;
  }
  setText("slak-total",  String(data.total_runs));

  const brEl = document.getElementById("slak-breach");
  if (brEl) { brEl.textContent = String(data.breaching_runs); brEl.className = `text-2xl font-bold ${data.breaching_runs > 0 ? "text-Cred" : "text-Cgreen"}`; }
  const arEl = document.getElementById("slak-atrisk");
  if (arEl) { arEl.textContent = String(data.at_risk_runs); arEl.className = `text-2xl font-bold ${data.at_risk_runs > 0 ? "text-Camber" : "text-Cgreen"}`; }
  setText("slak-limit", _n(data.sla_limit_hrs).toFixed(2) + "h");
  // explicit_sla_matrix = true ONLY when per-job contract rows from an uploaded
  // SLA file were matched. Schedule-type ceilings alone do NOT qualify.
  const isPerJob = data.explicit_sla_matrix === true;
  const limitSubEl = document.getElementById("slak-limit-sub");
  if (limitSubEl) {
    if (isPerJob) {
      limitSubEl.textContent = "SLA file + mode fallback";
      limitSubEl.className   = "text-[10px] mt-0.5 font-semibold text-Cgreen";
    } else {
      limitSubEl.textContent = "Assumed — no SLA file";
      limitSubEl.className   = "text-[10px] mt-0.5 font-semibold text-Camber";
    }
  }

  // Show assumed-SLA warning banner when no customer SLA file with contracts is active
  const banner    = document.getElementById("sla-assumed-banner");
  const bannerDtl = document.getElementById("sla-assumed-detail");
  if (banner) {
    if (isPerJob) {
      banner.classList.add("hidden");
    } else {
      banner.classList.remove("hidden");
      if (bannerDtl) {
        const hasCeilNote = (data.sla_label || "").includes("Schedule");
        const ceilNote = hasCeilNote
          ? "Schedule-type ceilings from the SLA intelligence file are available, but no per-job contract rows were matched for these jobs. "
          : "";
        bannerDtl.textContent =
          `${ceilNote}Unmatched jobs use the assumed ${_n(data.sla_limit_hrs).toFixed(2)}h global ceiling ` +
          `(${data.sla_label || "global mode"}). ` +
          `Upload a customer SLA matrix with per-job contract rows for accurate per-job compliance.`;
      }
    }
  }

  const wEl = document.getElementById("slak-worst");
  if (wEl) {
    wEl.textContent = data.worst_job ? `${data.worst_job} (${_n(data.worst_hrs).toFixed(2)}h)` : "—";
    wEl.title = data.worst_job ? `+${_n(data.worst_margin_hrs).toFixed(2)}h over SLA` : "";
  }

  // Breach detail — show a CRUX, not 200 rows.
  const detailWrap = document.getElementById("sla-detail-wrap");
  const tbody      = document.getElementById("sla-breach-tbody");
  const countLabel = document.getElementById("sla-breach-count-label");
  if (detailWrap) {
    detailWrap.querySelectorAll("[data-breach-crux],[data-breach-toggle]").forEach((n) => n.remove());
  }
  if (data.breaches?.length) {
    _renderSlaBreachCrux(data, detailWrap, tbody, countLabel);
  } else {
    if (detailWrap) detailWrap.classList.add("hidden");
  }

  // Store for findings engine
  window.appData.slaMatrix = data;
  refreshDataStatus();

  // Hardwired cross-pillar cascade — SLA Matrix is now the freshest signal,
  // so refresh PE Findings and Red Flags so they cite the same evidence,
  // then run the Senior PE Consultant for the unified verdict.
  (async () => {
    try { await triggerGenerateFindings(); } catch (e) {}
    try { await triggerRedFlags();         } catch (e) {}
    try { await triggerPeConsultant();     } catch (e) {}
  })();

  // ── SLA compliance donut + job buffer bars (graphical) ──
  _renderSlaCharts(data);

  // Job summary
  //   Rule 3: if 100% compliance with no breaches and no at-risk runs, the
  //           per-job table is just noise — replace it with a single sentence.
  //   Rule 2: otherwise show top 10 by peak runtime, with a "view all" toggle.
  const jobWrap  = document.getElementById("sla-job-wrap");
  const jobTbody = document.getElementById("sla-job-tbody");
  // Clean any prior summary/toggle blocks so re-renders don't stack
  if (jobWrap) {
    jobWrap.querySelectorAll("[data-job-summary],[data-job-more]").forEach((n) => n.remove());
  }
  const summary100 =
    _n(data.compliance_pct) >= 100 &&
    (data.breaching_runs || 0) === 0 &&
    (data.at_risk_runs   || 0) === 0;

  if (data.job_summary?.length) {
    if (jobWrap) jobWrap.classList.remove("hidden");
    const tableEl = jobTbody?.closest("table");

    // Show SLA source column header only when per-job SLA file was used
    const srcHdr = document.getElementById("sla-src-col-hdr");
    if (srcHdr) srcHdr.classList.toggle("hidden", !isPerJob);

    if (summary100) {
      // Suppress the table — one-line summary is enough
      if (jobTbody) jobTbody.innerHTML = "";
      if (tableEl) tableEl.classList.add("hidden");
      const line = document.createElement("div");
      line.dataset.jobSummary = "1";
      line.className = "text-[12px] text-Cgreen font-semibold py-3";
      line.textContent =
        `${data.total_runs} runs across ${data.job_summary.length} jobs · 0 breaches · 0 at-risk — all within SLA ceiling.`;
      jobWrap.appendChild(line);
    } else if (jobTbody) {
      if (tableEl) tableEl.classList.remove("hidden");
      const sorted = [...data.job_summary].sort((a, b) => (_n(b.peak_hrs) || 0) - (_n(a.peak_hrs) || 0));
      const MAX_ROWS = 10;
      const visible = sorted.slice(0, MAX_ROWS);
      const overflow = sorted.length - visible.length;

      const rowHtml = (j) => {
        const bCol = j.buffer_pct >= 30 ? "text-Cgreen" : j.buffer_pct >= 0 ? "text-Camber" : "text-Cred";
        const rCol = j.breach_rate > 20 ? "text-Cred"   : j.breach_rate > 0 ? "text-Camber" : "text-Cgreen";
        const slaLimitCell = `<td class="py-2 pr-4 text-right text-Cblue">${_n(j.sla_limit || j.sla_limit_hrs || data.sla_limit_hrs).toFixed(2)}</td>`;
        // SLA source badge — only shown when per-job SLA file is active
        let srcCell = "";
        if (isPerJob) {
          const src = j.sla_source || "global";
          const srcColor = src === "sla_matrix" ? "text-Cgreen" : src === "customer_fallback" ? "text-Cblue" : "text-Camber";
          const srcLabel = { sla_matrix: "SLA File", customer_fallback: "Schedule Type", assumed: "Assumed", global: "Global" }[src] || src;
          srcCell = `<td class="py-2 text-right ${srcColor} font-semibold text-[10px]">${srcLabel}</td>`;
        }
        return `<tr class="border-b border-Cborder/40 hover:bg-Ccard/40">
          <td class="py-2 pr-4 font-mono text-Cwhite text-[11px]">${_esc(j.job_name)}</td>
          <td class="py-2 pr-4 text-right text-Cmuted">${j.runs}</td>
          <td class="py-2 pr-4 text-right text-Camber font-semibold">${_n(j.peak_hrs).toFixed(2)}</td>
          <td class="py-2 pr-4 text-right text-Cmuted">${_n(j.avg_hrs).toFixed(2)}</td>
          ${slaLimitCell}
          <td class="py-2 pr-4 text-right ${bCol} font-semibold">${_n(j.buffer_pct).toFixed(1)}%</td>
          <td class="py-2 pr-4 text-right ${j.breach_runs > 0 ? "text-Cred font-bold" : "text-Cgreen"}">${j.breach_runs}</td>
          <td class="py-2 ${isPerJob ? "pr-4" : ""} text-right ${rCol}">${_n(j.breach_rate).toFixed(1)}%</td>
          ${srcCell}
        </tr>`;
      };
      jobTbody.innerHTML = visible.map(rowHtml).join("");

      if (overflow > 0) {
        const more = document.createElement("div");
        more.dataset.jobMore = "1";
        more.className = "mt-2 flex items-center justify-end";
        more.innerHTML = `<button type="button" class="text-[11px] font-semibold text-Cblue hover:underline">View all ${sorted.length} jobs ▾</button>`;
        const btn = more.querySelector("button");
        let expanded = false;
        btn.addEventListener("click", () => {
          expanded = !expanded;
          jobTbody.innerHTML = (expanded ? sorted : visible).map(rowHtml).join("");
          btn.textContent = expanded ? `Collapse to top ${MAX_ROWS} ▴` : `View all ${sorted.length} jobs ▾`;
        });
        jobWrap.appendChild(more);
      }
    }
  } else {
    if (jobWrap) jobWrap.classList.add("hidden");
  }

  // ── Adaptive per-job baselines (computed from this very file) ──
  _renderSlaBaselines(data);
  _renderSlaOutliers(data);
  _renderSlaResourceLink(data);
}

/** Per-job adaptive baseline table — shows what the dashboard learnt.
 *  Rule 2: cap default render at 5 most-demanding jobs; collapse the rest. */
function _renderSlaBaselines(data) {
  const wrap  = document.getElementById("sla-baseline-wrap");
  const tbody = document.getElementById("sla-baseline-tbody");
  const cnt   = document.getElementById("sla-baseline-count");
  const bls   = data?.job_baselines || null;
  if (!wrap || !tbody) return;
  // Clean prior toggle blocks so re-renders don't stack
  wrap.querySelectorAll("[data-baseline-more]").forEach((n) => n.remove());
  const entries = bls ? Object.entries(bls) : [];
  if (!entries.length) { wrap.classList.add("hidden"); return; }
  wrap.classList.remove("hidden");
  if (cnt) cnt.textContent = `${entries.length} job${entries.length === 1 ? "" : "s"}`;
  // Sort by expected_hrs descending — most demanding jobs first
  entries.sort((a, b) => (b[1].expected_hrs || 0) - (a[1].expected_hrs || 0));

  const MAX_ROWS = 5;
  const visible = entries.slice(0, MAX_ROWS);
  const overflow = entries.length - visible.length;

  const rowHtml = ([job, b]) => {
    const sample = b.sample_size_ok
      ? `<span class="text-Cgreen font-semibold">${b.runs}</span>`
      : `<span class="text-Camber" title="Need ≥ 3 runs for a confident baseline">${b.runs}</span>`;
    return `<tr class="border-b border-Cborder/40 hover:bg-Ccard/40">
      <td class="py-2 pr-4 font-mono text-Cwhite text-[11px]">${_esc(job)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${b.runs}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${_n(b.avg_hrs).toFixed(2)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${_n(b.std_hrs).toFixed(2)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${_n(b.p95_hrs).toFixed(2)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${_n(b.max_hrs).toFixed(2)}</td>
      <td class="py-2 pr-4 text-right text-Cpurple font-semibold">${_n(b.expected_hrs).toFixed(2)}</td>
      <td class="py-2 text-center">${sample}</td>
    </tr>`;
  };
  tbody.innerHTML = visible.map(rowHtml).join("");

  if (overflow > 0) {
    const more = document.createElement("div");
    more.dataset.baselineMore = "1";
    more.className = "mt-2 flex items-center justify-end";
    more.innerHTML = `<button type="button" class="text-[11px] font-semibold text-Cblue hover:underline">View all ${entries.length} jobs ▾</button>`;
    const btn = more.querySelector("button");
    let expanded = false;
    btn.addEventListener("click", () => {
      expanded = !expanded;
      tbody.innerHTML = (expanded ? entries : visible).map(rowHtml).join("");
      btn.textContent = expanded ? `Collapse to top ${MAX_ROWS} ▴` : `View all ${entries.length} jobs ▾`;
    });
    wrap.appendChild(more);
  }
}

/** Runs that exceeded the per-job baseline (z ≥ 2) but stayed under global SLA.
 *  Suppression: only render the *critical* outliers by default (z ≥ 3 OR
 *  margin ≥ 25% over expected), then offer a toggle to expand the rest.
 *  Hard cap at top 10 even when expanded was not requested — show all on demand. */
function _renderSlaOutliers(data) {
  const wrap  = document.getElementById("sla-outliers-wrap");
  const tbody = document.getElementById("sla-outliers-tbody");
  const cnt   = document.getElementById("sla-outliers-count");
  const out   = data?.outliers || [];
  if (!wrap || !tbody) return;
  // Clean any prior toggle/summary blocks so re-renders don't stack
  wrap.querySelectorAll("[data-outliers-more],[data-outliers-summary]").forEach((n) => n.remove());
  if (!out.length) { wrap.classList.add("hidden"); return; }
  wrap.classList.remove("hidden");

  // Sort by severity (z desc, then margin desc) so the worst is always on top
  const sorted = [...out].sort((a, b) => {
    const za = _n(a.outlier_z), zb = _n(b.outlier_z);
    if (zb !== za) return zb - za;
    return _n(b.expected_margin_hrs) - _n(a.expected_margin_hrs);
  });

  // Critical filter: z ≥ 3 (3-sigma) OR margin ≥ 25% over expected baseline.
  const isCritical = (r) => {
    const z = _n(r.outlier_z);
    const marginPct = _n(r.expected_hrs) > 0
      ? (_n(r.expected_margin_hrs) / _n(r.expected_hrs)) * 100
      : 0;
    return z >= 3 || marginPct >= 25;
  };
  const critical = sorted.filter(isCritical);
  const moderate = sorted.filter((r) => !isCritical(r));

  if (cnt) {
    cnt.textContent = critical.length
      ? `${critical.length} critical · ${out.length} total`
      : `${out.length} run${out.length === 1 ? "" : "s"}`;
  }

  const rowHtml = (r) => {
    const z = _n(r.outlier_z);
    const zCol = z >= 3 ? "text-Cred font-bold" : "text-Camber font-semibold";
    return `<tr class="border-b border-Cborder/40 hover:bg-Ccard/40">
      <td class="py-2 pr-4 font-mono text-Cwhite text-[11px]">${_esc(r.job_name)}</td>
      <td class="py-2 pr-4 text-Cmuted">${_esc(r.run_date)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${_esc(r.start_time)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${_esc(r.end_time)}</td>
      <td class="py-2 pr-4 text-right text-Camber font-semibold">${_n(r.run_hrs).toFixed(2)}</td>
      <td class="py-2 pr-4 text-right text-Cpurple">${_n(r.expected_hrs).toFixed(2)}</td>
      <td class="py-2 pr-4 text-right text-Camber font-semibold">+${_n(r.expected_margin_hrs).toFixed(2)}</td>
      <td class="py-2 text-right ${zCol}">${z.toFixed(1)}</td>
    </tr>`;
  };

  const tableEl = tbody.closest("table");

  if (!critical.length) {
    // Nothing severe enough to act on — collapse the table to one sentence.
    tbody.innerHTML = "";
    if (tableEl) tableEl.classList.add("hidden");
    const line = document.createElement("div");
    line.dataset.outliersSummary = "1";
    line.className = "text-[12px] text-Camber font-semibold py-3";
    line.textContent =
      `${out.length} mild outlier${out.length === 1 ? "" : "s"} (z 2–3, < 25% over baseline) — informational only, no action required.`;
    (tableEl?.parentNode || wrap).insertBefore(line, tableEl);
    return;
  }

  if (tableEl) tableEl.classList.remove("hidden");
  tbody.innerHTML = critical.map(rowHtml).join("");

  if (moderate.length > 0) {
    const more = document.createElement("div");
    more.dataset.outliersMore = "1";
    more.className = "mt-2 flex items-center justify-end";
    more.innerHTML = `<button type="button" class="text-[11px] font-semibold text-Cblue hover:underline">View ${moderate.length} mild outlier${moderate.length === 1 ? "" : "s"} ▾</button>`;
    const btn = more.querySelector("button");
    let expanded = false;
    btn.addEventListener("click", () => {
      expanded = !expanded;
      tbody.innerHTML = (expanded ? sorted : critical).map(rowHtml).join("");
      btn.textContent = expanded
        ? `Hide mild outliers ▴`
        : `View ${moderate.length} mild outlier${moderate.length === 1 ? "" : "s"} ▾`;
    });
    wrap.appendChild(more);
  }
}

/** Resource correlation for breaches + outliers (was the fleet hot at that hour?).
 *  Suppression rules:
 *   - Rule 1: if all rows share one verdict, replace the table with a one-line summary.
 *   - Rule 2: if 2+ verdicts but >15 rows, show top 15 and collapse the rest.
 */
function _renderSlaResourceLink(data) {
  const wrap  = document.getElementById("sla-reslink-wrap");
  const tbody = document.getElementById("sla-reslink-tbody");
  const cnt   = document.getElementById("sla-reslink-count");
  const linked = data?.resource_linked || [];
  if (!wrap || !tbody) return;
  if (!linked.length) { wrap.classList.add("hidden"); return; }
  wrap.classList.remove("hidden");
  if (cnt) cnt.textContent = `${linked.length} run${linked.length === 1 ? "" : "s"}`;

  // Rule 1 — uniform-verdict suppression
  const verdicts = linked.map((r) => r.resource_signal?.verdict || "—");
  const uniqueVerdicts = [...new Set(verdicts)];
  const tableEl = tbody.closest("table");

  // Remove any prior summary block we injected so we don't duplicate
  const priorSummary = wrap.querySelector("[data-reslink-summary]");
  if (priorSummary) priorSummary.remove();
  const priorMore = wrap.querySelector("[data-reslink-more]");
  if (priorMore) priorMore.remove();

  if (uniqueVerdicts.length === 1) {
    const v = uniqueVerdicts[0];
    const tone = v === "RESOURCE_LINK" ? "text-Cred"
              : v === "TIMING_PRESSURE" ? "text-Camber"
              : "text-Cgreen";
    const msg = v === "ISOLATED"
      ? `All ${linked.length} runs are ISOLATED — no fleet pressure detected, no variation worth tabulating.`
      : `All ${linked.length} runs share verdict ${v} — no variation to compare.`;
    tbody.innerHTML = "";
    if (tableEl) tableEl.classList.add("hidden");
    const summary = document.createElement("div");
    summary.dataset.reslinkSummary = "1";
    summary.className = `text-[12px] ${tone} font-semibold py-3`;
    summary.textContent = msg;
    (tableEl?.parentNode || wrap).insertBefore(summary, tableEl);
    return;
  }
  if (tableEl) tableEl.classList.remove("hidden");

  // Sort by verdict severity, then by run_hrs
  const order = { RESOURCE_LINK: 0, TIMING_PRESSURE: 1, ISOLATED: 2 };
  linked.sort((a, b) => {
    const va = order[a.resource_signal?.verdict] ?? 99;
    const vb = order[b.resource_signal?.verdict] ?? 99;
    if (va !== vb) return va - vb;
    return (b.run_hrs || 0) - (a.run_hrs || 0);
  });

  // Rule 2 — row count cap
  const MAX_ROWS = 15;
  const visible = linked.slice(0, MAX_ROWS);
  const overflow = linked.length - visible.length;

  const rowHtml = (r) => {
    const s = r.resource_signal || {};
    const verdictClass = s.verdict === "RESOURCE_LINK" ? "text-Cred font-bold"
                       : s.verdict === "TIMING_PRESSURE" ? "text-Camber font-semibold"
                       : "text-Cmuted";
    const cpuCls = (s.fleet_cpu || 0) >= 80 ? "text-Cred font-bold" : "text-Cmuted";
    const memCls = (s.fleet_mem || 0) >= 80 ? "text-Cred font-bold" : "text-Cmuted";
    const hosts = (s.critical_hosts || []).slice(0, 3).map(_esc).join(", ") || "—";
    return `<tr class="border-b border-Cborder/40 hover:bg-Ccard/40">
      <td class="py-2 pr-4 font-mono text-Cwhite text-[11px]">${_esc(r.job_name)}</td>
      <td class="py-2 pr-4 text-Cmuted">${_esc(r.run_date)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${r.start_hour ?? "—"}h</td>
      <td class="py-2 pr-4 text-right text-Cwhite font-semibold">${_n(r.run_hrs).toFixed(2)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${s.hot_hour_jobs ?? 0}</td>
      <td class="py-2 pr-4 text-right ${cpuCls}">${_n(s.fleet_cpu).toFixed(1)}%</td>
      <td class="py-2 pr-4 text-right ${memCls}">${_n(s.fleet_mem).toFixed(1)}%</td>
      <td class="py-2 pr-4 text-Cmuted text-[11px]">${hosts}</td>
      <td class="py-2 text-center"><span class="${verdictClass}">${s.verdict || "—"}</span></td>
    </tr>`;
  };

  tbody.innerHTML = visible.map(rowHtml).join("");

  if (overflow > 0) {
    const more = document.createElement("div");
    more.dataset.reslinkMore = "1";
    more.className = "mt-2 flex items-center justify-end";
    more.innerHTML = `
      <button type="button" class="text-[11px] font-semibold text-Cblue hover:underline">
        View all ${linked.length} rows ▾
      </button>`;
    const btn = more.querySelector("button");
    let expanded = false;
    btn.addEventListener("click", () => {
      expanded = !expanded;
      tbody.innerHTML = (expanded ? linked : visible).map(rowHtml).join("");
      btn.textContent = expanded
        ? `Collapse to top ${MAX_ROWS} ▴`
        : `View all ${linked.length} rows ▾`;
    });
    wrap.appendChild(more);
  }
}

// ── SLA breach "crux" renderer ────────────────────────────────
function _renderSlaBreachCrux(data, detailWrap, tbody, countLabel) {
  if (!detailWrap) return;
  detailWrap.classList.remove("hidden");

  const breachRows = data.breaches.filter((r) => r.status === "BREACH");
  const atRiskRows = data.breaches.filter((r) => r.status === "AT_RISK");

  // Aggregate per job: count breaches/at-risks, find peak runtime + worst date
  const byJob = new Map();
  for (const r of data.breaches) {
    const k = r.job_name || "\u2014";
    const cur = byJob.get(k) || { job: k, sub_app: r.sub_application || "\u2014",
      breach: 0, atrisk: 0, peak: 0, peak_margin: 0, peak_date: "" };
    if (r.status === "BREACH") cur.breach++;
    else if (r.status === "AT_RISK") cur.atrisk++;
    const hrs = _n(r.run_hrs) || 0;
    if (hrs > cur.peak) {
      cur.peak = hrs;
      cur.peak_margin = _n(r.breach_margin_hrs) || 0;
      cur.peak_date = r.run_date || "";
    }
    byJob.set(k, cur);
  }
  const jobs = [...byJob.values()].sort((a, b) =>
    (b.breach - a.breach) || (b.peak_margin - a.peak_margin));
  const topJobs = jobs.slice(0, 5);

  if (countLabel) {
    countLabel.textContent =
      `${breachRows.length} breach · ${atRiskRows.length} at-risk · ${jobs.length} job${jobs.length !== 1 ? "s" : ""} affected`;
  }

  // Crux: one-line headline + per-job pills
  const crux = document.createElement("div");
  crux.dataset.breachCrux = "1";
  crux.className = "mb-3 p-3 rounded-lg bg-Cred/5 border border-Cred/20";
  const worst = topJobs[0];
  const headline = worst
    ? `<span class="text-Cred">▲</span> <span class="font-bold text-Cwhite">${_esc(worst.job)}</span> is the worst offender — ${worst.breach} breach${worst.breach !== 1 ? "es" : ""}, peak <span class="text-Cred font-bold">${worst.peak.toFixed(2)}h</span> (+${worst.peak_margin.toFixed(2)}h over SLA) on ${_esc(worst.peak_date)}.`
    : "";
  const pillsHtml = topJobs.map((j) => {
    const riskPart = j.atrisk ? `<span class="text-Camber">${j.atrisk} risk</span>` : "";
    return `<div class="px-2.5 py-1.5 rounded-md bg-Ccard border border-Cborder text-[11px] flex items-center gap-2">
      <span class="font-mono text-Cwhite">${_esc(j.job)}</span>
      <span class="text-Cmuted">·</span>
      <span class="text-Cred font-bold">${j.breach} breach</span>
      ${riskPart}
      <span class="text-Cmuted">peak ${j.peak.toFixed(2)}h</span>
    </div>`;
  }).join("");
  crux.innerHTML =
    `<div class="text-[12px] text-Cmuted leading-snug mb-2">${headline}</div>` +
    `<div class="flex flex-wrap gap-2">${pillsHtml}</div>`;

  const hdrRow = detailWrap.querySelector("h3")?.parentElement;
  if (hdrRow && hdrRow.parentElement) {
    hdrRow.parentElement.insertBefore(crux, hdrRow.nextSibling);
  } else {
    detailWrap.prepend(crux);
  }

  // Render only the 5 worst rows by default; toggle to expand to full list.
  const tableEl = tbody?.closest("table");
  const tableWrap = tableEl?.parentElement;

  const sortedRows = [...data.breaches].sort((a, b) => {
    const sa = a.status === "BREACH" ? 0 : 1;
    const sb = b.status === "BREACH" ? 0 : 1;
    if (sa !== sb) return sa - sb;
    return (_n(b.breach_margin_hrs) || 0) - (_n(a.breach_margin_hrs) || 0);
  });
  const PREVIEW = 5;
  const previewRows = sortedRows.slice(0, PREVIEW);
  const hiddenCount = sortedRows.length - previewRows.length;

  const rowHtml = (r) => {
    const sColor = r.status === "BREACH" ? "text-Cred font-bold" : "text-Camber font-semibold";
    const mColor = r.breach_margin_hrs > 0 ? "text-Cred font-bold" : "text-Camber";
    const ddBtn = window.deepDiveBtn ? window.deepDiveBtn({
      title:    `Breach: ${r.job_name}`,
      question: `Why did job '${r.job_name}' breach SLA on ${r.run_date}? It ran ${_n(r.run_hrs).toFixed(2)}h vs the ${_n(r.sla_limit_hrs).toFixed(1)}h limit (margin +${_n(r.breach_margin_hrs).toFixed(2)}h). Use get_job_history, get_resource_linked_runs and get_host_metrics to determine the root cause.`,
      scope:    "breach",
      context:  { job_name: r.job_name, run_date: r.run_date, run_hrs: r.run_hrs,
                  sla_limit_hrs: r.sla_limit_hrs, status: r.status },
      label:    "Why",
    }) : "";
    return `<tr class="border-b border-Cborder/40 hover:bg-Ccard/40">
      <td class="py-2 pr-4 font-mono text-Cwhite text-[11px]">${_esc(r.job_name)}</td>
      <td class="py-2 pr-4 text-Cmuted text-[11px]">${_esc(r.sub_application)}</td>
      <td class="py-2 pr-4 text-Cmuted">${_esc(r.run_date)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${_esc(r.start_time)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${_esc(r.end_time)}</td>
      <td class="py-2 pr-4 text-right font-semibold text-Camber">${_n(r.run_hrs).toFixed(2)}</td>
      <td class="py-2 pr-4 text-right text-Cmuted">${_n(r.sla_limit_hrs).toFixed(2)}</td>
      <td class="py-2 pr-4 text-right ${mColor}">${r.breach_margin_hrs > 0 ? "+" : ""}${_n(r.breach_margin_hrs).toFixed(2)}</td>
      <td class="py-2 text-center"><span class="${sColor}">${r.status}</span> ${ddBtn}</td>
    </tr>`;
  };
  if (tbody) tbody.innerHTML = previewRows.map(rowHtml).join("");

  if (hiddenCount > 0 && tbody) {
    const toggle = document.createElement("div");
    toggle.dataset.breachToggle = "1";
    toggle.className = "mt-2 text-center";
    const btn = document.createElement("button");
    btn.className = "text-[11px] text-Cblue hover:text-Cwhite hover:underline";
    btn.textContent = `Show all ${sortedRows.length} breach/at-risk rows ▾`;
    let expanded = false;
    btn.addEventListener("click", () => {
      expanded = !expanded;
      if (expanded) {
        tbody.innerHTML = sortedRows.map(rowHtml).join("");
        btn.textContent = `Show top ${PREVIEW} only ▴`;
      } else {
        tbody.innerHTML = previewRows.map(rowHtml).join("");
        btn.textContent = `Show all ${sortedRows.length} breach/at-risk rows ▾`;
      }
    });
    toggle.appendChild(btn);
    (tableWrap?.parentElement || detailWrap).appendChild(toggle);
  }
}

// ── SLA Matrix graphical charts ──────────────────────────────
let _slaCompDonut = null, _slaBufferBars = null;

function _renderSlaCharts(data) {
  const chartWrap = document.getElementById("sla-charts-wrap");
  if (!chartWrap || typeof Chart === "undefined") return;
  chartWrap.classList.remove("hidden");

  // 1) Compliance donut — window-level (days pass vs breach) when available,
  //    falls back to per-run counts (OK/AT_RISK/BREACH) otherwise.
  const donutCanvas = document.getElementById("sla-comp-donut");
  if (donutCanvas) {
    let dd;
    if (data.window_total_days != null && data.window_breach_days != null) {
      const passDays   = data.window_total_days - data.window_breach_days;
      const breachDays = data.window_breach_days;
      dd = {
        labels:   ["Pass Days", "Breach Days"],
        datasets: [{
          data: [passDays, breachDays],
          backgroundColor: [THEME.green, THEME.red],
          borderColor: [THEME.card], borderWidth: 3,
        }],
      };
    } else {
      const ok   = data.ok_runs        || 0;
      const risk = data.at_risk_runs   || 0;
      const br   = data.breaching_runs || 0;
      dd = {
        labels:   ["OK", "At Risk", "Breach"],
        datasets: [{
          data: [ok, risk, br],
          backgroundColor: [THEME.green, THEME.amber, THEME.red],
          borderColor: [THEME.card], borderWidth: 3,
        }],
      };
    }
    if (_slaCompDonut) { _slaCompDonut.data = dd; _slaCompDonut.update(); }
    else {
      _slaCompDonut = new Chart(donutCanvas, {
        type: "doughnut", data: dd,
        options: {
          cutout: "65%",
          plugins: { legend: { display: false },
            tooltip: { callbacks: { label: (c) => ` ${c.label}: ${c.raw} runs` } },
          },
        },
      });
    }
  }

  // 2) Job buffer horizontal bars (top 12 jobs by peak)
  const barCanvas = document.getElementById("sla-buffer-bars");
  if (barCanvas && data.job_summary?.length) {
    const top12 = data.job_summary.slice(0, 12);
    const names   = top12.map((j) => j.job_name?.length > 20 ? j.job_name.slice(0, 18) + "…" : (j.job_name || "?"));
    const buffers = top12.map((j) => +j.buffer_pct);
    const bColors = buffers.map((b) => b < 0 ? THEME.red : (b < 15 ? THEME.amber : THEME.green));

    const bd = {
      labels: names,
      datasets: [{
        label: "SLA Buffer %",
        data: buffers,
        backgroundColor: bColors.map((c) => hexA(c, 0.75)),
        borderColor: bColors, borderWidth: 1,
        borderRadius: 3, barPercentage: 0.75,
      }],
    };

    if (_slaBufferBars) { _slaBufferBars.data = bd; _slaBufferBars.update(); }
    else {
      _slaBufferBars = new Chart(barCanvas, {
        type: "bar", data: bd,
        options: {
          indexAxis: "y",
          responsive: true, maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: { callbacks: { label: (c) => ` Buffer: ${c.parsed.x.toFixed(1)}%` } },
          },
          scales: {
            x: {
              title: { display: true, text: "Buffer %", color: THEME.muted, font: { size: 10 } },
              ticks: { color: THEME.muted, font: { size: 9 } },
              grid: { color: hexA(THEME.border, 0.3) },
            },
            y: {
              ticks: { color: THEME.muted, font: { family: '"JetBrains Mono"', size: 9 } },
              grid: { display: false },
            },
          },
        },
      });
    }
  }
}


// ═══════════════════════════════════════════════════════════════
//  UI BENCHMARK COMPARISON
// ═══════════════════════════════════════════════════════════════

function initBenchmarkUploader() {
  const dz    = document.getElementById("bench-drop-zone");
  const input = document.getElementById("bench-file-input");
  if (!dz || !input) return;

  dz.addEventListener("click", () => input.click());
  input.addEventListener("change", (e) => {
    const f = e.target.files?.[0];
    if (f) uploadBenchmarkFile(f);
    input.value = "";
  });
  ["dragenter", "dragover"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); dz.classList.add("border-Cpurple","bg-Cpurple/5"); })
  );
  ["dragleave", "dragend"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); dz.classList.remove("border-Cpurple","bg-Cpurple/5"); })
  );
  dz.addEventListener("drop", (e) => {
    e.preventDefault(); e.stopPropagation();
    dz.classList.remove("border-Cpurple", "bg-Cpurple/5");
    const f = e.dataTransfer?.files?.[0];
    if (f) uploadBenchmarkFile(f);
  });
}

async function uploadBenchmarkFile(file) {
  const statusEl = document.getElementById("bench-status");
  const textEl   = document.getElementById("bench-status-text");
  if (statusEl) statusEl.classList.remove("hidden");
  if (textEl)   textEl.textContent = `Processing ${file.name}…`;

  const threshold = parseFloat(
    document.getElementById("cfg-bench-thresh")?.value ||
    window.appData.config?.benchmark_threshold ||
    10
  );
  const fd = new FormData();
  fd.append("file", file);
  fd.append("threshold", String(threshold));

  try {
    const res  = await fetch("/api/benchmark", { method: "POST", body: fd });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: res.statusText }));
      toast("error", "Benchmark failed", (err.detail || "").slice(0, 200));
      return;
    }
    const data = await res.json();
    window.appData.benchmark = data;
    refreshDataStatus();
    _renderBenchmark(data);
    toast("success", "Benchmark loaded", `${data.total_transactions} transactions compared`);
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
  } finally {
    if (statusEl) statusEl.classList.add("hidden");
  }
}

function _renderBenchmark(data) {
  document.getElementById("bench-empty")?.classList.add("hidden");
  document.getElementById("bench-no-data-prompt")?.classList.add("hidden");
  document.getElementById("bench-loaded-chip")?.classList.remove("hidden");
  document.getElementById("bench-kpi-row")?.classList.remove("hidden");
  document.getElementById("bench-table-wrap")?.classList.remove("hidden");
  // Update loaded label
  const isBatchPerf = !!(data.batch_perf_summary);
  const cats = data.categories || [];
  const catLabel = isBatchPerf ? ` · batch runtime comparison` : (cats.length > 0 ? ` · ${cats.length} categories` : "");
  const lbl = document.getElementById("bench-loaded-label");
  if (lbl) lbl.textContent = `${data.filename || "Benchmark"} · ${data.total_transactions} ${isBatchPerf ? "jobs" : "transactions"}${catLabel}`;

  // Relabel comparison table headers for batch perf mode
  if (isBatchPerf) {
    const ths = document.querySelectorAll("#bench-tbody")?.closest("table")?.querySelectorAll("thead th") || [];
    const labels = ["Job", "Before (s)", "After (s)", "Delta %", "Δ sec", "Status"];
    ths.forEach((th, i) => { if (labels[i]) th.textContent = labels[i]; });
  }

  // KPI strip — relabel for batch perf mode
  const totalLbl  = document.querySelector("#bench-kpi-row [id='bk-total']")?.closest(".rounded-xl")?.querySelector(".text-\\[10px\\]");
  const slaLbl    = document.querySelector("#bench-kpi-row [id='bk-sla-breach']")?.closest(".rounded-xl")?.querySelector(".text-\\[10px\\]");
  const avgLbl    = document.querySelector("#bench-kpi-row [id='bk-avg-delta']")?.closest(".rounded-xl")?.querySelector(".text-\\[10px\\]");
  if (isBatchPerf) {
    if (totalLbl)  totalLbl.textContent  = "Total Jobs";
    if (slaLbl)    slaLbl.textContent    = "New Jobs";
    if (avgLbl)    avgLbl.textContent    = "Net Time Saved";
  }

  setText("bk-total", String(data.total_transactions));
  const degEl = document.getElementById("bk-degraded");
  if (degEl) { degEl.textContent = String(data.degraded); degEl.className = `text-2xl font-bold ${data.degraded > 0 ? "text-Cred" : "text-Cgreen"}`; }
  const slaEl = document.getElementById("bk-sla-breach");
  if (slaEl) {
    if (isBatchPerf) {
      const bp = data.batch_perf_summary;
      slaEl.textContent = String(bp.new_only || 0);
      slaEl.className = "text-2xl font-bold text-Cblue";
    } else {
      slaEl.textContent = String(data.sla_breaches);
      slaEl.className = `text-2xl font-bold ${data.sla_breaches > 0 ? "text-Camber" : "text-Cgreen"}`;
    }
  }
  const avgEl = document.getElementById("bk-avg-delta");
  if (avgEl) {
    if (isBatchPerf) {
      const net = _n(data.batch_perf_summary.net_delta_secs);
      const netMin = Math.abs(net / 60).toFixed(1);
      avgEl.textContent = (net >= 0 ? "+" : "-") + netMin + " min";
      avgEl.className = `text-2xl font-bold ${net >= 0 ? "text-Cgreen" : "text-Cred"}`;
    } else {
      const v = _n(data.avg_delta_pct);
      avgEl.textContent = (v > 0 ? "+" : "") + v.toFixed(1) + "%";
      avgEl.className = `text-2xl font-bold ${v > _n(data.threshold_pct) ? "text-Cred" : v > 0 ? "text-Camber" : "text-Cgreen"}`;
    }
  }

  const bannerEl = document.getElementById("bench-summary-banner");
  const summaryEl= document.getElementById("bench-summary-text");
  if (bannerEl && summaryEl && data.summary) {
    bannerEl.classList.remove("hidden");
    summaryEl.textContent = data.summary;
    bannerEl.className = `rounded-xl border px-5 py-3 ${data.degraded > 0 ? "border-Camber/40 bg-Camber/10" : "border-Cgreen/40 bg-Cgreen/10"}`;
  }

  // ── Category summary cards ──────────────────────────────────
  _renderBenchCategories(data);

  // ── Fill Rate panel ─────────────────────────────────────────
  _renderBenchFillRate(data);

  // ── Observations panel ──────────────────────────────────────
  _renderBenchObservations(data);

  // ── Main comparison table (grouped by category) ─────────────
  const tbody = document.getElementById("bench-tbody");
  if (tbody) {
    const bps = data.batch_perf_summary;
    let html = "";

    if (bps) {
      // Batch perf mode: render top regressions and improvements only
      const reg  = bps.top_regressions  || [];
      const impr = bps.top_improvements || [];
      const thresh = _n(data.threshold_pct);

      const renderBpRow = (e) => {
        const dSecs = _n(e.delta_secs);   // positive = improvement
        const dPct  = _n(e.delta_pct);    // positive = regression
        const dColor = dPct > thresh ? "text-Cred font-bold" : dPct > 0 ? "text-Camber" : "text-Cgreen";
        const stBg  = dPct > thresh ? "bg-Cred/20 text-Cred" : dPct < -5 ? "bg-Cgreen/20 text-Cgreen" : "bg-Cmuted/20 text-Cmuted";
        const status = dPct > thresh ? "REGRESSED" : dPct < -5 ? "IMPROVED" : "STABLE";
        return `<tr class="border-b border-Cborder/40 hover:bg-Ccard/40">
          <td class="py-2 pr-4 text-Cwhite font-semibold text-xs">${_esc(e.job)}</td>
          <td class="py-2 pr-4 text-right text-Cmuted font-mono text-xs">${_n(e.old_secs).toFixed(1)}s</td>
          <td class="py-2 pr-4 text-right font-mono text-xs ${dPct > 0 ? "text-Camber" : "text-Cgreen"}">${_n(e.new_secs).toFixed(1)}s</td>
          <td class="py-2 pr-4 text-right text-xs ${dColor}">${dPct > 0 ? "+" : ""}${dPct.toFixed(1)}%</td>
          <td class="py-2 pr-4 text-right font-mono text-xs ${dSecs >= 0 ? "text-Cgreen" : "text-Cred"}">${dSecs >= 0 ? "+" : ""}${dSecs.toFixed(0)}s</td>
          <td class="py-2 text-center"><span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${stBg}">${status}</span></td>
        </tr>`;
      };

      if (reg.length) {
        html += `<tr class="bg-Cbg/80"><td colspan="6" class="py-2.5 px-2">
          <span class="text-xs font-bold text-Cred uppercase tracking-wider">Top Regressions</span>
          <span class="ml-2 text-[10px] text-Cmuted">${bps.regressions} total · showing worst ${reg.length}</span>
        </td></tr>`;
        reg.forEach(e => { html += renderBpRow(e); });
      }
      if (impr.length) {
        html += `<tr class="bg-Cbg/80"><td colspan="6" class="py-2.5 px-2">
          <span class="text-xs font-bold text-Cgreen uppercase tracking-wider">Top Improvements</span>
          <span class="ml-2 text-[10px] text-Cmuted">${bps.improvements} total · showing best ${impr.length}</span>
        </td></tr>`;
        impr.forEach(e => { html += renderBpRow(e); });
      }
      if (!reg.length && !impr.length) {
        html = `<tr><td colspan="6" class="py-8 text-center text-Cmuted text-xs">All ${bps.total_jobs} jobs within tolerance — no regressions or significant improvements.</td></tr>`;
      }
      tbody.innerHTML = html;
    } else {
    // Normal mode: group by category
    const rows = data.rows || [];
    const catOrder = [];
    const catMap = {};
    rows.forEach((r) => {
      const c = r.category || "General";
      if (!catMap[c]) { catMap[c] = []; catOrder.push(c); }
      catMap[c].push(r);
    });

    catOrder.forEach((cat) => {
      const catRows = catMap[cat];
      const passed = catRows.filter(r => r.status === "GREEN" || (r.pass_fail && r.pass_fail.toLowerCase() === "pass")).length;
      html += `<tr class="bg-Cbg/80 sticky top-0 z-10">
        <td colspan="7" class="py-2.5 px-2">
          <span class="text-xs font-bold text-Cpurple uppercase tracking-wider">${_esc(cat)}</span>
          <span class="ml-2 text-[10px] text-Cmuted">${catRows.length} items · ${passed} passed</span>
        </td></tr>`;
      catRows.forEach((r) => {
        const stBg = r.status === "RED"   ? "bg-Cred/20 text-Cred"     :
                     r.status === "AMBER" ? "bg-Camber/20 text-Camber" :
                     r.status === "GREEN" ? "bg-Cgreen/20 text-Cgreen" : "bg-Cmuted/20 text-Cmuted";
        const dCol = r.delta_pct > data.threshold_pct ? "text-Cred font-bold" :
                     r.delta_pct > 0                  ? "text-Camber" :
                     r.delta_pct < -5                 ? "text-Cgreen" : "text-Cmuted";
        const pfBadge = r.pass_fail
          ? `<span class="ml-1 px-1.5 py-0.5 rounded text-[9px] font-bold ${r.pass_fail.toLowerCase()==='pass' ? 'bg-Cgreen/20 text-Cgreen' : 'bg-Cred/20 text-Cred'}">${_esc(r.pass_fail)}</span>`
          : "";
        html += `<tr class="border-b border-Cborder/40 hover:bg-Ccard/40">
          <td class="py-2 pr-4 text-Cwhite font-semibold text-xs">${_esc(r.transaction)}${pfBadge}</td>
          <td class="py-2 pr-4 text-right text-Cmuted font-mono text-xs">${_n(r.baseline_sec).toFixed(1)}</td>
          <td class="py-2 pr-4 text-right font-mono text-xs ${_n(r.current_sec) > _n(r.baseline_sec) ? "text-Camber" : "text-Cgreen"}">${_n(r.current_sec).toFixed(1)}</td>
          <td class="py-2 pr-4 text-right text-xs ${dCol}">${_n(r.delta_pct) > 0 ? "+" : ""}${_n(r.delta_pct).toFixed(1)}%</td>
          <td class="py-2 pr-4 text-right text-Cmuted text-xs">${r.sla_sec != null ? _n(r.sla_sec).toFixed(1) : "—"}</td>
          <td class="py-2 text-center"><span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${stBg}">${r.status}</span></td>
        </tr>`;
      });    });
    tbody.innerHTML = html;
    }   // end else (normal mode)
  }     // end if (tbody)
}

function _renderBenchCategories(data) {
  const wrap = document.getElementById("bench-category-cards");
  if (!wrap) return;
  const cats = data.categories || [];
  if (!cats.length) { wrap.classList.add("hidden"); return; }
  wrap.classList.remove("hidden");
  wrap.innerHTML = cats.map((c) => {
    const pct = c.total > 0 ? Math.round(c.passed / c.total * 100) : 0;
    const color = c.degraded > 0 ? "border-Cred/40" : c.failed > 0 ? "border-Camber/40" : "border-Cgreen/40";
    const badge = c.degraded > 0 ? "text-Cred" : "text-Cgreen";
    return `<div class="rounded-xl border ${color} bg-Ccard shadow-kpi p-3 min-w-[180px]">
      <div class="text-[10px] text-Cmuted uppercase tracking-widest font-semibold mb-1 truncate">${_esc(c.name)}</div>
      <div class="flex items-end gap-2">
        <span class="text-lg font-extrabold ${badge}">${pct}%</span>
        <span class="text-[10px] text-Cmuted mb-0.5">${c.passed}/${c.total} passed</span>
      </div>
      ${c.degraded > 0 ? `<div class="text-[10px] text-Cred mt-1">${c.degraded} regression(s)</div>` : ""}
      <div class="text-[10px] text-Cmuted mt-0.5">Avg Δ ${_n(c.avg_delta).toFixed(1)}%</div>
    </div>`;
  }).join("");
}

function _renderBenchFillRate(data) {
  const wrap = document.getElementById("bench-fill-rate");
  if (!wrap) return;
  const fr = data.fill_rate || [];
  if (!fr.length) { wrap.classList.add("hidden"); return; }
  wrap.classList.remove("hidden");

  // Group by date
  const dateMap = {};
  const dateOrder = [];
  fr.forEach((e) => {
    const d = e.date || "Unknown";
    if (!dateMap[d]) { dateMap[d] = []; dateOrder.push(d); }
    dateMap[d].push(e);
  });

  let html = `<h3 class="text-sm font-bold text-Cwhite mb-3">Fill Rate Comparison (PROD vs TEST)</h3>
    <div class="overflow-x-auto"><table class="w-full text-xs">
    <thead><tr class="border-b border-Cborder">
      <th class="text-left py-2 pr-4 text-Cmuted font-semibold">Date</th>
      <th class="text-left py-2 pr-4 text-Cmuted font-semibold">Type</th>
      <th class="text-right py-2 pr-4 text-Cmuted font-semibold">PROD %</th>
      <th class="text-right py-2 pr-4 text-Cmuted font-semibold">TEST %</th>
      <th class="text-right py-2 pr-4 text-Cmuted font-semibold">Diff</th>
      <th class="text-center py-2 text-Cmuted font-semibold">Status</th>
    </tr></thead><tbody>`;

  dateOrder.forEach((d) => {
    dateMap[d].forEach((e, i) => {
      const diffColor = Math.abs(e.diff) < 0.5 ? "text-Cgreen" : Math.abs(e.diff) < 1.0 ? "text-Camber" : "text-Cred";
      const stColor = (e.status || "").toLowerCase() === "pass" ? "bg-Cgreen/20 text-Cgreen" : "bg-Cred/20 text-Cred";
      html += `<tr class="border-b border-Cborder/40 hover:bg-Ccard/40">
        <td class="py-2 pr-4 text-Cmuted">${i === 0 ? _esc(d) : ""}</td>
        <td class="py-2 pr-4 text-Cwhite font-semibold">${_esc(e.type)}</td>
        <td class="py-2 pr-4 text-right font-mono text-Cmuted">${_n(e.prod).toFixed(3)}%</td>
        <td class="py-2 pr-4 text-right font-mono text-Cwhite">${_n(e.test).toFixed(3)}%</td>
        <td class="py-2 pr-4 text-right font-mono ${diffColor}">${_n(e.diff) > 0 ? "+" : ""}${_n(e.diff).toFixed(4)}</td>
        <td class="py-2 text-center"><span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${stColor}">${_esc(e.status||"")}</span></td>
      </tr>`;
    });
  });
  html += "</tbody></table></div>";
  wrap.innerHTML = html;
}

function _renderBatchPerfSummary(data) {
  const wrap = document.getElementById("bench-batch-perf");
  if (!wrap) return;
  const bps = data.batch_perf_summary;
  if (!bps) { wrap.classList.add("hidden"); return; }
  wrap.classList.remove("hidden");

  const netSecs = _n(bps.net_delta_secs);
  const netMin  = Math.abs(netSecs / 60).toFixed(1);
  const netDir  = netSecs >= 0 ? "saved" : "added";
  const netCol  = netSecs >= 0 ? "text-Cgreen" : "text-Cred";

  const statCard = (label, value, color, sub) =>
    `<div class="rounded-xl border border-Cborder bg-Cbg/40 p-3 text-center min-w-[130px]">
      <div class="text-[10px] text-Cmuted uppercase tracking-widest font-semibold mb-1">${label}</div>
      <div class="text-xl font-extrabold ${color}">${value}</div>
      ${sub ? `<div class="text-[10px] text-Cmuted mt-0.5">${sub}</div>` : ""}
    </div>`;

  const bpRow = (e, isReg) => {
    const pct = _n(e.delta_pct);
    const pctCol = isReg ? "text-Cred" : "text-Cgreen";
    const sav = _n(e.delta_secs);
    return `<tr class="border-b border-Cborder/30 hover:bg-Ccard/40">
      <td class="py-1.5 pr-3 text-Cwhite text-xs font-semibold">${_esc(e.job)}</td>
      <td class="py-1.5 pr-3 text-right text-Cmuted font-mono text-xs">${_n(e.old_secs).toFixed(0)}s</td>
      <td class="py-1.5 pr-3 text-right font-mono text-xs ${isReg ? "text-Camber" : "text-Cgreen"}">${_n(e.new_secs).toFixed(0)}s</td>
      <td class="py-1.5 text-right font-mono text-xs font-bold ${pctCol}">${pct > 0 ? "+" : ""}${pct.toFixed(0)}%</td>
      <td class="py-1.5 text-right font-mono text-xs ${sav >= 0 ? "text-Cgreen" : "text-Cred"}">${sav >= 0 ? "+" : ""}${sav.toFixed(0)}s</td>
    </tr>`;
  };

  const reg  = bps.top_regressions  || [];
  const impr = bps.top_improvements || [];

  let html = `<h3 class="text-sm font-bold text-Cwhite mb-3">Batch Runtime Comparison</h3>
    <div class="flex flex-wrap gap-3 mb-5">
      ${statCard("Total Jobs",    bps.total_jobs,    "text-Cwhite",  `${bps.comparable} with baseline`)}
      ${statCard("Regressions",   bps.regressions,   bps.regressions > 0 ? "text-Cred" : "text-Cgreen", "worse than before")}
      ${statCard("Improvements",  bps.improvements,  bps.improvements > 0 ? "text-Cgreen" : "text-Cmuted", "faster than before")}
      ${statCard("No Change",     bps.no_change,     "text-Cmuted",  "within ±threshold")}
      ${statCard("Net Runtime",   `${netSecs >= 0 ? "−" : "+"}${netMin} min`, netCol, `${netDir} per run`)}
    </div>`;

  const colHead = `<thead><tr class="border-b border-Cborder">
    <th class="text-left py-1.5 pr-3 text-Cmuted text-[10px] font-semibold">Job</th>
    <th class="text-right py-1.5 pr-3 text-Cmuted text-[10px] font-semibold">Before (s)</th>
    <th class="text-right py-1.5 pr-3 text-Cmuted text-[10px] font-semibold">After (s)</th>
    <th class="text-right py-1.5 text-Cmuted text-[10px] font-semibold">Δ %</th>
    <th class="text-right py-1.5 text-Cmuted text-[10px] font-semibold">Δ sec</th>
  </tr></thead>`;

  html += `<div class="grid grid-cols-1 xl:grid-cols-2 gap-4">`;

  if (reg.length) {
    html += `<div>
      <div class="text-xs font-bold text-Cred uppercase tracking-wider mb-2">Top Regressions <span class="font-normal text-Cmuted normal-case">(${bps.regressions} total)</span></div>
      <div class="overflow-x-auto"><table class="w-full text-xs">${colHead}<tbody>
        ${reg.map(e => bpRow(e, true)).join("")}
      </tbody></table></div>
    </div>`;
  }

  if (impr.length) {
    html += `<div>
      <div class="text-xs font-bold text-Cgreen uppercase tracking-wider mb-2">Top Improvements <span class="font-normal text-Cmuted normal-case">(${bps.improvements} total)</span></div>
      <div class="overflow-x-auto"><table class="w-full text-xs">${colHead}<tbody>
        ${impr.map(e => bpRow(e, false)).join("")}
      </tbody></table></div>
    </div>`;
  }

  if (!reg.length && !impr.length) {
    html += `<div class="col-span-2 py-6 text-center text-Cmuted text-xs">
      All ${bps.total_jobs} jobs ran within tolerance — no significant regressions or improvements.
    </div>`;
  }

  html += `</div>`;
  wrap.innerHTML = html;
}

function _renderBenchObservations(data) {
  const wrap = document.getElementById("bench-observations");
  if (!wrap) return;
  const obs = data.observations || [];
  if (!obs.length) { wrap.classList.add("hidden"); return; }
  wrap.classList.remove("hidden");

  let html = `<h3 class="text-sm font-bold text-Cwhite mb-3">SIT Observations</h3>
    <div class="overflow-x-auto"><table class="w-full text-xs">
    <thead><tr class="border-b border-Cborder">
      <th class="text-left py-2 pr-4 text-Cmuted font-semibold">Problem</th>
      <th class="text-left py-2 pr-4 text-Cmuted font-semibold">Date</th>
      <th class="text-left py-2 pr-4 text-Cmuted font-semibold">Root Cause</th>
      <th class="text-left py-2 pr-4 text-Cmuted font-semibold">Status</th>
      <th class="text-left py-2 pr-4 text-Cmuted font-semibold">Action</th>
      <th class="text-left py-2 text-Cmuted font-semibold">Owner</th>
    </tr></thead><tbody>`;
  obs.forEach((o) => {
    const stColor = (o.status || "").toLowerCase() === "closed" ? "text-Cgreen" : "text-Camber";
    html += `<tr class="border-b border-Cborder/40 hover:bg-Ccard/40">
      <td class="py-2 pr-4 text-Cwhite font-semibold">${_esc(o.problem || "")}</td>
      <td class="py-2 pr-4 text-Cmuted">${_esc(o.date || "")}</td>
      <td class="py-2 pr-4 text-Cmuted">${_esc(o["why_(root_cause)"] || o.root_cause || "")}</td>
      <td class="py-2 pr-4 ${stColor} font-semibold">${_esc(o.status || "")}</td>
      <td class="py-2 pr-4 text-Cmuted text-[11px]">${_esc(o.corrective_action_taken || "")}</td>
      <td class="py-2 text-Cmuted">${_esc(o.owner || "")}</td>
    </tr>`;
  });
  html += "</tbody></table></div>";
  wrap.innerHTML = html;
}


// ═══════════════════════════════════════════════════════════════
//  INTAKE UPLOAD ZONES — Zone C (SLA Matrix) & Zone D (Benchmark)
// ═══════════════════════════════════════════════════════════════

/** Zone C — SLA Matrix file upload on the Intake page */
function initSlaIntakeUploader() {
  const dz    = document.getElementById("sla-intake-drop-zone");
  const input = document.getElementById("sla-intake-file-input");
  if (!dz || !input) return;

  dz.addEventListener("click", () => input.click());
  input.addEventListener("change", (e) => {
    const f = e.target.files?.[0];
    if (f) _uploadSlaIntakeFile(f);
    input.value = "";
  });
  ["dragenter", "dragover"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); dz.classList.add("border-Camber","bg-Camber/5"); })
  );
  ["dragleave", "dragend"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); dz.classList.remove("border-Camber","bg-Camber/5"); })
  );
  dz.addEventListener("drop", (e) => {
    e.preventDefault(); e.stopPropagation();
    dz.classList.remove("border-Camber", "bg-Camber/5");
    const f = e.dataTransfer?.files?.[0];
    if (f) _uploadSlaIntakeFile(f);
  });
}

async function _uploadSlaIntakeFile(file) {
  const dot = document.getElementById("sla-status-dot");
  _renderIntakeProgress("sla-intake-status", {
    filename: file.name,
    message:  formatBytes(file.size),
    percent:  0,
    color:    "amber",
    phase:    "uploading",
  });

  const fd = new FormData();
  fd.append("file", file);
  fd.append("sla_mode", document.getElementById("sla-mode-select")?.value || "daily");
  fd.append("sla_hrs", "0");

  try {
    const { ok, status, body } = await _uploadWithProgress("/api/sla-matrix", fd, (pct, loaded, total, finished) => {
      _renderIntakeProgress("sla-intake-status", {
        filename: file.name,
        message:  finished ? `${formatBytes(file.size)} \u2014 resolving SLA contracts\u2026`
                           : `${formatBytes(loaded)} / ${formatBytes(total)}`,
        percent:  finished ? null : pct,
        color:    "amber",
        phase:    finished ? "parsing" : "uploading",
      });
    });
    if (!ok) {
      toast("error", "SLA Matrix upload failed", ((body?.detail) || `HTTP ${status}`).slice(0, 200));
      return;
    }
    const data = body;
    // Store for the SLA Matrix tab
    window.appData.slaMatrix = data;
    window.appData.slaMatrixFilename = file.name;

    // Run SLA intelligence engine (rich analysis with schema detection + traceability)
    if (file.name.toLowerCase().match(/\.(xlsx|xls|csv)$/)) {
      try {
        const intelFd = new FormData();
        intelFd.append("file", file);
        const intelRes = await fetch("/api/sla-intelligence", { method: "POST", body: intelFd });
        if (intelRes.ok) {
          const intel = await intelRes.json();
          window.appData.slaCeilings = intel.ceilings || null;
          window.appData.slaIntelligence = intel.intelligence || null;
          window.appData.slaTraceability = intel.traceability || null;
          _renderSlaIntelligencePanel(intel);
        } else {
          // Fallback to legacy ceilings endpoint
          const ceilFd = new FormData();
          ceilFd.append("file", file);
          const ceilRes = await fetch("/api/sla-ceilings", { method: "POST", body: ceilFd });
          if (ceilRes.ok) {
            window.appData.slaCeilings = await ceilRes.json();
          }
        }
      } catch (_e) { /* non-critical */ }
    }

    // Update dot
    if (dot) { dot.className = "w-2 h-2 rounded-full bg-Camber animate-pulse shrink-0"; }

    // Show result card on intake page
    _renderSlaIntakeCard(data, file.name);

    // Auto-populate the SLA Matrix tab
    _renderSlaMatrix(data);

    // Show intake status row + next prompt
    document.getElementById("intake-status-row")?.classList.remove("hidden");
    document.getElementById("upload-next-prompt")?.classList.remove("hidden");

    toast("success", "SLA Matrix loaded",
      `${data.total_runs} runs · ${data.compliance_pct.toFixed(1)}% compliance`);
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
  } finally {
    document.getElementById("sla-intake-status")?.classList.add("hidden");
  }
}

function _renderSlaIntakeCard(data, filename) {
  const card = document.getElementById("sla-result-card");
  if (!card) return;
  card.classList.remove("hidden");

  setText("sla-result-filename", filename || "—");
  const compEl = document.getElementById("sla-result-compliance");
  if (compEl) {
    compEl.textContent = data.compliance_pct.toFixed(1) + "%";
    compEl.className   = `text-lg font-extrabold mt-0.5 ${data.compliance_pct >= 95 ? "text-Cgreen" : data.compliance_pct >= 80 ? "text-Camber" : "text-Cred"}`;
  }
  setText("sla-result-mode", data.sla_label || data.sla_mode || "—");
  const brEl = document.getElementById("sla-result-breach");
  if (brEl) {
    brEl.textContent = String(data.breaching_runs);
    brEl.className   = `text-lg font-extrabold mt-0.5 ${data.breaching_runs > 0 ? "text-Cred" : "text-Cgreen"}`;
  }
}


// ── SLA Intelligence Panel ────────────────────────────────────
function _renderSlaIntelligencePanel(intel) {
  // ── Compact summary on upload page ──────────────────────────
  const panel = document.getElementById("sla-intelligence-panel");
  if (panel) {
    const info = intel.intelligence || {};
    const trace = intel.traceability || {};
    const ceil = intel.ceilings || {};

    panel.classList.remove("hidden");

    // Summary text
    const summaryEl = document.getElementById("sla-intel-summary-text");
    if (summaryEl) {
      const model = (info.schema_type || "unknown").toUpperCase();
      const valid = info.valid_rows || 0;
      const partial = info.partial_rows || 0;
      const total = info.total_rows || 0;
      const blocked = trace.blocked ? " · ⚠ BLOCKED" : "";
      summaryEl.textContent = `${model} model · ${valid} valid · ${partial} partial · ${total} total${blocked}`;
      if (trace.blocked) summaryEl.style.color = THEME.red;
    }

    // Mini ceiling chips — file-sourced values only
    const ceilEl = document.getElementById("sla-intel-ceilings-mini");
    if (ceilEl) {
      const missingMini = (intel.intelligence || {}).missing_ceilings || [];
      const fromFile = Object.entries(ceil).map(([sched, hrs]) =>
        `<span class="text-[9px] font-bold px-2 py-0.5 rounded border border-Cborder bg-Cbg/40 text-Cwhite">
          <span class="text-Cmuted">${_esc(sched)}</span> ${Number(hrs).toFixed(1)}h
        </span>`
      );
      const notInFile = missingMini.map(sched =>
        `<span class="text-[9px] font-bold px-2 py-0.5 rounded" style="border:1px solid rgba(245,158,11,.4);color:#f59e0b;background:rgba(245,158,11,.07)">
          <span style="opacity:.7">${_esc(sched)}</span> N/A
        </span>`
      );
      ceilEl.innerHTML = [...fromFile, ...notInFile].join("");
    }
  }

  // ── Full detail in SLA Matrix tab ───────────────────────────
  _renderSlaIntelligenceDetail(intel);
}

function _renderSlaIntelligenceDetail(intel) {
  const panel = document.getElementById("sla-intelligence-detail");
  if (!panel) return;

  const info = intel.intelligence || {};
  const trace = intel.traceability || {};
  const warnings = info.warnings || [];
  const contracts = (info.contracts || []).slice(0, 30);

  panel.classList.remove("hidden");

  // Schema detection header
  const schemaColor = info.valid_rows > 0 ? THEME.green : THEME.red;
  const schemaLabel = info.detected_model || info.schema_type || "Unknown";
  const blocked = trace.blocked;

  let html = `
    <div class="flex items-center gap-3 mb-3">
      <span class="text-[11px] font-bold px-2 py-0.5 rounded"
            style="color:${schemaColor};background:${hexA(schemaColor, 0.1)};border:1px solid ${hexA(schemaColor, 0.3)}">
        ${escapeHtml(info.schema_type?.toUpperCase() || "?")} MODEL
      </span>
      <span class="text-[11px] text-Cmuted">${escapeHtml(schemaLabel)}</span>
      <span class="text-[10px] text-Cmuted">${info.valid_rows || 0} valid · ${info.partial_rows || 0} partial · ${info.total_rows || 0} total rows</span>
      ${blocked ? '<span class="text-[10px] text-Cred font-bold">⚠ COMPLIANCE BLOCKED</span>' : ""}
    </div>`;

  // Warnings
  if (warnings.length) {
    html += '<div class="space-y-1 mb-3">';
    for (const w of warnings) {
      const wColor = w.severity === "critical" ? THEME.red : w.severity === "warning" ? THEME.amber : THEME.blue;
      html += `<div class="text-[10px] px-2 py-1 rounded border" style="color:${wColor};border-color:${hexA(wColor, 0.3)};background:${hexA(wColor, 0.05)}">
        <span class="font-bold">${escapeHtml(w.code || "")}</span> ${escapeHtml(w.text || "")}
      </div>`;
    }
    html += '</div>';
  }

  // Ceilings summary — file-sourced only, explicitly flag missing schedule types
  const ceil = intel.ceilings || {};
  const missingCeil = (intel.intelligence || {}).missing_ceilings || [];
  const allSchedTypes = ["DAILY", "WEEKLY", "MONTHLY"];
  html += '<div class="flex flex-wrap gap-3 mb-3">';
  // Show file-sourced ceilings
  for (const [sched, hrs] of Object.entries(ceil)) {
    const fromFile = trace.type === "sla_matrix";
    const srcLabel = fromFile ? "From SLA File" : "Config Assumed";
    const srcColor = fromFile ? "text-Cgreen" : "text-Camber";
    html += `<div class="rounded-lg border border-Cborder bg-Cbg/40 px-3 py-1.5 text-center min-w-[72px]">
      <div class="text-[9px] text-Cmuted font-bold uppercase tracking-wider">${_esc(sched)}</div>
      <div class="text-sm font-extrabold text-Cwhite">${Number(hrs).toFixed(1)}h</div>
      <div class="text-[8px] ${srcColor}">${srcLabel}</div>
    </div>`;
  }
  // Show missing schedule types as explicit 'Not in file' tiles
  for (const sched of missingCeil) {
    html += `<div class="rounded-lg border px-3 py-1.5 text-center min-w-[72px]" style="border-color:rgba(245,158,11,.35);background:rgba(245,158,11,.06)">
      <div class="text-[9px] font-bold uppercase tracking-wider" style="color:#f59e0b">${_esc(sched)}</div>
      <div class="text-sm font-extrabold" style="color:#f59e0b">N/A</div>
      <div class="text-[8px]" style="color:#f59e0b">Not in file</div>
    </div>`;
  }
  html += '</div>';

  // SLA contracts table
  if (contracts.length) {
    html += `<div class="text-[10px] font-bold text-Cmuted uppercase tracking-wider mb-1">Resolved SLA Rules (${contracts.length})</div>`;
    html += '<div class="overflow-x-auto"><table class="w-full text-[10px]">';
    html += '<thead><tr class="text-Cmuted border-b border-Cborder">';
    html += '<th class="text-left px-2 py-1">Batch</th>';
    html += '<th class="text-left px-2 py-1">Schedule</th>';
    html += '<th class="text-right px-2 py-1">Window</th>';
    html += '<th class="text-right px-2 py-1">Actual</th>';
    html += '<th class="text-right px-2 py-1">Buffer</th>';
    html += '<th class="text-left px-2 py-1">Health</th>';
    html += '<th class="text-left px-2 py-1">Reason</th>';
    html += '</tr></thead><tbody>';
    const _healthColor = (s) => s === "OK" ? THEME.green
      : s === "ACK"     ? THEME.green
      : s === "AT_RISK" ? THEME.amber
      : s === "BREACH"  ? THEME.red
      : s === "CYCLIC"  ? THEME.blue
      : THEME.muted;
    const _fmtHrs = (h) => (h === null || h === undefined) ? "—" : Number(h).toFixed(1) + "h";
    const _fmtBuf = (c) => {
      if (c.buffer_hrs === null || c.buffer_hrs === undefined) return "—";
      const sign = c.buffer_hrs < 0 ? "" : "+";
      const pct  = (c.buffer_pct === null || c.buffer_pct === undefined) ? "" : ` (${sign}${c.buffer_pct.toFixed(0)}%)`;
      return `${sign}${c.buffer_hrs.toFixed(1)}h${pct}`;
    };
    for (const c of contracts) {
      const hColor   = _healthColor(c.health_status || "NO_DATA");
      const winTxt   = c.sla_window_hrs ? c.sla_window_hrs.toFixed(1) + "h"
                       : c.sla_duration_hrs ? c.sla_duration_hrs.toFixed(1) + "h" : "—";
      const bufTxt   = _fmtBuf(c);
      const bufColor = (c.buffer_hrs !== null && c.buffer_hrs !== undefined && c.buffer_hrs < 0)
                       ? THEME.red : THEME.muted;
      html += `<tr class="border-b border-Cborder/30 hover:bg-Cblue/5">
        <td class="px-2 py-1 font-semibold text-Cwhite truncate max-w-[180px]">${escapeHtml(c.batch_name || "")}</td>
        <td class="px-2 py-1 text-Cmuted truncate max-w-[160px]">${escapeHtml((c.schedule_raw || c.schedule_type || "").substring(0, 32))}</td>
        <td class="px-2 py-1 text-right font-mono">${winTxt}</td>
        <td class="px-2 py-1 text-right font-mono">${_fmtHrs(c.actual_window_hrs)}</td>
        <td class="px-2 py-1 text-right font-mono" style="color:${bufColor}">${bufTxt}</td>
        <td class="px-2 py-1"><span class="px-1.5 py-0.5 rounded text-[9px] font-bold" style="color:${hColor};background:${hexA(hColor, 0.12)};border:1px solid ${hexA(hColor, 0.4)}">${escapeHtml(c.health_status || "—")}</span></td>
        <td class="px-2 py-1 text-Cmuted truncate max-w-[260px]" title="${escapeHtml(c.health_reason || "")}">${escapeHtml(c.health_reason || "")}</td>
      </tr>`;
    }
    html += '</tbody></table></div>';
  }

  panel.innerHTML = html;
}


/** Zone D — Benchmark file upload on the Intake page */
function initBenchIntakeUploader() {
  const dz    = document.getElementById("bench-intake-drop-zone");
  const input = document.getElementById("bench-intake-file-input");
  if (!dz || !input) return;

  dz.addEventListener("click", () => input.click());
  input.addEventListener("change", (e) => {
    const f = e.target.files?.[0];
    if (f) _uploadBenchIntakeFile(f);
    input.value = "";
  });
  ["dragenter", "dragover"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); dz.classList.add("border-Cpurple","bg-Cpurple/5"); })
  );
  ["dragleave", "dragend"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); dz.classList.remove("border-Cpurple","bg-Cpurple/5"); })
  );
  dz.addEventListener("drop", (e) => {
    e.preventDefault(); e.stopPropagation();
    dz.classList.remove("border-Cpurple", "bg-Cpurple/5");
    const f = e.dataTransfer?.files?.[0];
    if (f) _uploadBenchIntakeFile(f);
  });
}

async function _uploadBenchIntakeFile(file) {
  const dot = document.getElementById("bench-intake-dot");
  _renderIntakeProgress("bench-intake-status", {
    filename: file.name,
    message:  formatBytes(file.size),
    percent:  0,
    color:    "purple",
    phase:    "uploading",
  });

  const threshold = parseFloat(
    document.getElementById("cfg-bench-thresh")?.value ||
    window.appData.config?.benchmark_threshold ||
    10
  );
  const fd = new FormData();
  fd.append("file", file);
  fd.append("threshold", String(threshold));

  try {
    const { ok, status, body } = await _uploadWithProgress("/api/benchmark", fd, (pct, loaded, total, finished) => {
      _renderIntakeProgress("bench-intake-status", {
        filename: file.name,
        message:  finished ? `${formatBytes(file.size)} \u2014 comparing PROD vs TEST\u2026`
                           : `${formatBytes(loaded)} / ${formatBytes(total)}`,
        percent:  finished ? null : pct,
        color:    "purple",
        phase:    finished ? "analysing" : "uploading",
      });
    });
    if (!ok) {
      toast("error", "Benchmark upload failed", ((body?.detail) || `HTTP ${status}`).slice(0, 200));
      return;
    }
    const data = body;
    window.appData.benchmark = data;

    // Update dot
    if (dot) { dot.className = "w-2 h-2 rounded-full bg-Cpurple animate-pulse shrink-0"; }

    // Show result card
    _renderBenchIntakeCard(data, file.name);

    // Auto-populate the Benchmark tab
    _renderBenchmark(data);
    refreshDataStatus();
    // Re-run findings with benchmark data included
    triggerGenerateFindings().catch(() => {});

    // Show intake status row + next prompt
    document.getElementById("intake-status-row")?.classList.remove("hidden");
    document.getElementById("upload-next-prompt")?.classList.remove("hidden");

    toast("success", "Benchmark loaded",
      `${data.total_transactions} transactions · ${data.degraded} regression(s)`);
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
  } finally {
    document.getElementById("bench-intake-status")?.classList.add("hidden");
  }
}

// ═══════════════════════════════════════════════════════════════
//  DFU / SKU vs SOW BASELINE
// ═══════════════════════════════════════════════════════════════

const _SOW_FIELDS = [
  { key: "daily_dfu", baseId: "sow-dfu", label: "Daily DFU" },
  { key: "daily_sku", baseId: "sow-sku", label: "Daily SKU Count" },
];

function initSowTab() {
  // SOW doc upload zone
  const dz    = document.getElementById("sow-doc-drop");
  const input = document.getElementById("sow-doc-input");
  if (!dz || !input) return;
  dz.addEventListener("click", () => input.click());
  input.addEventListener("change", (e) => {
    const f = e.target.files?.[0];
    if (f) _parseSowDoc(f);
    input.value = "";
  });
  ["dragenter", "dragover"].forEach(ev =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); dz.classList.add("border-Cteal","bg-Cteal/10"); })
  );
  ["dragleave", "dragend"].forEach(ev =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); dz.classList.remove("border-Cteal","bg-Cteal/10"); })
  );
  dz.addEventListener("drop", (e) => {
    e.preventDefault(); e.stopPropagation();
    dz.classList.remove("border-Cteal","bg-Cteal/10");
    const f = e.dataTransfer?.files?.[0];
    if (f) _parseSowDoc(f);
  });
}

async function _parseSowDoc(file) {
  const statusEl = document.getElementById("sow-parse-status");
  const textEl   = document.getElementById("sow-parse-status-text");
  const resultEl = document.getElementById("sow-parse-result");
  if (statusEl) statusEl.classList.remove("hidden");
  if (resultEl) resultEl.classList.add("hidden");
  if (textEl) textEl.textContent = `Parsing ${file.name} with Gemini…`;

  const fd = new FormData();
  fd.append("file", file);
  try {
    const res  = await fetch("/api/sow/parse", { method: "POST", body: fd });
    const data = await res.json();
    if (!res.ok) { toast("error", "SOW parse failed", (data.detail || "").slice(0, 200)); return; }

    // Populate form fields with extracted values
    let filled = 0;
    _SOW_FIELDS.forEach(({ key, baseId }) => {
      if (data[key] != null) {
        const el = document.getElementById(`${baseId}-baseline`);
        if (el) { el.value = data[key]; filled++; }
      }
    });

    if (resultEl) {
      resultEl.classList.remove("hidden");
      resultEl.textContent = `✅ Extracted ${filled} volume target(s) from ${file.name}`;
    }
    toast("success", "SOW parsed", `${filled} metric(s) extracted — review and click Save & Compare`);
  } catch (err) {
    toast("error", "Network error", String(err?.message || err));
  } finally {
    if (statusEl) statusEl.classList.add("hidden");
  }
}

async function loadSowBaseline() {
  try {
    const res  = await fetch("/api/sow/baseline");
    if (!res.ok) return;
    const data = await res.json();
    _SOW_FIELDS.forEach(({ key, baseId }) => {
      if (data[key] != null) {
        const el = document.getElementById(`${baseId}-baseline`);
        if (el && !el.value) el.value = data[key];
      }
    });
    // Auto-populate actuals from loaded dashboard data
    _autoFillSowActuals();
  } catch (_) {}
}

function _autoFillSowActuals() {
  // Pull CPU/Mem averages from resource data
  const servers = window.appData.servers || [];
  if (servers.length > 0) {
    const avgCpu = servers.reduce((s, v) => s + (parseFloat(v.cpu_used || v.cpu_pct || 0)), 0) / servers.length;
    const avgMem = servers.reduce((s, v) => s + (parseFloat(v.mem_used || v.mem_pct || 0)), 0) / servers.length;
    const cpuEl = document.getElementById("sow-cpu-actual");
    const memEl = document.getElementById("sow-mem-actual");
    if (cpuEl && !cpuEl.value) cpuEl.value = avgCpu.toFixed(1);
    if (memEl && !memEl.value) memEl.value = avgMem.toFixed(1);
  }
  // Pull batch job count
  const batch = window.appData.batch;
  if (batch) {
    const jobsEl = document.getElementById("sow-batchjobs-actual");
    if (jobsEl && !jobsEl.value && batch.kpis?.total_jobs) {
      jobsEl.value = batch.kpis.total_jobs;
    }
  }
}

async function saveSowBaseline() {
  const baseline = {};
  const actuals  = {};

  _SOW_FIELDS.forEach(({ key, baseId }) => {
    const bEl = document.getElementById(`${baseId}-baseline`);
    const aEl = document.getElementById(`${baseId}-actual`);
    const bVal = parseFloat(bEl?.value || "");
    const aVal = parseFloat(aEl?.value || "");
    if (!isNaN(bVal) && bVal > 0) baseline[key] = bVal;
    if (!isNaN(aVal) && aVal > 0) actuals[key]  = aVal;
  });

  if (Object.keys(baseline).length === 0) {
    toast("error", "No targets set", "Enter at least one SOW target value before comparing.");
    return;
  }

  const msgEl = document.getElementById("sow-save-msg");

  try {
    // Save baseline
    await fetch("/api/sow/baseline", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(baseline),
    });

    // Compare
    const res  = await fetch("/api/sow/compare", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ actuals }),
    });
    const data = await res.json();
    // Store so Findings engine can read it
    window.appData.sowCompare = data;
    _renderSowComparison(data);
    // Re-run findings now that SOW data has changed
    triggerGenerateFindings().catch(() => {});
    if (msgEl) {
      msgEl.textContent = "✅ Saved and compared";
      msgEl.className   = "text-[11px] text-Cgreen";
      msgEl.classList.remove("hidden");
      setTimeout(() => msgEl.classList.add("hidden"), 3000);
    }
  } catch (err) {
    toast("error", "Error", String(err?.message || err));
  }
}

function _renderSowComparison(data) {
  document.getElementById("sow-empty")?.classList.add("hidden");
  document.getElementById("sow-chart-wrap")?.classList.remove("hidden");
  document.getElementById("sow-table-wrap")?.classList.remove("hidden");
  document.getElementById("sow-summary-banner")?.classList.remove("hidden");

  // Summary
  setText("sow-summary-text", data.summary || "");

  // Overall badge
  const badge = document.getElementById("sow-overall-badge");
  if (badge) {
    const cfg = {
      OPTIMAL:  { bg: "bg-Cgreen/20 border-Cgreen/40 text-Cgreen",  icon: "✅" },
      MODERATE: { bg: "bg-Camber/20 border-Camber/40 text-Camber",  icon: "🟡" },
      LOW:      { bg: "bg-Cred/20 border-Cred/40 text-Cred",        icon: "🔴" },
      HIGH:     { bg: "bg-Cred/20 border-Cred/40 text-Cred",        icon: "🔴" },
      "N/A":    { bg: "bg-Cmuted/20 border-Cborder text-Cmuted",     icon: "—"  },
    }[data.overall_status] || { bg: "bg-Cmuted/20 border-Cborder text-Cmuted", icon: "?" };
    badge.innerHTML = `<span class="text-[11px] font-bold px-3 py-1 rounded-full border ${cfg.bg}">${cfg.icon} ${data.overall_status}</span>`;
  }

  // Bar chart
  const barsEl = document.getElementById("sow-bars-container");
  if (barsEl && data.metrics?.length) {
    barsEl.innerHTML = data.metrics.map((m) => {
      const pct    = Math.min(m.pct, 150);     // cap at 150% for display
      const barPct = (pct / 150 * 100).toFixed(1);
      const color  = m.status === "OPTIMAL"  ? "#10d96e" :
                     m.status === "MODERATE" ? "#f59e0b" :
                     m.status === "LOW"      ? "#f43f5e" : "#f43f5e";
      const statusBg = m.status === "OPTIMAL"  ? "bg-Cgreen/20 text-Cgreen" :
                       m.status === "MODERATE" ? "bg-Camber/20 text-Camber" :
                       "bg-Cred/20 text-Cred";
      return `<div class="space-y-1">
        <div class="flex items-center justify-between text-[11px]">
          <span class="font-semibold text-Cwhite">${_esc(m.label)}</span>
          <div class="flex items-center gap-2">
            <span class="text-Cmuted font-mono">${_fmt(m.actual)} / ${_fmt(m.sow)}</span>
            <span class="font-bold" style="color:${color}">${m.pct.toFixed(1)}%</span>
            <span class="text-[10px] font-bold px-1.5 py-0.5 rounded-full uppercase ${statusBg}">${m.status}</span>
          </div>
        </div>
        <div class="relative h-5 rounded-lg overflow-hidden bg-Cbg border border-Cborder">
          <!-- Zone backgrounds -->
          <div class="absolute inset-y-0 left-0 bg-Cred/25" style="width:${(70/150*100).toFixed(1)}%"></div>
          <div class="absolute inset-y-0 bg-Camber/25" style="left:${(70/150*100).toFixed(1)}%;width:${((90-70)/150*100).toFixed(1)}%"></div>
          <div class="absolute inset-y-0 bg-Cgreen/25" style="left:${(90/150*100).toFixed(1)}%;width:${((110-90)/150*100).toFixed(1)}%"></div>
          <div class="absolute inset-y-0 bg-Cred/20" style="left:${(110/150*100).toFixed(1)}%;right:0"></div>
          <!-- SOW 100% marker -->
          <div class="absolute inset-y-0 w-px bg-white/40" style="left:${(100/150*100).toFixed(1)}%"></div>
          <!-- Actual bar -->
          <div class="absolute inset-y-0 left-0 rounded-lg transition-all duration-700"
               style="width:${barPct}%;background:${color};opacity:0.85"></div>
        </div>
        <div class="flex justify-between text-[9px] text-Cmuted font-mono">
          <span>0</span><span>70%</span><span>90%</span><span>SOW 100%</span><span>110%</span><span>150%+</span>
        </div>
      </div>`;
    }).join("");
  }

  // Table
  const tbody = document.getElementById("sow-table-tbody");
  if (tbody && data.metrics?.length) {
    tbody.innerHTML = data.metrics.map((m) => {
      const stBg = m.status === "OPTIMAL"  ? "bg-Cgreen/20 text-Cgreen" :
                   m.status === "MODERATE" ? "bg-Camber/20 text-Camber" :
                   "bg-Cred/20 text-Cred";
      const pctColor = m.pct >= 90 && m.pct <= 110 ? "text-Cgreen font-bold" :
                       m.pct >= 70                  ? "text-Camber font-semibold" : "text-Cred font-bold";
      return `<tr class="border-b border-Cborder/40 hover:bg-Ccard/40">
        <td class="py-2.5 pr-4 font-semibold text-Cwhite">${_esc(m.label)}</td>
        <td class="py-2.5 pr-4 text-right text-Cmuted font-mono">${_fmt(m.sow)}</td>
        <td class="py-2.5 pr-4 text-right font-mono text-Cwhite">${_fmt(m.actual)}</td>
        <td class="py-2.5 pr-4 text-right ${pctColor}">${m.pct.toFixed(1)}%</td>
        <td class="py-2.5 text-center"><span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${stBg}">${m.status}</span></td>
      </tr>`;
    }).join("");
  }
}

/** Format large numbers cleanly */
function _fmt(n) {
  if (n == null || isNaN(n)) return "—";
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000)     return (n / 1_000).toFixed(1) + "K";
  return Number(n).toFixed(n % 1 === 0 ? 0 : 1);
}


function _renderBenchIntakeCard(data, filename) {
  const card = document.getElementById("bench-result-card");
  if (!card) return;
  card.classList.remove("hidden");

  setText("bench-result-filename", filename || data.filename || "—");
  setText("bench-result-total", String(data.total_transactions));
  const degEl = document.getElementById("bench-result-degraded");
  if (degEl) {
    degEl.textContent = String(data.degraded);
    degEl.className   = `text-lg font-extrabold mt-0.5 ${data.degraded > 0 ? "text-Cred" : "text-Cgreen"}`;
  }
  const dEl = document.getElementById("bench-result-delta");
  if (dEl) {
    const v = data.avg_delta_pct || 0;
    dEl.textContent = (v > 0 ? "+" : "") + v.toFixed(1) + "%";
    dEl.className   = `text-lg font-extrabold mt-0.5 ${v > data.threshold_pct ? "text-Cred" : v > 0 ? "text-Camber" : "text-Cgreen"}`;
  }
}


// ---------------------------------------------------------------
//  AGENT � DEEP DIVE  (tool-using LLM panel)
// ---------------------------------------------------------------
