"""
Batch SLA Matrix router.

POST /api/sla-matrix
    Accepts raw Ctrl-M CSV/XLSX bytes (multipart) + optional SLA config.
    Returns a structured SLA compliance analysis with breach details,
    configurable daily/weekly/monthly/custom thresholds.

POST /api/sla-matrix/json
    Same but accepts pre-parsed rows array in JSON body.
"""
from __future__ import annotations

import io
from typing import Any, Dict, List, Literal, Optional

from fastapi import APIRouter, File, Form, HTTPException, UploadFile, status
from pydantic import BaseModel, ConfigDict

from services import config_store
from services import pe_config
from services.batch_calculator import load_ctrlm_bytes

router = APIRouter()

MODES = {
    "daily":    ("Daily SLA",     None),    # None = read live from pe_config
    "weekly":   ("Weekly SLA",    None),
    "biweekly": ("Bi-Weekly SLA", None),
    "monthly":  ("Monthly SLA",   None),
}


def _mode_hrs(mode: str) -> float:
    """Return the SLA ceiling for a given mode from pe_config (live)."""
    if mode == "daily":
        return pe_config.SLA_DAILY_HRS
    if mode == "weekly":
        return pe_config.SLA_WEEKLY_HRS
    if mode == "biweekly":
        return pe_config.SLA_BIWEEKLY_HRS
    return pe_config.SLA_MONTHLY_HRS


# ── Models ───────────────────────────────────────────────────────────────────

class SlaBreach(BaseModel):
    job_name:        str
    sub_application: str
    run_date:        str
    start_time:      str
    end_time:        str
    run_hrs:         float
    sla_limit_hrs:   float
    breach_margin_hrs: float   # how far over SLA (positive = over)
    status:          str       # BREACH | AT_RISK | OK


class SlaMatrixResponse(BaseModel):
    sla_mode:          str    # daily | weekly | biweekly | monthly | custom
    sla_limit_hrs:     float
    sla_label:         str
    total_runs:        int
    total_jobs:        int
    breaching_runs:    int
    at_risk_runs:      int
    ok_runs:           int
    compliance_pct:    float
    breach_rate_pct:   float
    worst_job:         Optional[str]
    worst_hrs:         float
    worst_margin_hrs:  float
    breaches:          List[SlaBreach]    # all breach + at-risk rows
    job_summary:       List[Dict[str, Any]]  # per-job rolled-up stats
    # Adaptive per-job intelligence (computed from the file itself).
    job_baselines:     Optional[Dict[str, Dict[str, Any]]] = None
    outliers:          Optional[List[Dict[str, Any]]] = None  # runs over their own baseline
    resource_linked:   Optional[List[Dict[str, Any]]] = None  # breaches/outliers + resource signal
    ai_narrative:      Optional[str] = None
    ai_model:          Optional[str] = None
    # Window-level compliance (daily elapsed wall-clock vs SLA)
    window_compliance_pct: Optional[float] = None   # % of days within SLA window
    window_total_days:     Optional[int]   = None
    window_breach_days:    Optional[int]   = None
    window_detail:         Optional[List[Dict[str, Any]]] = None  # per-day elapsed detail
    # Smartness-gate audit block — what the display gate dropped & why.
    gate_audit:        Optional[Dict[str, Any]] = None
    # True only when a customer SLA matrix file was uploaded with per-job contracts.
    # False when only schedule-type ceilings exist (from settings / SOW parsing).
    explicit_sla_matrix: bool = False


class JsonSlaRequest(BaseModel):
    model_config = ConfigDict(extra="allow")
    rows:     List[Dict[str, Any]]
    sla_mode: Optional[str]  = "daily"
    sla_hrs:  Optional[float] = None


# ── Logic ────────────────────────────────────────────────────────────────────

def _compute_sla_matrix(df, sla_mode: str, custom_sla_hrs: float | None) -> SlaMatrixResponse:
    import pandas as pd

    # ── Resolve SLA ceilings ─────────────────────────────────────────────
    # Priority:
    #   1. Per-job SLA from uploaded customer SLA matrix (contracts)
    #   2. Global mode ceiling (daily/weekly/monthly/custom) from pe_config
    # When per-job contracts exist, each run is judged against its own SLA.
    # This prevents the dangerous false-green where a 6h daily ceiling hides
    # a workflow with a 1.5h contractual SLA window.

    if sla_mode == "custom" and custom_sla_hrs:
        global_sla_hrs = float(custom_sla_hrs)
        sla_label = f"Custom SLA ({global_sla_hrs}h)"
    else:
        mode_label, _ = MODES.get(sla_mode, MODES["daily"])
        global_sla_hrs = _mode_hrs(sla_mode)
        sla_label = f"{mode_label} ({global_sla_hrs}h)"

    # Load per-job SLA contracts from the uploaded SLA matrix (if available)
    contracts = []
    ceilings: dict = {}
    has_per_job_sla = False
    # explicit_sla_matrix is True ONLY when a customer SLA matrix file was uploaded
    # with per-job contract rows. Schedule-type ceilings from settings/SOW alone do NOT count.
    explicit_sla_matrix = False
    try:
        from services import config_store as _cs
        sla_intel = _cs.get("_sla_intelligence") or {}
        if sla_intel.get("contracts"):
            from services.sla_engine import SlaContract, resolve_sla, classify_schedule
            import dataclasses as _dc
            _valid_fields = {f.name for f in _dc.fields(SlaContract)}
            contracts = []
            for c in sla_intel["contracts"]:
                if isinstance(c, dict):
                    if c.get("completeness") != "complete":
                        continue
                    filtered = {k: v for k, v in c.items() if k in _valid_fields}
                    try:
                        contracts.append(SlaContract(**filtered))
                    except Exception:
                        continue
                elif hasattr(c, "completeness") and c.completeness == "complete":
                    contracts.append(c)
            ceilings = sla_intel.get("ceilings") or {}
            # Only mark explicit_sla_matrix when actual per-job contracts were loaded
            explicit_sla_matrix = bool(contracts)
            has_per_job_sla = bool(contracts) or bool(ceilings)
    except Exception:
        pass

    def _resolve_job_sla(job_name: str, sub_app: str) -> tuple[float, str]:
        """Get the effective SLA ceiling + source label for a specific job.

        Returns (sla_hrs, sla_source) where sla_source is one of:
          'sla_matrix'        — matched a contract row in the uploaded SLA file
          'customer_fallback' — matched schedule-type ceiling from the uploaded file
          'assumed'           — no file match; falling back to user-selected global ceiling
          'global'            — no SLA intel loaded; using global ceiling
        """
        if not has_per_job_sla:
            return global_sla_hrs, "global"
        try:
            resolved = resolve_sla(job_name, sub_app, contracts, ceilings)
            # Only use the SLA engine's result when it's a genuine file-based match.
            # source="assumed" means the engine fell through to pe_config system defaults,
            # which would override the user's custom/weekly/monthly selection. Instead,
            # fall back to global_sla_hrs so the user's mode choice is always respected.
            if resolved.sla_hrs and resolved.sla_hrs > 0 and resolved.source != "assumed":
                return resolved.sla_hrs, resolved.source
        except Exception:
            pass
        # No contract match — use the user-selected global ceiling (respects custom mode)
        return global_sla_hrs, "assumed"

    # Ensure run_time_hrs column
    if "run_time_hrs" not in df.columns:
        df["run_time_hrs"] = df.get("Run_Sec", 0) / 3600.0

    results: list[dict] = []
    sla_source_note = "per-job (customer SLA matrix)" if has_per_job_sla else "global ceiling"

    for _, row in df.iterrows():
        hrs     = float(row.get("run_time_hrs", 0) or 0)
        job     = str(row.get("Job_Name", "?"))
        sub_app = str(row.get("Sub_Application", "—"))
        raw_status = str(row.get("Status", "")).strip().upper()

        # Per-job SLA resolution — returns (hours, source_label)
        sla_hrs, sla_source = _resolve_job_sla(job, sub_app)
        at_risk_floor = sla_hrs * 0.85

        run_date  = ""
        start_str = ""
        end_str   = ""
        try:
            st = pd.Timestamp(row.get("Start_Time", pd.NaT))
            run_date  = st.strftime("%Y-%m-%d") if pd.notna(st) else ""
            start_str = st.strftime("%H:%M") if pd.notna(st) else ""
        except Exception:
            pass
        try:
            et = pd.Timestamp(row.get("End_Time", pd.NaT))
            end_str = et.strftime("%H:%M") if pd.notna(et) else ""
        except Exception:
            pass

        margin = round(hrs - sla_hrs, 4)

        from services.pe_utils import SUCCESS_STATUSES
        is_failure = bool(raw_status) and raw_status not in SUCCESS_STATUSES
        if is_failure:
            st_label = "FAILED"
        elif hrs > sla_hrs:
            st_label = "BREACH"
        elif hrs >= at_risk_floor:
            st_label = "AT_RISK"
        else:
            st_label = "OK"
        results.append({
            "job_name": job, "sub_application": sub_app,
            "run_date": run_date, "start_time": start_str, "end_time": end_str,
            "run_hrs": round(hrs, 4), "sla_limit_hrs": round(sla_hrs, 4),
            "breach_margin_hrs": margin, "status": st_label,
            "sla_source": sla_source,  # sla_matrix | customer_fallback | assumed | global
        })

    rdf = pd.DataFrame(results) if results else pd.DataFrame()

    # FAILED runs are isolated — not counted toward SLA compliance/breach
    total_runs    = len(rdf)
    failed_count  = int((rdf["status"] == "FAILED").sum())  if not rdf.empty else 0
    eligible_runs = total_runs - failed_count
    breach_count  = int((rdf["status"] == "BREACH").sum())  if not rdf.empty else 0
    atrisk_count  = int((rdf["status"] == "AT_RISK").sum()) if not rdf.empty else 0
    ok_count      = int((rdf["status"] == "OK").sum())      if not rdf.empty else 0
    # Compliance: when all eligible runs failed, return 0% (not the misleading 100%).
    # Empty dataset (no runs at all) returns 100% ("nothing to comply with").
    if eligible_runs > 0:
        compliance = round((ok_count + atrisk_count) / eligible_runs * 100, 2)
    elif total_runs == 0:
        compliance = 100.0
    else:
        compliance = 0.0   # all runs FAILED — no successful delivery
    breach_rate   = round(breach_count / eligible_runs * 100, 2) if eligible_runs else 0.0

    # Filter breaches + at-risk for detail table
    detail = (rdf[rdf["status"].isin(["BREACH", "AT_RISK"])]
              .sort_values("run_hrs", ascending=False)
              .head(200)
              .to_dict(orient="records")) if not rdf.empty else []

    # Per-job rollup (excludes FAILED runs from peak/avg SLA metrics)
    if not rdf.empty:
        sla_rdf = rdf[rdf["status"] != "FAILED"]
        if sla_rdf.empty:
            sla_rdf = rdf  # fallback
        job_grp = sla_rdf.groupby("job_name").agg(
            runs        = ("run_hrs", "count"),
            peak_hrs    = ("run_hrs", "max"),
            avg_hrs     = ("run_hrs", "mean"),
            sla_limit   = ("sla_limit_hrs", "first"),   # per-job SLA
            sla_source  = ("sla_source", "first"),       # source label (sla_matrix | assumed | global …)
            breach_runs = ("status", lambda x: (x == "BREACH").sum()),
            atrisk_runs = ("status", lambda x: (x == "AT_RISK").sum()),
        ).reset_index()
        # Buffer calculated against each job's own SLA ceiling (not the global one)
        job_grp["buffer_pct"]  = job_grp.apply(
            lambda r: round((r.sla_limit - r.peak_hrs) / r.sla_limit * 100, 1)
            if r.sla_limit > 0 else 0.0, axis=1)
        job_grp["breach_rate"] = job_grp.apply(
            lambda r: round(r.breach_runs / r.runs * 100, 1) if r.runs else 0.0, axis=1)
        # Add fail count from the original rdf
        fail_grp = rdf[rdf["status"] == "FAILED"].groupby("job_name").size().reset_index(name="fail_count")
        job_grp = job_grp.merge(fail_grp, on="job_name", how="left")
        job_grp["fail_count"] = job_grp["fail_count"].fillna(0).astype(int)
        job_grp = job_grp.sort_values("peak_hrs", ascending=False)
        job_summary = job_grp.to_dict(orient="records")
    else:
        job_summary = []

    # Worst job
    worst_job     = ""
    worst_hrs_val = 0.0
    worst_margin  = 0.0
    if detail:
        worst = max(detail, key=lambda r: r["run_hrs"])
        worst_job    = worst["job_name"]
        worst_hrs_val = worst["run_hrs"]
        worst_margin = worst["breach_margin_hrs"]

    total_jobs = int(rdf["job_name"].nunique()) if not rdf.empty else 0

    # Update label to reflect actual source — always preserve the mode label so the
    # user can see their selection. Append SLA file context as a suffix.
    if explicit_sla_matrix:
        sla_label = f"Per-Job SLA file + {sla_label} fallback"
    elif has_per_job_sla:
        sla_label = f"Schedule ceilings + {sla_label} fallback"
    # else: keep the mode-only label (e.g. "Daily SLA (4.0h)")

    # ── Window-level compliance (daily elapsed wall-clock vs SLA) ────────
    # This is the same metric the Executive Dashboard uses — it measures
    # whether the entire batch completed within its SLA window each day,
    # NOT whether individual job runtimes are under the ceiling.
    window_comp_pct = None
    w_total_days = None
    w_breach_days = None
    w_detail_list = None
    try:
        has_end = "End_Time" in df.columns and df["End_Time"].notna().sum() > 0
        if has_end:
            wdf = df.copy()
            wdf["Start_Time"] = pd.to_datetime(wdf["Start_Time"], errors="coerce")
            wdf["End_Time"]   = pd.to_datetime(wdf["End_Time"],   errors="coerce")
            wdf = wdf.dropna(subset=["Start_Time", "End_Time"])
            if "run_date" not in wdf.columns:
                wdf["run_date"] = wdf["Start_Time"].dt.strftime("%Y-%m-%d")
            wgrp = (wdf.groupby("run_date")
                       .agg(first_start=("Start_Time", "min"),
                            last_end=("End_Time", "max"),
                            job_count=("Job_Name", "nunique"))
                       .dropna())
            if not wgrp.empty:
                wgrp["elapsed_hrs"] = (
                    (wgrp["last_end"] - wgrp["first_start"]).dt.total_seconds() / 3600.0
                ).clip(lower=0).round(3)
                wgrp["breach"] = wgrp["elapsed_hrs"] > global_sla_hrs
                w_total_days = len(wgrp)
                w_breach_days = int(wgrp["breach"].sum())
                if w_total_days > 0:
                    window_comp_pct = round((1 - w_breach_days / w_total_days) * 100, 1)
                w_detail_list = [
                    {"run_date": idx, "elapsed_hrs": round(float(r["elapsed_hrs"]), 3),
                     "job_count": int(r["job_count"]), "breach": bool(r["breach"]),
                     "sla_hrs": global_sla_hrs}
                    for idx, r in wgrp.iterrows()
                ]
    except Exception:
        pass

    # When window compliance is available, use it as the headline compliance
    # to match the Executive Dashboard — prevents contradictory stories.
    headline_compliance = window_comp_pct if window_comp_pct is not None else compliance

    resp = SlaMatrixResponse(
        sla_mode=sla_mode, sla_limit_hrs=global_sla_hrs, sla_label=sla_label,
        total_runs=total_runs, total_jobs=total_jobs,
        breaching_runs=breach_count, at_risk_runs=atrisk_count, ok_runs=ok_count,
        compliance_pct=headline_compliance, breach_rate_pct=breach_rate,
        worst_job=worst_job if worst_job else None,
        worst_hrs=worst_hrs_val, worst_margin_hrs=worst_margin,
        breaches=[SlaBreach(**r) for r in detail],
        job_summary=job_summary,
        window_compliance_pct=window_comp_pct,
        window_total_days=w_total_days,
        window_breach_days=w_breach_days,
        window_detail=w_detail_list,
        explicit_sla_matrix=explicit_sla_matrix,
    )

    # ── Adaptive per-job baselines + resource correlation ──────────
    # Compute even when no servers/heatmap are loaded — the baseline alone
    # surfaces job outliers that the global SLA doesn't catch.
    try:
        from services.job_baselines import (
            compute_job_baselines,
            enrich_runs_with_baselines,
            correlate_with_resource_hours,
        )
        baselines = compute_job_baselines(df)
        if baselines:
            resp.job_baselines = baselines
            enriched_runs = enrich_runs_with_baselines(df, baselines, sla_hrs=sla_hrs)
            outliers = [
                r for r in enriched_runs
                if r["is_job_outlier"] and not r["is_sla_breach"]
            ][:200]
            resp.outliers = outliers or None

            # Resource-link breaches + outliers when we have server context.
            from services import session_cache
            ad_resource = session_cache.get("last_resource", {}) or {}
            servers = (ad_resource.get("servers") or []) if isinstance(ad_resource, dict) else []
            hour_heatmap = session_cache.get("last_hour_heatmap")
            linked = correlate_with_resource_hours(
                enriched_runs, hour_heatmap, servers,
            )
            resp.resource_linked = linked[:200] or None
    except Exception as _exc:  # noqa: BLE001
        import logging
        logging.getLogger("pe_dashboard.sla_matrix").debug(
            "adaptive baselines skipped: %s", _exc,
        )
    # Cache the latest SLA matrix so agent tools can read it
    try:
        from services import session_cache
        session_cache.set("last_sla_matrix", resp.model_dump())
    except Exception:
        pass

    # ── Smartness gate (display layer) ─────────────────────────────
    # Filter parser-noise + magnitude-noise rows just before the
    # payload is shipped to the UI, and attach an audit block.
    try:
        from services.display_gate import gate
        cleaned = gate(resp.model_dump(), kind="sla_matrix")
        # Re-hydrate the response from the cleaned payload (fields the
        # gate touches: outliers, resource_linked, _gate audit).
        resp.outliers        = cleaned.get("outliers")
        resp.resource_linked = cleaned.get("resource_linked")
        # Stash the audit block on the response so the UI can show it.
        try:
            resp.gate_audit = cleaned.get("_gate")
        except Exception:
            pass
    except Exception:
        pass

    return resp


# ── Endpoints ────────────────────────────────────────────────────────────────

@router.post("/sla-matrix", response_model=SlaMatrixResponse)
async def sla_matrix_upload(
    file:     UploadFile = File(...),
    sla_mode: str        = Form("daily"),
    sla_hrs:  float      = Form(0.0),
) -> SlaMatrixResponse:
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="Empty file")

    try:
        df = load_ctrlm_bytes(raw, file.filename or "")
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Cannot parse Ctrl-M file: {exc}") from exc

    custom = float(sla_hrs) if sla_hrs and sla_hrs > 0 else config_store.get("custom_sla_hrs", 6.0)
    return _compute_sla_matrix(df, sla_mode, custom)


@router.post("/sla-matrix/json", response_model=SlaMatrixResponse)
def sla_matrix_json(body: JsonSlaRequest) -> SlaMatrixResponse:
    """Accept pre-parsed Ctrl-M rows (same format as /api/process-batch JSON)."""
    import pandas as pd

    if not body.rows:
        # Return empty response
        return SlaMatrixResponse(
            sla_mode="daily", sla_limit_hrs=6.0, sla_label="Daily SLA",
            total_runs=0, total_jobs=0, breaching_runs=0, at_risk_runs=0, ok_runs=0,
            compliance_pct=100.0, breach_rate_pct=0.0,
            worst_job=None, worst_hrs=0.0, worst_margin_hrs=0.0,
            breaches=[], job_summary=[],
        )

    df = pd.DataFrame(body.rows)
    # Ensure run_time_hrs
    if "run_time_hrs" not in df.columns and "Run_Sec" in df.columns:
        df["run_time_hrs"] = pd.to_numeric(df["Run_Sec"], errors="coerce").fillna(0) / 3600.0
    elif "run_time_hrs" not in df.columns and "peak_hrs" in df.columns:
        df["run_time_hrs"] = pd.to_numeric(df["peak_hrs"], errors="coerce").fillna(0)

    custom = body.sla_hrs or config_store.get("custom_sla_hrs", 6.0)
    return _compute_sla_matrix(df, body.sla_mode or "daily", custom)
