"""
PE Audit Dashboard — FastAPI entrypoint.

Stateless backend that replaces the original Streamlit monolith
(`app_v2.py`). Serves the Jinja2 shell at `/`, mounts static assets
at `/static`, and exposes `/api/*` REST endpoints.

Run locally:
    uvicorn main:app --host 127.0.0.1 --port 8765 --reload
or use the bundled `start.bat`.
"""
from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os

from routers import ai as ai_router
from routers import batch as batch_router
from routers import benchmark as benchmark_router
from routers import config as config_router
from routers import correlation as correlation_router
from routers import executive as executive_router
from routers import export as export_router
from routers import final_judgment as final_judgment_router
from routers import findings as findings_router
from routers import pe_consultant as pe_consultant_router
from routers import pe_narrative as pe_narrative_router
from routers import redflags as redflags_router
from routers import resource as resource_router
from routers import sla_matrix as sla_matrix_router
from routers import sla_intelligence as sla_intelligence_router
from routers import sow as sow_router
from routers import upload as upload_router
from routers import agent as agent_router
from routers import azure_resource as azure_resource_router

# ── Paths ───────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"

# ── App ─────────────────────────────────────────────────────────
app = FastAPI(
    title="PE Audit Dashboard",
    description="Stateless FastAPI backend for the Performance Engineering Audit Dashboard.",
    version="2.0.0",
)

# CORS — origins controlled via ALLOWED_ORIGINS env var (comma-separated).
# Defaults to localhost only for safety; set ALLOWED_ORIGINS='*' only for
# isolated local dev that never faces a network.
_raw_origins = os.environ.get("ALLOWED_ORIGINS", "http://127.0.0.1:8765,http://localhost:8765")
_CORS_ORIGINS: list[str] = [o.strip() for o in _raw_origins.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=_CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
)

# ── Static + templates ──────────────────────────────────────────
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

# ── Routers ─────────────────────────────────────────────────────
app.include_router(upload_router.router,      prefix="/api", tags=["upload"])
app.include_router(batch_router.router,       prefix="/api", tags=["batch"])
app.include_router(resource_router.router,    prefix="/api", tags=["resource"])
app.include_router(export_router.router,      prefix="/api", tags=["export"])
app.include_router(findings_router.router,    prefix="/api", tags=["findings"])
app.include_router(ai_router.router,          prefix="/api", tags=["ai"])
app.include_router(correlation_router.router, prefix="/api", tags=["correlation"])
app.include_router(executive_router.router,   prefix="/api", tags=["executive"])
app.include_router(redflags_router.router,    prefix="/api", tags=["redflags"])
app.include_router(sla_matrix_router.router,  prefix="/api", tags=["sla-matrix"])
app.include_router(sla_intelligence_router.router, prefix="/api", tags=["sla-intelligence"])
app.include_router(benchmark_router.router,   prefix="/api", tags=["benchmark"])
app.include_router(config_router.router,      prefix="/api", tags=["config"])
app.include_router(sow_router.router,         prefix="/api", tags=["sow"])
app.include_router(final_judgment_router.router, prefix="/api", tags=["judgment"])
app.include_router(pe_consultant_router.router, prefix="/api", tags=["consultant"])
app.include_router(pe_narrative_router.router,  prefix="/api", tags=["pe-narrative"])
app.include_router(agent_router.router,         prefix="/api", tags=["agent"])
app.include_router(azure_resource_router.router, prefix="/api", tags=["azure"])


# ── Shell route ─────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def index(request: Request) -> HTMLResponse:
    """Render the SPA shell. All UI rendering is done client-side."""
    return templates.TemplateResponse(request, "index.html")


@app.get("/favicon.ico", include_in_schema=False)
async def favicon() -> FileResponse:
    """Serve SVG favicon — eliminates the 404 in browser console."""
    ico = BASE_DIR / "static" / "favicon.svg"
    if ico.exists():
        return FileResponse(str(ico), media_type="image/svg+xml")
    return RedirectResponse("/static/favicon.svg")


@app.get("/api/health", tags=["meta"])
async def health() -> dict:
    """Simple liveness probe — used by `_open_browser.py` and CI."""
    return {"status": "ok", "service": "pe-audit-dashboard", "version": app.version}
