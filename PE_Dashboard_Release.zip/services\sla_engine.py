"""
SLA Intelligence Engine — metadata-driven SLA interpretation.

Auto-detects SLA schema from uploaded customer files, normalizes schedule
and time semantics, chooses the correct calculation model, applies
contingency/buffer rules when present, flags ambiguity when data is
incomplete, and outputs audit-friendly results with source traceability.

SLA Models supported:
  WINDOW    — absolute start/end time cutoff (e.g. 6:00 AM → 12:00 PM)
  DURATION  — expected runtime duration     (e.g. Expected Run time = 2h)
  BUFFERED  — window + contingency margin   (e.g. End + 30m buffer)
  CALENDAR  — schedule-text only, no numeric SLA (e.g. "Runs every Mon-Fri")
  PARTIAL   — some rows have SLA, some don't

Public API:
    ingest_sla_file(raw_bytes, filename)  → SlaIngestResult
    resolve_sla(batch_name, schedule, sla_contracts) → ResolvedSla
    compare_actual(resolved_sla, actual_start, actual_end, actual_runtime_hrs) → SlaVerdict
"""
from __future__ import annotations

import io
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, time as dtime, date, timedelta
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("pe_dashboard.sla_engine")

# ── Schedule text classification ──────────────────────────────────────────────

_DAILY_PATTERNS = [
    r"(?:^|[^A-Za-z])DAILY(?:$|[^A-Za-z])",       # DAILY, DMD_DAILY, FF_DAILY, daily-cyclic
    r"\bMON\s*[-–]\s*FRI\b", r"\bMON\s*[-–]\s*THU[R]?\b",  # Mon-Fri, Mon-Thu, Mon-Thur
    r"\bMON(?:DAY)?\s+TO\s+(?:FRI|FRIDAY|SAT|SATURDAY|THU|THURSDAY|THU[R]?S?|SUN|SUNDAY)\b",
    r"\bMONDAY\s+TO\s+(?:FRIDAY|SATURDAY|THURSDAY|SUNDAY)\b",  # full-word: Monday to Saturday
    r"\bMON\s*,\s*TUE\s*,\s*WED\b", r"\bEVERY\s+(WEEK\s*)?DAY\b",
    r"\bEVERY\s*DAY\b",                              # everyday, every day
    r"\bEVERY\s*D(?:AY)?\b",
    r"\bRUNS\s+EVERY\s*(?:DAY|WEEKDAY|WORKING\s*DAY)\b",  # Runs everyday, Runs every day
    r"\bRUNS\s+EVERYDAY\b",                          # "Runs everyday"
    r"\bOVERNIGHT\b", r"\bNIGHTLY\b", r"\bMON\s*[-–]\s*SAT\b",
    r"\bMONDAY\s*[-–]\s*SATURDAY\b", r"\bMON\s*[-–]\s*SUN\b",
    r"\bCYCLIC\b", r"\bINTRADAY\b",                 # daily cyclic / intraday batches
    r"\bD\d*\b",
]
_WEEKLY_PATTERNS = [
    r"(?:^|[^A-Za-z])WEEKLY(?:$|[^A-Za-z])",       # WEEKLY, DMD_BYC_WEEKLY
    r"\bEVERY\s+SUNDAY\b", r"\bEVERY\s+SATURDAY\b",
    r"\bEVERY\s+\w+DAY\b",
    r"\bSUN(?:DAY)?S?\b", r"\bSAT(?:URDAY)?S?\b",   # Sunday, Sundays, Saturday, Saturdays
    r"\bWEEKEND\b", r"\bW\d*\b",
]
_MONTHLY_PATTERNS = [
    r"(?:^|[^A-Za-z])MONTHLY(?:$|[^A-Za-z])",
    r"\b1ST\s+WORKING\s*DAY\b", r"\bFIRST\s+WORKING\b",
    r"\bEND\s+OF\s+MONTH\b", r"\bEOM\b", r"\bMONTH\s*[-–]?\s*END\b",
    r"\bM\d+\b", r"\b\d+(?:ST|ND|RD|TH)\s+OF\s+(?:EACH\s+)?MONTH\b",  # "12th of Month" or "12th of each month"
    r"\b\d+\s+(?:ST|ND|RD|TH)\s+OF\s+(?:EACH\s+)?MONTH\b",              # "12 Th of Month" (spaced ordinal)
    r"\bEVERY\s+\d+\s*(?:ST|ND|RD|TH)\b",                                # "Every 12th" / "Every 12 Th"
    r"\bON\s+EVERY\s+\d+\s*(?:ST|ND|RD|TH)\b",                           # "on Every 12 Th of Month"
    r"\bLAST\s+\w+\s+OF\s+(EACH\s+)?MONTH\b",
]
_ADHOC_PATTERNS = [
    r"\bAD\s*HOC\b", r"\bADHOC\b", r"\bON\s*DEMAND\b",
    r"\bMANUAL\b", r"\bAS\s+NEEDED\b", r"\bSPECIAL\b",
]

_COMPILED_SCHED = {
    "DAILY":   [re.compile(p, re.I) for p in _DAILY_PATTERNS],
    "WEEKLY":  [re.compile(p, re.I) for p in _WEEKLY_PATTERNS],
    "MONTHLY": [re.compile(p, re.I) for p in _MONTHLY_PATTERNS],
    "ADHOC":   [re.compile(p, re.I) for p in _ADHOC_PATTERNS],
}


def classify_schedule(text: str) -> str:
    """Classify schedule text → DAILY | WEEKLY | MONTHLY | ADHOC | UNKNOWN."""
    if not text:
        return "UNKNOWN"
    for sched_type, patterns in _COMPILED_SCHED.items():
        for pat in patterns:
            if pat.search(text):
                return sched_type
    return "UNKNOWN"


# ── Column name normalization ─────────────────────────────────────────────────

# Maps messy customer column names → canonical field names
_COLUMN_MAP: Dict[str, str] = {}
_COL_PATTERNS: List[Tuple[re.Pattern, str]] = [
    # Batch / Job name — most-specific first, then standalone "Batch"/"Job"
    (re.compile(r"batch[\s_-]?name|batch[\s_-]?type|window[\s_-]?name|module", re.I), "batch_name"),
    (re.compile(r"^batch$|^job$", re.I), "batch_name"),
    (re.compile(r"schedule[\s_-]?(type|name)?$", re.I), "schedule_text"),
    (re.compile(r"^day$|^days$|^frequency$|^run[\s_-]?days?$", re.I), "schedule_text"),
    (re.compile(r"first[\s_-]?job|first[\s_-]?jobname", re.I), "first_job"),
    (re.compile(r"last[\s_-]?job|last[\s_-]?jobname", re.I), "last_job"),
    # Time fields — ordered most-specific first
    (re.compile(r"sla[\s_-]?cutoff|cutoff", re.I), "sla_end_time"),                     # Batch_Plan__SLA_Check.csv
    (re.compile(r"expected[\s_-]?end[\s_-]?time[\s_-]?/?sla|expected[\s_-]?end[\s_-]?time|expected[\s_-]?end|expected[\s_-]?finish|deadline|close|window[\s_-]?end|sla[\s_-]?end", re.I), "sla_end_time"),
    (re.compile(r"start[\s_-]?time|window[\s_-]?start|begin|open", re.I), "start_time"),
    (re.compile(r"current[\s_-]?end[\s_-]?time|actual[\s_-]?end", re.I), "actual_end_time"),
    (re.compile(r"expected[\s_-]?run[\s_-]?time|expected[\s_-]?duration|sla[\s_-]?duration|sla[\s_-]?runtime", re.I), "sla_duration"),
    (re.compile(r"current[\s_-]?run[\s_-]?time|actual[\s_-]?run[\s_-]?time|actual[\s_-]?duration", re.I), "actual_duration"),
    # Buffer / contingency
    (re.compile(r"buffer|contingency|margin|grace", re.I), "buffer"),
    # Timezone
    (re.compile(r"time[\s_-]?zone|tz", re.I), "timezone"),
    # Comments / notes
    (re.compile(r"comment|note|remark|interpretation|agreement", re.I), "comments"),
    # Status
    (re.compile(r"pass[\s_-]?fail|sla[\s_-]?status|status|result|outcome", re.I), "status"),
]


def _normalize_column(raw_col: str) -> str:
    """Map a raw column name to canonical field name."""
    clean = str(raw_col).strip()
    for pat, canonical in _COL_PATTERNS:
        if pat.search(clean):
            return canonical
    return clean.lower().replace(" ", "_").replace("-", "_")


# ── Time parsing ──────────────────────────────────────────────────────────────

_TIME_FORMATS = [
    "%I:%M %p", "%I.%M %p", "%I.%M%p",  # 9:00 PM, 10.45 AM (dot-notation Haleon)
    "%H:%M", "%I %p", "%I:%M%p",
    "%H:%M:%S", "%I:%M:%S %p", "%H:%M:%S.%f",
    "%I%p",   # 5AM (no colon/space)
]
_TZ_SUFFIX = re.compile(
    r'\s+(?:CST|CDT|EST|EDT|PST|PDT|MST|MDT|IST|GMT|UTC[+-]?\d*|PHT|ET|CT|PT|MT)\s*$',
    re.IGNORECASE)


def _parse_time(raw: str) -> Optional[dtime]:
    """Parse time string in various formats → datetime.time or None.

    Handles: 9:00 PM, 10.45 AM, 21:00, 5AM, 5AM CST, 11:00 AM (Sequencing SLA)
    """
    if not raw or str(raw).lower() in ("nan", "none", "", "nat"):
        return None
    raw = str(raw).strip()
    # Strip trailing timezone qualifiers: "5AM CST", "5AM IST"
    raw = _TZ_SUFFIX.sub('', raw).strip()
    # Strip parenthetical notes: "11:00 AM (Morning SLA)"
    raw = re.sub(r'\s*\([^)]*\)\s*$', '', raw).strip()
    # Extract leading time token to drop trailing noise
    _tm = re.match(r'^(\d{1,2}[.:]\d{2}(?::\d{2})?(?:\s*[AP]M)?|\d{1,2}\s*[AP]M|\d{1,2}[AP]M)', raw, re.I)
    if _tm:
        raw = _tm.group(1).strip()
    for fmt in _TIME_FORMATS:
        try:
            return datetime.strptime(raw, fmt).time()
        except (ValueError, TypeError):
            continue
    m = re.search(r'(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?', raw, re.I)
    if m:
        try:
            hh = int(m.group(1))
            mm = int(m.group(2))
            ampm = (m.group(4) or "").upper()
            if ampm == "PM" and hh < 12:
                hh += 12
            elif ampm == "AM" and hh == 12:
                hh = 0
            return dtime(hh, mm)
        except Exception:
            pass
    return None


def _parse_duration_hrs(raw: str) -> Optional[float]:
    """Parse a duration string (e.g. '2h 30m', '02:30', '150 min') → hours."""
    if not raw or str(raw).lower() in ("nan", "none", "", "nat"):
        return None
    raw = str(raw).strip()
    # Try HH:MM format
    m = re.match(r'^(\d{1,3}):(\d{2})(?::(\d{2}))?$', raw)
    if m:
        hrs = int(m.group(1)) + int(m.group(2)) / 60
        if m.group(3):
            hrs += int(m.group(3)) / 3600
        return round(hrs, 3)
    # Try "Xh Ym" format
    m = re.search(r'(\d+(?:\.\d+)?)\s*h(?:ours?)?', raw, re.I)
    hrs = float(m.group(1)) if m else 0.0
    m2 = re.search(r'(\d+(?:\.\d+)?)\s*m(?:in(?:utes?)?)?', raw, re.I)
    if m2:
        hrs += float(m2.group(1)) / 60
    if hrs > 0:
        return round(hrs, 3)
    # Try pure numeric (assume hours if < 24, else minutes)
    try:
        val = float(raw)
        if val <= 0:
            return None
        return round(val, 3) if val < 24 else round(val / 60, 3)
    except (ValueError, TypeError):
        return None


def _time_delta_hours(start: Optional[dtime], end: Optional[dtime]) -> Optional[float]:
    """Hours between two time objects. Handles overnight crossing."""
    if start is None or end is None:
        return None
    base = date(2000, 1, 1)
    dt_start = datetime.combine(base, start)
    dt_end = datetime.combine(base, end)
    delta = (dt_end - dt_start).total_seconds() / 3600.0
    if delta < 0:
        delta += 24.0
    return round(delta, 3) if delta > 0 else None


# ── Business-context interpretation (generic, customer-agnostic) ─────────────

_ACK_PATTERNS = re.compile(
    r"\b("
    r"no\s*breach|"
    r"not\s*a\s*breach|"
    r"agreed|"
    r"acceptable|"
    r"buffer\s*(agreed|approved|exists)|"
    r"approved\s*by|"
    r"system\s*(is\s*)?available\s*(around\s*)?\d+\s*[-–]?\s*\d*\s*min|"
    r"available\s*\d+\s*[-–]?\s*\d*\s*min\s*earlier|"
    r"spooling\s*jobs|"
    r"runs?\s*through(?:\s*out)?\s*the\s*day|"
    r"running\s*every\s*\d+\s*min"
    r")\b",
    re.I,
)
_CYCLIC_PATTERNS = re.compile(
    r"\b("
    r"cyclic|intraday|every\s*\d+\s*min|every\s*\d+\s*minutes|"
    r"continuous(?:ly)?|24[x×]7|round[\s-]*the[\s-]*clock"
    r")\b",
    re.I,
)


def _detect_business_ack(comments: str) -> bool:
    return bool(_ACK_PATTERNS.search(comments or ""))


def _detect_cyclic(*texts: str) -> bool:
    blob = " ".join(t for t in texts if t)
    return bool(_CYCLIC_PATTERNS.search(blob))


def _compute_buffer(window_hrs: Optional[float],
                    actual_window_hrs: Optional[float],
                    buffer_minutes: Optional[float]
                    ) -> Tuple[Optional[float], Optional[float]]:
    """Return (buffer_hrs, buffer_pct).

    Priority: explicit buffer column > derived from (window − actual).
    """
    if buffer_minutes and buffer_minutes > 0:
        b_hrs = buffer_minutes / 60.0
        b_pct = (b_hrs / window_hrs * 100.0) if window_hrs and window_hrs > 0 else None
        return round(b_hrs, 3), (round(b_pct, 1) if b_pct is not None else None)
    if window_hrs and actual_window_hrs is not None:
        b_hrs = window_hrs - actual_window_hrs
        b_pct = (b_hrs / window_hrs * 100.0) if window_hrs > 0 else None
        return round(b_hrs, 3), (round(b_pct, 1) if b_pct is not None else None)
    return None, None


def _derive_health(window_hrs: Optional[float],
                   actual_window_hrs: Optional[float],
                   buffer_pct: Optional[float],
                   business_ack: bool,
                   is_cyclic: bool
                   ) -> Tuple[str, str]:
    """Decide the traffic-light status. Returns (status, reason)."""
    if is_cyclic:
        return "CYCLIC", "Cyclic / intraday — SLA window not applicable"
    if actual_window_hrs is None or window_hrs is None:
        return "NO_DATA", "No actual end time — health undetermined"
    if actual_window_hrs > window_hrs:
        if business_ack:
            return "ACK", "Overrun acknowledged in comments"
        overrun = actual_window_hrs - window_hrs
        return "BREACH", f"Overran SLA by {overrun:.1f}h"
    # within window
    if buffer_pct is not None and buffer_pct < 10.0:
        return "AT_RISK", f"Only {buffer_pct:.0f}% buffer remaining"
    if business_ack:
        return "ACK", "Within SLA — business note acknowledged"
    return "OK", "Within SLA window"


def _parse_buffer_minutes(raw: str) -> Optional[float]:
    """Parse buffer/contingency value → minutes."""
    if not raw or str(raw).lower() in ("nan", "none", "", "nat", "0"):
        return None
    raw = str(raw).strip()
    m = re.search(r'(\d+(?:\.\d+)?)\s*m(?:in)?', raw, re.I)
    if m:
        return float(m.group(1))
    m = re.search(r'(\d+(?:\.\d+)?)\s*h', raw, re.I)
    if m:
        return float(m.group(1)) * 60
    try:
        val = float(raw)
        return val if val > 0 else None
    except (ValueError, TypeError):
        return None


# ── Data classes ──────────────────────────────────────────────────────────────

@dataclass
class SlaContract:
    """One resolved SLA rule for a batch/schedule."""
    batch_name: str
    schedule_type: str          # DAILY | WEEKLY | MONTHLY | ADHOC | UNKNOWN
    schedule_raw: str           # original schedule text
    sla_model: str              # WINDOW | DURATION | BUFFERED | CALENDAR | PARTIAL | ASSUMED
    sla_start: Optional[dtime] = None
    sla_end: Optional[dtime] = None
    sla_duration_hrs: Optional[float] = None
    sla_window_hrs: Optional[float] = None   # computed from start→end or explicit
    buffer_minutes: Optional[float] = None
    first_job: str = ""
    last_job: str = ""
    timezone: str = ""
    comments: str = ""
    interpretation_notes: str = ""
    source_row: int = -1        # row index in original file
    source_sheet: str = ""
    completeness: str = "complete"  # complete | partial | missing
    # Enrichment — derived from row + comments, used by UI/display gate
    actual_end: Optional[dtime] = None        # observed batch end time from file
    actual_window_hrs: Optional[float] = None # start → actual_end
    buffer_hrs: Optional[float] = None        # window − actual_window (or buffer_minutes/60)
    buffer_pct: Optional[float] = None        # buffer_hrs / window * 100
    business_acknowledged: bool = False       # comments waive breach (no breach / agreed)
    is_cyclic: bool = False                   # cyclic / intraday / every Nmin
    health_status: str = "NO_DATA"            # OK | AT_RISK | BREACH | ACK | CYCLIC | NO_DATA
    health_reason: str = ""                   # human-readable explanation

    def to_dict(self) -> Dict[str, Any]:
        return {
            "batch_name": self.batch_name,
            "schedule_type": self.schedule_type,
            "schedule_raw": self.schedule_raw,
            "sla_model": self.sla_model,
            "sla_start": self.sla_start.isoformat() if self.sla_start else None,
            "sla_end": self.sla_end.isoformat() if self.sla_end else None,
            "sla_duration_hrs": self.sla_duration_hrs,
            "sla_window_hrs": self.sla_window_hrs,
            "buffer_minutes": self.buffer_minutes,
            "first_job": self.first_job,
            "last_job": self.last_job,
            "timezone": self.timezone,
            "comments": self.comments,
            "interpretation_notes": self.interpretation_notes,
            "source_row": self.source_row,
            "source_sheet": self.source_sheet,
            "completeness": self.completeness,
            "actual_end": self.actual_end.isoformat() if self.actual_end else None,
            "actual_window_hrs": self.actual_window_hrs,
            "buffer_hrs": self.buffer_hrs,
            "buffer_pct": self.buffer_pct,
            "business_acknowledged": self.business_acknowledged,
            "is_cyclic": self.is_cyclic,
            "health_status": self.health_status,
            "health_reason": self.health_reason,
        }


@dataclass
class SlaIngestResult:
    """Full result of ingesting an SLA file."""
    filename: str
    schema_type: str          # "window" | "duration" | "buffered" | "mixed" | "unrecognised"
    detected_model: str       # human-readable label
    contracts: List[SlaContract] = field(default_factory=list)
    ceilings: Dict[str, float] = field(default_factory=dict)    # DAILY/WEEKLY/MONTHLY → hours (file-sourced only)
    missing_ceilings: List[str] = field(default_factory=list)   # schedule types absent from the file
    schedule_map: Dict[str, str] = field(default_factory=dict)  # batch_name → schedule_type
    warnings: List[Dict[str, str]] = field(default_factory=list)
    sections_detected: List[str] = field(default_factory=list)  # e.g. ["sla_table", "actuals", "comparison"]
    raw_columns: List[str] = field(default_factory=list)
    normalized_columns: Dict[str, str] = field(default_factory=dict)
    total_rows: int = 0
    valid_rows: int = 0
    partial_rows: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "filename": self.filename,
            "schema_type": self.schema_type,
            "detected_model": self.detected_model,
            "contracts": [c.to_dict() for c in self.contracts],
            "ceilings": self.ceilings,
            "missing_ceilings": self.missing_ceilings,
            "schedule_map": self.schedule_map,
            "warnings": self.warnings,
            "sections_detected": self.sections_detected,
            "raw_columns": self.raw_columns,
            "normalized_columns": self.normalized_columns,
            "total_rows": self.total_rows,
            "valid_rows": self.valid_rows,
            "partial_rows": self.partial_rows,
        }


@dataclass
class ResolvedSla:
    """Result of resolving the right SLA for a specific batch execution."""
    sla_hrs: float
    sla_model: str              # WINDOW | DURATION | BUFFERED | ASSUMED
    source: str                 # "sla_matrix" | "customer_fallback" | "assumed"
    source_detail: str          # human-readable description
    schedule_type: str          # DAILY | WEEKLY | MONTHLY | ADHOC | UNKNOWN
    matched_contract: Optional[SlaContract] = None
    buffer_minutes: Optional[float] = None
    confidence: str = "high"    # high | medium | low
    blocked: bool = False       # True → cannot produce green compliance
    block_reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sla_hrs": self.sla_hrs,
            "sla_model": self.sla_model,
            "source": self.source,
            "source_detail": self.source_detail,
            "schedule_type": self.schedule_type,
            "buffer_minutes": self.buffer_minutes,
            "confidence": self.confidence,
            "blocked": self.blocked,
            "block_reason": self.block_reason,
            "matched_contract": self.matched_contract.to_dict() if self.matched_contract else None,
        }


@dataclass
class SlaVerdict:
    """Result of comparing actual execution against resolved SLA."""
    status: str                 # PASS | BREACH | AT_RISK | PASS_WITH_BUFFER | FAIL
    strict_status: str          # PASS | BREACH (without buffer)
    buffered_status: str        # PASS | BREACH (with buffer applied)
    actual_hrs: float
    sla_hrs: float
    margin_hrs: float           # positive = headroom, negative = overrun
    buffer_applied: bool
    buffer_margin_hrs: Optional[float] = None
    explanation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status,
            "strict_status": self.strict_status,
            "buffered_status": self.buffered_status,
            "actual_hrs": round(self.actual_hrs, 3),
            "sla_hrs": round(self.sla_hrs, 3),
            "margin_hrs": round(self.margin_hrs, 3),
            "buffer_applied": self.buffer_applied,
            "buffer_margin_hrs": round(self.buffer_margin_hrs, 3) if self.buffer_margin_hrs is not None else None,
            "explanation": self.explanation,
        }


# ── Section boundary detection ────────────────────────────────────────────────

_SECTION_MARKERS = {
    "sla_table":  re.compile(r"batch\s*name|schedule|expected\s*end|sla\s*window", re.I),
    "actuals":    re.compile(r"actual\s*start|actual\s*end|current\s*end|date.wise|sample", re.I),
    "comparison": re.compile(r"test\s*vs\s*prod|prod\s*vs\s*test|comparison|environment", re.I),
    "contingency": re.compile(r"contingency|buffer|grace|pass.?fail\s*after", re.I),
    "notes":      re.compile(r"note|comment|remark|assumption|interpretation", re.I),
}


def _detect_sections(df_raw) -> List[str]:
    """Detect logical sections in a worksheet by scanning all cell text."""
    import pandas as pd
    found = set()
    text_blob = " ".join(
        str(v) for v in df_raw.values.flatten()
        if pd.notna(v) and str(v).strip()
    )[:5000]
    for section, pat in _SECTION_MARKERS.items():
        if pat.search(text_blob):
            found.add(section)
    return sorted(found)


# ── File ingestion ────────────────────────────────────────────────────────────

def _truncate_at_secondary_header(df_raw):
    """Detect a mid-sheet secondary header and truncate the dataframe.

    Real-world SLA workbooks frequently stack a second table below the first
    (e.g. per-run actuals after the SLA contract list, separated by blank
    rows). We detect this by scanning every row for cells whose VALUES look
    like header tokens (``DATE``, ``DAY``, ``START TIME``, ``END TIME``,
    ``Duration``, ``First Job``, etc.). If at least two such tokens appear
    in a single row AND that row sits below the first row, we truncate
    everything from that row onward — those are not SLA contracts, those
    are run-history records masquerading as them.
    """
    import pandas as pd
    if df_raw is None or df_raw.empty:
        return df_raw
    header_tokens = re.compile(
        r"^(date|day|start\s*time|end\s*time|duration|first\s*job|"
        r"last\s*job|run\s*time|job\s*name|status|run\s*date)\b",
        re.I,
    )
    for i in range(1, len(df_raw)):
        row = df_raw.iloc[i]
        hits = 0
        for v in row.values:
            if pd.notna(v) and isinstance(v, str) and header_tokens.match(v.strip()):
                hits += 1
                if hits >= 2:
                    return df_raw.iloc[:i].copy()
    return df_raw


def _ingest_sla_sheet(df_raw, sheet_name: str, result: "SlaIngestResult") -> int:
    """Parse a single sheet's dataframe into contracts. Returns rows added."""
    import pandas as pd

    df_raw = _truncate_at_secondary_header(df_raw)
    df_raw.columns = [str(c).strip() for c in df_raw.columns]
    if not result.raw_columns:
        result.raw_columns = list(df_raw.columns)
    result.total_rows += len(df_raw)

    # Normalize column names
    col_map = {raw: _normalize_column(raw) for raw in df_raw.columns}
    df = df_raw.rename(columns=col_map)

    # Coalesce duplicate canonical columns (see comment below)
    if not df.columns.is_unique:
        seen: Dict[str, int] = {}
        new_frames = {}
        order: List[str] = []
        for col in df.columns:
            if col in seen:
                continue
            seen[col] = 1
            same = [c for c in df.columns if c == col]
            if len(same) == 1:
                new_frames[col] = df[col]
            else:
                block = df.loc[:, same]
                new_frames[col] = block.bfill(axis=1).iloc[:, 0]
            order.append(col)
        df = pd.DataFrame({c: new_frames[c] for c in order})

    has_start       = "start_time"   in df.columns
    has_end         = "sla_end_time" in df.columns
    has_duration    = "sla_duration" in df.columns
    has_buffer      = "buffer"       in df.columns
    has_schedule    = "schedule_text" in df.columns
    has_batch_name  = "batch_name"   in df.columns

    def _cell(row, key: str) -> str:
        try:
            v = row.get(key, "")
        except Exception:
            v = ""
        if hasattr(v, "iloc"):
            try:
                v = v.dropna().iloc[0] if v.dropna().size else ""
            except Exception:
                v = ""
        if v is None:
            return ""
        try:
            if pd.isna(v):
                return ""
        except Exception:
            pass
        s = str(v).strip()
        if "dtype:" in s and "Name:" in s:
            return ""
        if s.lower() in ("nan", "none", "nat"):
            return ""
        return s

    added = 0
    for idx, row in df.iterrows():
        batch_name    = _cell(row, "batch_name")    if has_batch_name else ""
        schedule_raw  = _cell(row, "schedule_text") if has_schedule   else ""
        schedule_type = classify_schedule(schedule_raw or batch_name)

        start_t = _parse_time(_cell(row, "start_time"))   if has_start    else None
        end_cell = _cell(row, "sla_end_time") if has_end else ""
        end_t    = _parse_time(end_cell) if end_cell else None
        dur_hrs  = _parse_duration_hrs(_cell(row, "sla_duration")) if has_duration else None
        # Generic fallback: the "Expected End Time/SLA" column sometimes holds a
        # duration string ('1.5 hrs', '45 min') rather than a clock time. If
        # _parse_time returned None and we have no explicit duration column, try
        # interpreting the same cell as a duration.
        if end_t is None and end_cell and dur_hrs is None:
            dur_hrs = _parse_duration_hrs(end_cell)
        window_hrs = _time_delta_hours(start_t, end_t)
        if window_hrs is None and dur_hrs is not None:
            window_hrs = dur_hrs

        buffer_min = _parse_buffer_minutes(_cell(row, "buffer")) if has_buffer else None
        first_job  = _cell(row, "first_job") if "first_job" in df.columns else ""
        last_job   = _cell(row, "last_job")  if "last_job"  in df.columns else ""
        tz         = _cell(row, "timezone")  if "timezone"  in df.columns else ""
        comments   = _cell(row, "comments")  if "comments"  in df.columns else ""

        if not batch_name and not schedule_raw and window_hrs is None and dur_hrs is None:
            continue

        if window_hrs is not None and window_hrs > 0:
            completeness = "complete"
            result.valid_rows += 1
        elif dur_hrs is not None and dur_hrs > 0:
            completeness = "complete"
            result.valid_rows += 1
        elif batch_name or schedule_raw:
            completeness = "partial"
            result.partial_rows += 1
        else:
            continue

        if has_buffer and buffer_min and buffer_min > 0 and window_hrs:
            row_model = "BUFFERED"
        elif window_hrs is not None:
            row_model = "WINDOW"
        elif dur_hrs is not None:
            row_model = "DURATION"
        elif schedule_raw:
            row_model = "CALENDAR"
        else:
            row_model = "PARTIAL"

        interp_notes = ""
        if comments and comments.lower() not in ("nan", "none", ""):
            if re.search(r"unofficial|no breach|agreed|buffer|optimizer|existing", comments, re.I):
                interp_notes = f"Business context: {comments[:200]}"
            else:
                interp_notes = comments[:200]

        contract = SlaContract(
            batch_name=batch_name or f"Row_{idx}",
            schedule_type=schedule_type,
            schedule_raw=schedule_raw,
            sla_model=row_model,
            sla_start=start_t,
            sla_end=end_t,
            sla_duration_hrs=dur_hrs,
            sla_window_hrs=window_hrs,
            buffer_minutes=buffer_min,
            first_job=first_job,
            last_job=last_job,
            timezone=tz,
            comments=comments,
            interpretation_notes=interp_notes,
            source_row=int(idx) + 2,
            source_sheet=sheet_name,
            completeness=completeness,
        )
        # ── Enrichment: actual end + derived buffer + health traffic-light ──
        actual_end_t = (
            _parse_time(_cell(row, "actual_end_time"))
            if "actual_end_time" in df.columns else None
        )
        actual_window_hrs = _time_delta_hours(start_t, actual_end_t) if actual_end_t else None
        buffer_hrs, buffer_pct = _compute_buffer(window_hrs, actual_window_hrs, buffer_min)
        is_cyclic_flag        = _detect_cyclic(comments, schedule_raw, batch_name)
        business_ack_flag     = _detect_business_ack(comments)
        health_status, health_reason = _derive_health(
            window_hrs, actual_window_hrs, buffer_pct, business_ack_flag, is_cyclic_flag,
        )
        contract.actual_end           = actual_end_t
        contract.actual_window_hrs    = actual_window_hrs
        contract.buffer_hrs           = buffer_hrs
        contract.buffer_pct           = buffer_pct
        contract.business_acknowledged = business_ack_flag
        contract.is_cyclic            = is_cyclic_flag
        contract.health_status        = health_status
        contract.health_reason        = health_reason

        result.contracts.append(contract)
        added += 1

        if batch_name:
            result.schedule_map[batch_name] = schedule_type

    return added


def ingest_sla_file(raw_bytes: bytes, filename: str) -> SlaIngestResult:
    """Ingest an SLA file and extract structured contracts.

    Pipeline: ingest → walk every sheet → detect layout → normalize columns →
              parse schedule → resolve SLA model → build contracts.

    Multi-sheet support: real customer SLA workbooks (e.g. WESCO) stack
    summary contracts on one sheet and the per-batch detailed SLAs on
    another. Reading only sheet 0 silently misses the most important data.
    Every sheet is parsed; contracts are merged.
    """
    import pandas as pd

    result = SlaIngestResult(filename=filename, schema_type="unrecognised",
                              detected_model="Unknown")

    ext = (filename or "").rsplit(".", 1)[-1].lower() if "." in (filename or "") else ""

    sheet_frames: List[Tuple[str, "pd.DataFrame"]] = []
    try:
        if ext in ("xlsx", "xls"):
            xl = pd.ExcelFile(io.BytesIO(raw_bytes), engine="openpyxl")
            for sh in xl.sheet_names:
                try:
                    sheet_frames.append((sh, xl.parse(sh)))
                except Exception:
                    continue
        elif ext == "csv":
            sheet_frames.append(("csv", pd.read_csv(io.BytesIO(raw_bytes))))
        else:
            result.warnings.append({"code": "UNSUPPORTED_FORMAT",
                                     "text": f"File type .{ext} not supported for SLA parsing"})
            return result
    except Exception as exc:
        result.warnings.append({"code": "PARSE_FAILED",
                                 "text": f"Could not read file: {exc}"})
        return result

    # Section detection — run once on the first sheet for the trace UI
    if sheet_frames:
        try:
            result.sections_detected = _detect_sections(sheet_frames[0][1])
        except Exception:
            pass

    # Walk every sheet and merge contracts. We treat the schema as the union
    # of capabilities seen across sheets — if any sheet has start+end+buffer
    # we call the file BUFFERED, else WINDOW, etc.
    has_start_any = has_end_any = has_dur_any = has_buf_any = has_sched_any = has_batch_any = False
    sheets_with_data = 0
    for sh_name, df_raw in sheet_frames:
        if df_raw is None or df_raw.empty:
            continue
        cols = {_normalize_column(str(c)) for c in df_raw.columns}
        if not ({"batch_name", "schedule_text", "sla_end_time",
                 "sla_duration", "start_time"} & cols):
            # Sheet has no SLA-shaped columns — skip
            continue
        has_start_any |= "start_time"   in cols
        has_end_any   |= "sla_end_time" in cols
        has_dur_any   |= "sla_duration" in cols
        has_buf_any   |= "buffer"       in cols
        has_sched_any |= "schedule_text" in cols
        has_batch_any |= "batch_name"   in cols

        added = _ingest_sla_sheet(df_raw, sh_name, result)
        if added:
            sheets_with_data += 1

    # Detect overall schema type from union of capabilities
    if has_start_any and has_end_any and has_buf_any:
        result.schema_type = "buffered"
        result.detected_model = "Window + Contingency SLA (start→end with buffer)"
    elif has_start_any and has_end_any:
        result.schema_type = "window"
        result.detected_model = "Absolute Window SLA (start→end cutoff)"
    elif has_dur_any:
        result.schema_type = "duration"
        result.detected_model = "Duration-based SLA (expected runtime)"
    elif has_sched_any and not has_end_any and not has_dur_any:
        result.schema_type = "calendar"
        result.detected_model = "Schedule-only (no numeric SLA provided)"
    elif sheets_with_data:
        result.schema_type = "mixed"
        result.detected_model = "Mixed/incomplete SLA structure"

    # Build ceilings (tightest SLA per schedule type, across all sheets)
    for contract in result.contracts:
        if contract.sla_window_hrs and contract.sla_window_hrs > 0:
            sched = contract.schedule_type
            if sched in ("DAILY", "WEEKLY", "MONTHLY"):
                existing = result.ceilings.get(sched)
                if existing is None or contract.sla_window_hrs < existing:
                    result.ceilings[sched] = contract.sla_window_hrs

    # Generate warnings
    if result.partial_rows > 0:
        result.warnings.append({
            "code": "PARTIAL_ROWS",
            "text": f"{result.partial_rows} row(s) have batch names but no numeric SLA — "
                    "these will use assumed defaults.",
            "severity": "warning",
        })
    if result.valid_rows == 0:
        result.warnings.append({
            "code": "NO_VALID_SLA",
            "text": "No valid SLA windows could be extracted from this file. "
                    "Check that the file has Start Time + Expected End Time columns.",
            "severity": "critical",
        })
    if "MONTHLY" not in result.ceilings:
        result.missing_ceilings.append("MONTHLY")
        result.warnings.append({
            "code": "MISSING_MONTHLY",
            "text": "No MONTHLY SLA found in file — no default applied. Monthly jobs will be assessed without a ceiling.",
            "severity": "warning",
        })

    return result


# ── Legacy single-sheet ingestion (kept for back-compat / tests) ─────────────

def _ingest_sla_file_single_sheet(raw_bytes: bytes, filename: str) -> SlaIngestResult:
    """Original single-sheet ingestion path. Retained for compatibility."""
    import pandas as pd

    result = SlaIngestResult(filename=filename, schema_type="unrecognised",
                              detected_model="Unknown")

    ext = (filename or "").rsplit(".", 1)[-1].lower() if "." in (filename or "") else ""

    try:
        if ext in ("xlsx", "xls"):
            df_raw = pd.read_excel(io.BytesIO(raw_bytes), sheet_name=0, engine="openpyxl")
        elif ext == "csv":
            df_raw = pd.read_csv(io.BytesIO(raw_bytes))
        else:
            result.warnings.append({"code": "UNSUPPORTED_FORMAT",
                                     "text": f"File type .{ext} not supported for SLA parsing"})
            return result
    except Exception as exc:
        result.warnings.append({"code": "PARSE_FAILED",
                                 "text": f"Could not read file: {exc}"})
        return result

    df_raw.columns = [str(c).strip() for c in df_raw.columns]
    result.raw_columns = list(df_raw.columns)
    result.total_rows = len(df_raw)

    # Detect sections in the worksheet
    result.sections_detected = _detect_sections(df_raw)

    # Normalize column names
    col_map = {}
    for raw_col in df_raw.columns:
        canonical = _normalize_column(raw_col)
        col_map[raw_col] = canonical
    result.normalized_columns = col_map

    # Rename for processing
    df = df_raw.rename(columns=col_map)

    # ── Coalesce duplicate canonical columns ─────────────────────────────
    # Several customer headers (e.g. "Batch Name", "Module", "Window Name")
    # all map to the canonical "batch_name". After rename, df can contain
    # multiple columns with the same name, which makes ``row.get(name)``
    # return a Series instead of a scalar — and ``str(Series)`` produces
    # the infamous  "batch_name  NaN\nbatch_name  NaN\nName: 3, dtype: object"
    # garbage that leaks straight into the dashboard.
    #
    # Fix: for every duplicated canonical name, collapse the columns by
    # taking the first non-null value across them per row, then drop the
    # extras. This also de-noises rows where one source column is blank
    # but another carries the real value.
    if not df.columns.is_unique:
        seen: Dict[str, int] = {}
        new_frames = {}
        order: List[str] = []
        for col in df.columns:
            if col in seen:
                continue
            seen[col] = 1
            same = [c for c in df.columns if c == col]
            if len(same) == 1:
                new_frames[col] = df[col]
            else:
                # Coalesce: bfill across the duplicate columns, take the first.
                block = df.loc[:, same]
                new_frames[col] = block.bfill(axis=1).iloc[:, 0]
            order.append(col)
        df = pd.DataFrame({c: new_frames[c] for c in order})

    # Detect SLA model type from available columns
    has_start = "start_time" in df.columns
    has_end = "sla_end_time" in df.columns
    has_duration = "sla_duration" in df.columns
    has_buffer = "buffer" in df.columns
    has_schedule = "schedule_text" in df.columns
    has_batch_name = "batch_name" in df.columns

    if has_start and has_end and has_buffer:
        schema_type = "buffered"
        detected_model = "Window + Contingency SLA (start→end with buffer)"
    elif has_start and has_end:
        schema_type = "window"
        detected_model = "Absolute Window SLA (start→end cutoff)"
    elif has_duration:
        schema_type = "duration"
        detected_model = "Duration-based SLA (expected runtime)"
    elif has_schedule and not has_end and not has_duration:
        schema_type = "calendar"
        detected_model = "Schedule-only (no numeric SLA provided)"
    else:
        schema_type = "mixed"
        detected_model = "Mixed/incomplete SLA structure"

    result.schema_type = schema_type
    result.detected_model = detected_model

    # Parse each row into an SLA contract
    valid_count = 0
    partial_count = 0

    def _cell(row, key: str) -> str:
        """Return a clean scalar string for a row cell.

        Defensive against pandas Series that can leak through duplicate
        columns, NaN floats, and stringified-Series garbage of the form
        ``"batch_name  NaN\\nName: 3, dtype: object"``.
        """
        try:
            v = row.get(key, "")
        except Exception:
            v = ""
        # Series → take first non-null scalar
        if hasattr(v, "iloc"):
            try:
                v = v.dropna().iloc[0] if v.dropna().size else ""
            except Exception:
                v = ""
        if v is None:
            return ""
        try:
            import pandas as _pd
            if _pd.isna(v):
                return ""
        except Exception:
            pass
        s = str(v).strip()
        # Drop pandas Series/DataFrame repr leaks
        if "dtype:" in s and "Name:" in s:
            return ""
        if s.lower() in ("nan", "none", "nat"):
            return ""
        return s

    for idx, row in df.iterrows():
        batch_name    = _cell(row, "batch_name")    if has_batch_name else ""
        schedule_raw  = _cell(row, "schedule_text") if has_schedule   else ""
        schedule_type = classify_schedule(schedule_raw or batch_name)

        # Parse times
        start_t  = _parse_time(_cell(row, "start_time"))   if has_start    else None
        end_cell = _cell(row, "sla_end_time") if has_end else ""
        end_t    = _parse_time(end_cell) if end_cell else None
        dur_hrs  = _parse_duration_hrs(_cell(row, "sla_duration")) if has_duration else None
        # Generic fallback: the "Expected End Time/SLA" column sometimes holds a
        # duration string ('1.5 hrs', '45 min') rather than a clock time. If
        # _parse_time returned None and we have no explicit duration column, try
        # interpreting the same cell as a duration.
        if end_t is None and end_cell and dur_hrs is None:
            dur_hrs = _parse_duration_hrs(end_cell)

        # Compute window from start/end
        window_hrs = _time_delta_hours(start_t, end_t)

        # If no explicit window but we have duration, use that
        if window_hrs is None and dur_hrs is not None:
            window_hrs = dur_hrs

        # Parse buffer
        buffer_min = _parse_buffer_minutes(_cell(row, "buffer")) if has_buffer else None

        # Parse jobs, timezone, comments
        first_job = _cell(row, "first_job") if "first_job" in df.columns else ""
        last_job  = _cell(row, "last_job")  if "last_job"  in df.columns else ""
        tz        = _cell(row, "timezone")  if "timezone"  in df.columns else ""
        comments  = _cell(row, "comments")  if "comments"  in df.columns else ""

        # Skip completely empty / placeholder rows. A row with only a
        # Row_<idx> autogenerated batch_name and no other signal is noise.
        if not batch_name and not schedule_raw and window_hrs is None and dur_hrs is None:
            continue

        # Determine completeness
        if window_hrs is not None and window_hrs > 0:
            completeness = "complete"
            valid_count += 1
        elif dur_hrs is not None and dur_hrs > 0:
            completeness = "complete"
            valid_count += 1
        elif batch_name or schedule_raw:
            completeness = "partial"
            partial_count += 1
        else:
            continue

        # Determine per-row SLA model
        if has_buffer and buffer_min and buffer_min > 0 and window_hrs:
            row_model = "BUFFERED"
        elif window_hrs is not None:
            row_model = "WINDOW"
        elif dur_hrs is not None:
            row_model = "DURATION"
        elif schedule_raw:
            row_model = "CALENDAR"
        else:
            row_model = "PARTIAL"

        # Build interpretation notes from comments
        interp_notes = ""
        if comments and comments.lower() not in ("nan", "none", ""):
            # Check for business-logic keywords in comments
            if re.search(r"unofficial|no breach|agreed|buffer|optimizer|existing", comments, re.I):
                interp_notes = f"Business context: {comments[:200]}"
            else:
                interp_notes = comments[:200]

        contract = SlaContract(
            batch_name=batch_name or f"Row_{idx}",
            schedule_type=schedule_type,
            schedule_raw=schedule_raw,
            sla_model=row_model,
            sla_start=start_t,
            sla_end=end_t,
            sla_duration_hrs=dur_hrs,
            sla_window_hrs=window_hrs,
            buffer_minutes=buffer_min,
            first_job=first_job,
            last_job=last_job,
            timezone=tz,
            comments=comments,
            interpretation_notes=interp_notes,
            source_row=int(idx) + 2,  # +2 for header row + 0-based
            source_sheet="Sheet1",
            completeness=completeness,
        )
        result.contracts.append(contract)

        # Build schedule_map
        if batch_name:
            result.schedule_map[batch_name] = schedule_type

    result.valid_rows = valid_count
    result.partial_rows = partial_count

    # Build ceilings (best SLA window per schedule type)
    for contract in result.contracts:
        if contract.sla_window_hrs and contract.sla_window_hrs > 0:
            sched = contract.schedule_type
            if sched in ("DAILY", "WEEKLY", "MONTHLY"):
                existing = result.ceilings.get(sched)
                if existing is None or contract.sla_window_hrs < existing:
                    # Use the tightest SLA per schedule type
                    result.ceilings[sched] = contract.sla_window_hrs

    # Generate warnings
    if partial_count > 0:
        result.warnings.append({
            "code": "PARTIAL_ROWS",
            "text": f"{partial_count} row(s) have batch names but no numeric SLA — "
                    "these will use assumed defaults.",
            "severity": "warning",
        })

    if valid_count == 0:
        result.warnings.append({
            "code": "NO_VALID_SLA",
            "text": "No valid SLA windows could be extracted from this file. "
                    "All compliance results will use assumed defaults.",
            "severity": "critical",
        })

    # Check for ADHOC entries
    adhoc_count = sum(1 for c in result.contracts if c.schedule_type == "ADHOC")
    if adhoc_count > 0:
        result.warnings.append({
            "code": "ADHOC_ENTRIES",
            "text": f"{adhoc_count} ADHOC entries found — these have no fixed SLA.",
            "severity": "info",
        })

    # Check for missing schedule types in ceilings
    for sched in ("DAILY", "WEEKLY", "MONTHLY"):
        if sched not in result.ceilings:
            from services import pe_config
            defaults = {
                "DAILY": pe_config.SLA_DAILY_HRS,
                "WEEKLY": pe_config.SLA_WEEKLY_HRS,
                "MONTHLY": pe_config.SLA_MONTHLY_HRS,
            }
            result.ceilings[sched] = defaults[sched]
            result.warnings.append({
                "code": f"MISSING_{sched}",
                "text": f"No {sched} SLA found in file — using default {defaults[sched]}h",
                "severity": "info",
            })

    logger.info(
        "sla_engine: ingested %s — schema=%s, contracts=%d, valid=%d, partial=%d, ceilings=%s",
        filename, schema_type, len(result.contracts), valid_count, partial_count, result.ceilings,
    )

    return result


# ── SLA Resolution ────────────────────────────────────────────────────────────

def _normalize_batch_name(name: str) -> str:
    """Strip environment prefix (PROD_, TEST_, DEV_, UAT_, SIT_, STG_) from a
    batch name so that PROD_WEEKLY_WF1_REQPL and TEST_WEEKLY_WF1_REQPL both
    resolve to the same canonical suffix WEEKLY_WF1_REQPL.

    Works generically — no hardcoded env list.  Strategy:
      - Split on underscore.
      - If the first segment is a known env token OR is ≤4 chars (typical
        abbreviated env prefix), drop it and keep the rest.
      - If the name has only 1 segment, keep it as-is.
    """
    _ENV_TOKENS = frozenset({
        "PROD", "TEST", "DEV", "UAT", "SIT", "STG", "DR", "PRD",
        "TST", "QA", "PREPROD", "NONPROD", "SANDBOX", "STAGE",
    })
    parts = name.upper().split("_")
    if len(parts) <= 1:
        return name.upper()
    # Drop first segment if it looks like an environment prefix
    if parts[0] in _ENV_TOKENS or len(parts[0]) <= 4:
        return "_".join(parts[1:])
    return "_".join(parts)


def _sla_from_contract(contract: SlaContract) -> float:
    """Extract the usable SLA hours from a contract (window preferred over duration)."""
    return contract.sla_window_hrs or contract.sla_duration_hrs or 0.0


def resolve_sla(
    batch_name: str,
    schedule_hint: str,
    contracts: List[SlaContract],
    ceilings: Dict[str, float],
) -> ResolvedSla:
    """Resolve the correct SLA for a specific batch execution.

    Match priority (high → low confidence):
      1. Exact match         — case-insensitive full name match
      2. Env-prefix stripped — PROD_WEEKLY_WF1 matches TEST_WEEKLY_WF1
      3. Token-set overlap   — WF1_REQPL matches BYC_WF1_REQPL (longest
                               common token sequence wins)
      4. Schedule-type from  — per-customer ceiling from uploaded SLA file
         customer file
      5. System default      — assumed / blocked (no customer data)
    """
    from services import pe_config

    if not batch_name:
        batch_name = ""

    batch_upper  = batch_name.upper()
    batch_norm   = _normalize_batch_name(batch_name)   # env-prefix stripped
    batch_tokens = set(batch_norm.split("_"))          # token set for overlap
    schedule_type = classify_schedule(schedule_hint or batch_name or "")

    # Only consider contracts with a usable SLA value
    valid = [c for c in contracts if _sla_from_contract(c) > 0]

    # ── Pass 1: exact match ──────────────────────────────────────
    for contract in valid:
        if contract.batch_name.upper() == batch_upper:
            return ResolvedSla(
                sla_hrs=_sla_from_contract(contract),
                sla_model=contract.sla_model,
                source="sla_matrix",
                source_detail=f"Exact match '{contract.batch_name}' (row {contract.source_row})",
                schedule_type=contract.schedule_type or schedule_type,
                matched_contract=contract,
                buffer_minutes=contract.buffer_minutes,
                confidence="high",
            )

    # ── Pass 2: env-prefix stripped match ───────────────────────
    for contract in valid:
        contract_norm = _normalize_batch_name(contract.batch_name)
        if contract_norm == batch_norm:
            return ResolvedSla(
                sla_hrs=_sla_from_contract(contract),
                sla_model=contract.sla_model,
                source="sla_matrix",
                source_detail=(
                    f"Env-prefix match '{contract.batch_name}' → '{batch_name}' "
                    f"(suffix='{batch_norm}', row {contract.source_row})"
                ),
                schedule_type=contract.schedule_type or schedule_type,
                matched_contract=contract,
                buffer_minutes=contract.buffer_minutes,
                confidence="high",
            )

    # ── Pass 3: substring / contains match ──────────────────────
    for contract in valid:
        cn = contract.batch_name.upper()
        cn_norm = _normalize_batch_name(contract.batch_name)
        if cn and (cn in batch_upper or batch_upper in cn):
            return ResolvedSla(
                sla_hrs=_sla_from_contract(contract),
                sla_model=contract.sla_model,
                source="sla_matrix",
                source_detail=(
                    f"Substring match '{contract.batch_name}' ↔ '{batch_name}' "
                    f"(row {contract.source_row})"
                ),
                schedule_type=contract.schedule_type or schedule_type,
                matched_contract=contract,
                buffer_minutes=contract.buffer_minutes,
                confidence="medium",
            )

    # ── Pass 4: token-overlap match (≥60% shared tokens, schedule-type must agree) ──
    # Handles: WF1_REQPL in CSV vs BYC_WF1_REQPL in SLA file
    best_overlap: Optional[tuple] = None   # (overlap_ratio, contract)
    for contract in valid:
        ct_tokens = set(_normalize_batch_name(contract.batch_name).split("_"))
        if not batch_tokens or not ct_tokens:
            continue
        # Only consider schedule-consistent contracts
        if (contract.schedule_type not in ("UNKNOWN", "")
                and contract.schedule_type != schedule_type
                and schedule_type not in ("UNKNOWN", "")):
            continue
        shared = batch_tokens & ct_tokens
        # Require at least 2 shared tokens to avoid false positives on short names
        if len(shared) < 2:
            continue
        ratio = len(shared) / max(len(batch_tokens), len(ct_tokens))
        if ratio >= 0.60:
            if best_overlap is None or ratio > best_overlap[0]:
                best_overlap = (ratio, contract)

    if best_overlap is not None:
        _, contract = best_overlap
        return ResolvedSla(
            sla_hrs=_sla_from_contract(contract),
            sla_model=contract.sla_model,
            source="sla_matrix",
            source_detail=(
                f"Token-overlap match ({best_overlap[0]:.0%}) "
                f"'{contract.batch_name}' ↔ '{batch_name}' "
                f"(row {contract.source_row})"
            ),
            schedule_type=contract.schedule_type or schedule_type,
            matched_contract=contract,
            buffer_minutes=contract.buffer_minutes,
            confidence="medium",
        )

    # ── Pass 5: schedule-type ceiling from customer SLA file ────
    if schedule_type in ceilings:
        sla_hrs = ceilings[schedule_type]
        return ResolvedSla(
            sla_hrs=sla_hrs,
            sla_model="WINDOW",
            source="customer_fallback",
            source_detail=(
                f"No batch-name match — using {schedule_type} ceiling "
                f"{sla_hrs:.2f}h from customer SLA file"
            ),
            schedule_type=schedule_type,
            confidence="medium",
        )

    # ── Pass 6: system default (assumed / blocked) ───────────────
    defaults = {
        "DAILY":   pe_config.SLA_DAILY_HRS,
        "WEEKLY":  pe_config.SLA_WEEKLY_HRS,
        "MONTHLY": pe_config.SLA_MONTHLY_HRS,
    }
    if schedule_type in defaults:
        assumed = defaults[schedule_type]
        return ResolvedSla(
            sla_hrs=assumed,
            sla_model="ASSUMED",
            source="assumed",
            source_detail=(
                f"No SLA matrix match — assumed {schedule_type} default {assumed:.1f}h"
            ),
            schedule_type=schedule_type,
            confidence="low",
            blocked=True,
            block_reason=(
                f"Cannot confirm compliance — SLA is assumed ({assumed:.1f}h), "
                "not sourced from a customer SLA matrix."
            ),
        )

    # ── Pass 7: absolute fallback ────────────────────────────────
    fallback_hrs = pe_config.SLA_DAILY_HRS
    return ResolvedSla(
        sla_hrs=fallback_hrs,
        sla_model="ASSUMED",
        source="assumed",
        source_detail=f"Unknown schedule + no SLA matrix — assumed daily default {fallback_hrs:.1f}h",
        schedule_type="UNKNOWN",
        confidence="low",
        blocked=True,
        block_reason=f"Cannot resolve SLA — schedule unrecognised, using daily default {fallback_hrs:.1f}h",
    )


# ── Actual vs SLA comparison ─────────────────────────────────────────────────

def compare_actual(
    resolved: ResolvedSla,
    actual_hrs: float,
) -> SlaVerdict:
    """Compare actual execution against resolved SLA.

    Produces both strict (no buffer) and buffered verdicts.
    """
    sla_hrs = resolved.sla_hrs
    margin = sla_hrs - actual_hrs

    # Strict status (no buffer)
    if actual_hrs <= sla_hrs:
        strict = "PASS"
    else:
        strict = "BREACH"

    # Buffered status
    buffer_margin_hrs = None
    if resolved.buffer_minutes and resolved.buffer_minutes > 0:
        buffered_sla = sla_hrs + (resolved.buffer_minutes / 60)
        buffer_margin_hrs = buffered_sla - actual_hrs
        buffered = "PASS" if actual_hrs <= buffered_sla else "BREACH"
    else:
        buffered = strict

    # At-risk detection (within 15% of SLA)
    at_risk_floor = sla_hrs * 0.85
    if strict == "PASS" and actual_hrs >= at_risk_floor:
        at_risk = True
    else:
        at_risk = False

    # Final composite status
    if strict == "PASS" and not at_risk:
        final = "PASS"
    elif strict == "PASS" and at_risk:
        final = "AT_RISK"
    elif strict == "BREACH" and buffered == "PASS":
        final = "PASS_WITH_BUFFER"
    else:
        final = "BREACH"

    # Build explanation
    parts = [f"Actual: {actual_hrs:.2f}h vs SLA: {sla_hrs:.2f}h"]
    if margin >= 0:
        parts.append(f"Headroom: {margin:.2f}h")
    else:
        parts.append(f"Overrun: {abs(margin):.2f}h")
    if resolved.buffer_minutes:
        parts.append(f"Buffer: {resolved.buffer_minutes:.0f}min → buffered status: {buffered}")
    parts.append(f"Source: {resolved.source_detail}")

    return SlaVerdict(
        status=final,
        strict_status=strict,
        buffered_status=buffered,
        actual_hrs=actual_hrs,
        sla_hrs=sla_hrs,
        margin_hrs=margin,
        buffer_applied=resolved.buffer_minutes is not None and resolved.buffer_minutes > 0,
        buffer_margin_hrs=buffer_margin_hrs,
        explanation=" · ".join(parts),
    )


# ── Batch-level SLA resolution for all jobs ──────────────────────────────────

def resolve_batch_sla_map(
    job_names: List[str],
    sla_result: Optional[SlaIngestResult],
) -> Dict[str, ResolvedSla]:
    """Resolve SLA for every job name. Returns job_name → ResolvedSla."""
    contracts = sla_result.contracts if sla_result else []
    ceilings = sla_result.ceilings if sla_result else {}
    return {
        job: resolve_sla(job, "", contracts, ceilings)
        for job in job_names
    }


def build_sla_traceability(sla_result: Optional[SlaIngestResult]) -> Dict[str, Any]:
    """Build the SLA source traceability payload for the frontend.

    Returns a dict suitable for inclusion in the batch payload.
    """
    if not sla_result:
        from services import pe_config
        return {
            "type": "assumed",
            "label": "Assumed (no SLA file uploaded)",
            "model": "ASSUMED",
            "daily_hrs": pe_config.SLA_DAILY_HRS,
            "weekly_hrs": pe_config.SLA_WEEKLY_HRS,
            "monthly_hrs": pe_config.SLA_MONTHLY_HRS,
            "custom_hrs": pe_config.SLA_CUSTOM_HRS,
            "contracts": [],
            "warnings": [{
                "code": "NO_SLA_FILE",
                "text": "No SLA matrix uploaded — all compliance uses assumed system defaults. "
                        "Upload a customer SLA file for audit-defensible results.",
                "severity": "critical",
            }],
            "schema_type": "none",
            "valid_rows": 0,
            "blocked": True,
            "block_reason": "Compliance is based on assumed defaults — cannot be marked green for audit sign-off",
        }

    contracts_brief = []
    for c in (sla_result.contracts or [])[:20]:
        contracts_brief.append({
            "batch": c.batch_name,
            "schedule": c.schedule_type,
            "schedule_raw": c.schedule_raw,
            "model": c.sla_model,
            "window_hrs": c.sla_window_hrs,
            "duration_hrs": c.sla_duration_hrs,
            "buffer_min": c.buffer_minutes,
            "completeness": c.completeness,
            "row": c.source_row,
            "comments": c.comments[:100] if c.comments else "",
        })

    return {
        "type": "sla_matrix",
        "label": f"From SLA Matrix ({sla_result.filename})",
        "model": sla_result.schema_type.upper(),
        "daily_hrs": sla_result.ceilings.get("DAILY"),
        "weekly_hrs": sla_result.ceilings.get("WEEKLY"),
        "monthly_hrs": sla_result.ceilings.get("MONTHLY"),
        "custom_hrs": sla_result.ceilings.get("CUSTOM"),
        "contracts": contracts_brief,
        "warnings": sla_result.warnings,
        "schema_type": sla_result.schema_type,
        "detected_model": sla_result.detected_model,
        "valid_rows": sla_result.valid_rows,
        "partial_rows": sla_result.partial_rows,
        "total_rows": sla_result.total_rows,
        "sections_detected": sla_result.sections_detected,
        "blocked": sla_result.valid_rows == 0,
        "block_reason": (
            "SLA file parsed but no valid numeric SLA rules found"
            if sla_result.valid_rows == 0 else ""
        ),
    }
