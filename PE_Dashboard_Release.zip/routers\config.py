"""
Config router — persistent dashboard settings.

GET  /api/config          → returns current config (API key masked)
POST /api/config          → update one or more config keys
POST /api/config/test-key → validate a Gemini API key live
"""
from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter
from pydantic import BaseModel

from services import config_store

router = APIRouter()


class ConfigPayload(BaseModel):
    gemini_api_key:          Optional[str]   = None
    nvidia_api_key:          Optional[str]   = None
    ai_text_provider:        Optional[str]   = None    # "nvidia" | "gemini"
    ai_text_model:           Optional[str]   = None    # e.g. google/gemma-3-27b-it
    ai_post_upload:          Optional[bool]  = None
    daily_sla_hrs:           Optional[float] = None
    weekly_sla_hrs:          Optional[float] = None
    biweekly_sla_hrs:        Optional[float] = None
    monthly_sla_hrs:         Optional[float] = None
    custom_sla_hrs:          Optional[float] = None
    sla_mode:                Optional[str]   = None
    benchmark_threshold:     Optional[float] = None
    # Azure SPN credentials
    azure_tenant_id:         Optional[str]   = None
    azure_client_id:         Optional[str]   = None
    azure_client_secret:     Optional[str]   = None
    azure_subscription_id:   Optional[str]   = None
    azure_resource_group:    Optional[str]   = None


class TestKeyRequest(BaseModel):
    api_key: str


@router.get("/config")
def get_config() -> dict[str, Any]:
    data = config_store.get_all()
    key = data.get("gemini_api_key", "")
    if key and len(key) > 8:
        data["gemini_api_key_masked"] = key[:6] + "••••" + key[-4:]
    else:
        data["gemini_api_key_masked"] = "(not set)"

    nvkey = data.get("nvidia_api_key", "")
    if nvkey and len(nvkey) > 12:
        data["nvidia_api_key_masked"] = nvkey[:8] + "••••" + nvkey[-4:]
    else:
        data["nvidia_api_key_masked"] = "(not set)"
    return data


@router.post("/config")
def update_config(payload: ConfigPayload) -> dict[str, Any]:
    updates = payload.model_dump(exclude_none=True)
    for k, v in updates.items():
        config_store.set(k, v)
    return {"status": "ok", "updated": list(updates.keys())}


@router.post("/config/test-key")
def test_gemini_key(body: TestKeyRequest) -> dict[str, Any]:
    """Quick liveness check for a Gemini API key."""
    key = body.api_key.strip()
    if not key:
        return {"valid": False, "error": "Empty key"}
    try:
        import google.generativeai as genai
        genai.configure(api_key=key)
        models = list(genai.list_models())
        flash = [m.name for m in models if "flash" in m.name.lower()]
        return {"valid": True, "model_count": len(models),
                "recommended": flash[0] if flash else (models[0].name if models else "")}
    except ImportError:
        return {"valid": False, "error": "google-generativeai not installed"}
    except Exception as e:
        err = str(e)
        if "API_KEY" in err.upper() or "INVALID" in err.upper():
            return {"valid": False, "error": "Invalid API key"}
        return {"valid": False, "error": str(e)[:120]}


@router.post("/config/test-nvidia-key")
def test_nvidia_key(body: TestKeyRequest) -> dict[str, Any]:
    """Quick liveness check for an NVIDIA NIM API key."""
    from services.nvidia_llm import test_api_key
    return test_api_key(body.api_key)
