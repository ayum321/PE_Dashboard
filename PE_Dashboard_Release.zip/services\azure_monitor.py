"""
Azure Monitor resource fetcher — SPN (Service Principal) authentication.

Uses the azure-monitor-query + azure-identity SDK to pull CPU / Memory /
Disk metrics for all VMs in a given subscription + resource group, then
returns records in the same dict shape as resource_parser_generic.py so
they feed directly into resource_calculator.build_resource_payload().

Public API
----------
    fetch_vm_metrics(config: dict, hours_back: int = 24) -> list[dict]
        Raises AzureConfigError if SPN credentials are missing/invalid.
        Raises AzureFetchError  if the API call fails.

Required config keys (stored in .pe_config.json via Settings):
    azure_tenant_id     — Directory (tenant) ID from Azure App Registration
    azure_client_id     — Application (client) ID from App Registration
    azure_client_secret — Client secret value (not the secret ID)
    azure_subscription_id — Target subscription to query
    azure_resource_group  — (optional) limit to one resource group

Required Azure RBAC:
    The SPN must have "Monitoring Reader" role on the subscription
    (or resource group). "Reader" alone is not enough — it misses metrics.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger("pe_dashboard.azure_monitor")


class AzureConfigError(Exception):
    """Raised when SPN credentials are missing or incomplete."""


class AzureFetchError(Exception):
    """Raised when the Azure Monitor API call fails."""


# ── Metric definitions ────────────────────────────────────────────────────────
# Azure Monitor metric names for VM insights.
# Percentage CPU is always available; Memory/Disk require the Azure Monitor
# Agent (AMA) or legacy MMA to be installed on the VM.
_VM_METRICS = [
    "Percentage CPU",                     # Always available
    "Available Memory Bytes",             # AMA / MMA agent required
    "OS Disk Used Bytes Percentage",      # AMA required (some VMs)
    "Disk Read Bytes",                    # Fallback disk activity metric
]

# Aggregation type for each metric
_METRIC_AGG = {
    "Percentage CPU":               "Average",
    "Available Memory Bytes":       "Average",
    "OS Disk Used Bytes Percentage":"Average",
    "Disk Read Bytes":              "Total",
}

# Total RAM in bytes — Azure doesn't expose this directly via Monitor.
# We read it from VM size metadata and use it to compute mem_used %.
# If unavailable, memory will be 0.0 (flagged as image_only=False, partial).
_BYTES_PER_GB = 1_073_741_824


def _require_sdk() -> None:
    """Check that azure packages are installed; raise a clear error if not."""
    try:
        import azure.identity          # noqa: F401
        import azure.monitor.query     # noqa: F401
    except ImportError:
        raise AzureConfigError(
            "Azure SDK not installed. Run: pip install azure-monitor-query azure-identity"
        )


def _build_credential(cfg: dict):
    """Return a ClientSecretCredential from SPN config."""
    from azure.identity import ClientSecretCredential
    tenant  = (cfg.get("azure_tenant_id") or "").strip()
    client  = (cfg.get("azure_client_id") or "").strip()
    secret  = (cfg.get("azure_client_secret") or "").strip()
    if not all([tenant, client, secret]):
        raise AzureConfigError(
            "Azure SPN credentials incomplete. Set Tenant ID, Client ID, and "
            "Client Secret in Settings → Azure Connection."
        )
    return ClientSecretCredential(
        tenant_id=tenant,
        client_id=client,
        client_secret=secret,
    )


def _list_vms(credential, subscription_id: str, resource_group: Optional[str]) -> List[dict]:
    """
    List all VMs in the subscription (optionally filtered by resource group).
    Returns list of dicts with keys: resource_id, name, location, vm_size, rg.
    """
    try:
        from azure.mgmt.compute import ComputeManagementClient
    except ImportError:
        raise AzureConfigError(
            "azure-mgmt-compute not installed. Run: pip install azure-mgmt-compute"
        )

    compute = ComputeManagementClient(credential, subscription_id)
    vms = []
    try:
        if resource_group:
            vm_list = compute.virtual_machines.list(resource_group)
        else:
            vm_list = compute.virtual_machines.list_all()

        for vm in vm_list:
            rg = vm.id.split("/resourceGroups/")[1].split("/")[0] if vm.id else ""
            vms.append({
                "resource_id": vm.id,
                "name":        vm.name,
                "location":    vm.location or "",
                "vm_size":     (vm.hardware_profile.vm_size if vm.hardware_profile else "") or "",
                "rg":          rg,
            })
    except Exception as exc:
        raise AzureFetchError(f"Failed to list VMs: {exc}") from exc

    return vms


def _query_metrics(
    credential,
    resource_ids: List[str],
    hours_back: int,
) -> Dict[str, Dict[str, float]]:
    """
    Batch-query Azure Monitor for CPU / Memory / Disk metrics.
    Returns {resource_id: {metric_name: avg_value, ...}}
    """
    from azure.monitor.query import MetricsQueryClient, MetricAggregationType

    client = MetricsQueryClient(credential)

    end_time   = datetime.now(timezone.utc)
    start_time = end_time - timedelta(hours=hours_back)
    granularity = timedelta(hours=1)  # hourly averages

    results: Dict[str, Dict[str, float]] = {}

    # Azure Monitor batches by resource — process one at a time to stay
    # within API limits (max 20 resources per batch query).
    BATCH_SIZE = 20
    for i in range(0, len(resource_ids), BATCH_SIZE):
        batch = resource_ids[i : i + BATCH_SIZE]
        for rid in batch:
            results[rid] = {}
            for metric_name in _VM_METRICS:
                agg_type = _METRIC_AGG.get(metric_name, "Average")
                agg_enum = (MetricAggregationType.AVERAGE
                            if agg_type == "Average"
                            else MetricAggregationType.TOTAL)
                try:
                    response = client.query_resource(
                        resource_uri=rid,
                        metric_names=[metric_name],
                        timespan=(start_time, end_time),
                        granularity=granularity,
                        aggregations=[agg_enum],
                    )
                    for m in response.metrics:
                        vals = []
                        for ts in m.timeseries:
                            for dp in ts.data:
                                v = dp.average if agg_type == "Average" else dp.total
                                if v is not None:
                                    vals.append(v)
                        if vals:
                            results[rid][metric_name] = sum(vals) / len(vals)
                except Exception as exc:
                    # Metric not available on this VM — skip silently
                    logger.debug("Metric %s not available for %s: %s", metric_name, rid, exc)

    return results


def _vm_total_memory_bytes(credential, subscription_id: str, vm_size: str) -> Optional[float]:
    """
    Look up total RAM for a VM size from the Azure Compute SKUs list.
    Returns bytes, or None if unavailable.
    Cached in-process to avoid repeated API calls for the same size.
    """
    if not vm_size:
        return None
    cache = _vm_total_memory_bytes.__dict__.setdefault("_cache", {})
    if vm_size in cache:
        return cache[vm_size]
    try:
        from azure.mgmt.compute import ComputeManagementClient
        compute = ComputeManagementClient(credential, subscription_id)
        # list_skus is subscription-scoped; we just need any location result
        for sku in compute.resource_skus.list(filter=f"name eq '{vm_size}'"):
            for cap in (sku.capabilities or []):
                if cap.name == "MemoryGB":
                    val = float(cap.value) * _BYTES_PER_GB
                    cache[vm_size] = val
                    return val
    except Exception:
        pass
    cache[vm_size] = None
    return None


def _infer_server_type(name: str) -> str:
    """
    Classify VM role from its name — same logic as resource_parser_generic.py.
    Returns "DB", "SRE", or "APP".
    """
    n = (name or "").lower()
    if any(k in n for k in ("db", "sql", "ora", "pg", "mysql", "mongo", "data")):
        return "DB"
    if any(k in n for k in ("sre", "batch", "sch", "job", "worker", "cron")):
        return "SRE"
    return "APP"


def fetch_vm_metrics(cfg: dict, hours_back: int = 24) -> List[Dict[str, Any]]:
    """
    Main entry point. Fetches VM metrics from Azure Monitor via SPN.

    Parameters
    ----------
    cfg        : Full config dict from config_store.get_all()
    hours_back : How many hours of history to average (default 24)

    Returns
    -------
    List of server dicts compatible with resource_calculator.build_resource_payload():
        host, server, type, cpu_used, mem_used, disk_used_max,
        cpu_pct, mem_pct, disk_pct, source
    """
    _require_sdk()

    sub_id = (cfg.get("azure_subscription_id") or "").strip()
    if not sub_id:
        raise AzureConfigError(
            "Azure Subscription ID not set. Add it in Settings → Azure Connection."
        )

    rg = (cfg.get("azure_resource_group") or "").strip() or None

    credential = _build_credential(cfg)

    # 1. List VMs
    logger.info("Listing Azure VMs (sub=%s, rg=%s)…", sub_id, rg or "ALL")
    vms = _list_vms(credential, sub_id, rg)
    if not vms:
        raise AzureFetchError(
            f"No VMs found in subscription {sub_id}"
            + (f" / resource group {rg}" if rg else "")
            + ". Check SPN permissions (Monitoring Reader required)."
        )
    logger.info("Found %d VMs — querying metrics (last %dh)…", len(vms), hours_back)

    # 2. Query metrics
    resource_ids = [v["resource_id"] for v in vms]
    metrics_map  = _query_metrics(credential, resource_ids, hours_back)

    # 3. Build server records
    servers: List[Dict[str, Any]] = []
    for vm in vms:
        rid  = vm["resource_id"]
        name = vm["name"]
        m    = metrics_map.get(rid, {})

        cpu_pct = round(m.get("Percentage CPU", 0.0), 2)

        # Memory: Azure gives *available* bytes; compute used%
        avail_bytes = m.get("Available Memory Bytes")
        if avail_bytes is not None:
            total_bytes = _vm_total_memory_bytes(credential, sub_id, vm["vm_size"])
            if total_bytes and total_bytes > 0:
                used_pct = max(0.0, min(100.0, (1.0 - avail_bytes / total_bytes) * 100.0))
                mem_pct  = round(used_pct, 2)
            else:
                # Can't compute % without total — estimate conservatively
                mem_pct = 0.0
        else:
            mem_pct = 0.0

        disk_pct = round(m.get("OS Disk Used Bytes Percentage", 0.0), 2)

        servers.append({
            "host":          name,
            "server":        name,
            "type":          _infer_server_type(name),
            # Keys expected by resource_parser._calculate_host_health
            "cpu_used":      cpu_pct,
            "mem_used":      mem_pct,
            "disk_used_max": disk_pct,
            # Explicit pct fields for resource_calculator
            "cpu_pct":       cpu_pct,
            "mem_pct":       mem_pct,
            "disk_pct":      disk_pct,
            # Metadata
            "location":      vm["location"],
            "vm_size":       vm["vm_size"],
            "resource_group":vm["rg"],
            "source":        "azure_monitor",
            "hours_back":    hours_back,
        })

    logger.info("Azure fetch complete — %d server records returned.", len(servers))
    return servers
