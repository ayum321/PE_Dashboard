"""
PE Narrative API — produces the structured "Completed the PE Review" report
across four sections (Data Volume, Batch & SLA, Infrastructure, UAT) with
prose + tabular evidence. The LLM (NIM → Gemini cascade) fills sections from
real data; missing data shows as 'NA'.

POST /api/pe-narrative
  Body: {batch, resource, sla_matrix, sla_intel, sow_compare, benchmark,
         red_flags, customer_name}
  Returns:
    {
      "verdict": "APPROVED" | "CONDITIONAL" | "BLOCKED",
      "summary": "<1-paragraph executive summary>",
      "sections": [
        {"id": "data_volume",      "title": "...", "prose": "...",
         "table": {"headers": [...], "rows": [[...]]}},
        ...
      ],
      "model": "nvidia:openai/gpt-oss-120b" | "gemini:..." | "deterministic",
      "customer": "..."
    }
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict

log = logging.getLogger("pe_dashboard.pe_narrative")

router = APIRouter()


class PeNarrativeRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    batch:         Optional[Dict[str, Any]] = None
    resource:      Optional[Dict[str, Any]] = None
    sla_matrix:    Optional[Dict[str, Any]] = None
    sla_intel:     Optional[Dict[str, Any]] = None
    sow_compare:   Optional[Dict[str, Any]] = None
    benchmark:     Optional[Dict[str, Any]] = None
    red_flags:     Optional[Dict[str, Any]] = None
    findings:      Optional[Dict[str, Any]] = None
    customer_name: Optional[str]            = None


_SECTIONS = [
    {
        "id":    "data_volume",
        "title": "Data Volume Analysis",
        "guide": (
            "Compare SOW-promised volumes (DFU, SKU, transactions, jobs) "
            "vs actual measured volumes. Compute utilization % and headroom. "
            "If no SOW data is loaded, output a single-row table with NA values "
            "and explain in prose."
        ),
        "default_table": {
            "headers": ["Dimension", "SOW", "Actual", "Utilization"],
            "rows":    [["NA", "NA", "NA", "NA"]],
        },
    },
    {
        "id":    "batch_sla",
        "title": "Batch Execution & SLA Compliance",
        "guide": (
            "Summarise total runs, SLA window, longest job runtime + buffer, "
            "weekly batches, success rate, failure breakdown. Pull worst jobs "
            "from top_breaches. If batch data is empty, mark fields NA."
        ),
        "default_table": {
            "headers": ["Workflow", "Max Runtime", "SLA Window", "Buffer"],
            "rows":    [["NA", "NA", "NA", "NA"]],
        },
    },
    {
        "id":    "infrastructure",
        "title": "Infrastructure Utilization & Resource Health",
        "guide": (
            "Average + peak CPU / memory / disk per server role "
            "(application, database, batch). Highlight any host >75% utilization. "
            "If resource data is empty, mark fields NA."
        ),
        "default_table": {
            "headers": ["Resource Type", "Avg Utilization", "Peak Utilization"],
            "rows":    [["NA", "NA", "NA"]],
        },
    },
    {
        "id":    "uat",
        "title": "User Acceptance Testing (UAT) Validation",
        "guide": (
            "If UAT artefacts are present in the digest (look in red_flags, "
            "benchmark, or findings for 'UAT' / 'test_cases'), summarise pass "
            "rate per category. If no UAT data exists, the table should show "
            "'NA — UAT artefacts not loaded' and prose must say UAT data is "
            "not available in this audit run."
        ),
        "default_table": {
            "headers": ["Test Category", "Test Cases"],
            "rows":    [["NA — UAT artefacts not loaded", "NA"]],
        },
    },
]


def _digest(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Compact context — reuses fields the AI needs to fill all 4 sections."""
    out: Dict[str, Any] = {}
    b = payload.get("batch") or {}
    if b:
        out["batch"] = {
            "kpis":         b.get("kpis"),
            "top_jobs":     (b.get("top_jobs") or [])[:10],
            "top_breaches": (b.get("top_breaches") or [])[:10],
            "sub_stats":    (b.get("sub_stats") or [])[:8],
            "data_coverage": b.get("data_coverage"),
        }
    r = payload.get("resource") or {}
    if r:
        srv = r.get("servers") or []
        out["resource"] = {
            "kpis": r.get("kpis"),
            # Use the actual field names from ResourceServer:
            # type (not role), cpu_pct / mem_pct (snapshot values — no time-series in PDF reports)
            "servers": [
                {k: s.get(k) for k in (
                    "host", "type", "cpu_pct", "mem_pct",
                    "disk_pct", "status", "dual_pressure", "agg_trap",
                ) if s.get(k) is not None}
                for s in srv[:15]
            ],
        }
    si = payload.get("sla_intel") or {}
    if si:
        out["sla_intel"] = {
            "ceilings": si.get("ceilings"),
            "valid_rows": si.get("valid_rows"),
            "contracts": [
                {k: c.get(k) for k in (
                    "batch_name", "sla_window_hrs", "actual_window_hrs",
                    "buffer_hrs", "buffer_pct", "health_status",
                ) if c.get(k) is not None}
                for c in (si.get("contracts") or [])[:20]
            ],
        }
    sm = payload.get("sla_matrix") or {}
    if sm:
        out["sla_matrix"] = {
            "kpis":     sm.get("kpis"),
            "outliers": (sm.get("outliers") or [])[:8],
        }
    sw = payload.get("sow_compare") or {}
    if sw:
        out["sow_compare"] = sw
    bm = payload.get("benchmark") or {}
    if bm:
        out["benchmark"] = {"summary": bm.get("summary")}
    rf = payload.get("red_flags") or {}
    if rf:
        out["red_flags"] = {"summary": rf.get("summary")}
    return out


def _deterministic_fallback(digest: Dict[str, Any], customer: str) -> Dict[str, Any]:
    """Build the 4-section narrative without an LLM — uses real data where
    present, 'NA' everywhere else. Always returns a complete payload so the
    frontend can render even when the LLM is unreachable."""
    sections: List[Dict[str, Any]] = []

    # ── 1. Data Volume ──
    sw = digest.get("sow_compare") or {}
    dv_rows: List[List[str]] = []
    if sw and isinstance(sw, dict):
        for dim, vals in sw.items():
            if not isinstance(vals, dict):
                continue
            sow_v = vals.get("sow") or vals.get("promised") or "NA"
            act_v = vals.get("actual") or vals.get("measured") or "NA"
            util  = vals.get("utilization") or vals.get("util_pct") or "NA"
            dv_rows.append([str(dim), str(sow_v), str(act_v),
                            f"{util}%" if isinstance(util, (int, float)) else str(util)])
    if not dv_rows:
        dv_rows = [["NA", "NA", "NA", "NA"]]
    sections.append({
        "id": "data_volume", "title": "Data Volume Analysis",
        "prose": ("SOW vs actual volume comparison data is not loaded for this audit run. "
                  "Upload SOW comparison artefacts to see DFU/SKU/transaction utilization."
                  if dv_rows == [["NA", "NA", "NA", "NA"]]
                  else f"Reviewed measured workload volumes across {len(dv_rows)} dimensions."),
        "table": {"headers": ["Dimension", "SOW", "Actual", "Utilization"], "rows": dv_rows},
    })

    # ── 2. Batch & SLA ──
    b = digest.get("batch") or {}
    bk = b.get("kpis") or {}
    si = digest.get("sla_intel") or {}
    sla_rows: List[List[str]] = []
    for c in (si.get("contracts") or [])[:6]:
        sla_rows.append([
            str(c.get("batch_name", "NA")),
            f"{c.get('actual_window_hrs', 'NA')} hrs",
            f"{c.get('sla_window_hrs', 'NA')} hrs",
            f"{c.get('buffer_hrs', 'NA')} hrs",
        ])
    if not sla_rows and bk:
        # fall back to top_breaches
        for j in (b.get("top_breaches") or [])[:5]:
            sla_rows.append([
                str(j.get("Job_Name", j.get("job", "NA"))),
                f"{j.get('peak_hrs', j.get('elapsed_hrs', 'NA'))} hrs",
                f"{bk.get('daily_limit_hrs', 'NA')} hrs",
                f"{j.get('buffer_hrs', 'NA')} hrs",
            ])
    if not sla_rows:
        sla_rows = [["NA", "NA", "NA", "NA"]]

    total_jobs = bk.get("total_jobs", "NA")
    compliance = bk.get("compliance_pct", "NA")
    fails      = bk.get("jobs_breach", bk.get("failed_jobs", "NA"))
    prose_b = (
        f"Batch execution analysis covers {total_jobs} job runs. Overall SLA "
        f"compliance: {compliance}% with {fails} breaches recorded."
        if total_jobs != "NA"
        else "Batch execution data is not loaded — upload Ctrl-M / batch CSVs for SLA compliance analysis."
    )
    sections.append({
        "id": "batch_sla", "title": "Batch Execution & SLA Compliance",
        "prose": prose_b,
        "table": {"headers": ["Workflow", "Max Runtime", "SLA Window", "Buffer"], "rows": sla_rows},
    })

    # ── 3. Infrastructure ──
    r = digest.get("resource") or {}
    rk = r.get("kpis") or {}
    inf_rows: List[List[str]] = []
    servers = r.get("servers") or []
    # Group servers by type (APP / DB / SRE) — field is 'type', not 'role'
    type_buckets: Dict[str, List[Dict[str, Any]]] = {}
    for s in servers:
        stype = (s.get("type") or "APP").upper()
        type_buckets.setdefault(stype, []).append(s)
    for stype, items in type_buckets.items():
        if not items:
            continue
        # cpu_pct / mem_pct are the snapshot utilisation values from the resource report
        cpu_vals = [float(s.get("cpu_pct") or 0) for s in items]
        mem_vals = [float(s.get("mem_pct") or 0) for s in items]
        cpu_avg = sum(cpu_vals) / len(cpu_vals)
        cpu_peak = max(cpu_vals, default=0)
        mem_avg = sum(mem_vals) / len(mem_vals)
        mem_peak = max(mem_vals, default=0)
        label = {"APP": "Application", "DB": "Database", "SRE": "SRE/Batch"}.get(stype, stype)
        inf_rows.append([f"{label} CPU",    f"{cpu_avg:.1f}%",  f"{cpu_peak:.1f}%"])
        inf_rows.append([f"{label} Memory",  f"{mem_avg:.1f}%",  f"{mem_peak:.1f}%"])
    if not inf_rows:
        inf_rows = [["NA", "NA", "NA"]]

    # Build a prose statement with real fleet averages
    n_crit = int(rk.get("n_critical") or 0)
    n_warn = int(rk.get("n_warning") or 0)
    fleet_avg_cpu = float(rk.get("avg_cpu") or 0)
    fleet_avg_mem = float(rk.get("avg_mem") or 0)
    fleet_grade   = rk.get("fleet_grade") or "N/A"
    fleet_score   = float(rk.get("fleet_score") or 0)
    n_dual        = int(rk.get("n_dual_pressure") or 0)
    cpu_thresh    = 75.0
    hot_hosts     = [s.get("host") or s.get("server") or "?"
                     for s in servers if float(s.get("cpu_pct") or 0) > cpu_thresh]
    if servers:
        prose_i = (
            f"Average CPU utilization across the fleet is {fleet_avg_cpu:.1f}% and memory is "
            f"{fleet_avg_mem:.1f}%, with "
            + (f"{len(hot_hosts)} host(s) exceeding the {cpu_thresh:.0f}% utilization threshold "
               f"({', '.join(hot_hosts[:3])})."
               if hot_hosts else f"no host exceeding the {cpu_thresh:.0f}% utilization threshold.")
            + f" The fleet has {n_crit} critical and {n_warn} warning server(s)."
            + (f" {n_dual} host(s) show simultaneous CPU + memory pressure."
               if n_dual else "")
            + f" Fleet grade is {fleet_grade} with a score of {fleet_score:.1f}."
        )
    else:
        prose_i = "Resource utilization data is not loaded — upload resource report (DOCX/PDF) for infrastructure health."
    sections.append({
        "id": "infrastructure", "title": "Infrastructure Utilization & Resource Health",
        "prose": prose_i,
        "table": {"headers": ["Resource Type", "Avg Utilization", "Peak Utilization"], "rows": inf_rows},
    })

    # ── 4. UAT ──
    sections.append({
        "id": "uat", "title": "User Acceptance Testing (UAT) Validation",
        "prose": "UAT validation artefacts were not provided in this audit run. "
                 "Upload UAT test results for sign-off coverage analysis.",
        "table": {"headers": ["Test Category", "Test Cases"],
                  "rows": [["NA — UAT artefacts not loaded", "NA"]]},
    })

    # ── Verdict heuristic (cross-validated with smart findings if available) ──
    verdict = "CONDITIONAL"
    try:
        crit = int((digest.get("red_flags") or {}).get("summary", {}).get("critical") or 0)
        if isinstance(compliance, (int, float)) and compliance >= 98 and crit == 0:
            verdict = "APPROVED"
        elif crit > 0 or (isinstance(compliance, (int, float)) and compliance < 90):
            verdict = "BLOCKED"
    except Exception:
        pass

    # Cross-check with smart_findings verdict from session cache
    try:
        from services import session_cache as _sc
        smart_data = _sc.get("last_smart_findings") or {}
        smart_verdict = (smart_data.get("verdict") or {}).get("decision", "")
        if smart_verdict:
            _vrank = {"BLOCKED": 2, "CONDITIONAL": 1, "APPROVED": 0, "PENDING": -1}
            # Use the stricter of the two
            if _vrank.get(smart_verdict, -1) > _vrank.get(verdict, -1):
                verdict = smart_verdict
    except Exception:
        pass

    return {
        "verdict": verdict,
        "summary": (
            f"Completed the PE Review for {customer or 'the account'}. "
            f"Based on the available evidence, the review verdict is {verdict}. "
            "Sections below show the captured analysis; missing pillars are marked NA."
        ),
        "sections": sections,
        "model":    "deterministic",
        "customer": customer,
    }


def _ai_prompt(digest: Dict[str, Any], customer: str) -> str:
    schema_hint = (
        '{"verdict":"APPROVED|CONDITIONAL|BLOCKED",'
        '"summary":"<3-5 sentence executive paragraph that mirrors the '
        '\\"Completed the PE Review\\" tone>",'
        '"sections":[{'
        '"id":"data_volume|batch_sla|infrastructure|uat",'
        '"title":"<exact section title>",'
        '"prose":"<2-4 sentence evidence-led narrative for this section>",'
        '"table":{"headers":["..."],"rows":[["..."]]}'
        "}]}"
    )
    section_briefs = "\n".join(
        f"- {s['title']} (id={s['id']}): {s['guide']}"
        for s in _SECTIONS
    )
    return (
        f"CUSTOMER: {customer or '(unspecified)'}\n\n"
        "You are a Senior PE consultant writing the closing review.\n"
        "Produce EXACTLY 4 sections in the order below. Use the customer's real "
        "numbers from DATA. Where a section's source data is empty, set the table "
        "rows to NA (literal string 'NA') and explicitly say in the prose that the "
        "data was not loaded. Keep prose evidence-led: quote real numbers, "
        "hostnames, batch names, and percentages. No filler.\n\n"
        f"SECTIONS:\n{section_briefs}\n\n"
        f"OUTPUT JSON SHAPE (strict):\n{schema_hint}\n\n"
        f"DATA:\n{json.dumps(digest, default=str)[:14000]}"
    )


_SYSTEM = (
    "You are a Senior Performance Engineering consultant authoring a final "
    "review report. Output STRICT JSON only — no markdown, no prose outside "
    "the JSON. Always include all 4 sections in fixed order: data_volume, "
    "batch_sla, infrastructure, uat. When the supplied data is empty for a "
    "section, the table rows MUST contain 'NA' and the prose must state that "
    "the data was not loaded for this audit run."
)


def _validate_and_merge(ai_payload: Any, fallback: Dict[str, Any],
                        digest: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Ensure the AI returned all 4 sections; backfill missing ones from the
    deterministic fallback so the frontend always has a complete shape.
    Also cross-validates the AI verdict against actual KPI data."""
    if not isinstance(ai_payload, dict):
        return fallback
    out = dict(fallback)

    # ── Verdict reconciliation against real KPIs ─────────────────
    ai_verdict = ""
    if isinstance(ai_payload.get("verdict"), str):
        ai_verdict = ai_payload["verdict"].upper()
    det_verdict = fallback.get("verdict", "CONDITIONAL")

    # Cross-validate: if real data shows criticals/breaches but LLM says APPROVED
    # → force the stricter verdict
    if digest:
        batch_kpis = (digest.get("batch") or {}).get("kpis") or {}
        rf_summary = (digest.get("red_flags") or {}).get("summary") or {}
        resource_kpis = (digest.get("resource") or {}).get("kpis") or {}

        actual_breaches = int(batch_kpis.get("jobs_breach") or 0)
        compliance = batch_kpis.get("compliance_pct")
        rf_critical = int(rf_summary.get("critical") or rf_summary.get("CRITICAL") or 0)
        n_crit_servers = int((resource_kpis or {}).get("n_critical") or 0)

        has_blockers = (
            actual_breaches > 0
            or rf_critical > 0
            or n_crit_servers >= 2
            or (compliance is not None and compliance < 85)
        )
        has_warnings = (
            (compliance is not None and compliance < 95)
            or int((resource_kpis or {}).get("n_warning") or 0) > 0
        )

        # Force verdict based on evidence
        if has_blockers:
            kpi_verdict = "BLOCKED"
        elif has_warnings:
            kpi_verdict = "CONDITIONAL"
        else:
            kpi_verdict = "APPROVED"

        # Rank: BLOCKED > CONDITIONAL > APPROVED
        _vrank = {"BLOCKED": 2, "CONDITIONAL": 1, "APPROVED": 0}
        # Use the strictest of AI verdict, deterministic verdict, and KPI verdict
        choices = [(ai_verdict, _vrank.get(ai_verdict, -1)),
                   (det_verdict, _vrank.get(det_verdict, -1)),
                   (kpi_verdict, _vrank.get(kpi_verdict, -1))]
        final_verdict = max(choices, key=lambda x: x[1])[0]

        if final_verdict and final_verdict != ai_verdict and ai_verdict:
            log.info("pe_narrative: verdict override AI=%s → %s (KPI evidence)",
                     ai_verdict, final_verdict)
        out["verdict"] = final_verdict or det_verdict
    else:
        # No digest for validation — take stricter of AI and deterministic
        _vrank = {"BLOCKED": 2, "CONDITIONAL": 1, "APPROVED": 0}
        if _vrank.get(ai_verdict, -1) >= _vrank.get(det_verdict, -1):
            out["verdict"] = ai_verdict or det_verdict
        else:
            out["verdict"] = det_verdict

    if isinstance(ai_payload.get("summary"), str) and ai_payload["summary"].strip():
        out["summary"] = ai_payload["summary"].strip()

    ai_secs = ai_payload.get("sections") or []
    by_id = {s.get("id"): s for s in ai_secs if isinstance(s, dict)}
    merged_sections: List[Dict[str, Any]] = []
    for proto in _SECTIONS:
        sid = proto["id"]
        ai_sec = by_id.get(sid)
        if ai_sec and isinstance(ai_sec, dict):
            tbl = ai_sec.get("table") or {}
            headers = tbl.get("headers") or proto["default_table"]["headers"]
            rows    = tbl.get("rows")    or proto["default_table"]["rows"]

            # ── Per-section data validation: prefer deterministic tables ──
            # If the deterministic fallback has real data (not NA) for this
            # section, use the fallback table (real numbers) but keep the
            # AI prose (better readability).
            fb_sec = next((s for s in fallback["sections"] if s["id"] == sid), None)
            if fb_sec:
                fb_rows = (fb_sec.get("table") or {}).get("rows") or []
                fb_has_data = fb_rows and not all(
                    all(str(c).strip().upper() in ("NA", "") for c in row)
                    for row in fb_rows
                )
                ai_has_data = rows and not all(
                    all(str(c).strip().upper() in ("NA", "") for c in row)
                    for row in rows
                )
                # Use fallback table with real data; keep AI prose
                if fb_has_data:
                    headers = (fb_sec.get("table") or {}).get("headers") or headers
                    rows = fb_rows

            merged_sections.append({
                "id":    sid,
                "title": ai_sec.get("title") or proto["title"],
                "prose": ai_sec.get("prose") or (fb_sec.get("prose") if fb_sec else ""),
                "table": {"headers": headers, "rows": rows},
            })
        else:
            # use fallback section
            fb_sec = next((s for s in fallback["sections"] if s["id"] == sid), None)
            if fb_sec:
                merged_sections.append(fb_sec)
    out["sections"] = merged_sections
    return out


@router.post(
    "/pe-narrative",
    summary="Structured 4-section PE review narrative (Data Volume / Batch SLA / Infrastructure / UAT)",
)
async def pe_narrative(body: PeNarrativeRequest) -> Dict[str, Any]:
    """Generate the 'Completed the PE Review' structured report.

    Calls NIM → Gemini cascade for the AI-authored version; falls back to a
    deterministic template (with NA placeholders) if every model fails or
    times out. Always returns a complete 4-section payload.
    """
    from services import session_cache
    from services.ai_engine import chat_json, is_ready

    payload = body.model_dump(exclude_none=True)

    # Hydrate missing pillars from session cache (same pattern as /ai-findings)
    payload.setdefault("batch",      session_cache.get("last_batch")      or {})
    payload.setdefault("resource",   session_cache.get("last_resource")   or {})
    payload.setdefault("sla_matrix", session_cache.get("last_sla_matrix") or {})
    payload.setdefault("red_flags",  session_cache.get("last_red_flags")  or {})
    if not payload.get("sla_intel"):
        from services import config_store
        payload["sla_intel"] = config_store.get("_sla_intelligence") or {}

    customer = payload.get("customer_name") or ""
    digest = _digest(payload)
    fallback = _deterministic_fallback(digest, customer)

    # No AI keys → return deterministic immediately
    ready = is_ready()
    if not (ready.get("nvidia_key") or ready.get("gemini_key")):
        return fallback

    try:
        prompt = _ai_prompt(digest, customer)
        result, model = await asyncio.wait_for(
            asyncio.to_thread(
                chat_json, prompt,
                system=_SYSTEM,
                max_tokens=2400, temperature=0.3,
            ),
            timeout=35.0,
        )
        merged = _validate_and_merge(result, fallback, digest=digest)
        merged["model"] = model
        merged["customer"] = customer
        return merged
    except asyncio.TimeoutError:
        log.info("pe_narrative: LLM timeout — returning deterministic fallback")
        return fallback
    except Exception as exc:  # noqa: BLE001
        log.info("pe_narrative: LLM failed (%s) — returning deterministic fallback", exc)
        return fallback
