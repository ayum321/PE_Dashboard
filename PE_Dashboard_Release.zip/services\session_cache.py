"""
session_cache — in-memory, process-local cache of the last-uploaded payloads
so cross-pillar engines (SLA matrix adaptive baselines, correlation, etc.)
can reach for them without an extra HTTP round-trip.

This is intentionally NOT persisted: a server restart should clear the
state so stale resource snapshots don't leak into a fresh audit.

Public API:
    set(key, value) -> None
    get(key, default=None) -> any
    clear() -> None
"""
from __future__ import annotations

import copy
import threading
from typing import Any

_lock = threading.Lock()
_state: dict[str, Any] = {}


def set(key: str, value: Any) -> None:  # noqa: A001 - mirror dict-style API
    with _lock:
        _state[key] = value


def get(key: str, default: Any = None) -> Any:
    """Return a shallow copy of dicts/lists to prevent cross-thread mutation.

    Callers that need a stable snapshot should not mutate the returned value.
    Deep-copy is intentionally avoided for performance — nested structures
    are immutable in practice (replaced wholesale on each upload).
    """
    with _lock:
        val = _state.get(key, default)
    if isinstance(val, dict):
        return dict(val)
    if isinstance(val, list):
        return list(val)
    return val


def clear() -> None:
    with _lock:
        _state.clear()
